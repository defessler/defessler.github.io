# Keeping the agents in sync

M365 agents can't learn. Their instructions are a static 8,000-character
string you paste into Agent Builder. Improving an agent means editing that
string.

So **drift** is what breaks. You paste a block, then edit the repo file three
weeks later. The agent everyone uses no longer matches git. Nothing tells
you until someone quotes an answer you don't recognise. This tooling catches
that with two commands and a probe set.

## Check

```
python scripts/m365-agents.py status
```

Illustrative output. Run `status` for the real numbers.

```
AGENT                 CHARS  FREE  DESC  DEPLOY
ue5-engineer           NNNN  NNNN   NNN  in sync (YYYY-MM-DD)
doc-writer             NNNN  NNNN   NNN  DRIFT (repo aaaaaaaaaaaa, deployed bbbbbbbbbbbb on YYYY-MM-DD)
build-crash-doctor     NNNN   NNN   NNN  never stamped

  1 agent(s) under 1000 free characters:
    build-crash-doctor: NNN left. Trim it, or split a concern into its own agent.

  2 agent(s) differ from what is pasted in M365.
  Paste the block, then: python scripts/m365-agents.py deployed <agent>
```

`refresh.sh` prints this without being asked. It **reports rather than fails**, since
"never stamped" and "DRIFT" are normal between editing a block and pasting
it. It's there to catch a paste forgotten for a month. An agent under 1,000
free characters also gets a warn-only line. `status` **does** fail on an
over-cap field, because Agent Builder rejects that paste outright.

## Change

1. Run the probe set and note the answers. This is the *before*.
   ```
   python scripts/m365-agents.py probe ue5-engineer
   ```
2. Edit the instruction block in the agent's file directly.
3. `git diff` to read what changed.
4. Copy the block, then paste it into Agent Builder and save.
   ```
   python scripts/m365-agents.py copy ue5-engineer
   ```
5. Stamp it:
   ```
   python scripts/m365-agents.py deployed ue5-engineer
   ```
6. Re-run the probe set. If an answer got worse, `git checkout` the previous
   block and paste that back.

Steps 1 and 6 are the only ones that take discipline. They separate "I
changed the prompt" from "the agent got better".

## Why the deploy stamp

It's a hash of the instruction block plus the date you pasted it. It answers
one question: **is the agent people are using the same as the one in git?**

Trailing whitespace is stripped before hashing. A browser textarea can add
or drop it on a paste. A stamp that flips on invisible characters teaches you
to ignore the stamp.

## Why there's no lesson ledger

A per-agent lessons table feeding a managed block is the obvious design. It
needs a habit, though. A habit nobody keeps is worse than no system. It
leaves a half-filled file that the next person trusts as a record.

Editing the instructions directly takes the same ten seconds and lands where
the change takes effect. **Git already gives you history, diff, blame and
rollback**, which is most of what a ledger was for. If a lesson is worth
keeping, it's worth being an instruction.

## What this can't do

Nothing here makes the agent smarter on its own.
[Can Agents Learn?](05-self-improvement-loop.md) covers why this platform
can't do that at any effort, and what the adjacent features do.
