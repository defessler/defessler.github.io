<!-- Produced 2026-08-12 by an 18-agent primary-source sweep of every
persistence surface Microsoft documents, with an adversarial refuter on each
claim of self-modification. 55 surfaces assessed, 7 claims refuted — every
one of them reclassified DOWNWARD from "the agent learns" to something
weaker. Sources are learn.microsoft.com only. -->

# Can your agents learn?

Note: section 3's ledger wasn't adopted. Drift detection and probe sets shipped instead (see `06-keeping-them-in-sync.md`). The platform findings hold either way.

## 1. The direct answer

**No.** No Microsoft 365 Copilot agent modifies its own definition on any documented surface, Agent Builder and Copilot Studio included.

**Something adjacent exists.** Copilot Studio's Memory component is a per-user store the runtime writes across sessions, without touching the agent's Instructions, Skills, Knowledge, or Tools.

**Your three agents are frozen.** UE5 Engineer, Studio Doc Writer, and Build & Crash Doctor are identical on every turn for everyone. The v1.8 declarative agent manifest never mentions memory or persistence. Only a human editing and republishing improves them.

---

## 2. Every persistence surface, ranked by usefulness to this goal

| Surface | What persists | Who writes it | Reaches your three agents? | Status |
|---|---|---|---|---|
| **SharePoint / OneDrive knowledge files** | File contents | Human, or a Copilot Studio agent via connector | **Yes** | GA |
| **SharePoint list as Knowledge** | List rows, a true append | Human | **Yes**, 1 list per agent, 20,000 rows / 50 MB | GA since 2026-07-15 |
| **Instructions field** | One string, 8,000 chars | Human, then republish | **It is the agent** | GA |
| **OneNote pages as Knowledge** | Page content | Human | **Yes**, individual pages via file picker. No licence needed | GA |
| **Copilot Studio Memory component** | Per-user, per-agent preference and context files, 28-day inactivity expiry. Maker can't read it | Runtime, plus the user | **No.** GitHub Copilot harness only | Production-ready preview |
| **Cowork custom skills** | Up to 50 `SKILL.md` files in `/Documents/Cowork/skills/` | Human | **No.** Cowork only | GA, usage-billed |
| **Saved memories** | Facts in the user's mailbox (`IPM.Contact` under `CopilotMemory`), no expiry | Copilot (with confirmation) or the user | **No** | Preview |
| **Custom instructions** | One user's standing instructions | The user | **No** | Preview. Not eDiscoverable |
| **Details inferred from chat history** | A derived profile of one user | The Copilot service | **No** | Preview |
| **Work IQ Workspaces** | Per-task artefacts for long-running workflows | The calling agent | **No.** Developer API | Preview / undated |
| **Copilot Studio created files** | Files made in a turn, for **the conversation only**. 10 MB each, deleted after 28 idle days | The agent | **No** | Preview |
| **Copilot Pages / Notebooks** | One user's `.page` / `.pod` files | Human | **No.** `.page` isn't a supported index content type | GA |
| **Global variables (standard harness)** | Nothing across sessions | Runtime | **No** | GA |
| **Work IQ button in Chat** | **Nothing.** It's a grounding-scope switch | Nobody | **No** | GA, licence-gated |

The build-agents page's **"20 knowledge sources"** is the embedded-upload cap, not a total. Per-type caps on `agent-builder-add-knowledge` are 4 public URLs, 100 SharePoint files/folders/sites, 50 OneDrive files, 1 SharePoint list, 5 Teams chat URLs, and 20 device-uploaded files. Add a list by its own URL, since selecting its site doesn't include it.

Work IQ's "persistent memory of how your teams work" comes from a `page_type: marketing` page with no technical backing. Don't plan around it.

---

## 3. The loop that actually works

**The agent drafts each update. A human commits it.**

### Setup, once, about an hour

**a. One list per agent.** In the agents' SharePoint site, create `UE5 Engineer Lessons`, `Doc Writer Corrections`, and `Crash Signatures`. Columns: Signature, Symptom, Root cause, Fix, First seen, Times seen, Status (Candidate / Stable / Graduated / Retired), Evidence. Attach each list to its agent by its URL.

**b. Reserve a managed block at the bottom of each agent's Instructions.**

```
## Lessons (managed block, regenerated weekly, do not hand-edit)
<!-- budget 1200 chars. Evict the oldest Stable entry when full. -->
```

Without the eviction rule the block grows until a republish fails.

**c. Put the drafting contract above the block**, about 400 characters:

```
When asked to draft a ledger entry, output exactly one row:
Signature | Symptom | Root cause | Fix | Confidence 1-3 | Evidence
Evidence must quote the user's actual correction from this
conversation. If you cannot cite one, say so and stop.
```

The last line stops the agent inventing a lesson to be helpful.

**d. Add two starter prompts** (a built-in Agent Builder field) to each agent:
- *"What did you get wrong here? Draft a ledger entry."*
- *"Review the lessons list and propose this week's managed block."*

### In the moment, roughly 30 seconds

When you correct an agent, click the first starter prompt and paste its row into the list as Status = Candidate. This step decides whether any of this happens.

### Friday, roughly 15 minutes, one named owner

1. Promote anything seen **twice or more** to Stable, the threshold `smartplan/SKILL.md` uses to stop self-repair.
2. Run the probe set (five fixed questions per agent, kept in the list) and record the answers.
3. Click the second starter prompt to get a replacement managed block, under budget, naming what it evicted.
4. Read that diff, paste the block into Instructions, and republish.
5. Re-run the probe set. If anything regressed, restore the previous block from a `Block History` list.

### Can it really answer "what did I get wrong this week"?

Only through the list. The agent can't see last week's conversations, only the rows they left.

### What makes it cheap enough to actually happen

- Instructions are one string. A commit is a plain replace.
- Skipping a week loses nothing. Candidate rows already improve answers, since the list is a knowledge source.
- An edit to an **already-indexed** document is indexed immediately. A **new** document in a site two or more people can reach is indexed **daily**. Rewrite one ledger in place.

Note: new Agent Builder uploads take "up to several minutes." List-row freshness is undocumented. Copilot caches answers within a session, even across tool calls. Test in a fresh chat. For immediate effect, republish Instructions.

---

## 4. Why human-gated is arguably right here

The `smartplan` family gates its own changes on a human. Three of its reasons transfer to a shared studio agent.

**n=1 is not a lesson.** One bad afternoon isn't a pattern, which is why the threshold is two.

**The blast radius is shared.** A wrong lesson becomes everyone's default answer, including at 2am for someone who wasn't in that conversation.

**The changelog is most of the value.** Without a record of what changed and when, you can't attribute a regression.

**The gate you'd design and the gate Microsoft ships aren't the same gate.** A good gate is a diff, a reviewer, a changelog, and a rollback. Agent Builder has *no write path at all*. You rebuild the ledger, changelog, and rollback by hand in SharePoint.

The one surface that *does* write autonomously is gated **worse**. Copilot Studio Memory is per-user and maker-blind, with no Purview audit log entries, retention policies, or labels. Admins can't restrict what goes in.

Rebuilding the three agents in Copilot Studio on the GitHub Copilot harness gets you Memory, along with Copilot Credits billed from the start of building, preview terms, per-user isolation, a 28-day inactivity wipe, and no Memory in Teams channels. For studio-wide learning, that's a bad trade.

---

## 5. What would change the answer

| Signal | Where to watch | What it would change |
|---|---|---|
| A `memory` or `persistence` key appears in the declarative agent manifest | `declarative-agent-manifest-1.9` and later. 1.8 (2026-08-10) has none | Agent Builder agents get state |
| "Skills and memory" flips from *Not a focus* to *Yes* for the standard or Copilot chat harness | `harnesses-overview` | Memory reaches agents that extend M365 Copilot |
| A shared or team-scoped Memory, or maker visibility into it | `agents-experience/memory-overview` | Per-user personalization becomes institutional learning |
| A first-party **write** capability targeting a knowledge store | The capabilities array, where v1.8 added `EmailActions` and `MeetingActions` | Automates the paste step. The Instructions gate still holds |
| A documented grounding-freshness SLA for SharePoint knowledge | `knowledge-unstructured-data`, `agent-builder-add-knowledge`, `semantic-index-for-copilot` | A same-session loop becomes designable |
| A **technical** Work IQ page describing a persistent per-team store with a write API | `microsoft-365/copilot/extensibility/work-iq/`, not the `/agents/` marketing hub | Answers this page's question |

Also watch:

- **Governance.** If anyone turns on Copilot Studio Memory, put its section 4 gaps on a risk register first.
- **Frontier isn't a documented gate** for Copilot memory, despite the preview banner linking to it. Memory is documented for Copilot Chat users with and without a Microsoft 365 Copilot licence. Don't plan around Frontier either way.

The personalization and memory page is older (`ms.date 2025-11-18`, updated 2026-05-22). Its preview statuses weren't freshly confirmed.
