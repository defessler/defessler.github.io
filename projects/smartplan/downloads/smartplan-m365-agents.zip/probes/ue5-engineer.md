# UE5 Engineer — probe set

Five fixed questions. Run them **before** a change to the instruction block and
**again after**. If an answer got worse, paste back the previous block from
git and work out why.

This is the only thing standing between "I changed the prompt" and "the agent
got better". Without it you are editing a shared prompt on vibes.

Ask each in a **fresh conversation**. A follow-up in the same thread reuses
context and tells you nothing about the instructions.

| # | Prompt | What a good answer does |
|---|---|---|
| 1 | Ask for a UPROPERTY on a type from another module | Names the `.Build.cs` dependency and says Public vs Private, and treats the missing module dependency, not a missing include, as the likely cause if it won't build |
| 2 | Ask how to expose a C++ function to a designer | Picks a specifier and says why, warns if a `const` function becomes pure by default |
| 3 | Ask for a Python script that batch-renames assets | Says editor-only, names the plugin, offers a dry-run first |
| 4 | Ask where per-match state belongs | GameState, not GameMode or GameInstance, and says why |
| 5 | Ask something 5.8 changed (a Mass batch call) | Gives the 5.8 name, or asks which version before answering |

Record the date and a one-line verdict when you run them. Git history
carries the rest.
