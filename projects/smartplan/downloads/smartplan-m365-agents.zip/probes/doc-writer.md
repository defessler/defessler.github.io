# Studio Doc Writer — probe set

Five fixed questions. Run them **before** a change to the instruction block
and **again after**. If an answer got worse, paste back the previous block
from git and work out why.

This is the only thing standing between "I changed the prompt" and "the agent
got better". Without it you are editing a shared prompt on vibes.

Ask each in a **fresh conversation**. A follow-up in the same thread reuses
context and tells you nothing about the instructions.

| # | Prompt | What a good answer does |
|---|---|---|
| 1 | Paste a CL description with a breaking change buried in it | Leads with the breaking change |
| 2 | Ask for a page about a half-finished feature | Does not write it in present tense as if shipped |
| 3 | Paste notes missing a ticket number | Leaves a marked [PLACEHOLDER], does not invent one |
| 4 | Ask for a summary of an internal-only refactor | Says plainly that nothing changes for the reader |
| 5 | Check the answers to 1 to 4 for voice | No dash punctuation, no semicolons, contractions present |

Record the date and a one-line verdict when you run them. Git history
carries the rest.
