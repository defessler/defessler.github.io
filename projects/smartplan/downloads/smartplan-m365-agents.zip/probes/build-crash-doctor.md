# UE5 Build & Crash Doctor probe set

Five fixed questions. Run them **before** a change to the instruction block and
**again after**. If an answer got worse, paste back the previous block from
git and work out why.

This is the only thing standing between "I changed the prompt" and "the agent
got better". Without it you are editing a shared prompt on vibes.

Ask each in a **fresh conversation**. A follow-up in the same thread reuses
context and tells you nothing about the instructions.

| # | Prompt | What a good answer does |
|---|---|---|
| 1 | Paste an unresolved-external for a symbol in another module | Names the missing `.Build.cs` dependency first |
| 2 | Paste a 200-line build log with the real error in the middle | Quotes the middle line, says which lines are cascade |
| 3 | Ask whether a `check()` fires in a Shipping build | Says no by default, names USE_CHECKS_IN_SHIPPING |
| 4 | Paste an access violation at 0x38 | Says null plus member offset, not a plain null deref |
| 5 | Give it a crash it cannot solve from what you pasted | Asks for one specific thing, does not guess a third time |

Record the date and a one-line verdict when you run them. Git history
carries the rest.
