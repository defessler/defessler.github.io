<!-- Produced 2026-08-12 by a 44-agent primary-source sweep with an
adversarial refuter on every claimed reach path. 60 paths assessed, 7 refuted.
Sources are vendor documentation only: learn.microsoft.com, atlassian.com,
and official product docs. -->

# Jira and Confluence in the Copilot era: what actually works behind your firewall

**Decided against:** every Atlassian-published AI surface (all Cloud-only), and every write path from M365 Copilot (none documented).
**Recommended:** a small local MCP server for Claude Code. M365 Copilot stays a Q&A tool.
**Date:** 2026-08-12, from vendor primary sources.

---

## 0. Settle this before you read the table

Server vs Data Center changes two of the four answers. Check the **license string**, not the version number: Jira admin -> Applications -> Versions and licenses, or Confluence admin -> General Configuration -> License Details. Note the version too.

- **Server**: support ended 2024-02-15. No connectors and no patches. The REST API still works.
- **Data Center**: connectors are possible, above version floors higher than you'd guess.

---

## 1. What just died

| Option | Why it's dead |
|---|---|
| **"Jira Cloud for Microsoft Teams" / "Confluence Cloud for Microsoft Teams"** (the two agents in your agent store) | Both need an Atlassian Cloud site. |
| **Atlassian Rovo MCP Server** (`mcp.atlassian.com/v1/mcp/authv2`) | Cloud-only, with no base-URL parameter for your host. |
| **Rovo as a product, running on Data Center** | Cloud-only. Its DC connectors pull content *into* Atlassian's Cloud. |
| **Atlassian's Teamwork Graph DC connectors** | Needs Jira 11.0+ (11.3+ for the current path) or Confluence 9.4+ (10.2+), plus a paid Atlassian Cloud org. It feeds Rovo, not M365 Copilot. |
| **Copilot Studio agent → custom connector → on-premises data gateway, to write to Jira** | Copilot Studio scopes custom connectors to "any publicly available API" and isn't on the gateway's supported-services lists. Unproven at primary source. |
| **A declarative agent API plugin or MCP plugin pointed at your instance** | Microsoft's cloud calls plugin endpoints directly, with no gateway. A firewalled host is unreachable. |
| **Microsoft's "Confluence On-premises" connector, if you're on Server** | The required Marketplace plugin has no Server build. |

---

## 2. Per-job verdict

| Job | Best tool | M365 Copilot involved? | Effort | Who must approve |
|---|---|---|---|---|
| **Perforce CL descriptions** | Claude Code reading the pending changelist through `p4`. Nothing leaves the workstation. | No | Already working | Nobody |
| **Confluence pages** (stakeholder change summaries) | Claude Code + a local MCP server doing `POST /rest/api/content` with your own Personal Access Token | No | Half a day to a day | Nobody if PATs work (see Auth). Otherwise a Confluence admin |
| **Jira issue creation** | Same local server, `POST /rest/api/2/issue` | No | Two hours after the Confluence path | Same as above |
| **Gamedev error triage** | Claude Code for the depot, engine source, and build logs. M365 Copilot for "how does Unreal do X" and Perforce how-to. | Partly, and it already works | Zero | Nobody |

---

## 3. The recommended build

**Build a local MCP server for Claude Code that speaks Jira and Confluence Data Center REST.** The hard part, turning a VCS diff into a stakeholder summary, already exists as a skill family. What's missing is a POST.

### Why this path and not the others

It's the only option that can write. It needs no Atlassian Cloud org, M365 admin action, Windows VM, firewall change, Entra app, or production plugin. A process on an engineer's workstation is already inside the firewall, where `https://jira.internal/rest/api/2/issue` is just a URL.

### What to build

Four tools:

- `confluence_create_page` → `POST {base}/rest/api/content`
- `confluence_update_page` → `PUT {base}/rest/api/content/{id}`
- `jira_create_issue` → `POST {base}/rest/api/2/issue`
- `jira_search` → JQL, for "has this already been filed"

### The five things that will actually cost you time

1. **Confluence storage format, not Markdown.** The body is an XHTML subset. Code blocks need `<ac:structured-macro ac:name="code">`. This conversion is most of the day.
2. **Update is read-modify-write.** A `PUT` must carry `version.number` incremented by exactly one. Fetch, bump, send.
3. **Don't copy Cloud code.** DC uses Jira `/rest/api/2` (plain text or wiki markup in `description`, `username`/`userKey` for users) and Confluence `/rest/api/content`. Cloud uses `/rest/api/3` (Atlassian Document Format, `accountId`) and `/wiki/api/v2/pages`. Most Stack Overflow answers from the last three years are Cloud-shaped.
4. **Base URL includes the context path.** Atlassian's own example is `http://localhost:8080/confluence/rest/api/content/`.
5. **Internal CA.** Set `NODE_EXTRA_CA_CERTS` or `REQUESTS_CA_BUNDLE` for the corporate root rather than disabling verification.

### Auth

Send a Personal Access Token as `Authorization: Bearer <token>`. Each engineer makes their own in their profile. It inherits their permissions and attributes writes to them.

PATs need Jira Core/Software 8.14+, Jira Service Management 4.15+, or Confluence 7.9+. Below that you're on basic auth. A retry loop on a stale password trips Jira's CAPTCHA, which **locks the REST API out entirely** until someone solves it in a browser.

Admins can disable PATs with `-Datlassian.pats.enabled`. Tokens expire (default 365 days, max 10 per user) and can't be reactivated. Plan rotation.

### One Jira gotcha

Don't build field discovery on `createmeta`. Atlassian recommends disabling it on 8.4+ and removed it in Jira 9.0. Hardcode `project`, `summary`, `description`, and `issuetype` per template.

### What this costs

A day and one engineer, with no procurement or IT meetings.

### The build that is genuinely worth considering, and it isn't this one

If the goal becomes "**let the whole studio ask Copilot Chat what's in the wiki**," use Microsoft's GA Copilot connectors for **Jira Data Center** and **Confluence On-premises**. A Windows box inside your network crawls over the LAN and pushes outbound to Graph. Here's the price:

| Requirement | Detail |
|---|---|
| Deployment | Data Center only. |
| Version | Confluence 8.0+. Jira 8.14 through 11.3.10, with the *matching* plugin build (build 3.0.0 won't install below 11.3). Microsoft's own pages disagree (8.10.0 to 10.5.1, or 8.14+). |
| Infrastructure | Windows VM inside the network, 8 cores, 16 GB, 40 GB per 5M items |
| Atlassian side | Third-party Marketplace plugin on production. Confluence needs a **Global Administrator** service account, public User Email Visibility, and the Mobile Web Plugin. |
| Entra side | App registration with tenant-wide admin consent. Confluence DC needs `Directory.Read.All`. |
| Network | Outbound 443 allowlist. Proxy authentication isn't supported either way. An outbound proxy breaks the crawl unless bypassed. |
| Capability | **Read-only.** No issue or page creation, ever. |
| Support | Microsoft's plugin EULA disclaims support and caps liability at USD 5.00. |
| People | Four: AI administrator, Azure App admin, Confluence admin, network admin |

Expect one to three days across four people who don't report to you, likely stalling at the production plugin install. Tell security that Microsoft's Confluence prerequisite asks you to allowlist Microsoft IP ranges "so the connector can access Confluence APIs," which contradicts the outbound-only story.

**Recommendation:** not now. Do the local build first, prove people read the summaries, and revisit when someone outside engineering asks.

### And explicitly: no Copilot Studio build

The write path is unproven. Licensing is metered per action. It'd be a worse version of an HTTP POST you can already make from a laptop.

---

## 4. What M365 Copilot is genuinely best at here

Copilot is strong where the answer is **public knowledge or lives in M365**: Unreal API questions, Perforce syntax, what a build config flag does, C++ patterns. None of that needs a connector.

Underused surfaces you already own:

- **Power BI** is connected. Copilot can already answer questions over build health, crash rates, test pass rates, or burndown kept there.
- **M365 content** (producer notes, milestone plans, publisher threads, meeting recaps, SharePoint design docs) holds most of the non-code decision record at a lot of studios.
- **Agent Builder over a SharePoint document library** costs an afternoon, needs no approvals, and gives non-engineers a self-serve answer source.
- **Viva Engage and Viva Learning** already cover announcements and onboarding.

---

## 5. The honest ceiling

1. **Nothing writes to self-hosted Jira or Confluence from M365 Copilot.** Writes originate inside the network.
2. **Read grounding needs at least one Windows VM and four approvals.** Nothing lighter is coming.
3. **Perforce is not a Copilot data source at any tier.** Nor are Unreal source or build logs. What changed, why, and what broke stays on the Claude Code side.
4. **Data Center itself runs until 2029-03-28**, with extensions "by exception only." Your own release gets two years from its feature or LTS release and runs out first. After a Cloud migration the MCP server is a day's rewrite against Cloud's `/rest/api/3` and ADF. The connector build costs the whole project again.
5. **Per-user PATs scale to a team but not to automation.** A nightly job needs a service account, which means an admin conversation. Push that out as far as you can.

---

**Do this week:** check Server vs Data Center, build the four-tool MCP server, and ship one real change summary to see if designers read it.

**Don't do this week:** anything involving Copilot Studio, an Atlassian Cloud trial, or a gateway.
