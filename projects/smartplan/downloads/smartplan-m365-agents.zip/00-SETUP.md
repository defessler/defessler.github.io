# Building these agents in M365 Copilot

Three agents, one file each, pasted into Agent Builder. None needs a
developer, admin, connector, or new licence. Steps were tested in a live
tenant on 2026-08-12. Microsoft Learn pages were read 2026-09-29 unless
marked.

Note: In August 2026 Microsoft 365 Copilot became Microsoft Copilot.
Pricing pages still use the old name.

## The limits you're working inside

| Field | Limit |
| --- | --- |
| Name | 30 characters |
| Description | 1,000 characters |
| **Instructions** | **8,000 characters** |
| Knowledge sources | per type, see below |
| Response mode | Auto · Quick response · **Think deeper** |

Some blocks in files 01 to 03 sit near that cap. Run
`python scripts/m365-agents.py status` before adding to one.

**Knowledge caps are per type** (`agent-builder-add-knowledge`). The "up
to 20" on `learn.microsoft.com/.../agent-builder-build-agents` matches the
device-upload cap, not a total.

| Knowledge type | Cap |
| --- | --- |
| SharePoint files, folders, sites | 100 |
| OneDrive files | 50 |
| SharePoint list | **1 per agent** |
| Public website URLs | 4 |
| Teams chats and meetings | 5 of each |
| Uploaded files (embedded) | 20 |

Selecting a SharePoint *site* skips its lists. Add the list by its URL.

## Steps

1. In M365 Copilot, choose **New agent** in the left rail.
2. Choose **Skip to configure**. The Describe tab writes generic
   instructions.
3. Fill Name and Description from the file, then paste the Instructions
   block and edit every `[BRACKETED]` placeholder.
4. Set **Model / response mode** to **Think deeper**.
5. Add knowledge sources if the file lists any.
6. Test on the **Try it** tab, then create.

## Three things that will bite you

**Open the agent directly. Don't `@mention` it.** An @mention may ignore
Think deeper. Microsoft pulled the known-issue note without saying it
was fixed.

**One job per agent.** An agent mixing C++ and design docs spends half
its 8,000 characters switching hats.

**Instructions re-inject every turn. Chat history doesn't.** Anything you
re-type by the third message belongs in the instructions.

## What came from the smartplan family, and what couldn't

- Doc Writer: a shortened smartvoice keyed profile (Voice section) and
  smartwiki's change-summary shape (Output template). Prose rules port
  cleanly.
- UE5 Engineer: smartreview's Epic C++ standard and findings ranked
  BREAKING, PRACTICE, CONVENTION (Conventions). Error Triage takes
  smartplan's ranked verify oracles, a falsification test that says what
  turns it red, a two-strike spiral guard that also fixes context drift,
  and a false-success guard for the all-green wrong answer.

**The big one didn't transfer: model tiering.** Agent Builder has three
response modes and no per-call model, cheap executor, or verifier seat.
Fan-out doesn't port either. There's no dispatch and no filesystem for
`run-state.md`. What ports is the *judgment*.

Copilot Cowork, a separate product, is the one exception. Its per-user
model picker (Opus 5, Sonnet 5, Fable 5.1, and the GPT line) and
five-level effort dial, Light to Max, are set in the chat box, not per
call (`learn.microsoft.com/.../cowork/cowork-models`). Microsoft's Copilot
blog announced Opus 5.5 and GPT-6 Sol rolling out to Cowork on 2026-09-22,
though the models page doesn't list them yet. What you see depends on
licence, region, and admin settings. Fable 5 (Preview) stays off until an
admin turns it on.

Custom skills, a preview for Frontier Preview orgs only, could carry the
smartvoice and smartwiki material into declarative agents. Each is a
folder with a `SKILL.md` under 20,000 characters, up to 8 per agent,
loaded only when a task needs it. Tiering still isn't possible without a
model pick (`learn.microsoft.com/.../extensibility/declarative-agent-skills`,
read 2026-09-15).

## The three agents, and what each covers

| Agent | Covers |
| --- | --- |
| **UE5 Engineer** | C++, Python (editor), Blueprint boundaries, gameplay systems and engine architecture, across 5.7 and 5.8+ |
| **Studio Doc Writer** | Confluence pages, change summaries, design docs, postmortems |
| **UE5 Build & Crash Doctor** | UHT, compile, and linker errors, asserts, crashes, crash dumps, cook and shader failures |

Jira and Confluence prior-art search doesn't ship. Those connectors are
unlikely to deploy on self-hosted Atlassian
(`04-atlassian-onprem-verdict.md`).

## Which agent to build first

Build **UE5 Engineer** first. It's the one you'll use daily and where
drift costs most. Give it a week, then fold your corrections into its
instructions.

**Build & Crash Doctor second.** It pays for itself the first time a
linker error would have eaten an afternoon.
