# smartplan quickstart

smartplan gives each model the work it's good at. A strong model plans and
judges. Cheaper models do the building. An independent verifier checks their
work. The flow moves to a stronger model only after a failure.

## 1. Install

**Windows:** `.github/skills/smartplan/scripts/smart-plan-setup.cmd` or `.github/skills/smartplan/scripts/smart-plan-setup.ps1` replaces the
manual steps below. It asks where to install and which skills to turn on.

**Copilot CLI.** Open this project. The skills load from
`.github/skills/` and seven pinned agents from `.github/agents/`. The
skill only dispatches the three that run GPT-6 Luna:
`@smartplan-scout`, `@smartplan-implementer-cheap` and
`@smartplan-verifier-cheap`. On a Luna session, Luna does the work and
a fresh Luna checks it. On a pricier session, that model plans and
checks every Luna diff while Luna writes the code. The other four
(`@smartplan-planner`, `@smartplan-implementer`, `-reserve` and
`@smartplan-verifier`) are there to call by hand. For personal use, copy the skill folders into
`~/.copilot/skills/` and the agents into `~/.copilot/agents/`.
**Don't leave the session model on Auto** for tiered work. Auto
overrides every subagent's pin and re-routes mid-task. Inline sessions
can keep Auto (Copilot Fusion in the CLI). Auto runs at 30% off on paid plans through 2026-11-30.

## 2. Fill-once configuration

Only smartreview needs filling before first use.

- **smartplan `{{MODE}}` (quality/cost dial): optional.** Pick
  `max-quality`, `high-quality`, `balanced`, `budget`, or `max-savings`
  per run (`--mode budget` or plain words), per leaf (a plan's unit of
  work) with a `MODE:` line in its brief, or here as the default. A mode
  sets which model class plans (the "seat"), the implementer's minimum
  tier (the "floor"), verify depth, effort, report detail, and
  parallelism. No mode changes the human gate, verify-before-merge, or
  honest reporting. The full matrix is in `smartcost/references/modes.md`.

  The default is **`max-savings`**, since Copilot meters AI credits per
  token. On our benchmarks it matched balanced's quality at 54% of the
  cost on mechanical work and 32% on judgment work. It samples the
  verify on waves of five or more leaves. Ask for `budget` to verify
  every leaf, or `max-quality` when a mistake would be costly.

- **smartreview (code review): FILL BEFORE FIRST USE.** In
  `.github/skills/smartreview/references/cpp-review-standards.md`
  § Project Profile, set **Engine** (`vanilla`, `custom`, or `unreal`)
  and the C++ tokens (`{{COMPANY}}`, `{{PREFIX}}`, and the rest). In
  `.github/skills/smartreview/SKILL.md` § Project Profile, set
  indentation, max line length, and local-variable case. A token you leave unset
  makes its row N/A. The bug hunt needs only **Engine**. Not C++?
  Point `{{STANDARDS}}` at your own standards doc. For HTML and CSS,
  point it at the shipped `references/web-ui-review-standards.md` and
  set its **Surface** (`component`, `screen` or `page`).
- **smartvoice (house voice): works out of the box.** It uses
  `voice-profiles/<username>.md` when one matches your OS username, else
  `defaultvoice.md`. To personalize, copy either to
  `voice-profiles/<your-username>.md` (your `whoami` name in lowercase,
  without the domain).
  Delete `defaultvoice.md` to skip the voice pass for everyone else.
  `python .github/skills/smartvoice/scripts/install_voice.py --copilot`
  applies the chat rules to every reply, subagents included.
  `--uninstall` removes them.
- **smartwiki (change writeups): ships ready** for Git and Perforce. For
  another version control system (VCS), fill in the four verbs in its VCS Adapter.
- **Model roster: edit by hand when models move.** Reclassify a model in
  `.github/skills/smartroute/references/model-classes.md` and every seat
  rule follows.

## 3. First run

In your project, type:

```
/smartplan <task>
```

For a first test, pick work that's too big for one context or needs an
independent check. A small task just runs inline. That's correct, but
it shows you less.

smartplan **routes by regime**. A task that fits one strong model's
context runs *inline*. It skips plan, fan-out, and verify. At that scale
those steps cost more than they save (T14, T19, T20, T21). On a real UE5
task, the skill as shipped cost 1.05x a plain session, at equal quality, in
Copilot credits (T28).

Fan-out (running leaves in parallel) pays only for work too big for one context,
failure-prone work that keeps needing rework inline (T9),
batches with a deadline, and merges that need independent verification. Width
alone doesn't pay. A wide, easy, one-context task cost 180% of inline (T20).

When the full flow runs, you'll see:

1. A **plan** of small independent leaves, each with a model class. An
   ambiguous ask gets a clarifying question first.
2. A **gate**. Nothing edits until you approve.
3. A **dispatch-board line** showing each leaf's model, like
   `▶ 3 running: L1 stubs→haiku · L2 parser→sonnet · L3 scout→haiku | seat: opus (plan)`
   Between updates, watch `/tasks`.
4. **Verification**: every cheap leaf gets an independent check.
5. An **Integrate pass** that reconciles the seams before you accept.

Two files may appear in your project root: `run-state.md`, which lets a
crashed run resume, and `contracts.md`, which freezes the interfaces
parallel leaves share. Commit or ignore them.

## 4. Verify it actually works

```bash
bash .github/skills/smartplan/scripts/smart-plan-selftest.sh
```

That checks the static install in about two seconds. Then run the six
behavioral probes in `references/selftest.md`, graded on visible
artifacts (files, board lines, gate behavior) rather than the model's
claims.

## 5. Day-to-day

- The plan seats by class even when you name a model. "Use Opus for the
  renames" gets Haiku, flagged at the gate. Say "seat it anyway" to
  override.
- Under budget or rate-cap pressure, mechanical work drops a tier.
  Planning waits for the reset instead.
- Repeated deterministic work moves into a script, which costs no model
  calls.
- **Switch off any part you don't want.** Each smartplan feature is its
  own skill: `smartflow` (fan-out), `smartroute` (model tiers),
  `smartcost` (the dial), `smartbrief`, `smartexec`, `smartcheck`,
  `smartcheck-cpp`. Turn one off in your skill list and
  smartplan works without it, saying once per task what it skipped.

## Going deeper

The skill body (`.github/skills/smartplan/SKILL.md`) is the router, and
its Parts table says what each part skill adds and what happens when
it's off. `smartroute`'s `routing.md` maps task classes to tiers.
`model-classes.md` is the roster.
`check.md` is the verifier protocol. `copilot.md` holds the Copilot
depth.
