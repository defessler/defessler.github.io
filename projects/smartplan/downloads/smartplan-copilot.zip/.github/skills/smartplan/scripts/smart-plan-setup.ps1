# .github/skills/smartplan/scripts/smart-plan-setup.ps1 — interactive Windows installer for the smartplan family.
#
# Works in Windows PowerShell 5.1 and PowerShell 7+. Command Prompt users:
# run the .cmd shim beside this file (it launches the .ps1 sharing its
# basename, so the renamed export pair stays wired).
#
# What it does, all by menu (this export carries the skills in
# .github\skills):
#
#   - Install selected skills into another project
#   - Install personally for Copilot CLI (~\.copilot\skills + agents)
#   - Enable / disable skills in place — per skill, or all of them
#   - Status — what is installed and enabled where
#
# "Disable" renames a skill's SKILL.md to SKILL.md.off (harnesses stop
# discovering it); "enable" renames it back. Reversible, no deletion.
# The script never edits skill content and never touches your git history.

$ErrorActionPreference = 'Stop'

# Locate the skill tree by walking up from this script's location: a repo
# checkout keeps the script in scripts\ with the skill tree one
# level up; the Copilot export encapsulates a renamed copy inside the skill
# folder (.github\skills\smartplan\scripts\ — tree four levels up). The
# nearest ancestor containing either tree flavor wins.
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$RepoRoot  = $null
$TreeRel   = $null
$cand = $ScriptDir
while ($cand) {
  foreach ($rel in @(
    '.github\skills')) {
    if (Test-Path (Join-Path $cand $rel)) { $RepoRoot = $cand; $TreeRel = $rel; break }
  }
  if ($RepoRoot) { break }
  $parent = Split-Path -Parent $cand
  if (-not $parent -or $parent -eq $cand) { break }
  $cand = $parent
}
if (-not $RepoRoot) {
  Write-Host "No .github\skills tree found at or above $ScriptDir - run this from a Copilot export." -ForegroundColor Yellow
  exit 1
}
$SourceTree   = Join-Path $RepoRoot $TreeRel
$IsExportTree = ($TreeRel -eq '.github\skills')

# smartplan ships with its part skills, one per feature since v4.164.0.
# Each installs by default, and each can be switched off below on its own:
# smartplan loads a part only when the skill listing names it, and follows
# that part's Off rule when it doesn't. An export can leave a part out
# (smartcache), so only parts present in this tree count.
$CoreSkills     = @('smartplan', 'smartexec', 'smartflow', 'smartroute', 'smartcost',
                    'smartbrief', 'smartcheck', 'smartcheck-cpp', 'smartcache') |
                  Where-Object { Test-Path (Join-Path (Join-Path $SourceTree $_) 'SKILL.md') }
# What turns off with each part, printed when one is disabled.
$PartOff = @{
  'smartplan'      = 'smartplan routes everything. Its parts do nothing without it.'
  'smartflow'      = 'smartplan stops fanning out. Every task runs inline.'
  'smartroute'     = 'subagents run the session model, with no tier climbs.'
  'smartcost'      = 'smartplan runs its default mode, with no quality/cost dial.'
  'smartbrief'     = 'no Cheap leaves. Leaves get a plain task at the Mid tier.'
  'smartexec'      = 'no Cheap leaves. Leaves get a plain task at the Mid tier.'
  'smartcheck'     = 'executable checks only, no model verify, no Cheap leaves.'
  'smartcheck-cpp' = 'smartcheck runs without its C++ gamedev layer.'
  'smartcache'     = 'fan-out ignores prompt-cache ordering.'
}
$OptionalSkills = @('smartreview', 'smartwiki', 'smartvoice', 'smartdiagram', 'smartdiff')
$AllSkills      = $CoreSkills + $OptionalSkills

function Write-Head([string]$Text) {
  Write-Host ''
  Write-Host "== $Text ==" -ForegroundColor Cyan
}

function Confirm-YesNo([string]$Prompt, [bool]$DefaultYes) {
  if ($DefaultYes) { $suffix = '[Y/n]' } else { $suffix = '[y/N]' }
  $answer = Read-Host "$Prompt $suffix"
  if ([string]::IsNullOrWhiteSpace($answer)) { return $DefaultYes }
  return $answer.Trim().ToLower().StartsWith('y')
}

function Select-Skills {
  # Returns the list of skills the user wants. Core pair is one question.
  $chosen = @()
  Write-Host ''
  Write-Host 'Choose what to include. smartplan and its parts are the tiering'
  Write-Host 'loop itself. Switch any part off later from the enable/disable menu.'
  Write-Host 'The other five are optional companion seats.'
  if (Confirm-YesNo '  Include smartplan and its parts (the core loop)?' $true) {
    $chosen += $CoreSkills
  }
  if (Confirm-YesNo '  Include smartreview (code review: breaking bugs, practices, conventions; C++ gamedev default)?' $true) {
    $chosen += 'smartreview'
  }
  if (Confirm-YesNo '  Include smartwiki (stakeholder change writeups)?' $true) {
    $chosen += 'smartwiki'
  }
  if (Confirm-YesNo '  Include smartvoice (house-voice pass; per-user profiles)?' $true) {
    $chosen += 'smartvoice'
  }
  if (Confirm-YesNo '  Include smartdiagram (curated interactive architecture diagrams)?' $true) {
    $chosen += 'smartdiagram'
  }
  if (Confirm-YesNo '  Include smartdiff (HTML session diff review, Unreal Blueprints included)?' $true) {
    $chosen += 'smartdiff'
  }
  if ($chosen.Count -eq 0) {
    Write-Host '  Nothing selected - nothing to do.' -ForegroundColor Yellow
  }
  return $chosen
}

function Copy-Skills([string[]]$Skills, [string]$DestSkillsDir) {
  New-Item -ItemType Directory -Force -Path $DestSkillsDir | Out-Null
  foreach ($s in $Skills) {
    $src = Join-Path $SourceTree $s
    if (-not (Test-Path (Join-Path $src 'SKILL.md'))) {
      Write-Host "  SKIP $s (missing in source tree?)" -ForegroundColor Yellow
      continue
    }
    $dst = Join-Path $DestSkillsDir $s
    if (Test-Path $dst) { Remove-Item -Recurse -Force $dst }
    Copy-Item -Recurse -Force $src $dst
    Write-Host "  installed $s -> $dst"
  }
}

function Install-ToProject {
  Write-Head 'Install into another project'
  $target = Read-Host 'Project root path (the repo you code in)'
  if ([string]::IsNullOrWhiteSpace($target) -or -not (Test-Path $target)) {
    Write-Host '  Path not found - aborting this action.' -ForegroundColor Yellow
    return
  }
  $target = (Resolve-Path $target).Path
  if ($target -eq $RepoRoot) {
    Write-Host '  That IS this repo - skills already load from here. Nothing to copy.' -ForegroundColor Yellow
    return
  }
  $skills = Select-Skills
  if ($skills.Count -eq 0) { return }
  Copy-Skills $skills (Join-Path $target $TreeRel)
  if (Confirm-YesNo 'Also copy the 7 Copilot agent profiles (.github\agents) into the project?' $false) {
    $agentsSrc = Join-Path $RepoRoot '.github\agents'
    $agentsDst = Join-Path $target '.github\agents'
    New-Item -ItemType Directory -Force -Path $agentsDst | Out-Null
    Copy-Item -Force (Join-Path $agentsSrc '*.agent.md') $agentsDst
    Write-Host "  installed Copilot agents -> $agentsDst"
  }
  Write-Host ''
  Write-Host 'Manual follow-ups (see smartplan-quickstart.md section 2):' -ForegroundColor Cyan
  if ($skills -contains 'smartreview') {
    Write-Host '  - smartreview: fill the Project Profile (Engine + tokens); the conventions half needs it, the breaking-bug hunt does not.'
  }
}

function Install-PersonalCopilot {
  Write-Head 'Install personally for Copilot CLI'
  $skills = Select-Skills
  if ($skills.Count -eq 0) { return }
  Copy-Skills $skills (Join-Path $HOME '.copilot\skills')
  if (Confirm-YesNo 'Also install the 7 pinned agent profiles (~\.copilot\agents)?' $true) {
    $agentsDst = Join-Path $HOME '.copilot\agents'
    New-Item -ItemType Directory -Force -Path $agentsDst | Out-Null
    Copy-Item -Force (Join-Path $RepoRoot '.github\agents\*.agent.md') $agentsDst
    Write-Host "  installed Copilot agents -> $agentsDst"
  }
  Write-Host '  Check with /skills list in a Copilot session.'
}

function Get-SkillState([string]$SkillsDir, [string]$Skill) {
  $dir = Join-Path $SkillsDir $Skill
  if (Test-Path (Join-Path $dir 'SKILL.md'))     { return 'enabled' }
  if (Test-Path (Join-Path $dir 'SKILL.md.off')) { return 'DISABLED' }
  return 'not installed'
}

function Resolve-SkillsDir {
  $locations = @()
  $locations += @{ Label = "This tree            ($SourceTree)"; Path = $SourceTree }
  $locations += @{ Label = "Personal Copilot     ($(Join-Path $HOME '.copilot\skills'))"; Path = (Join-Path $HOME '.copilot\skills') }
  Write-Host ''
  Write-Host 'Which install location?'
  for ($i = 0; $i -lt $locations.Count; $i++) {
    Write-Host ("  [{0}] {1}" -f ($i + 1), $locations[$i].Label)
  }
  Write-Host ("  [{0}] Another path..." -f ($locations.Count + 1))
  $pick = Read-Host 'Choice'
  $n = 0
  if (-not [int]::TryParse($pick.Trim(), [ref]$n)) { return $null }
  if ($n -ge 1 -and $n -le $locations.Count) { return $locations[$n - 1].Path }
  if ($n -eq ($locations.Count + 1)) {
    $p = Read-Host 'Path to the skills directory (the one containing smartplan\, smartexec\, ...)'
    if ([string]::IsNullOrWhiteSpace($p) -or -not (Test-Path $p)) { return $null }
    return (Resolve-Path $p).Path
  }
  return $null
}

function Set-SkillsEnabled {
  Write-Head 'Enable / disable skills (reversible: SKILL.md <-> SKILL.md.off)'
  $dir = Resolve-SkillsDir
  if (-not $dir) { Write-Host '  No location chosen.' -ForegroundColor Yellow; return }
  if ($dir -eq $SourceTree) {
    Write-Host '  NOTE: this is the source tree - a toggle here shows up in version control.' -ForegroundColor Yellow
    Write-Host '  Re-enable (or revert) before committing unless you mean it.'
  }
  Write-Host ''
  foreach ($s in $AllSkills) {
    Write-Host ("  {0,-15} {1}" -f $s, (Get-SkillState $dir $s))
  }
  Write-Host ''
  $which = Read-Host "Skill name to toggle, 'all' to toggle everything, or blank to cancel"
  if ([string]::IsNullOrWhiteSpace($which)) { return }
  $targets = @()
  if ($which.Trim().ToLower() -eq 'all') { $targets = $AllSkills } else { $targets = @($which.Trim().ToLower()) }
  foreach ($s in $targets) {
    $on  = Join-Path (Join-Path $dir $s) 'SKILL.md'
    $off = Join-Path (Join-Path $dir $s) 'SKILL.md.off'
    if (Test-Path $on) {
      Rename-Item $on $off
      Write-Host "  $s -> DISABLED"
      if ($PartOff.ContainsKey($s)) { Write-Host "    (off: $($PartOff[$s]))" -ForegroundColor Yellow }
    } elseif (Test-Path $off) {
      Rename-Item $off (Split-Path $on -Leaf)
      Write-Host "  $s -> enabled"
    } else {
      Write-Host "  $s : not installed at $dir" -ForegroundColor Yellow
    }
  }
  Write-Host '  Restart the harness session (or reload skills) for the change to load.'
}

function Show-Status {
  Write-Head 'Status'
  $locations = @(
    @{ Name = 'This tree';        Path = $SourceTree }
  )
  $locations += @{ Name = 'Personal Copilot';     Path = (Join-Path $HOME '.copilot\skills') }
  foreach ($loc in $locations) {
    Write-Host ''
    Write-Host ("{0}  ({1})" -f $loc.Name, $loc.Path)
    if (-not (Test-Path $loc.Path)) { Write-Host '  (nothing installed)'; continue }
    foreach ($s in $AllSkills) {
      $state = Get-SkillState $loc.Path $s
      if ($state -ne 'not installed') {
        Write-Host ("  {0,-12} {1}" -f $s, $state)
      }
    }
  }
  Write-Host ''
  Write-Host 'Deeper checks: bash .github/skills/smartplan/scripts/smart-plan-selftest.sh (static surface, needs Git-Bash).'
}

# ---------------------------------------------------------------------------
# Menu loop — built from the tree flavor: a Copilot export (.github\skills)
# carries only the Copilot install options.
# ---------------------------------------------------------------------------

$MenuItems = @()
$MenuItems += @{ Label = 'Install into another project';                        Action = { Install-ToProject } }
$MenuItems += @{ Label = 'Install personally for Copilot CLI';                  Action = { Install-PersonalCopilot } }
$MenuItems += @{ Label = 'Enable / disable skills (parts or all)';              Action = { Set-SkillsEnabled } }
$MenuItems += @{ Label = 'Status';                                              Action = { Show-Status } }

Write-Host 'smartplan interactive installer' -ForegroundColor Cyan
Write-Host "source: $SourceTree"

while ($true) {
  Write-Host ''
  Write-Host 'What would you like to do?'
  for ($i = 0; $i -lt $MenuItems.Count; $i++) {
    Write-Host ("  [{0}] {1}" -f ($i + 1), $MenuItems[$i].Label)
  }
  Write-Host '  [Q] Quit'
  $choice = Read-Host 'Choice'
  if ($choice.Trim().ToUpper() -eq 'Q') { break }
  $n = 0
  if ([int]::TryParse($choice.Trim(), [ref]$n) -and $n -ge 1 -and $n -le $MenuItems.Count) {
    & $MenuItems[$n - 1].Action
  } else {
    Write-Host '  Unrecognized choice.' -ForegroundColor Yellow
  }
}

Write-Host 'Done.'
