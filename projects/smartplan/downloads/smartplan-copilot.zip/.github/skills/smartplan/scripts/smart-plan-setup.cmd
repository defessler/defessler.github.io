@echo off
rem .github/skills/smartplan/scripts/smart-plan-setup.cmd - Command Prompt shim for the smartplan installer.
rem Launches the PowerShell installer sharing this shim's basename (so a
rem renamed pair - e.g. smart-plan-setup.cmd/.ps1 in the Copilot export -
rem stays wired), with a policy bypass so it runs on stock Windows without
rem changing machine execution policy.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0%~n0.ps1"
