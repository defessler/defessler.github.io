#!/usr/bin/env python3
"""trail: export only the agent's own edits from a session, never the live files.

  python trail.py --messages 1          # the work since the previous message
  python trail.py --messages 3          # the last 3 messages and their work
  python trail.py --whole-session
  python trail.py --list-messages       # find a boundary for --request-id

Writes before/after copies, agent-only.diff, comparisons.json, prompts.md,
transcript.md and index.html into one timestamped folder, then opens the page.

Sessions it reads, found from the environment when --session is left out:
  Claude Code  the transcript named by CLAUDE_CODE_SESSION_ID, or --session <file.jsonl>
  Copilot CLI  the folder named by COPILOT_AGENT_SESSION_ID, or --session <session folder>
A harness started from inside the other inherits both variables, so when both
resolve, the transcript written most recently is the one running this.

Every change is rebuilt from recorded evidence: the file as it was before each
edit plus the patch the tool applied. A change it can't prove is left out and
reported, and the run exits 2 (partial) instead of 0.
"""
import argparse
import difflib
import hashlib
import json
import os
import re
import subprocess
import sys
import tempfile
import webbrowser
from datetime import datetime
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import diffview  # noqa: E402

SHELL_TOOLS = {"Bash", "PowerShell", "powershell", "execute_terminal_command", "bash", "shell"}
# Copilot CLI tools whose result.detailedContent is the applied unified diff.
# Which one runs depends on the model: GPT seats patch, others edit and create.
# view also returns a diff-shaped detailedContent, so the name gates it.
COPILOT_PATCH_TOOLS = {"apply_patch", "edit", "create"}
OUT_PARTS = ("saved", "smartdiff")


class EvidenceError(ValueError):
    pass


# ------------------------------------------------------------------ paths

def canonical(path, cwd):
    if os.name == "nt":
        path = path.replace("/", "\\")
    if not os.path.isabs(path):
        path = os.path.join(cwd, path)
    return os.path.normpath(path)


def key(path):
    return os.path.normcase(path)


def normalize(raw):
    if isinstance(raw, bytes):
        if b"\x00" in raw:
            raise EvidenceError("Binary file is not supported.")
        raw = raw.decode("utf-8")
    return raw.replace("\r\n", "\n").replace("\r", "\n")


# ------------------------------------------------------------------ replay

def replay(before, section):
    """Apply one file's hunks [(start, old_lines, new_lines)] to before, checking
    every removed and context line against it."""
    if section["added"] and before is not None:
        raise EvidenceError("Added file already exists in the preimage.")
    if not section["added"] and before is None:
        raise EvidenceError("Edited file has an absent preimage.")
    lines = [] if before is None else before.split("\n")
    offset = 0
    previous_end = 0
    for start, old, new in section["hunks"]:
        base = start - 1 if old else start
        if before is None and not lines and start in (0, 1) and not old:
            base = 0
        position = base + offset
        if base < previous_end or position < 0 or position > len(lines) or lines[position:position + len(old)] != old:
            raise EvidenceError("Applied diff does not match the recorded original.")
        lines[position:position + len(old)] = new
        previous_end = base + len(old)
        offset += len(new) - len(old)
    if section["deleted"]:
        if any(lines):
            raise EvidenceError("Deleted file diff left content behind.")
        return None
    # apply_patch spells a new file's final newline as a trailing empty line.
    # edit and create write standard unified diffs, where the newline is
    # implied unless marked, and parse_applied refuses that marker.
    if before is None and section["added"] and lines and section.get("unified_eol"):
        lines.append("")
    return "\n".join(lines)


def structured_hunks(patch):
    """Claude Code's structuredPatch (jsdiff) as replay() hunks."""
    hunks = []
    for h in patch:
        old, new = [], []
        for line in h.get("lines", []):
            tag, body = line[:1], line[1:].rstrip("\r")
            if tag in " -":
                old.append(body)
            if tag in " +":
                new.append(body)
        if len(old) != h.get("oldLines", len(old)) or len(new) != h.get("newLines", len(new)):
            raise EvidenceError("Recorded patch hunk counts do not match.")
        start = h.get("oldStart", 1)
        # jsdiff keeps oldStart one past the insertion point for a pure insert.
        hunks.append((start - 1 if not old and start > 0 else start, old, new))
    return hunks


# ------------------------------------------------------------------ Copilot CLI

def copilot_human(event):
    data = event.get("data", {})
    text = data.get("content", "")
    if event.get("type") != "user.message" or data.get("source") or not isinstance(text, str) or not text.strip():
        return False
    return not text.lstrip().startswith(("<skill-context", "<system_reminder", "<session_memory_recovery"))


def copilot_events(raw):
    out = []
    for e in raw:
        kind, data, ts = e.get("type"), e.get("data", {}), e.get("timestamp", "")
        if kind == "user.message":
            if copilot_human(e):
                out.append({"kind": "human", "id": e["id"], "ts": ts, "text": data["content"], "raw": e})
            elif str(data.get("source", "")).startswith("agent-") and data.get("content"):
                out.append({"kind": "subprompt", "ts": ts, "text": data["content"], "raw": e})
        elif kind == "assistant.message" and data.get("phase") in (None, "commentary", "final", "final_answer") and data.get("content"):
            out.append({"kind": "say", "ts": ts, "text": data["content"], "raw": e})
        elif kind == "tool.execution_start":
            out.append({"kind": "call", "ts": ts, "id": data.get("toolCallId"), "name": data.get("toolName", "unknown"),
                        "input": data.get("arguments", {}), "raw": e})
        elif kind == "tool.execution_complete":
            out.append({"kind": "result", "ts": ts, "id": data.get("toolCallId"), "error": not data.get("success", False),
                        "content": data.get("result"), "fault": data.get("error"), "raw": e})
        else:
            out.append({"kind": "other", "ts": ts, "raw": e})
    return out


def parse_applied(text, cwd):
    """Copilot's recorded apply_patch result: a unified diff per file."""
    lines = text.replace("\r\n", "\n").split("\n")
    sections, current, i = [], None, 0
    while i < len(lines):
        line = lines[i]
        if line.startswith("--- "):
            if i + 1 >= len(lines) or not lines[i + 1].startswith("+++ "):
                raise EvidenceError("Missing applied diff destination.")
            old = line[4:].split("\t")[0]
            new = lines[i + 1][4:].split("\t")[0]
            old = old[2:] if old.startswith("a/") else old
            new = new[2:] if new.startswith("b/") else new
            old = None if old in {"/dev/null", "dev/null"} else canonical(old, cwd)
            new = None if new in {"/dev/null", "dev/null"} else canonical(new, cwd)
            if old and new and key(old) != key(new):
                raise EvidenceError("Renamed files require separate add/delete evidence.")
            current = {"path": new or old, "added": old is None, "deleted": new is None, "hunks": []}
            sections.append(current)
            i += 2
            continue
        if line.startswith("@@"):
            match = re.match(r"^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@", line)
            if not match or current is None:
                raise EvidenceError("Unsupported applied diff hunk.")
            start, size, _, new_size = [int(v) if v is not None else 1 for v in match.groups()]
            old_lines, new_lines = [], []
            i += 1
            while len(old_lines) < size or len(new_lines) < new_size:
                if i >= len(lines) or not lines[i] or lines[i][0] not in " +-":
                    raise EvidenceError("Truncated applied diff hunk.")
                prefix, content = lines[i][0], lines[i][1:]
                if prefix in " -":
                    old_lines.append(content)
                if prefix in " +":
                    new_lines.append(content)
                if len(old_lines) > size or len(new_lines) > new_size:
                    raise EvidenceError("Applied diff hunk counts do not match.")
                i += 1
            current["hunks"].append((start, old_lines, new_lines))
            continue
        if line.startswith("\\ No newline"):
            raise EvidenceError("This diff's EOF marker format is not supported.")
        i += 1
    if not sections or any(not s["path"] or not s["hunks"] for s in sections):
        raise EvidenceError("No complete applied diff sections found.")
    return sections


def copilot_preimage(entry, root):
    image = entry.get("preimage", {})
    if image.get("kind") == "absent":
        return None
    digest, backup = image.get("contentHash", ""), image.get("backupFile", "")
    if image.get("kind") != "content" or not re.fullmatch(r"[a-fA-F0-9]{64}", digest) or backup != digest:
        raise EvidenceError("Missing or unsupported rewind preimage.")
    raw = (root / "backups" / backup).read_bytes()
    if hashlib.sha256(raw).hexdigest() != digest:
        raise EvidenceError("Rewind preimage hash mismatch.")
    return normalize(raw)


class CopilotSession:
    harness = "Copilot CLI"

    def __init__(self, folder):
        self.folder = folder
        raw = [json.loads(line) for line in (folder / "events.jsonl").read_text(encoding="utf-8").splitlines() if line.strip()]
        self.events = copilot_events(raw)
        self.cwd = next((e.get("data", {}).get("context", {}).get("cwd") for e in raw if e.get("type") == "session.start"), None)
        if not self.cwd:
            raise EvidenceError("Session working directory is missing.")
        self.root = folder / "rewind-file-snapshots"

    def extract(self, selected, generated):
        index_file = self.root / "index.json"
        if not index_file.is_file():
            raise EvidenceError("This session recorded no file snapshots, so no edit can be attributed.")
        index = json.loads(index_file.read_text(encoding="utf-8"))
        if index.get("schema", index.get("version", index.get("schemaVersion"))) != 1:
            raise EvidenceError("Unsupported rewind snapshot schema.")
        by_event = {s["eventId"]: s for s in index["snapshots"]}
        calls = {e["id"]: e for e in self.events if e["kind"] == "call"}
        out, warnings = Comparisons(), []
        for message, interval in selected:
            entries = by_event.get(message["id"], {}).get("files", {})
            entries = {key(canonical(v.get("path", k), self.cwd)): v for k, v in entries.items()}
            changes, failed = {}, set()
            for event in interval:
                if event["kind"] != "result" or event["error"]:
                    continue
                call = calls.get(event["id"], {})
                name = call.get("name", "").replace("functions.", "").replace("rider-", "")
                if name not in COPILOT_PATCH_TOOLS:
                    if name in SHELL_TOOLS:
                        warnings.append(f"{message['id']}: Shell commands ran. Only recorded patch edits are attributed, so command-driven edits may be missing.")
                    elif event["raw"].get("data", {}).get("fileEdits") or name in {"create_new_file", "replace_string_in_file", "edit_file", "reformat_file"}:
                        warnings.append(f"{message['id']}: {name} has no supported attribution evidence.")
                    continue
                result = event["content"]
                detail = result.get("detailedContent") if isinstance(result, dict) else None
                args = call.get("input", {})
                requested = args if isinstance(args, str) else "\n".join(v for v in args.values() if isinstance(v, str))
                requested_paths = [canonical(p, self.cwd) for p in re.findall(r"\*\*\* (?:Update|Add|Delete) File: ([^\r\n]+)", requested)]
                if name != "apply_patch" and isinstance(args, dict) and isinstance(args.get("path"), str):
                    requested_paths = [canonical(args["path"], self.cwd)]
                if requested_paths and all(generated(p) for p in requested_paths):
                    continue
                try:
                    if not isinstance(detail, str) or not detail.strip():
                        raise EvidenceError("Successful patch has no recorded applied diff.")
                    for section in parse_applied(detail, self.cwd):
                        section["unified_eol"] = name != "apply_patch"
                        path = section["path"]
                        k = key(path)
                        if generated(path) or k in failed:
                            continue
                        try:
                            if k not in changes:
                                if k not in entries:
                                    raise EvidenceError("No rewind preimage for this message.")
                                before = copilot_preimage(entries[k], self.root)
                                changes[k] = [path, before, before]
                            changes[k][2] = replay(changes[k][2], section)
                        except (EvidenceError, OSError, UnicodeError) as error:
                            failed.add(k)
                            warnings.append(f"{path}: {error}")
                except EvidenceError as error:
                    failed.update(key(p) for p in requested_paths)
                    warnings.append(f"{message['id']}: {error}")
            for k, entry in entries.items():
                path = canonical(entry.get("path", k), self.cwd)
                if generated(path):
                    continue
                pre, post = entry.get("preimage", {}), entry.get("postimage", {})
                if post and (post.get("kind"), post.get("contentHash")) != (pre.get("kind"), pre.get("contentHash")) \
                        and k not in changes and k not in failed:
                    warnings.append(f"{path}: Snapshot records changes without supported applied diffs. Attribution is unknown.")
            for k, (path, before, after) in changes.items():
                if k not in failed:
                    out.add(path, before, after, message["id"])
        return out.items(), warnings


# ------------------------------------------------------------------ Claude Code

def text_of(content):
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        return "\n".join(b.get("text", "") for b in content if isinstance(b, dict) and b.get("type") == "text")
    return ""


def claude_human(e):
    """The prompt text when e is a message a person sent, else None."""
    if e.get("isSidechain") or e.get("isMeta") or e.get("isCompactSummary"):
        return None
    if e.get("type") == "attachment":
        a = e.get("attachment") or {}
        if a.get("type") != "queued_command" or a.get("commandMode", "prompt") != "prompt":
            return None
        if not (a.get("humanTurn") or (a.get("origin") or {}).get("kind") == "human"):
            return None
        text = text_of(a.get("prompt"))
        return text if text.strip() else None
    if e.get("type") != "user":
        return None
    content = (e.get("message") or {}).get("content")
    if isinstance(content, list) and any(isinstance(b, dict) and b.get("type") == "tool_result" for b in content):
        return None
    text = text_of(content)
    if not text.strip():
        return None
    origin = (e.get("origin") or {}).get("kind")
    if origin is not None:
        return text if origin == "human" else None
    if text.lstrip().startswith(("<local-command", "<task-notification", "<system-reminder", "[Request interrupted",
                                 "This session is being continued")):
        return None
    return text


def load_jsonl(path):
    out = []
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.strip():
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                pass  # the session is still writing its last line
    return out


def claude_events(entries, side):
    out = []
    for e in entries:
        ts = e.get("timestamp", "")
        text = claude_human(e) if side == "main" else None
        if text is not None:
            out.append({"kind": "human", "id": e.get("uuid"), "ts": ts, "text": text})
            continue
        msg = e.get("message") or {}
        content = msg.get("content")
        if e.get("type") == "assistant" and isinstance(content, list):
            for b in content:
                if b.get("type") == "text" and b.get("text", "").strip():
                    out.append({"kind": "say", "ts": ts, "text": b["text"], "side": side})
                elif b.get("type") == "tool_use":
                    out.append({"kind": "call", "ts": ts, "id": b.get("id"), "name": b.get("name", ""),
                                "input": b.get("input", {}), "side": side})
        elif e.get("type") == "user" and isinstance(content, list):
            results = [b for b in content if isinstance(b, dict) and b.get("type") == "tool_result"]
            for b in results:
                out.append({"kind": "result", "ts": ts, "id": b.get("tool_use_id"), "error": bool(b.get("is_error")),
                            "content": b.get("content"), "detail": e.get("toolUseResult") if len(results) == 1 else None,
                            "side": side})
            if side != "main" and not results and text_of(content).strip():
                out.append({"kind": "subprompt", "ts": ts, "text": text_of(content), "side": side})
        elif side != "main" and e.get("type") == "user" and isinstance(content, str) and content.strip():
            out.append({"kind": "subprompt", "ts": ts, "text": content, "side": side})
    return out


def claude_home():
    return Path(os.environ.get("CLAUDE_CONFIG_DIR") or Path.home() / ".claude")


class ClaudeSession:
    harness = "Claude Code"

    def __init__(self, transcript):
        self.transcript = transcript
        self.sid = transcript.stem
        entries = load_jsonl(transcript)
        self.cwd = next((e.get("cwd") for e in entries if e.get("cwd")), None)
        if not self.cwd:
            raise EvidenceError("Session working directory is missing.")
        events = claude_events(entries, "main")
        # Subagent transcripts sit beside the main one. Their edits are the
        # agent's work too, placed on the timeline by timestamp.
        sub = transcript.with_suffix("") / "subagents"
        if sub.is_dir():
            for f in sorted(sub.glob("*.jsonl")):
                events += claude_events(load_jsonl(f), f.stem)
            last = ""
            for e in events:  # carry a timestamp onto the rare entry with none
                e["ts"] = e["ts"] or last
                last = e["ts"]
            events.sort(key=lambda e: e["ts"])  # stable, so same-time entries keep file order
        self.events = events
        self.backups = []  # (key, time, backupFileName or None)
        for e in entries:
            if e.get("type") == "file-history-snapshot":
                for p, b in ((e.get("snapshot") or {}).get("trackedFileBackups") or {}).items():
                    self.backups.append((key(canonical(p, self.cwd)), b.get("backupTime", ""), b.get("backupFileName")))
            elif e.get("type") == "file-history-delta" and e.get("trackingPath"):
                b = e.get("backup") or {}
                self.backups.append((key(canonical(e["trackingPath"], self.cwd)), b.get("backupTime", ""), b.get("backupFileName")))

    def backup(self, k, before_ts):
        """The file as backed up most recently before before_ts. None means absent."""
        hits = sorted((t, name) for kk, t, name in self.backups if kk == k and t and t <= before_ts)
        if not hits:
            raise EvidenceError("The edit record has no original file and no file-history backup covers it.")
        name = hits[-1][1]
        if name is None:
            return None
        return normalize((claude_home() / "file-history" / self.sid / name).read_bytes())

    def extract(self, selected, generated):
        calls = {e["id"]: e for e in self.events if e["kind"] == "call"}
        out, warnings = Comparisons(), []
        for message, interval in selected:
            chains, failed, shell = {}, set(), False
            for event in interval:
                if event["kind"] != "result" or event["error"]:
                    continue
                call = calls.get(event["id"], {})
                name = call.get("name", "")
                if name in SHELL_TOOLS:
                    shell = True
                    continue
                if name == "NotebookEdit":
                    warnings.append(f"{message['id']}: NotebookEdit has no supported attribution evidence.")
                    continue
                if name not in ("Edit", "Write", "MultiEdit"):
                    continue
                d = event.get("detail")
                raw_path = (d or {}).get("filePath") or (call.get("input") or {}).get("file_path")
                if not raw_path:
                    warnings.append(f"{message['id']}: {name} result names no file.")
                    continue
                path = canonical(raw_path, self.cwd)
                k = key(path)
                if generated(path) or k in failed:
                    continue
                try:
                    if not isinstance(d, dict):
                        raise EvidenceError(f"{name} result carries no file record.")
                    original = d.get("originalFile")
                    if name == "Write":
                        if d.get("type") == "create":
                            before = None
                        elif isinstance(original, str):
                            before = normalize(original)
                        else:
                            before = chains[k][-1][2] if k in chains else self.backup(k, event["ts"])
                        content = d.get("content", (call.get("input") or {}).get("content"))
                        if not isinstance(content, str):
                            raise EvidenceError("Write record has no content.")
                        after = normalize(content)
                    else:
                        if isinstance(original, str):
                            before = normalize(original)
                        else:
                            before = chains[k][-1][2] if k in chains else self.backup(k, event["ts"])
                        section = {"added": False, "deleted": False, "hunks": structured_hunks(d.get("structuredPatch") or [])}
                        after = replay(before, section) if section["hunks"] else before
                    if d.get("userModified"):
                        warnings.append(f"{path}: The edit was changed by hand before it applied, so it isn't all agent work.")
                    segs = chains.setdefault(k, [])
                    if segs and segs[-1][2] == before:
                        segs[-1][2] = after
                    else:  # first edit, or the file changed between two agent edits
                        segs.append([path, before, after])
                except (EvidenceError, OSError, UnicodeError) as error:
                    failed.add(k)
                    warnings.append(f"{path}: {error}")
            if shell:
                warnings.append(f"{message['id']}: Shell commands ran. Only recorded Edit and Write results are attributed, so command-driven edits may be missing.")
            for k, segs in chains.items():
                if k not in failed:
                    for path, before, after in segs:
                        out.add(path, before, after, message["id"])
        return out.items(), warnings


# ------------------------------------------------------------------ shared

class Comparisons:
    """Joins a file's change across messages while the edits stay contiguous."""

    def __init__(self):
        self.list = []

    def add(self, path, before, after, message):
        if before == after:
            return
        prior = next((c for c in reversed(self.list) if key(c["path"]) == key(path)), None)
        if prior and prior["after"] == before:
            prior["after"] = after
            prior["messages"].append(message)
        else:
            self.list.append({"path": path, "before": before, "after": after, "messages": [message]})

    def items(self):
        return [c for c in self.list if c["before"] != c["after"]]


def select_messages(events, request_id=None, count=1, whole=False):
    humans = [i for i, e in enumerate(events) if e["kind"] == "human"]
    if not humans:
        raise EvidenceError("No human messages found.")
    if request_id:
        boundary = next((i for i in humans if events[i]["id"] == request_id), None)
        if boundary is None:
            raise EvidenceError("The requested boundary is not a recorded human message.")
    else:
        boundary = humans[-1]
    previous = [i for i in humans if i < boundary]
    if not whole and count > len(previous):
        raise EvidenceError(f"Requested {count} earlier messages, but only {len(previous)} are recorded.")
    chosen = previous if whole else previous[-count:]
    ends = chosen[1:] + [boundary]
    return [(events[i], events[i:end]) for i, end in zip(chosen, ends)], events[boundary]


def open_session(arg):
    if arg:
        p = Path(arg).expanduser().resolve()
        if p.is_dir() and (p / "events.jsonl").is_file():
            return CopilotSession(p)
        if p.is_file() and p.suffix == ".jsonl":
            return ClaudeSession(p)
        raise EvidenceError(f"{arg} is neither a Copilot session folder nor a Claude Code transcript.")
    found = []  # (transcript file, opener)
    sid = os.environ.get("COPILOT_AGENT_SESSION_ID")
    if sid:
        folder = copilot_home() / "session-state" / sid
        if not (folder / "events.jsonl").is_file():
            raise EvidenceError(f"No Copilot session folder for {sid}. Pass --session.")
        found.append((folder / "events.jsonl", lambda: CopilotSession(folder)))
    sid = os.environ.get("CLAUDE_CODE_SESSION_ID")
    if sid:
        hits = list((claude_home() / "projects").glob(f"*/{sid}.jsonl"))
        if len(hits) != 1:
            raise EvidenceError(f"Found {len(hits)} transcripts for session {sid}. Pass --session.")
        found.append((hits[0], lambda: ClaudeSession(hits[0])))
    if not found:
        raise EvidenceError("No session given. Pass --session, or run inside Copilot CLI or Claude Code.")
    # The parent of a nested run sits waiting on a tool call, so the session
    # running this command is the one that wrote last.
    return max(found, key=lambda f: f[0].stat().st_mtime)[1]()


def copilot_home():
    return Path(os.environ.get("COPILOT_HOME") or Path.home() / ".copilot")


def block(value):
    text = value if isinstance(value, str) else json.dumps(value, indent=2, ensure_ascii=False)
    fence = "`" * max([3] + [len(m.group()) + 1 for m in re.finditer(r"`+", text)])
    return f"{fence}{'text' if isinstance(value, str) else 'json'}\n{text}\n{fence}\n\n"


def export_history(selected, output, boundary):
    internal = {"session_history", "session_artifacts"}
    prompts = ["# User Prompts\n\n"]
    transcript = ["# Transcript\n\n", f"Range ends before request `{boundary['id']}`.\n\n",
                  "Recorded conversation and tool activity, in event order. Private reasoning and "
                  "context-management records are omitted. Tool outputs may already be truncated in the recording.\n\n"]
    events = [e for _, interval in selected for e in interval]
    names = {e["id"]: e["name"] for e in events if e["kind"] == "call"}
    for e in events:
        stamp = " | ".join(v for v in (e.get("ts"), e.get("id")) if v)
        who = "" if e.get("side", "main") == "main" else f"Subagent {e['side']} "
        if e["kind"] == "human":
            title = f"## User | {stamp}\n\n"
            prompts += [title, block(e["text"])]
            transcript += [title, block(e["text"])]
        elif e["kind"] == "subprompt":
            transcript += [f"## Subagent Prompt | {stamp}\n\n", block(e["text"])]
        elif e["kind"] == "say":
            transcript += [f"## {who}Assistant | {stamp}\n\n", block(e["text"])]
        elif e["kind"] == "call":
            transcript.append(f"## {who}Tool Call: {e['name']} | {stamp}\n\n")
            transcript.append("Internal context record omitted.\n\n" if e["name"] in internal else block(e["input"]))
        elif e["kind"] == "result":
            name = names.get(e["id"], "unknown")
            transcript.append(f"## {who}Tool Result: {name} ({'failure' if e['error'] else 'success'}) | {stamp}\n\n")
            if name in internal:
                transcript.append("Internal context record omitted.\n\n")
                continue
            c = e.get("content")
            if isinstance(c, dict):
                for k, v in c.items():
                    transcript += [f"### {k}\n\n", block(v)]
            elif isinstance(c, list):
                transcript.append(block("\n".join(b.get("text", "") if isinstance(b, dict) else str(b) for b in c)))
            elif c is not None:
                transcript.append(block(c))
            if e.get("fault") is not None:
                transcript += ["### Error\n\n", block(e["fault"])]
    (output / "prompts.md").write_bytes("".join(prompts).encode("utf-8"))
    (output / "transcript.md").write_bytes("".join(transcript).encode("utf-8"))


def revision_label(paths):
    """What the workspace sat on at export time: an Unreal Game Sync changelist
    or a git commit, found from each file's nearest .ugs or .git."""
    seen, missing = [], False
    for path in paths:
        found = None
        for d in Path(path).parents:
            ugs = d / ".ugs" / "state.json"
            if ugs.is_file():
                try:
                    state = json.loads(ugs.read_text(encoding="utf-8"))
                    cl = state.get("CurrentChangeNumber")
                    if isinstance(cl, int) and not isinstance(cl, bool) and cl > 0 and not state.get("StreamSwitched"):
                        found = f"CL {cl}"
                except (OSError, ValueError):
                    pass
                break
            if (d / ".git").exists():
                r = subprocess.run(["git", "-C", str(d), "rev-parse", "--short", "HEAD"], capture_output=True, text=True)
                if r.returncode == 0 and r.stdout.strip():
                    found = f"git {r.stdout.strip()}"
                break
        if found is None:
            missing = True
        elif found not in seen:
            seen.append(found)
    if not seen:
        return "revision unavailable"
    return ", ".join(seen) + (" (partial)" if missing else "")


GENERATED_DIRS = {"binaries", "build", "deriveddatacache", "dist", "intermediate", "node_modules", "saved"}
# Source the page lists by default. diffview.CODE_EXT is the subset it also
# highlights. Scripts outside it render as plain text rather than vanish.
SOURCE_EXT = diffview.CODE_EXT | {".sh", ".bash", ".ps1", ".psm1", ".bat", ".cmd", ".lua",
                                  ".go", ".rs", ".kt", ".swift", ".m", ".mm", ".rb", ".php"}


def render_html(comparisons, title, notes, all_files):
    files, paths = [], []
    for index, item in enumerate(comparisons):
        path = item["path"]
        parts = [p.lower() for p in Path(path).parts[:-1]]
        if not all_files:
            if os.path.splitext(path)[1].lower() not in SOURCE_EXT or GENERATED_DIRS.intersection(parts):
                continue
            if Path(path).name.lower().endswith((".generated.h", ".gen.cpp")):
                continue
        before_lines = [line + "\n" for line in (item["before"] or "").splitlines()]
        after_lines = [line + "\n" for line in (item["after"] or "").splitlines()]
        shown = path.replace("\\", "/")
        patch = "".join(difflib.unified_diff(before_lines, after_lines, fromfile=shown, tofile=shown, n=5))
        parsed = diffview.parse(patch)
        if not parsed:
            continue
        f = parsed[0]
        f.anchor = f"file-{index}"
        f.before_lines = (item["before"] or "").splitlines()
        f.after_lines = (item["after"] or "").splitlines()
        if item["before"] is None:
            f.status = "added"
        elif item["after"] is None:
            f.status = "deleted"
        files.append(f)
        paths.append(path)
    return diffview.render(files, title, notes, 800, revision_label(paths))


def export(comparisons, output, boundary, warnings, selected=(), html_page=False, title="Agent changes",
           notes=None, all_files=False):
    output.mkdir(parents=True, exist_ok=False)
    manifest = {"boundary": boundary["id"], "partial": bool(warnings), "warnings": warnings, "comparisons": []}
    patch, names = [], set()
    for item in comparisons:
        stem, ext = os.path.splitext(os.path.basename(item["path"]))
        name, n = stem, 2
        while (name + ext).casefold() in names:
            name, n = f"{stem}-{n}", n + 1
        names.add((name + ext).casefold())
        pair = {"path": item["path"], "messages": item["messages"], "added": item["before"] is None,
                "deleted": item["after"] is None}
        for side in ("before", "after"):
            target = output / f"{name}-{side}{ext}"
            target.write_bytes((item[side] or "").encode("utf-8"))
            pair[side] = str(target)
        a = (item["before"] or "").splitlines(keepends=True)
        b = (item["after"] or "").splitlines(keepends=True)
        for line in difflib.unified_diff(a, b, fromfile=item["path"] + " (before)", tofile=item["path"] + " (after)"):
            patch.append(line if line.endswith("\n") else line + "\n\\ No newline at end of file\n")
        manifest["comparisons"].append(pair)
    (output / "agent-only.diff").write_text("".join(patch), encoding="utf-8")
    (output / "comparisons.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    export_history(selected, output, boundary)
    if html_page:
        (output / "index.html").write_text(render_html(comparisons, title, notes or {}, all_files), encoding="utf-8")
    return manifest


def default_out(cwd):
    """Saved/ is ignored in an Unreal project. Anywhere else, keep the export
    out of the working tree so it never lands in a commit."""
    root = Path(cwd)
    if (root / "Saved").is_dir() or any(root.glob("*.uproject")):
        return root / "Saved" / "smartdiff"
    return Path(tempfile.gettempdir()) / "smartdiff"


def main(argv=None):
    ap = argparse.ArgumentParser(description="Export only the agent's own edits from a session.")
    ap.add_argument("--session", help="Claude Code transcript (.jsonl) or Copilot CLI session folder")
    scope = ap.add_mutually_exclusive_group()
    scope.add_argument("--messages", type=int, help="how many earlier human messages to cover")
    scope.add_argument("--whole-session", action="store_true")
    ap.add_argument("--request-id", help="end the range before this message instead of the latest one")
    ap.add_argument("--list-messages", action="store_true")
    ap.add_argument("--out", help="output folder (default Saved/smartdiff in an Unreal project, else the system temp folder)")
    ap.add_argument("--title", default="Agent changes")
    ap.add_argument("--notes", help="JSON of per-file notes, plus optional \"_summary\"")
    ap.add_argument("--all-files", action="store_true", help="show every text file in the page, not only code")
    ap.add_argument("--no-open", action="store_true")
    page = ap.add_mutually_exclusive_group()
    page.add_argument("--html", dest="html", action="store_true")
    page.add_argument("--no-html", dest="html", action="store_false", help="skip the page and open nothing")
    ap.set_defaults(html=True)
    a = ap.parse_args(argv)
    if a.messages is not None and a.messages < 1:
        ap.error("--messages must be positive")
    try:
        session = open_session(a.session)
        if a.list_messages:
            msgs = [{"id": e["id"], "text": e["text"][:180]} for e in session.events if e["kind"] == "human"]
            print(json.dumps(msgs[-30:], indent=2, ensure_ascii=False))
            return 0
        selected, boundary = select_messages(session.events, a.request_id, a.messages or 1, a.whole_session)
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S-%f")
        output = Path(a.out).resolve() / stamp if a.out else default_out(session.cwd) / stamp
        out_root = key(str(output.parent))

        def generated(path):
            k = key(path)
            parts = [p.lower() for p in Path(path).parts]
            return k.startswith(out_root + os.sep) or any(parts[i:i + 2] == list(OUT_PARTS) for i in range(len(parts)))

        comparisons, warnings = session.extract(selected, generated)
        warnings = list(dict.fromkeys(warnings))
        notes = {}
        if a.notes:
            with open(a.notes, encoding="utf-8") as fh:
                notes = json.load(fh)
        export(comparisons, output, boundary, warnings, selected, a.html, a.title, notes, a.all_files)
        print(json.dumps({"harness": session.harness, "output": str(output),
                          "messages": [m["id"] for m, _ in selected], "comparisons": len(comparisons),
                          "partial": bool(warnings), "warnings": warnings}, indent=2, ensure_ascii=False))
        if a.html and not a.no_open:
            webbrowser.open((output / "index.html").as_uri())
        return 2 if warnings else 0
    except (EvidenceError, OSError, UnicodeError, KeyError, json.JSONDecodeError) as error:
        print(f"trail: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
