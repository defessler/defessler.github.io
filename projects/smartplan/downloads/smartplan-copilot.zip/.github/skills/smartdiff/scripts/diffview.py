#!/usr/bin/env python3
"""diffview: render a unified diff (git, diff -u, or `p4 diff -du`) as one
self-contained HTML page. Python stdlib only; the output makes no network requests.

  git diff -U5 | python diffview.py -o review.html
  python diffview.py session.diff -o review.html --title "Grapple tuning" --notes notes.json
  python diffview.py session.diff --blueprints work/bp -o review.html

notes.json (optional):  {"_summary": "Why this change set exists.",
                         "GrappleComponent.cpp": "Note shown above that file."}
Keys match a full path or a path suffix. `backticks` render as code.

--blueprints reads the folder bp_prepare.py and bp_export.py fill, and shows
each changed Blueprint as a semantic diff (graphs, nodes, links, pin defaults,
variables, components, class defaults) instead of "binary file".

--git-context REPO reads each file whole (HEAD and the working tree) so the
page can expand the lines between hunks. trail.py does the same from the
session record.
"""
import argparse, difflib, html, itertools, json, os, re, subprocess, sys
from datetime import datetime
from html import unescape

HUNK_RE = re.compile(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@ ?(.*)$')
CODE_EXT = {'.h', '.hpp', '.hh', '.hxx', '.inl', '.c', '.cc', '.cpp', '.cxx', '.cs',
            '.ush', '.usf', '.hlsl', '.js', '.jsx', '.ts', '.tsx', '.java', '.py'}
CPP_EXT = {'.c', '.cc', '.cpp', '.cxx', '.h', '.hh', '.hpp', '.hxx', '.inl'}
SYNTAX = re.compile(r'''
   (?P<com>//.*$|/\*.*?\*/|/\*.*$|^\s*\*(?:\s|/|$).*$)
  |(?P<str>"(?:\\.|[^"\\])*"?|'(?:\\.|[^'\\])*'?)
  |(?P<pp>^\s*\#\s*\w+)
  |(?P<mac>\b(?:\w+_API|WITH_[A-Z0-9_]+|UCLASS|USTRUCT|UENUM|UFUNCTION|UPROPERTY|UINTERFACE|UMETA|UPARAM|GENERATED_BODY|
      GENERATED_UCLASS_BODY|TEXT|LOCTEXT|NSLOCTEXT|check|checkf|checkSlow|ensure|ensureMsgf|
      ensureAlways|verify|UE_LOGF|UE_LOGFMT|UE_LOG|UE_CLOG|DECLARE_\w+|DEFINE_\w+|IMPLEMENT_\w+|TRACE_\w+|SCOPE_\w+)\b)
  |(?P<kw>\b(?:alignas|auto|bool|break|case|catch|char|class|const|constexpr|consteval|continue|
      default|delete|do|double|else|enum|explicit|extern|false|final|float|for|friend|if|inline|
      int|int8|int16|int32|int64|uint8|uint16|uint32|uint64|long|mutable|namespace|new|noexcept|
      nullptr|operator|override|private|protected|public|return|short|signed|sizeof|static|
      static_cast|dynamic_cast|reinterpret_cast|const_cast|struct|switch|template|this|throw|
      true|try|typedef|typename|union|unsigned|using|virtual|void|volatile|while|co_await|
      co_return|co_yield)\b)
  |(?P<type>\b[UAFTEIS][A-Z][A-Za-z0-9]*[a-z]\w*\b)
  |(?P<num>\b(?:0x[\da-fA-F]+|\d+\.?\d*(?:[eE][+-]?\d+)?)[fFuUlL]*\b)
  |(?P<fn>\b[A-Za-z_]\w*(?=\s*\())
''', re.M | re.X)
TOKENS = re.compile(r'\w+|\s+|[^\w\s]')
PY_SYNTAX = re.compile(r'''(?P<com>\#[^\n]*)|(?P<str>"(?:\\.|[^"\\])*"?|'(?:\\.|[^'\\])*'?)
    |(?P<kw>\b(?:and|as|assert|async|await|break|class|continue|def|del|elif|else|except|False|finally|for|from|if|import|in|is|lambda|None|not|or|pass|raise|return|True|try|while|with|yield)\b)
    |(?P<num>\b\d+(?:\.\d+)?\b)''', re.X)
FORMAT_SPEC = re.compile(r'%(?:\d+\$)?[-+#0]*(?:\d+|\*)?(?:\.(?:\d+|\*))?(?:hh|ll|[hljztL])?[diuoxXfFeEgGaAcspn]')
PREPROC_CONDITION = re.compile(r'^\s*#\s*(?:if|elif)\b')
PREPROC_DEFINED = re.compile(r'\bdefined\b')
ASSET_EXT = ('.uasset', '.umap')
# File-type badges in each file header, next to the Blueprint one.
LANG_NAME = {**dict.fromkeys(('.h', '.hpp', '.hh', '.hxx', '.inl', '.c', '.cc', '.cpp', '.cxx'), 'C++'),
             '.c': 'C', '.cs': 'C#', '.ush': 'HLSL', '.usf': 'HLSL', '.hlsl': 'HLSL',
             '.js': 'JavaScript', '.jsx': 'JavaScript', '.mjs': 'JavaScript', '.ts': 'TypeScript',
             '.tsx': 'TypeScript', '.java': 'Java', '.py': 'Python', '.sh': 'Shell', '.ps1': 'PowerShell',
             '.bat': 'Batch', '.cmd': 'Batch', '.md': 'Markdown', '.json': 'JSON', '.yml': 'YAML',
             '.yaml': 'YAML', '.toml': 'TOML', '.ini': 'INI', '.xml': 'XML', '.html': 'HTML', '.css': 'CSS',
             '.lua': 'Lua', '.rs': 'Rust', '.go': 'Go', '.cmake': 'CMake', '.uproject': 'JSON',
             '.uplugin': 'JSON', '.umap': 'Level', '.uasset': 'Asset'}


class FileDiff:
    def __init__(self, old=None, new=None):
        self.old, self.new = old, new
        self.status, self.binary = 'modified', False
        self.hunks, self.adds, self.dels, self.mods = [], 0, 0, 0
        self.bp = None  # Blueprint diff sections, when --blueprints covers this file

    @property
    def path(self):
        p = (self.old or self.new) if self.status == 'deleted' else (self.new or self.old)
        return (p or '(unnamed)').replace('\\', '/')


def clean_path(p):
    p = p.split('\t')[0].strip()
    if p == '/dev/null':
        return None
    if p[:2] in ('a/', 'b/'):
        p = p[2:]
    return re.sub(r'#\d+$', '', p)


def parse(text):
    files, cur, hunk, orem, nrem = [], None, None, 0, 0

    def start(old=None, new=None):
        nonlocal cur, hunk
        cur, hunk = FileDiff(old, new), None
        files.append(cur)

    for raw in text.splitlines():
        if hunk is not None and (orem > 0 or nrem > 0):
            tag, body = raw[:1], raw[1:].expandtabs(4)
            if tag in (' ', ''):
                hunk['lines'].append((' ', body)); orem -= 1; nrem -= 1; continue
            if tag == '-':
                hunk['lines'].append(('-', body)); orem -= 1; cur.dels += 1; continue
            if tag == '+':
                hunk['lines'].append(('+', body)); nrem -= 1; cur.adds += 1; continue
            if tag == '\\':
                continue
        if raw.startswith('\\'):
            continue
        if raw.startswith('diff --git '):
            m = re.match(r'diff --git a/(.*) b/(.*)$', raw)
            start(*(m.groups() if m else ()))
        elif raw.startswith('==== '):  # p4 diff -du header
            m = re.match(r'^==== (.+?)(?:#\d+)? - (.+?) ====', raw)
            start(m.group(1), m.group(1)) if m else start()
            if '(binary)' in raw or raw.rstrip().endswith('binary'):
                cur.binary = True
        elif raw.startswith('--- ') or raw.startswith('+++ '):
            if cur is None or cur.hunks:
                start()
            p = clean_path(raw[4:])
            if raw[0] == '-':
                if p is None: cur.status = 'added'
                elif cur.old is None: cur.old = p
            else:
                if p is None: cur.status = 'deleted'
                elif cur.new is None: cur.new = p
        elif raw.startswith('@@'):
            m = HUNK_RE.match(raw)
            if not m:
                continue
            if cur is None:
                start()
            a, b, c, d, ctx = m.groups()
            hunk = {'os': int(a), 'oc': int(b or 1), 'ns': int(c), 'nc': int(d or 1),
                    'ctx': ctx.strip().expandtabs(4), 'lines': []}
            orem, nrem = hunk['oc'], hunk['nc']
            cur.hunks.append(hunk)
        elif cur is not None:
            if raw.startswith('new file mode'): cur.status = 'added'
            elif raw.startswith('deleted file mode'): cur.status = 'deleted'
            elif raw.startswith('rename from '): cur.status, cur.old = 'renamed', raw[12:]
            elif raw.startswith('rename to '): cur.new = raw[10:]
            elif raw.startswith('Binary files') or raw.startswith('GIT binary patch'): cur.binary = True
    return [f for f in files if f.hunks or f.binary or f.status != 'modified']


# ---------------------------------------------------------------- Blueprints

def split_top(s, sep=','):
    """Split on sep outside quotes and parentheses."""
    out, depth, q, cur = [], 0, False, []
    for ch in s:
        if ch == '"':
            q = not q
        elif not q and ch == '(':
            depth += 1
        elif not q and ch == ')':
            depth -= 1
        if ch == sep and not q and depth == 0:
            out.append(''.join(cur)); cur = []
        else:
            cur.append(ch)
    if cur:
        out.append(''.join(cur))
    return [x for x in out if x.strip()]


def kv(item):
    k, _, v = item.partition('=')
    return k.strip(), v.strip()


def unq(v):
    return v[1:-1] if len(v) >= 2 and v[0] == v[-1] == '"' else v


def struct(v):
    """(A=1,B="x") -> {'A': '1', 'B': 'x'}"""
    v = v.strip()
    if v.startswith('(') and v.endswith(')'):
        v = v[1:-1]
    return {k: unq(x) for k, x in map(kv, split_top(v))}


def parse_t3d(text):
    """Return {relpath: obj}. relpath drops the package so revisions line up:
    '' is the root object, 'EventGraph.K2Node_CallFunction_0' a node."""
    objs, stack = {}, []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith('Begin Object'):
            name = re.search(r'\bName="([^"]*)"', s)
            name = name.group(1) if name else '?'
            cls = re.search(r'\bClass=(\S+)', s)
            ep = re.search(r'\bExportPath="([^"]*)"', s)
            key = None
            if ep:
                inner = ep.group(1)
                if not cls and "'" in inner:
                    cls = re.match(r"([^']+)'", inner)
                path = inner.split("'")[1] if "'" in inner else inner
                key = path.split(':', 1)[1] if ':' in path else ''
            if key is None:
                key = '.'.join([o['name'] for o in stack[1:]] + [name]) if stack else ''
            o = objs.setdefault(key, {'name': name, 'cls': '', 'props': {}, 'pins': [],
                                      'parent': stack[-1]['key'] if stack else None, 'key': key})
            if cls:
                o['cls'] = cls.group(1).rsplit('.', 1)[-1]
            stack.append(o)
        elif s.startswith('End Object'):
            if stack:
                stack.pop()
        elif stack and s.startswith('CustomProperties Pin'):
            body = s[s.index('(') + 1:s.rindex(')')] if '(' in s else ''
            stack[-1]['pins'].append({k: v for k, v in map(kv, split_top(body))})
        elif stack and '=' in s and not s.startswith('CustomProperties'):
            k, v = kv(s)
            stack[-1]['props'][k] = v
    return objs


def short_ref(v):
    """/Script/CoreUObject.Class'/Script/Engine.Actor' -> Actor"""
    v = unq(v)
    m = re.match(r"^[\w/.]+'([^']*)'$", v)
    if m:
        v = m.group(1)
    if v.startswith('/') and ' ' not in v:
        v = re.split(r'[.:/]', v)[-1]
    return v


def short_val(v, limit=90):
    v = short_ref(v) if v else v
    return v if len(v) <= limit else v[:limit - 1] + '…'


def node_title(o):
    c, p = o['cls'], o['props']
    ref = lambda k, f='MemberName': struct(p[k]).get(f, '') if k in p else ''
    if c in ('K2Node_CallFunction', 'K2Node_CallArrayFunction', 'K2Node_CallParentFunction',
             'K2Node_PromotableOperator', 'K2Node_CommutativeAssociativeBinaryOperator',
             'K2Node_CallMaterialParameterCollectionFunction', 'K2Node_Message'):
        return ref('FunctionReference') or c
    if c in ('K2Node_VariableGet', 'K2Node_VariableSet'):
        return ('Get ' if c.endswith('Get') else 'Set ') + ref('VariableReference')
    if c == 'K2Node_Event':
        return 'Event ' + (ref('EventReference') or unq(p.get('CustomFunctionName', '')))
    if c == 'K2Node_CustomEvent':
        return 'Custom Event ' + unq(p.get('CustomFunctionName', ''))
    if c in ('K2Node_FunctionEntry', 'K2Node_FunctionResult'):
        return 'Entry' if c.endswith('Entry') else 'Return'
    if c == 'K2Node_IfThenElse':
        return 'Branch'
    if c == 'K2Node_Knot':
        return 'Reroute'
    if c == 'K2Node_DynamicCast':
        return 'Cast To ' + short_ref(p.get('TargetType', '?'))
    if c == 'K2Node_MacroInstance' and 'MacroGraphReference' in p:
        return short_ref(struct(p['MacroGraphReference']).get('MacroGraph', 'Macro'))
    if c == 'EdGraphNode_Comment':
        return 'Comment "' + short_val(unq(p.get('NodeComment', '')), 40) + '"'
    if c in ('K2Node_SpawnActorFromClass', 'K2Node_ConstructObjectFromClass', 'K2Node_CreateWidget'):
        return c.replace('K2Node_', '')
    if 'InputAction' in p:
        return 'Input ' + short_ref(p['InputAction'])
    return re.sub(r'^(K2Node_|EdGraphNode_|AnimGraphNode_|MaterialGraphNode_)', '', c) or o['name']


NODE_NOISE = {'NodePosX', 'NodePosY', 'NodeWidth', 'NodeHeight', 'NodeGuid', 'ErrorType',
              'ErrorMsg', 'bHasCompilerMessage', 'bCommentBubblePinned', 'bCommentBubbleVisible',
              'AdvancedPinDisplay', 'bCommentBubbleMakeVisible'}
ROOT_SKIP = re.compile(r'^(NewVariables|UbergraphPages|FunctionGraphs|MacroGraphs|'
                       r'DelegateSignatureGraphs|IntermediateGeneratedGraphs|LastEditedDocuments|'
                       r'EventGraphs|CategorySorting|GeneratedClass|SkeletonGeneratedClass|'
                       r'ThumbnailInfo|BlueprintGuid|SimpleConstructionScript|InheritableComponentHandler|'
                       r'BlueprintSystemVersion|Status|bCachedDependenciesUpToDate|CachedDependencies|'
                       r'CachedUDSDependencies|CompileStatus|bLegacyGeneratedClassIsAuthoritative|'
                       r'BookmarkNodes|Bookmarks)\b')
CDO_SKIP = re.compile(r'^(UberGraphFrame|RootComponent|DefaultSceneRoot|BlueprintCreatedComponents)\b')


def pin_default(p):
    for k in ('DefaultValue', 'DefaultObject', 'DefaultTextValue'):
        if k in p and unq(p[k]) not in ('', 'None'):
            return unq(p[k])
    return ''


def graph_model(objs, gkey):
    nodes = {o['key']: o for o in objs.values() if o['parent'] == gkey}
    by_name = {o['name']: o for o in nodes.values()}
    model, edges = {}, set()
    for o in nodes.values():
        nid = o['props'].get('NodeGuid', o['name'])
        pins = {}
        for p in o['pins']:
            if p.get('bHidden') == 'True' and not p.get('LinkedTo'):
                continue
            pins[unq(p.get('PinName', '?'))] = p
        model[nid] = {'title': node_title(o), 'cls': o['cls'], 'props': o['props'], 'pins': pins,
                      'pos': (o['props'].get('NodePosX'), o['props'].get('NodePosY'))}
    for o in nodes.values():
        nid = o['props'].get('NodeGuid', o['name'])
        for p in o['pins']:
            if p.get('Direction') != '"EGPD_Output"' and p.get('Direction') != 'EGPD_Output':
                continue
            for link in split_top(p.get('LinkedTo', '()').strip('()')):
                parts = link.split()
                if len(parts) != 2 or parts[0] not in by_name:
                    continue
                tgt = by_name[parts[0]]
                tpin = next((unq(q.get('PinName', '?')) for q in tgt['pins'] if q.get('PinId') == parts[1]), '?')
                edges.add((nid, unq(p.get('PinName', '?')), tgt['props'].get('NodeGuid', tgt['name']), tpin))
    return model, edges


def label(model_a, model_b, nid):
    n = model_b.get(nid) or model_a.get(nid)
    return n['title'] if n else nid[:8]


def diff_graph(oa, ob, ga, gb):
    """(rows, svg) for one graph. Rows are (kind, html), kind add, del, mod or info.
    svg is a drawing of the graph with the changes marked, or '' when it has no nodes."""
    ma, ea = graph_model(oa, ga) if ga is not None else ({}, set())
    mb, eb = graph_model(ob, gb) if gb is not None else ({}, set())
    rows, moved, changed = [], 0, {}
    E = lambda s: html.escape(s, quote=False)
    for nid in mb.keys() - ma.keys():
        rows.append(('add', f'Node <b>{E(mb[nid]["title"])}</b>'))
    for nid in ma.keys() - mb.keys():
        rows.append(('del', f'Node <b>{E(ma[nid]["title"])}</b>'))
    for nid in ma.keys() & mb.keys():
        a, b = ma[nid], mb[nid]
        changes, pins_changed = [], set()
        for k in sorted((a['props'].keys() | b['props'].keys()) - NODE_NOISE):
            va, vb = a['props'].get(k, ''), b['props'].get(k, '')
            if va != vb:
                changes.append(f'{E(k)}: <s>{E(short_val(va)) or "∅"}</s> → {E(short_val(vb)) or "∅"}')
        for pn in sorted(a['pins'].keys() | b['pins'].keys()):
            pa, pb = a['pins'].get(pn), b['pins'].get(pn)
            if pa is None or pb is None or pin_default(pa) != pin_default(pb):
                pins_changed.add(pn)
            if pa is None:
                changes.append(f'pin <code>{E(pn)}</code> added')
            elif pb is None:
                changes.append(f'pin <code>{E(pn)}</code> removed')
            elif pin_default(pa) != pin_default(pb):
                changes.append(f'<code>{E(pn)}</code>: <s>{E(short_val(pin_default(pa))) or "∅"}</s>'
                               f' → {E(short_val(pin_default(pb))) or "∅"}')
        if changes:
            rows.append(('mod', f'Node <b>{E(b["title"])}</b>: ' + '; '.join(changes)))
            changed[nid] = (unescape(re.sub(r'<[^>]+>', '', '; '.join(changes))), pins_changed)
        elif a['pos'] != b['pos']:
            moved += 1
    fmt = lambda e, ma_, mb_: (f'<b>{E(label(ma_, mb_, e[0]))}</b>.<code>{E(e[1])}</code> → '
                               f'<b>{E(label(ma_, mb_, e[2]))}</b>.<code>{E(e[3])}</code>')
    for e in sorted(eb - ea):
        rows.append(('add', 'Wire ' + fmt(e, ma, mb)))
    for e in sorted(ea - eb):
        rows.append(('del', 'Wire ' + fmt(e, ma, mb)))
    if moved:
        rows.append(('info', f'{moved} node{"s" if moved != 1 else ""} moved (layout only)'))
    order = {'del': 0, 'mod': 1, 'add': 2, 'info': 3}
    return sorted(rows, key=lambda r: order[r[0]]), graph_svg(ma, mb, ea, eb, changed)


# ---------------------------------------------------------------- graph drawing
# A simplified Blueprint editor view: nodes at their saved positions, pins
# colored by type, wires as curves. T3D saves no size for most nodes, so boxes
# are sized from the title and pin labels. Close to the editor, not exact.

PIN_COLORS = {'exec': 'var(--ink)', 'bool': '#c4262e', 'byte': '#18a090', 'enum': '#18a090',
              'int': '#1fe3af', 'int64': '#acd7c0', 'real': '#9ef04a', 'float': '#9ef04a',
              'double': '#9ef04a', 'string': '#f04ad0', 'name': '#c88cff', 'text': '#e67fb3',
              'object': '#00a8f4', 'softobject': '#7fd6ff', 'class': '#9b5cf0', 'softclass': '#c8a2ff',
              'interface': '#d8f0a0', 'delegate': '#ff5050', 'mcdelegate': '#ff5050', 'struct': '#3a7bd5'}
STRUCT_COLORS = {'Vector': '#f5c400', 'Rotator': '#a0b4ff', 'Transform': '#ff8a2a'}
EVENT_CLS = ('K2Node_Event', 'K2Node_CustomEvent', 'K2Node_ComponentBoundEvent', 'K2Node_ActorBoundEvent',
             'K2Node_InputAction', 'K2Node_InputKey', 'K2Node_EnhancedInputAction')
# Close to the editor's own metrics at 1:1 zoom: a 30-unit title bar, 24-unit
# pin rows. Widths are estimated from text, since T3D saves no node size.
G_HEAD, G_ROW, G_KNOT = 30, 24, 12
TITLE_CH, LABEL_CH = 7.6, 6.6
GRID_IDS = itertools.count()


def pin_info(p):
    """(category, color, is_output, is_linked) for one raw pin."""
    cat = unq(p.get('PinType.PinCategory', ''))
    sub = short_ref(p.get('PinType.PinSubCategoryObject', '')) if cat == 'struct' else ''
    color = STRUCT_COLORS.get(sub) or PIN_COLORS.get(cat, 'var(--muted)')
    return cat, color, 'Output' in p.get('Direction', ''), bool(p.get('LinkedTo', '()').strip('()'))


def head_color(n):
    c = n['cls']
    if c in EVENT_CLS:
        return '#9a2a2a'
    if c in ('K2Node_FunctionEntry', 'K2Node_FunctionResult'):
        return '#6a3d9a'
    if c == 'K2Node_DynamicCast':
        return '#22766e'
    if c.startswith('K2Node_Variable'):
        return '#3d4a57'
    if c.startswith('K2Node_Call') or c in ('K2Node_Message', 'K2Node_PromotableOperator',
                                             'K2Node_CommutativeAssociativeBinaryOperator'):
        impure = any(pin_info(p)[0] == 'exec' for p in n['pins'].values())
        return '#2c5d9c' if impure else '#3f7a3a'
    return '#4b5058'


def num(v, default=0):
    try:
        return int(float(unq(v)))
    except (TypeError, ValueError):
        return default


def node_box(n, wired=()):
    """Geometry for one node: x, y, w, h, kind, pin rows and pin anchors by name.
    wired names the pins a drawn wire touches, so they draw filled even when
    only the other end of the link carries LinkedTo."""
    x, y = num(n['pos'][0]), num(n['pos'][1])
    box = {'x': x, 'y': y, 'kind': 'node', 'ins': [], 'outs': [], 'anchors': {}, 'title': n['title']}
    if n['cls'] == 'K2Node_Knot':
        # A reroute is a small dot that both wires meet at its center.
        box.update(kind='knot', w=G_KNOT, h=G_KNOT)
        for pn in n['pins']:
            box['anchors'][pn] = (x + G_KNOT // 2, y + G_KNOT // 2)
        return box
    if n['cls'] == 'EdGraphNode_Comment':
        box.update(kind='comment', w=num(n['props'].get('NodeWidth'), 400), h=num(n['props'].get('NodeHeight'), 200),
                   title=short_val(unq(n['props'].get('NodeComment', '')), 60))
        return box
    gone = n.get('gone', ())
    for pn, p in n['pins'].items():
        cat, color, out, linked = pin_info(p)
        linked = linked or pn in wired
        lab = '' if cat == 'exec' and pn in ('execute', 'then', 'exec') and pn not in gone else \
            'Return Value' if pn == 'ReturnValue' else 'Target' if pn == 'self' else pn
        dv = '' if linked or out or pn in gone else short_val(pin_default(p), 14)
        box['outs' if out else 'ins'].append((pn, lab, dv, color, cat, linked, pn in gone))
    width = lambda side: max([len(r[1]) + (len(r[2]) + 1 if r[2] else 0) for r in side] or [0])
    w = max(len(box['title']) * TITLE_CH + 32, (width(box['ins']) + width(box['outs'])) * LABEL_CH + 60, 120)
    box['w'] = int(min(w, 380))
    box['h'] = G_HEAD + max(len(box['ins']), len(box['outs'])) * G_ROW + 8
    for i, r in enumerate(box['ins']):
        box['anchors'][r[0]] = (x, y + G_HEAD + G_ROW * i + G_ROW // 2)
    for i, r in enumerate(box['outs']):
        box['anchors'][r[0]] = (x + box['w'], y + G_HEAD + G_ROW * i + G_ROW // 2)
    return box


def svg_node(b, state, tip, pins_changed):
    A = lambda s: html.escape(str(s), quote=True)
    x, y, w, h = b['x'], b['y'], b['w'], b['h']
    cls = f'n {state}'.strip()
    out = [f'<g class="{cls}"><title>{A(tip)}</title>']
    if b['kind'] == 'comment':
        out.append(f'<rect class="cm" x="{x}" y="{y}" width="{w}" height="{h}" rx="4"/>'
                   f'<text class="ct" x="{x + 8}" y="{y + 16}">{A(b["title"])}</text></g>')
        return ''.join(out)
    if b['kind'] == 'knot':
        r = w // 2
        out.append(f'<circle class="kn" cx="{x + r}" cy="{y + r}" r="{r - 1}" '
                   f'style="fill:{b.get("color", "var(--muted)")}"/></g>')
        return ''.join(out)
    hc = b['hc']
    chars = max(4, int((w - 24) / TITLE_CH))
    title = b['title'] if len(b['title']) <= chars else b['title'][:chars - 1] + '…'
    out.append(f'<rect class="nb" x="{x}" y="{y}" width="{w}" height="{h}" rx="6"/>'
               f'<path d="M{x} {y + G_HEAD}V{y + 6}q0 -6 6 -6H{x + w - 6}q6 0 6 6V{y + G_HEAD}Z" fill="{hc}"/>'
               f'<text class="nt" x="{x + 10}" y="{y + 20}">{A(title)}</text>')
    for side, rows in (('in', b['ins']), ('out', b['outs'])):
        for i, (pn, lab, dv, color, cat, linked, gone) in enumerate(rows):
            px = x if side == 'in' else x + w
            py = y + G_HEAD + G_ROW * i + G_ROW // 2
            fill = color if linked else 'none'
            pc = (' on' if linked else '') + (' gone' if gone else '')
            if cat == 'exec':
                tx = px + (10 if side == 'in' else -10)
                out.append(f'<path class="pin{pc}" d="M{tx - 5} {py - 6}H{tx}L{tx + 5} {py}L{tx} {py + 6}H{tx - 5}Z" '
                           f'fill="{fill}" stroke="{color}" stroke-width="1.5"/>')
            else:
                cx = px + (10 if side == 'in' else -10)
                out.append(f'<circle class="pin{pc}" cx="{cx}" cy="{py}" r="5" fill="{fill}" stroke="{color}" '
                           f'stroke-width="1.5"/>')
            if not lab and not dv:
                continue
            chg = ' chg' if pn in pins_changed else ''
            tc = ' class="gone"' if gone else ''
            if side == 'in':
                dv_html = f'<tspan class="dv{chg}"> {A(dv)}</tspan>' if dv else ''
                out.append(f'<text{tc} x="{x + 20}" y="{py + 4}">{A(lab)}{dv_html}</text>')
            else:
                out.append(f'<text{tc} x="{x + w - 20}" y="{py + 4}" text-anchor="end">{A(lab)}</text>')
    out.append('</g>')
    return ''.join(out)


def draw_layer(name, items, wires, models, spare=None):
    """One view of a graph. items are (nid, node, state, tip, changed pins), wires
    are (edge, state). models resolve a wire's source pin for its color. spare
    holds boxes from the other revision, for a pin a ghost wire still names."""
    wired = {}
    for e, _ in wires:
        wired.setdefault(e[0], set()).add(e[1])
        wired.setdefault(e[2], set()).add(e[3])
    boxes, meta = {}, {}
    for nid, n, state, tip, pins in items:
        b = node_box(n, wired.get(nid, ()))
        b['hc'] = head_color(n)
        boxes[nid], meta[nid] = b, (state, tip, pins)

    def anchor(nid, pin, side):
        for src in (boxes.get(nid), (spare or {}).get(nid)):
            if src and pin in src['anchors']:
                return src['anchors'][pin]
        b = boxes[nid]
        return (b['x'] + (b['w'] if side == 'out' else 0), b['y'] + G_HEAD // 2)
    paths = []
    for e, state in sorted(wires, key=lambda t: (t[1] != 'del', t[0])):
        if e[0] not in boxes or e[2] not in boxes:
            continue
        src = next((m[e[0]]['pins'][e[1]] for m in models if e[1] in m.get(e[0], {}).get('pins', {})), None)
        cat, color = pin_info(src)[:2] if src else ('', 'var(--muted)')
        (x1, y1), (x2, y2) = anchor(e[0], e[1], 'out'), anchor(e[2], e[3], 'in')
        dx = max(40, abs(x2 - x1) // 2)
        cls = ' '.join(c for c in ('w', 'x' if cat == 'exec' else '', state) if c)
        paths.append(f'<path class="{cls}" stroke="{color}" d="M{x1} {y1}C{x1 + dx} {y1} {x2 - dx} {y2} {x2} {y2}"/>')
        for k in (e[0], e[2]):
            if boxes[k]['kind'] == 'knot' and cat != 'wildcard':
                boxes[k].setdefault('color', color)
    order = sorted(boxes, key=lambda i: (boxes[i]['kind'] != 'comment', meta[i][0] != 'del'))
    nodes = [svg_node(boxes[i], *meta[i]) for i in order]
    comments = [s for i, s in zip(order, nodes) if boxes[i]['kind'] == 'comment']
    rest = [s for i, s in zip(order, nodes) if boxes[i]['kind'] != 'comment']
    svg = f'<g class="L L-{name}">' + ''.join(comments + paths + rest) + '</g>'
    return boxes, svg


def graph_svg(ma, mb, ea, eb, changed):
    """Inline SVG of one graph in three switchable views: Changes (the new layout
    with removed nodes and wires as ghosts beside their old neighbors), Before (the old
    graph at its old layout) and After (the new graph alone). Big graphs open
    on the changed area."""
    if not ma and not mb:
        return ''
    tip = lambda n, nid, st: n['title'] + {'add': ' (added)', 'del': ' (removed)'}.get(st, '') + \
        (': ' + changed[nid][0] if nid in changed else '')
    pins = lambda nid: changed.get(nid, ('', set()))[1]
    st_new = lambda nid: 'add' if nid not in ma else 'mod' if nid in changed else ''
    st_old = lambda nid: 'del' if nid not in mb else 'mod' if nid in changed else ''
    after_items = [(nid, n, st_new(nid), tip(n, nid, st_new(nid)), pins(nid)) for nid, n in mb.items()]
    before_items = [(nid, n, st_old(nid), tip(n, nid, st_old(nid)), pins(nid)) for nid, n in ma.items()]
    wires_all = [(e, 'add' if e not in ea else 'del' if e not in eb else '') for e in ea | eb]
    # Changes draws the new layout, so a removed node can't keep its old
    # coordinates: when the kept nodes around it moved, it would land far from
    # them with its dashed wires stretched across the graph. Each ghost moves
    # with the wired neighbor that moved least (a node that moved far usually
    # went to a new job, and an average lands between the two), else with the
    # nearest kept node.
    pos = lambda n: (num(n['pos'][0]), num(n['pos'][1]))
    shift = {nid: (pos(mb[nid])[0] - pos(n)[0], pos(mb[nid])[1] - pos(n)[1]) for nid, n in ma.items() if nid in mb}
    gone = [nid for nid in ma if nid not in mb]
    near = {nid: set() for nid in gone}
    for e in ea:
        if e[0] in near:
            near[e[0]].add(e[2])
        if e[2] in near:
            near[e[2]].add(e[0])
    for _ in range(len(gone) + 1):
        todo = [g for g in gone if g not in shift]
        if not todo:
            break
        for g in todo:
            ds = [shift[k] for k in near[g] if k in shift]
            if ds:
                shift[g] = min(ds, key=lambda d: d[0] ** 2 + d[1] ** 2)
    kept = [k for k in ma if k in mb]
    for g in gone:
        if g not in shift:
            gx, gy = pos(ma[g])
            k = min(kept, key=lambda k: (pos(ma[k])[0] - gx) ** 2 + (pos(ma[k])[1] - gy) ** 2, default=None)
            shift[g] = shift[k] if k else (0, 0)
    moved = lambda n, d: {**n, 'pos': (str(pos(n)[0] + d[0]), str(pos(n)[1] + d[1]))}
    # A ghost often lands where its replacement now sits. Step it up or down
    # to the nearest spot clear of live nodes and other ghosts.
    taken = [node_box(n) for n in mb.values() if n['cls'] != 'EdGraphNode_Comment']
    hit = lambda a, b: a['x'] < b['x'] + b['w'] and b['x'] < a['x'] + a['w'] and \
        a['y'] < b['y'] + b['h'] and b['y'] < a['y'] + a['h']
    for g in gone:
        if ma[g]['cls'] == 'EdGraphNode_Comment':
            continue
        base = shift[g]
        for k in range(13):
            dy = (k + 1) // 2 * 32 * (1 if k % 2 else -1)
            b = node_box(moved(ma[g], (base[0], base[1] + dy)))
            if not any(hit(b, t) for t in taken):
                shift[g] = (base[0], base[1] + dy)
                taken.append(b)
                break
    ghosts = [(nid, moved(n, shift[nid]), st, t, p) for nid, n, st, t, p in before_items if st == 'del']
    # A kept node that lost a pin still shows it in Changes, struck through,
    # so a removed wire from that pin starts somewhere visible.
    def with_lost(nid, n):
        lost = {pn: p for pn, p in ma.get(nid, {}).get('pins', {}).items() if pn not in n['pins']}
        return {**n, 'pins': {**n['pins'], **lost}, 'gone': set(lost)} if lost else n
    change_items = [(nid, with_lost(nid, n), *rest) for nid, n, *rest in after_items]
    spare = {nid: node_box(moved(n, shift.get(nid, (0, 0)))) for nid, n in ma.items()}
    layers = [draw_layer('changes', change_items + ghosts, wires_all, (mb, ma), spare)]
    both = bool(ma) and bool(mb)
    if both:
        layers.append(draw_layer('before', before_items, [(e, '' if e in eb else 'del') for e in ea], (ma,)))
        layers.append(draw_layer('after', after_items, [(e, '' if e in ea else 'add') for e in eb], (mb,)))
    boxes = {}
    for bx, _ in layers:
        for nid, b in bx.items():
            boxes[f'{len(boxes)}'] = b
    focus_boxes = [b for nid, b in layers[0][0].items()
                   if (st_new(nid) if nid in mb else 'del') or any(nid in (e[0], e[2]) for e, s in wires_all if s)]

    def bbox(bs, pad):
        return (min(b['x'] for b in bs) - pad, min(b['y'] for b in bs) - pad,
                max(b['x'] + b['w'] for b in bs) + pad, max(b['y'] + b['h'] for b in bs) + pad)
    x0, y0, x1, y1 = bbox(list(boxes.values()), 40)
    full = f'{x0} {y0} {x1 - x0} {y1 - y0}'
    fb = (x0, y0, x1, y1)
    note = ''
    count = len(layers[0][0])
    if (x1 - x0 > 2600 or y1 - y0 > 1600) and focus_boxes:
        x0, y0, x1, y1 = bbox(focus_boxes, 240)
        shown = sum(1 for b in layers[0][0].values()
                    if b['x'] < x1 and b['x'] + b['w'] > x0 and b['y'] < y1 and b['y'] + b['h'] > y0)
        note = (f'<p class="bpg-note">Starts on the changed area, {shown} of {count} nodes. '
                f'Drag or zoom out, or press All, to see the rest.</p>')
    w, h = x1 - x0, y1 - y0
    scale = max(0.6, min(1.0, 1100 / w))
    # Editor-style grid in graph units, so it pans and zooms with the nodes:
    # a faint line every 16 units, a stronger one every 128. Sized far past the
    # graph so a drag or a full zoom-out never runs off its edge.
    gid = f'bpg{next(GRID_IDS)}'
    span = max(fb[2] - fb[0], fb[3] - fb[1], w, h) * 6
    gx, gy = (fb[0] + fb[2]) / 2 - span / 2, (fb[1] + fb[3]) / 2 - span / 2
    body = [f'<defs><pattern id="{gid}m" width="16" height="16" patternUnits="userSpaceOnUse">'
            f'<path class="g1" d="M16 0H0V16" vector-effect="non-scaling-stroke"/></pattern>'
            f'<pattern id="{gid}" width="128" height="128" patternUnits="userSpaceOnUse">'
            f'<rect width="128" height="128" fill="url(#{gid}m)"/>'
            f'<path class="g2" d="M128 0H0V128" vector-effect="non-scaling-stroke"/></pattern></defs>'
            f'<rect class="grid" x="{gx:.0f}" y="{gy:.0f}" width="{span:.0f}" height="{span:.0f}" fill="url(#{gid})"/>']
    body += [svg for _, svg in layers]
    legend = ('<p class="bpg-key"><span class="k-add">added</span><span class="k-del">removed</span>'
              '<span class="k-mod">changed</span> Drag to pan, scroll to zoom, double-click to reset. '
              'Hover a node for its changes.</p>')
    views = ('<span class="bpg-views" role="group" aria-label="Graph view">'
             '<button type="button" data-l="changes" aria-pressed="true" title="New layout, removed parts as ghosts">Changes</button>'
             '<button type="button" data-l="before" aria-pressed="false" title="The old graph at its old layout">Before</button>'
             '<button type="button" data-l="after" aria-pressed="false" title="The new graph alone">After</button></span>'
             if both else '')
    tools = (f'<div class="bpg-tools">{views}<button type="button" data-z="in" title="Zoom in">+</button>'
             '<button type="button" data-z="out" title="Zoom out">−</button>'
             '<button type="button" data-z="fit" title="Back to the starting view">Fit</button>'
             '<button type="button" data-z="all" title="Show the whole graph">All</button></div>')
    return (f'<div class="bpg" data-l="changes">{tools}<svg viewBox="{x0} {y0} {w} {h}" data-full="{full}" width="100%" '
            f'height="{min(560, max(160, int(h * scale)))}" role="img" aria-label="Graph drawing">'
            f'{"".join(body)}</svg></div>' + note + legend)


def variables(objs):
    out = {}
    for k, v in (objs.get('', {}).get('props') or {}).items():
        if k.startswith('NewVariables('):
            s = struct(v)
            out[s.get('VarGuid', s.get('VarName'))] = s
    return out


def var_type(s):
    t = struct(s.get('VarType', '()'))
    base = t.get('PinSubCategoryObject') and short_ref(t['PinSubCategoryObject']) or \
        t.get('PinSubCategory') or t.get('PinCategory', '?')
    cont = t.get('ContainerType')
    return f'{cont}<{base}>' if cont and cont != 'None' else base


def prop_rows(pa, pb, skip):
    rows = []
    E = lambda s: html.escape(s, quote=False)
    for k in sorted(pa.keys() | pb.keys()):
        if skip.match(k):
            continue
        va, vb = pa.get(k), pb.get(k)
        if va == vb:
            continue
        if va is None:
            rows.append(('add', f'<code>{E(k)}</code> = {E(short_val(vb))}'))
        elif vb is None:
            rows.append(('del', f'<code>{E(k)}</code> = {E(short_val(va))}'))
        else:
            rows.append(('mod', f'<code>{E(k)}</code>: <s>{E(short_val(va))}</s> → {E(short_val(vb))}'))
    return rows


def is_graph(o):
    return o['cls'].endswith('Graph') and o['cls'] not in ('BlueprintGeneratedClass',)


def bp_diff(old, new):
    """old/new are (meta, objs, cdo_objs) or None. Returns [(section title, status, rows)]."""
    om, oa, ca = old or ({}, {}, {})
    nm, ob, cb = new or ({}, {}, {})
    E = lambda s: html.escape(s, quote=False)
    sections = []

    va, vb = variables(oa), variables(ob)
    rows = []
    for g in vb.keys() - va.keys():
        rows.append(('add', f'<b>{E(vb[g].get("VarName", "?"))}</b> : {E(var_type(vb[g]))}'))
    for g in va.keys() - vb.keys():
        rows.append(('del', f'<b>{E(va[g].get("VarName", "?"))}</b> : {E(var_type(va[g]))}'))
    for g in va.keys() & vb.keys():
        a, b, ch = va[g], vb[g], []
        if a.get('VarName') != b.get('VarName'):
            ch.append(f'renamed from {E(a.get("VarName", "?"))}')
        if var_type(a) != var_type(b):
            ch.append(f'type <s>{E(var_type(a))}</s> → {E(var_type(b))}')
        for k in ('DefaultValue', 'Category', 'PropertyFlags', 'RepNotifyFunc', 'ReplicationCondition'):
            if a.get(k) != b.get(k):
                ch.append(f'{k} <s>{E(short_val(a.get(k) or "∅"))}</s> → {E(short_val(b.get(k) or "∅"))}')
        if ch:
            rows.append(('mod', f'<b>{E(b.get("VarName", "?"))}</b>: ' + '; '.join(ch)))
    if rows:
        sections.append(('Variables', None, rows))

    def graphs(meta, objs):
        authored = set(meta.get('graphs') or [])
        out = {}
        for k, o in objs.items():
            if not is_graph(o):
                continue
            top = o if o['parent'] == '' else None
            if top is not None and authored and o['name'] not in authored:
                continue
            if not authored and re.search(r'(_MERGED$|^ExecuteUbergraph_)', o['name']):
                continue
            if top is None:  # a nested graph (collapsed node, state machine): keep if its root graph is kept
                root = k.split('.')[0]
                if root not in objs or (authored and objs[root]['name'] not in authored):
                    continue
            out[k] = o
        return out
    ga, gb = graphs(om, oa), graphs(nm, ob)
    for k in sorted(ga.keys() | gb.keys(), key=lambda x: (x.count('.'), x.lower())):
        st = 'added' if k not in ga else 'deleted' if k not in gb else None
        rows, svg = diff_graph(oa, ob, k if k in ga else None, k if k in gb else None)
        if st or rows:
            title = k.replace('.', ' › ')
            sections.append((f'Graph {title}', st, rows, svg))

    def in_graph(o, objs):  # graph nodes, compiler graphs and their contents are covered above or noise
        while o is not None:
            if is_graph(o):
                return True
            o = objs.get(o['parent']) if o['parent'] is not None else None
        return False
    other_a = {k: o for k, o in oa.items() if k and not in_graph(o, oa)}
    other_b = {k: o for k, o in ob.items() if k and not in_graph(o, ob)}
    rows = []
    for k in sorted(other_b.keys() - other_a.keys()):
        rows.append(('add', f'<b>{E(other_b[k]["name"])}</b> ({E(other_b[k]["cls"])})'))
    for k in sorted(other_a.keys() - other_b.keys()):
        rows.append(('del', f'<b>{E(other_a[k]["name"])}</b> ({E(other_a[k]["cls"])})'))
    for k in sorted(other_a.keys() & other_b.keys()):
        sub = prop_rows(other_a[k]['props'], other_b[k]['props'], re.compile(r'^$^'))
        for kind, text in sub:
            rows.append((kind, f'<b>{E(other_b[k]["name"])}</b> {text}'))
    if rows:
        sections.append(('Components and subobjects', None, rows))

    rows = prop_rows(oa.get('', {}).get('props', {}), ob.get('', {}).get('props', {}), ROOT_SKIP)
    if om.get('parent') != nm.get('parent') and old and new:
        rows.insert(0, ('mod', f'Parent class <s>{E(om.get("parent") or "?")}</s> → {E(nm.get("parent") or "?")}'))
    if rows:
        sections.append(('Blueprint settings', None, rows))
    rows = prop_rows(ca.get('', {}).get('props', {}), cb.get('', {}).get('props', {}), CDO_SKIP)
    if rows and old and new:
        sections.append(('Class defaults', None, rows))
    return sections


def load_side(folder, flat):
    meta_f = os.path.join(folder, flat + '.json')
    if not os.path.exists(meta_f):
        return None
    with open(meta_f, encoding='utf-8') as fh:
        meta = json.load(fh)
    read = lambda fn: parse_t3d(open(fn, encoding='utf-8', errors='replace').read()) \
        if os.path.exists(fn) else {}
    return meta, read(os.path.join(folder, flat + '.t3d')), read(os.path.join(folder, flat + '.cdo.t3d'))


def attach_blueprints(files, folder):
    with open(os.path.join(folder, 'manifest.json'), encoding='utf-8') as fh:
        man = json.load(fh)
    for a in man.get('assets', []):
        rel = a['file'].replace('\\', '/')
        old, new = load_side(os.path.join(folder, 'old'), a['flat']), load_side(os.path.join(folder, 'new'), a['flat'])
        f = next((x for x in files if x.path == rel or x.path.endswith('/' + rel)), None)
        if f is None:
            f = FileDiff(None if a['status'] == 'added' else rel, None if a['status'] == 'deleted' else rel)
            f.status = a['status'] if a['status'] in ('added', 'deleted') else 'modified'
            f.binary = True
            files.append(f)
        meta = (new or old or ({},))[0]
        if meta and meta.get('class') and 'Blueprint' not in meta['class']:
            f.bp = ('asset', meta['class'])
            continue
        if old is None and new is None:
            f.bp = ('missing', None)
            continue
        f.bp = ('bp', meta, bp_diff(old, new))
        for _, _, rows, *_ in f.bp[2]:
            for kind, _ in rows:
                if kind == 'add': f.adds += 1
                elif kind == 'del': f.dels += 1
                elif kind == 'mod': f.mods += 1
    return files


def render_bp(f):
    kind = f.bp[0]
    if kind == 'asset':
        return f'<p class="empty-msg">{html.escape(f.bp[1])} asset. Only Blueprints get a semantic diff.</p>'
    if kind == 'missing':
        return '<p class="empty-msg">No Blueprint export found. Check the bp_export log.</p>'
    meta, sections = f.bp[1], f.bp[2]
    head = (f'<p class="bp-head"><span class="bp-tag">{html.escape(meta.get("class", "Blueprint"))}</span>'
            f' parent <code>{html.escape(meta.get("parent") or "?")}</code></p>')
    if not sections:
        return head + '<p class="empty-msg">No semantic changes. The file changed but its graphs, variables and defaults did not.</p>'
    sign = {'add': '+', 'del': '−', 'mod': '~', 'info': '·'}
    out = [head]
    for title, st, rows, *svg in sections:
        badge = f' <span class="st st-{st}">{"Added" if st == "added" else "Removed"}</span>' if st else ''
        out.append(f'<div class="bp-sec"><h3>{html.escape(title)}{badge}</h3>')
        if svg and svg[0]:
            out.append(svg[0])
        out.append('<ul class="bp">')
        out.extend(f'<li class="{k}"><span class="sg">{sign[k]}</span><span>{t}</span></li>' for k, t in rows)
        if not rows:
            out.append('<li class="info"><span class="sg">·</span><span>Empty graph</span></li>')
        out.append('</ul></div>')
    return ''.join(out)


# ---------------------------------------------------------------- text diff

def intraline(a, b):
    ta, tb = TOKENS.findall(a), TOKENS.findall(b)
    sm = difflib.SequenceMatcher(None, ta, tb, autojunk=False)
    if not a.strip() or not b.strip() or sm.ratio() < 0.5:
        return None, None
    pa, pb = [0], [0]
    for t in ta: pa.append(pa[-1] + len(t))
    for t in tb: pb.append(pb[-1] + len(t))
    ma, mb = [False] * len(a), [False] * len(b)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag != 'equal':
            for x in range(pa[i1], pa[i2]): ma[x] = True
            for x in range(pb[j1], pb[j2]): mb[x] = True
    return ma, mb


def code(text, lang, mark=None):
    n = len(text)
    cls = [None] * n
    if lang:
        syntax = PY_SYNTAX if lang == '.py' else SYNTAX
        for m in syntax.finditer(text):
            token = m.lastgroup
            if token == 'fn' and lang in CPP_EXT:
                prefix = text[:m.start()]
                if re.search(r'\b[UAFTEIS][A-Z]\w*::$', prefix):
                    token = 'sfn'
                elif not prefix.endswith(('->', '.')):
                    token = 'gfn'
            for i in range(m.start(), m.end()):
                cls[i] = token
            if m.lastgroup == 'str' and lang in CPP_EXT:
                for spec in FORMAT_SPEC.finditer(m.group()):
                    if spec.start() and m.group()[spec.start() - 1] == '%':
                        continue
                    for i in range(m.start() + spec.start(), m.start() + spec.end()):
                        cls[i] = 'fmt'
        if lang in CPP_EXT and PREPROC_CONDITION.match(text):
            for m in PREPROC_DEFINED.finditer(text):
                if all(cls[i] in (None, 'fn') for i in range(m.start(), m.end())):
                    for i in range(m.start(), m.end()):
                        cls[i] = 'pp'
    out, i = [], 0
    while i < n:
        c, mk, j = cls[i], bool(mark and mark[i]), i
        while j < n and cls[j] == c and bool(mark and mark[j]) == mk:
            j += 1
        seg = html.escape(text[i:j], quote=False)
        if c: seg = f'<span class="t-{c}">{seg}</span>'
        if mk: seg = f'<mark>{seg}</mark>'
        out.append(seg)
        i = j
    return ''.join(out)


def similar(a, b):
    return difflib.SequenceMatcher(None, TOKENS.findall(a), TOKENS.findall(b), autojunk=False).ratio()


def align(dels, adds, cutoff=0.5):
    """Pair removed and added lines that look alike, in order. Unpaired lines
    stay pure removals or additions, so an inserted line never sits beside an
    unrelated removed one."""
    out, i, j = [], 0, 0
    while i < len(dels) and j < len(adds):
        best = max(range(j, len(adds)), key=lambda k: similar(dels[i], adds[k]))
        if similar(dels[i], adds[best]) < cutoff:
            out.append((i, None)); i += 1
            continue
        out.extend((None, k) for k in range(j, best))
        out.append((i, best)); i, j = i + 1, best + 1
    out.extend((k, None) for k in range(i, len(dels)))
    out.extend((None, k) for k in range(j, len(adds)))
    return out


def rows_for(h, lang):
    """Rows: ('ctx', o, n, html) or ('chg', [(left, right)]), each side
    (line no, html) or None."""
    rows, o, n, ls, i = [], h['os'], h['ns'], h['lines'], 0
    while i < len(ls):
        if ls[i][0] == ' ':
            rows.append(('ctx', o, n, code(ls[i][1], lang))); o += 1; n += 1; i += 1
            continue
        dels, adds = [], []
        while i < len(ls) and ls[i][0] == '-': dels.append(ls[i][1]); i += 1
        while i < len(ls) and ls[i][0] == '+': adds.append(ls[i][1]); i += 1
        pairs = []
        for di, ai in align(dels, adds):
            dm, am = intraline(dels[di], adds[ai]) if di is not None and ai is not None else (None, None)
            pairs.append(((o + di, code(dels[di], lang, dm)) if di is not None else None,
                          (n + ai, code(adds[ai], lang, am)) if ai is not None else None))
        rows.append(('chg', pairs))
        o += len(dels); n += len(adds)
    return rows


def hunk_row(h, span, lang, gap=None, count=0):
    fn = f' <span class="fn">{code(h["ctx"], lang)}</span>' if h['ctx'] else ''
    control = (f' <button type="button" aria-expanded="false">Show {count} omitted line{"s" if count != 1 else ""}</button>'
               if gap else '')
    gap_attr = f' data-gap="{html.escape(gap, quote=True)}"' if gap else ''
    return (f'<tr class="hunk{" expandable" if gap else ""}"{gap_attr}>'
            f'<td colspan="{span}"><span class="at">@@ -{h["os"]},{h["oc"]} +{h["ns"]},{h["nc"]} @@</span>{fn}{control}</td></tr>')


def omitted_rows(before, after, os_, oe, ns, ne, lang, gap):
    sp, un = [], []
    old, new = before[os_:oe], after[ns:ne]
    for i in range(max(len(old), len(new))):
        left = code(old[i].expandtabs(4), lang) if i < len(old) else None
        right = code(new[i].expandtabs(4), lang) if i < len(new) else None
        old_num, new_num = os_ + i + 1, ns + i + 1
        lcell = f'<td class="ln">{old_num}</td><td class="cd">{left}</td>' if left is not None else '<td class="ln e"></td><td class="cd e"></td>'
        rcell = f'<td class="ln">{new_num}</td><td class="cd">{right}</td>' if right is not None else '<td class="ln e"></td><td class="cd e"></td>'
        sp.append(f'<tr class="omitted" data-gap="{gap}" hidden>{lcell}{rcell}</tr>')
        if left is not None and right is not None and old[i] == new[i]:
            un.append(f'<tr class="omitted" data-gap="{gap}" hidden><td class="ln">{old_num}</td><td class="ln">{new_num}</td><td class="cd">{left}</td></tr>')
        else:
            if left is not None:
                un.append(f'<tr class="omitted" data-gap="{gap}" hidden><td class="ln del">{old_num}</td><td class="ln del"></td><td class="cd del">{left}</td></tr>')
            if right is not None:
                un.append(f'<tr class="omitted" data-gap="{gap}" hidden><td class="ln add"></td><td class="ln add">{new_num}</td><td class="cd add">{right}</td></tr>')
    return sp, un


def tables(f, lang):
    sp, un = [], []
    before, after = getattr(f, 'before_lines', None), getattr(f, 'after_lines', None)
    old_end = new_end = 0
    empty = '<td class="ln e"></td><td class="cd e"></td>'
    for index, h in enumerate(f.hunks):
        old_hunk_start = h['os'] - 1 if h['oc'] else h['os']
        new_hunk_start = h['ns'] - 1 if h['nc'] else h['ns']
        old_start = max(old_end, old_hunk_start)
        new_start = max(new_end, new_hunk_start)
        is_last = index == len(f.hunks) - 1
        tail_old = len(before) - (old_hunk_start + h['oc']) if is_last and before is not None else 0
        tail_new = len(after) - (new_hunk_start + h['nc']) if is_last and after is not None else 0
        count = max(old_start - old_end, new_start - new_end) + max(tail_old, tail_new)
        gap = f'{f.anchor}-gap-{index}' if count and before is not None and after is not None else None
        sp.append(hunk_row(h, 4, lang, gap, count)); un.append(hunk_row(h, 3, lang, gap, count))
        if gap:
            left, right = omitted_rows(before, after, old_end, old_start, new_end, new_start, lang, gap)
            sp.extend(left); un.extend(right)
        for r in rows_for(h, lang):
            if r[0] == 'ctx':
                _, o, n, c = r
                sp.append(f'<tr><td class="ln">{o}</td><td class="cd">{c}</td><td class="ln">{n}</td><td class="cd">{c}</td></tr>')
                un.append(f'<tr><td class="ln">{o}</td><td class="ln">{n}</td><td class="cd">{c}</td></tr>')
                continue
            for L, R in r[1]:
                left = f'<td class="ln del">{L[0]}</td><td class="cd del">{L[1]}</td>' if L else empty
                right = f'<td class="ln add">{R[0]}</td><td class="cd add">{R[1]}</td>' if R else empty
                sp.append(f'<tr>{left}{right}</tr>')
            un.extend(f'<tr><td class="ln del">{o}</td><td class="ln del"></td><td class="cd del">{c}</td></tr>'
                      for o, c in (L for L, _ in r[1] if L))
            un.extend(f'<tr><td class="ln add"></td><td class="ln add">{n}</td><td class="cd add">{c}</td></tr>'
                      for n, c in (R for _, R in r[1] if R))
        old_end, new_end = old_hunk_start + h['oc'], new_hunk_start + h['nc']
        if gap and is_last:
            left, right = omitted_rows(before, after, old_end, len(before), new_end, len(after), lang, gap)
            sp.extend(left); un.extend(right)
    if f.status in ('added', 'deleted'):  # one side is empty, so skip the split layout
        return f'<table class="d"><colgroup><col class="c-ln"><col class="c-ln"><col></colgroup>{"".join(un)}</table>'
    cols4 = '<colgroup><col class="c-ln"><col><col class="c-ln"><col></colgroup>'
    cols3 = '<colgroup><col class="c-ln"><col class="c-ln"><col></colgroup>'
    return (f'<table class="d v-split">{cols4}{"".join(sp)}</table>'
            f'<table class="d v-uni">{cols3}{"".join(un)}</table>')


def git_context(files, repo):
    """Give each text file its whole before and after so the page can expand
    the lines between hunks. Old side from HEAD, new side from the working
    tree. A file whose hunks don't match both exactly keeps hunks only."""
    top = subprocess.run(['git', '-C', repo, 'rev-parse', '--show-toplevel'], capture_output=True, text=True)
    if top.returncode:
        raise OSError(f'{repo} is not inside a git work tree')
    root = top.stdout.strip()
    rev = subprocess.run(['git', '-C', root, 'rev-parse', '--short', 'HEAD'], capture_output=True, text=True)
    for f in files:
        if f.binary or f.bp or not f.hunks or f.status == 'renamed':
            continue
        try:
            after = [] if f.status == 'deleted' else \
                open(os.path.join(root, f.new or f.old), encoding='utf-8', newline='').read().splitlines()
        except (OSError, UnicodeError):
            continue
        before = []
        if f.status != 'added':
            r = subprocess.run(['git', '-C', root, 'show', f'HEAD:{f.old or f.new}'], capture_output=True)
            if r.returncode:
                continue
            before = r.stdout.decode('utf-8', 'replace').splitlines()
        if all(hunk_matches(h, before, after) for h in f.hunks):
            f.before_lines, f.after_lines = before, after
    return f'git {rev.stdout.strip()} + working tree' if rev.returncode == 0 else None


def hunk_matches(h, before, after):
    old = [b for t, b in h['lines'] if t in ' -']
    new = [b for t, b in h['lines'] if t in ' +']
    o = h['os'] - 1 if h['oc'] else h['os']
    n = h['ns'] - 1 if h['nc'] else h['ns']
    return ([x.expandtabs(4) for x in before[o:o + len(old)]] == old and
            [x.expandtabs(4) for x in after[n:n + len(new)]] == new)


def prose(text):
    paras = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]
    fmt = lambda p: re.sub(r'`([^`]+)`', r'<code>\1</code>', html.escape(p, quote=False))
    return ''.join(f'<p>{fmt(p)}</p>' for p in paras)


def find_note(notes, path):
    for k, v in notes.items():
        if k != '_summary' and (path == k or path.endswith('/' + k) or path.endswith(k)):
            return v
    return None


def mass(f, biggest):
    total = f.adds + f.dels + f.mods
    w = max(2.0, 100.0 * total / biggest) if total else 0
    a = 100.0 * f.adds / total if total else 0
    m = 100.0 * f.mods / total if total else 0
    return (f'<span class="mass" aria-hidden="true"><span class="fill" style="width:{w:.1f}%">'
            f'<span class="ma" style="width:{a:.1f}%"></span><span class="mm" style="width:{m:.1f}%"></span>'
            f'<span class="md"></span></span></span>')


def counts(f):
    mod = f' <span class="pm">~{f.mods}</span>' if f.mods else ''
    return f'<span class="pa">+{f.adds}</span> <span class="pd">-{f.dels}</span>{mod}'


def split_path(p):
    d, _, b = p.rpartition('/')
    return (html.escape(d + '/') if d else ''), html.escape(b)


def render(files, title, notes, collapse, changelist=None):
    paths = [f.path for f in files]
    prefix = ''
    if len(paths) > 1:
        prefix = os.path.commonprefix(paths)
        prefix = prefix[:prefix.rfind('/') + 1]
    rel = lambda p: p[len(prefix):] if prefix else p
    biggest = max([f.adds + f.dels + f.mods for f in files] + [1])
    adds, dels = sum(f.adds for f in files), sum(f.dels for f in files)
    label_ = {'added': 'Added', 'deleted': 'Deleted', 'renamed': 'Renamed'}

    nav, body = [], []
    for i, f in enumerate(files):
        if not getattr(f, 'anchor', None):
            f.anchor = f'f{i}'
        d, b = split_path(rel(f.path))
        lang = os.path.splitext(f.path)[1].lower()
        if lang not in CODE_EXT:
            lang = None
        st = f'<span class="st st-{f.status}">{label_[f.status]}</span>' if f.status in label_ else ''
        ext = os.path.splitext(f.path)[1].lower()
        if f.bp and f.bp[0] == 'bp':
            bp_tag = '<span class="st st-bp">Blueprint</span>'
        elif os.path.basename(f.path) == 'CMakeLists.txt' or ext in LANG_NAME:
            bp_tag = f'<span class="st st-lang">{LANG_NAME.get(ext, "CMake")}</span>'
        else:
            bp_tag = ''
        nav.append(f'<li><a href="#{f.anchor}"><span class="nb">{b}</span><span class="nc">{counts(f)}</span>'
                   f'<span class="nd">{d}</span>{mass(f, biggest)}</a></li>')
        sub = (f'<div class="ren">Renamed from <code>{html.escape(f.old.replace(chr(92), "/"))}</code></div>'
               if f.status == 'renamed' and f.old else '')
        note = find_note(notes, f.path)
        note_html = f'<div class="note">{prose(note)}</div>' if note else ''
        if f.bp:
            content = render_bp(f)
        elif f.binary:
            hint = ' Pass <code>--blueprints</code> for a Blueprint diff.' if f.path.lower().endswith(ASSET_EXT) else ''
            content = f'<p class="empty-msg">Binary file, no text diff.{hint}</p>'
        elif not f.hunks:
            content = '<p class="empty-msg">No content changes.</p>'
        else:
            content = tables(f, lang)
        big = f.adds + f.dels + f.mods > collapse
        hint = '<p class="empty-msg">Large diff collapsed. Open the header to show it.</p>' if big else ''
        body.append(
            f'<details class="file" id="{f.anchor}"{"" if big else " open"}><summary>'
            f'<span class="path"><span class="dir">{d}</span><span class="base">{b}</span></span>{st}{bp_tag}'
            f'<span class="cnt">{counts(f)}</span>'
            f'</summary>{sub}{note_html}<div class="scroll">{content}</div></details>{hint if big else ""}')

    summary = notes.get('_summary')
    where = f' in <code>{html.escape(prefix)}</code>' if prefix else ''
    plural = 's' if len(files) != 1 else ''
    key_list = (('jk', 'Next or previous file'), ('e', 'Expand all'), ('c', 'Collapse all'),
                ('b', 'File list'), ('v', 'Split or unified'), ('a', 'Omitted code'))
    keys = ('<ul class="keys" aria-label="Keyboard shortcuts">'
            + ''.join(f'<li>{"".join(f"<kbd>{k}</kbd>" for k in ks)}<span>{label}</span></li>'
                      for ks, label in key_list)
            + '</ul>')
    return TEMPLATE.format(
        title=html.escape(title), css=CSS.replace('/*DARK*/', DARK), js=JS, graph_js=GRAPH_JS,
        meta=(f'{len(files)} file{plural} changed{where}'
              f'<span class="tot"><span class="pa">+{adds}</span> <span class="pd">-{dels}</span></span>'),
        when=datetime.now().strftime('%b %d, %Y at %H:%M'),
        changelist=f' · {html.escape(changelist)}' if changelist else '',
        summary=f'<div class="summary">{prose(summary)}</div>' if summary else '',
        nav=''.join(nav), body=''.join(body) or '<p class="empty-msg">The diff is empty.</p>', keys=keys)


DARK = '''--bg:#17191c;--surface:#1e1e1e;--ink:#dcdcdc;--muted:#858b93;--line:#343a40;--accent:#569cd6;
--add-bg:rgba(63,185,104,.14);--add-ln:rgba(63,185,104,.2);--add-mark:#3a5b79;--add-ink:#62cd87;
--del-bg:rgba(236,83,104,.14);--del-ln:rgba(236,83,104,.2);--del-mark:#69475b;--del-ink:#f27d8e;
--mod-bg:rgba(86,156,214,.14);--mod-ink:#79b8ea;
--hunk:#252a30;--empty:#1d2024;--t-kw:#569cd6;--t-type:#00b3b3;--t-str:#d69d85;--t-fmt:#80ff80;--t-com:#559b45;
--t-num:#b5cea8;--t-pp:#bd63c5;--t-fn:#ff8000;--t-sfn:#ffaa00;--t-gfn:#add8e6;
--sb:#464d56;--sb-hover:#5d6670;--grid1:rgba(255,255,255,.055);--grid2:rgba(255,255,255,.12);color-scheme:dark;'''

CSS = '''
:root{--bg:#f3f5f8;--surface:#fff;--ink:#1c232c;--muted:#68717d;--line:#dde2e8;--accent:#2d68a2;
--add-bg:#e9f6ed;--add-ln:#d4efdc;--add-mark:#a9e1bb;--add-ink:#1a7a3a;
--del-bg:#fdecee;--del-ln:#f8d7dc;--del-mark:#f2b3bc;--del-ink:#b3233a;
--mod-bg:#e8f0fa;--mod-ink:#2d68a2;
--hunk:#edf2f8;--empty:#f6f7f9;--t-kw:#7036d6;--t-type:#0e7672;--t-str:#94570f;--t-fmt:#137c32;--t-com:#7a8491;
--t-num:#1f68b0;--t-pp:#7d39bf;--t-fn:#a44200;--t-sfn:#975500;--t-gfn:#18567d;
--sb:#c3cad3;--sb-hover:#a3acb8;--grid1:rgba(20,40,70,.07);--grid2:rgba(20,40,70,.15);
--mono:"JetBrains Mono","Cascadia Code","SF Mono",ui-monospace,Menlo,Consolas,monospace;
--sans:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color-scheme:light}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){/*DARK*/}}
:root[data-theme="dark"]{/*DARK*/}
*{box-sizing:border-box}
*{scrollbar-width:thin;scrollbar-color:var(--sb) transparent}
@supports not (scrollbar-color:auto){
::-webkit-scrollbar{width:10px;height:10px}::-webkit-scrollbar-track,::-webkit-scrollbar-corner{background:transparent}
::-webkit-scrollbar-thumb{background:var(--sb);border-radius:6px;border:2px solid transparent;background-clip:padding-box}
::-webkit-scrollbar-thumb:hover{background:var(--sb-hover);border:2px solid transparent;background-clip:padding-box}}
body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 var(--sans)}
code{font:12.5px var(--mono);background:var(--hunk);padding:.05em .35em;border-radius:4px}
.pa{color:var(--add-ink)}.pd{color:var(--del-ink)}.pm{color:var(--mod-ink)}
.top{padding:2rem 1.5rem 1.25rem;display:flex;flex-wrap:wrap;gap:1rem 2rem;align-items:end;justify-content:space-between}
.top h1{margin:0;font-size:1.55rem;font-weight:650;letter-spacing:-.015em}
.meta{margin:.3rem 0 0;color:var(--muted)}.tot{font:12.5px var(--mono);margin-left:.75rem}.meta .when{display:block;font-size:12.5px}
.ctl{display:flex;gap:.5rem;align-items:center}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:7px;overflow:hidden;background:var(--surface)}
button{font:inherit;font-size:13px;color:var(--ink);background:var(--surface);border:0;padding:.35rem .8rem;cursor:pointer}
.seg button+button{border-left:1px solid var(--line)}
.seg button[aria-pressed="true"]{background:var(--ink);color:var(--surface)}
#theme{border:1px solid var(--line);border-radius:7px}
button:focus-visible,a:focus-visible,summary:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.summary{padding:0 1.5rem 1rem}
.summary p,.note p{margin:0 0 .5rem}
.wrap{padding:0 1.5rem 3rem;display:grid;grid-template-columns:16.5rem 1.125rem minmax(0,1fr);gap:1.5rem .75rem}
.wrap.nav-hidden{grid-template-columns:1.125rem minmax(0,1fr)}
.wrap.nav-hidden nav{display:none}
.wrap.nav-hidden .keys{grid-column:2}
nav{position:sticky;top:1rem;align-self:start;max-height:calc(100vh - 2rem);overflow:auto}
#sidebar{position:sticky;top:1rem;align-self:start;display:grid;place-items:center;width:1.125rem;height:1.5rem;padding:0;border:1px solid var(--line);border-radius:5px;color:var(--muted)}
#sidebar:hover{background:var(--hunk);color:var(--accent)}
#sidebar::before{content:"";width:.5rem;height:.625rem;background:currentColor;clip-path:polygon(0 0,25% 0,100% 50%,25% 100%,0 100%,75% 50%);transform:rotate(180deg)}
.wrap.nav-hidden #sidebar::before{transform:none}
nav ul{list-style:none;margin:0;padding:0}
nav a{display:grid;grid-template-columns:1fr auto;gap:.1rem .5rem;padding:.5rem .6rem;border-radius:7px;color:inherit;text-decoration:none}
nav a:hover{background:var(--surface)}
.nb{font:600 12.5px var(--mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.nc{font:12px var(--mono)}
.nd{grid-column:1/-1;font-size:11.5px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:rtl;text-align:left}
.mass{grid-column:1/-1;display:block;height:3px;margin-top:.3rem;background:var(--line);border-radius:2px}
.fill{display:flex;height:100%;border-radius:2px;overflow:hidden}
.ma{background:var(--add-ink)}.mm{background:var(--mod-ink)}.md{flex:1;background:var(--del-ink)}
.file{background:var(--surface);border:1px solid var(--line);border-radius:9px;margin:0 0 1.25rem;overflow:clip}
.file>summary{position:sticky;top:0;z-index:2;display:flex;align-items:center;gap:.75rem;padding:.6rem .9rem;background:var(--surface);border-bottom:1px solid var(--line);cursor:pointer;list-style:none}
.file:not([open])>summary{border-bottom:0}
.file>summary::-webkit-details-marker{display:none}
.file>summary::before{content:"";width:0;height:0;border:5px solid transparent;border-left-color:var(--muted);transform:translateX(3px);flex:none}
.file[open]>summary::before{transform:translate(0,3px) rotate(90deg)}
.path{font:13px var(--mono);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dir{color:var(--muted)}.base{font-weight:650}
.st{font-size:11.5px;padding:.05rem .45rem;border-radius:99px;border:1px solid currentColor;flex:none}
.st-added{color:var(--add-ink)}.st-deleted{color:var(--del-ink)}.st-renamed,.st-bp{color:var(--accent)}
.st-lang{color:var(--muted)}
.cnt{margin-left:auto;font:12.5px var(--mono);flex:none}
.ren{padding:.5rem .9rem 0;color:var(--muted);font-size:13px}
.note{margin:.75rem .9rem;padding:.6rem .8rem;border-left:3px solid var(--accent);background:var(--hunk);border-radius:0 6px 6px 0}
.note p:last-child{margin-bottom:0}
.scroll{overflow-x:auto}
.d{width:100%;border-collapse:collapse;table-layout:fixed;font:12.5px/1.6 var(--mono)}
.c-ln{width:3.6rem}
.d td{vertical-align:top;padding:0}
.ln{color:var(--muted);text-align:right;padding:0 .6rem!important;font-size:11.5px;user-select:none;-webkit-user-select:none}
.v-split td:nth-child(3){border-left:1px solid var(--line)}
.cd{white-space:pre-wrap;overflow-wrap:anywhere;padding:0 .8rem 0 1.5rem!important;position:relative}
.cd.add{background:var(--add-bg)}.cd.del{background:var(--del-bg)}
.ln.add{background:var(--add-ln);color:var(--add-ink)}.ln.del{background:var(--del-ln);color:var(--del-ink)}
.cd.add::before,.cd.del::before{position:absolute;left:.55rem;user-select:none}
.cd.add::before{content:"+";color:var(--add-ink)}.cd.del::before{content:"-";color:var(--del-ink)}
.e{background:var(--empty)}
mark{background:none;color:inherit;border-radius:3px}
.add mark{background:var(--add-mark)}.del mark{background:var(--del-mark)}
.hunk td{position:relative;background:var(--hunk);color:var(--muted);padding:.3rem .8rem!important;font-size:12px}
.hunk .fn{color:var(--ink);margin-left:.5rem}
.hunk.expandable{cursor:pointer}
.hunk.expandable:hover td{filter:brightness(1.1)}
.hunk button{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);padding:0;background:transparent;color:var(--accent);font:inherit;white-space:nowrap}
.d tr[hidden]{display:none!important}
.t-kw{color:var(--t-kw)}.t-pp,.t-mac{color:var(--t-pp)}.t-type{color:var(--t-type)}.t-str{color:var(--t-str)}
.t-com{color:var(--t-com)}.t-fmt{color:var(--t-fmt)}.t-num{color:var(--t-num)}.t-fn{color:var(--t-fn)}
.t-sfn{color:var(--t-sfn)}.t-gfn{color:var(--t-gfn)}
.empty-msg{color:var(--muted);padding:.75rem .9rem;margin:0}
.bp-head{margin:0;padding:.75rem .9rem 0;color:var(--muted);font-size:13px}
.bp-tag{color:var(--accent);font-weight:600}
.bp-sec{padding:.5rem .9rem .25rem}
.bp-sec h3{margin:.25rem 0 .4rem;font:600 13px var(--mono);display:flex;gap:.5rem;align-items:center}
ul.bp{list-style:none;margin:0 0 .5rem;padding:0;font:12.5px/1.6 var(--mono);border:1px solid var(--line);border-radius:6px;overflow:hidden}
ul.bp li{display:flex;gap:.6rem;padding:.15rem .7rem;overflow-wrap:anywhere}
ul.bp li+li{border-top:1px solid var(--line)}
ul.bp .sg{flex:none;width:.8rem;text-align:center}
ul.bp .add{background:var(--add-bg)}ul.bp .add .sg{color:var(--add-ink)}
ul.bp .del{background:var(--del-bg)}ul.bp .del .sg{color:var(--del-ink)}
ul.bp .mod{background:var(--mod-bg)}ul.bp .mod .sg{color:var(--mod-ink)}
.bpg{position:relative;overflow:hidden;margin:.6rem 0 .3rem;border:1px solid var(--line);border-radius:6px;background:var(--empty)}
.bpg .g1{fill:none;stroke:var(--grid1);stroke-width:1}.bpg .g2{fill:none;stroke:var(--grid2);stroke-width:1}
.bpg svg{display:block;cursor:grab;user-select:none;touch-action:none}.bpg.dragging svg{cursor:grabbing}
.bpg-tools{position:absolute;top:.4rem;right:.4rem;display:flex;gap:.25rem;z-index:1}
.bpg-tools button{min-width:1.8rem;padding:.15rem .45rem;font:12px var(--sans);color:var(--ink);background:var(--surface);border:1px solid var(--line);border-radius:5px;cursor:pointer}
.bpg-tools button:hover{border-color:var(--accent);color:var(--accent)}
.bpg-views{display:flex;margin-right:.35rem}.bpg-views button{border-radius:0;margin-left:-1px}
.bpg-views button:first-child{border-radius:5px 0 0 5px}.bpg-views button:last-child{border-radius:0 5px 5px 0}
.bpg-views button[aria-pressed="true"]{background:var(--accent);border-color:var(--accent);color:#fff}
.bpg .L{display:none}.bpg[data-l="changes"] .L-changes,.bpg[data-l="before"] .L-before,.bpg[data-l="after"] .L-after{display:inline}
.bpg text{font:11px system-ui,sans-serif;fill:var(--ink)}.bpg .nt{font-size:12px;font-weight:600;fill:#fff}
.bpg .dv{fill:var(--muted)}.bpg .dv.chg{fill:var(--mod-ink);font-weight:600}
.bpg .nb{fill:var(--surface);stroke:var(--line);stroke-width:1.2}
.bpg .add .nb{stroke:var(--add-ink);stroke-width:2.5}.bpg .mod .nb{stroke:var(--mod-ink);stroke-width:2.5}
.bpg .del{opacity:.5}.bpg .del .nb{stroke:var(--del-ink);stroke-width:2.5;stroke-dasharray:6 4}
.bpg .kn{stroke:none}.bpg .add .kn{stroke:var(--add-ink);stroke-width:2}.bpg .del .kn{stroke:var(--del-ink);stroke-width:2}
.bpg .mod .kn{stroke:var(--mod-ink);stroke-width:2}
.bpg .pin.gone{stroke:var(--del-ink);stroke-dasharray:2 2;fill:none}.bpg text.gone{fill:var(--del-ink);text-decoration:line-through}
.bpg .cm{fill:var(--mod-bg);stroke:var(--line)}.bpg .ct{font-size:13px;font-weight:600}
.bpg .w{fill:none;stroke-width:1.6;opacity:.85}.bpg .w.x{stroke-width:2.4}
.bpg .w.add{stroke:var(--add-ink);stroke-width:3;opacity:1}.bpg .w.del{stroke:var(--del-ink);stroke-dasharray:6 4;opacity:.8}
.bpg-note,.bpg-key{margin:.2rem 0 .5rem;font-size:12px;color:var(--muted)}
.bpg-key span{margin-right:.8rem;padding-left:1rem;position:relative}
.bpg-key span::before{content:"";position:absolute;left:0;top:.15em;width:.7rem;height:.7rem;border-radius:2px;border:2px solid}
.bpg-key .k-add::before{border-color:var(--add-ink)}.bpg-key .k-del::before{border-color:var(--del-ink);border-style:dashed}
.bpg-key .k-mod::before{border-color:var(--mod-ink)}
ul.bp .info{color:var(--muted)}
ul.bp b{font-weight:600}ul.bp s{color:var(--muted)}
ul.bp code{background:none;padding:0}
.keys{grid-column:3;display:flex;flex-wrap:wrap;gap:.4rem;list-style:none;margin:0;padding:0;color:var(--muted);font-size:12px}
.keys li{display:inline-flex;align-items:center;gap:.2rem;padding:.2rem .55rem .2rem .3rem;border:1px solid var(--line);border-radius:99px;background:var(--surface)}
.keys li span{margin-left:.25rem}
.top .keys{margin:.75rem 0 0}
kbd{display:inline-block;min-width:1.25rem;text-align:center;font:600 11px/1.5 var(--mono);color:var(--ink);border:1px solid var(--line);border-bottom-width:2px;border-radius:5px;padding:0 .3rem;background:var(--empty)}
.d,code,.nb,.nd,.path,.keys,kbd,ul.bp{font-variant-ligatures:none}
body:not(.unified) .v-uni,body.unified .v-split{display:none}
@media (max-width:1100px){.wrap{grid-template-columns:1.125rem minmax(0,1fr)}nav{grid-column:1/-1;position:static;max-height:none}
  nav ul{display:grid;grid-template-columns:repeat(auto-fill,minmax(14rem,1fr));gap:.25rem}.keys{grid-column:2}}
@media (max-width:820px){.v-split{display:none!important}.v-uni{display:table!important}.seg.layout{display:none}}
@media (prefers-reduced-motion:no-preference){.file>summary::before{transition:transform .12s}}
'''

JS = '''(()=>{const b=document.body,r=document.documentElement,
g=k=>{try{return localStorage.getItem(k)}catch(e){return null}},s=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const view=v=>{b.classList.toggle('unified',v==='unified');document.querySelectorAll('[data-view]').forEach(x=>x.setAttribute('aria-pressed',x.dataset.view===v));s('diffview.view',v)};
view(g('diffview.view')||'split');document.querySelectorAll('[data-view]').forEach(x=>x.onclick=()=>view(x.dataset.view));
const w=document.querySelector('.wrap'),sidebar=document.getElementById('sidebar');
const showFiles=open=>{
w.classList.toggle('nav-hidden',!open);
sidebar.setAttribute('aria-expanded',String(open));
sidebar.setAttribute('aria-label',open?'Collapse file list':'Expand file list');
sidebar.title=sidebar.getAttribute('aria-label');
s('diffview.sidebar',open?'open':'closed')};
const toggleFiles=()=>showFiles(w.classList.contains('nav-hidden'));
showFiles(g('diffview.sidebar')!=='closed');sidebar.onclick=toggleFiles;
const hunks=[...document.querySelectorAll('.hunk.expandable')];
const setGaps=(open,gap)=>document.querySelectorAll('.hunk.expandable,.omitted').forEach(x=>{if(gap&&x.dataset.gap!==gap)return;
if(x.classList.contains('omitted'))x.hidden=!open;
else{const button=x.querySelector('button');button.setAttribute('aria-expanded',String(open));
button.textContent=button.textContent.replace(/^(Show|Hide)/,open?'Hide':'Show')}});
hunks.forEach(row=>row.addEventListener('click',()=>setGaps(row.querySelector('button').getAttribute('aria-expanded')!=='true',row.dataset.gap)));
const t=g('diffview.theme');if(t)r.dataset.theme=t;
document.getElementById('theme').onclick=()=>{const c=r.dataset.theme||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'),n=c==='dark'?'light':'dark';r.dataset.theme=n;s('diffview.theme',n)};
const fs=[...document.querySelectorAll('.file')];
const fold=open=>{const top=fs.find(f=>f.getBoundingClientRect().bottom>12);fs.forEach(f=>f.open=open);
if(top&&!open&&top.getBoundingClientRect().top<0)top.scrollIntoView({block:'start'})};
document.querySelectorAll('[data-fold]').forEach(x=>x.onclick=()=>fold(x.dataset.fold==='open'));
addEventListener('keydown',e=>{if(e.metaKey||e.ctrlKey||e.altKey||/INPUT|TEXTAREA/.test(e.target.tagName))return;
if(e.key==='j'||e.key==='k'){let i=-1;fs.forEach((f,j)=>{if(f.getBoundingClientRect().top<=12)i=j});
const f=fs[Math.max(0,Math.min(fs.length-1,i+(e.key==='j'?1:-1)))];if(f){f.open=true;f.scrollIntoView({block:'start'})}}
if(e.key==='v')view(b.classList.contains('unified')?'split':'unified');
if(e.key==='b'||e.key==='f')toggleFiles();
if(e.key==='e'||e.key==='c')fold(e.key==='e');
if(e.key==='a'&&hunks.length){e.preventDefault();if(e.target.matches('.hunk button'))e.target.blur();
setGaps(hunks.some(x=>x.querySelector('button').getAttribute('aria-expanded')!=='true'))}})})();'''

# Graph drawings: left-drag pans, the wheel zooms at the pointer, double-click
# or Fit returns to the starting view. The view is the SVG viewBox, so text
# and lines stay sharp at any zoom.
GRAPH_JS = '''(()=>{document.querySelectorAll('.bpg').forEach(box=>{const svg=box.querySelector('svg');if(!svg)return;
const home=svg.getAttribute('viewBox').split(' ').map(Number),full=(svg.dataset.full||'').split(' ').map(Number);
let v=home.slice(),drag=null;const maxW=Math.max(home[2]*4,full[2]*1.2||0),minW=home[2]/10;
const set=()=>svg.setAttribute('viewBox',v.join(' '));
const pt=e=>{const m=svg.getScreenCTM();return m?new DOMPoint(e.clientX,e.clientY).matrixTransform(m.inverse()):{x:0,y:0}};
const zoom=(f,p)=>{const w=Math.min(maxW,Math.max(minW,v[2]*f));f=w/v[2];
v=[p.x-(p.x-v[0])*f,p.y-(p.y-v[1])*f,v[2]*f,v[3]*f];set()};
const mid=()=>({x:v[0]+v[2]/2,y:v[1]+v[3]/2});
svg.addEventListener('pointerdown',e=>{if(e.button!==0)return;drag=pt(e);svg.setPointerCapture(e.pointerId);box.classList.add('dragging')});
svg.addEventListener('pointermove',e=>{if(!drag)return;const p=pt(e);v[0]-=p.x-drag.x;v[1]-=p.y-drag.y;set()});
const end=e=>{drag=null;box.classList.remove('dragging')};
svg.addEventListener('pointerup',end);svg.addEventListener('pointercancel',end);
svg.addEventListener('wheel',e=>{e.preventDefault();zoom(Math.pow(1.0015,e.deltaY),pt(e))},{passive:false});
const fit=()=>{v=home.slice();set()};svg.addEventListener('dblclick',fit);
box.querySelectorAll('[data-l]').forEach(b=>b.onclick=()=>{box.dataset.l=b.dataset.l;
box.querySelectorAll('[data-l]').forEach(x=>x.setAttribute('aria-pressed',x===b))});
box.querySelectorAll('[data-z]').forEach(b=>b.onclick=()=>{const z=b.dataset.z;
if(z==='fit')fit();else if(z==='all'&&full.length===4){v=full.slice();set()}else zoom(z==='in'?0.8:1.25,mid())})})})();'''

TEMPLATE = '''<!doctype html><html lang="en" data-theme="dark"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title>
<style>{css}</style></head><body>
<header class="top"><div><h1>{title}</h1><p class="meta">{meta}<span class="when">Generated {when}{changelist}</span></p>{keys}</div>
<div class="ctl"><span class="seg" role="group" aria-label="Files"><button data-fold="open" title="Expand all files (e)">Expand all</button><button data-fold="shut" title="Collapse all files (c)">Collapse all</button></span>
<span class="seg layout" role="group" aria-label="Diff layout"><button data-view="split">Split</button><button data-view="unified">Unified</button></span>
<button id="theme" title="Switch light or dark">Theme</button></div></header>
{summary}
<div class="wrap"><nav id="files-nav" aria-label="Changed files"><ul>{nav}</ul></nav>
<button id="sidebar" type="button" aria-controls="files-nav" aria-expanded="true" aria-label="Collapse file list" title="Collapse file list"></button>
<main>{body}</main>
{keys}</div>
<script>{js}</script><script>{graph_js}</script></body></html>'''


def main():
    ap = argparse.ArgumentParser(description='Render a unified diff as styled, self-contained HTML.')
    ap.add_argument('diff', nargs='?', help='diff file (reads stdin if omitted)')
    ap.add_argument('-o', '--out', default='diff.html')
    ap.add_argument('--title', default='Changes')
    ap.add_argument('--notes', help='JSON of per-file notes, plus optional "_summary"')
    ap.add_argument('--blueprints', help='folder filled by bp_prepare.py and bp_export.py')
    ap.add_argument('--git-context', metavar='REPO', help='read whole files from this git repo so the page can expand omitted lines')
    ap.add_argument('--collapse', type=int, default=800, help='collapse files with more changed lines')
    a = ap.parse_args()
    try:
        run(a)
    except (OSError, ValueError) as e:  # json.JSONDecodeError is a ValueError
        sys.exit(f'diffview: {e}')


def run(a):
    if a.blueprints and not os.path.isfile(os.path.join(a.blueprints, 'manifest.json')):
        raise OSError(f'{a.blueprints} has no manifest.json. Run bp_prepare.py first.')
    if a.diff:
        with open(a.diff, encoding='utf-8', errors='replace') as fh:
            text = fh.read()
    elif not sys.stdin.isatty():
        sys.stdin.reconfigure(encoding='utf-8', errors='replace')
        text = sys.stdin.read()
    else:
        text = ''
    notes = {}
    if a.notes:
        with open(a.notes, encoding='utf-8') as fh:
            notes = json.load(fh)
    files = parse(text)
    if a.blueprints:
        attach_blueprints(files, a.blueprints)
    label = git_context(files, a.git_context) if a.git_context else None
    with open(a.out, 'w', encoding='utf-8') as fh:
        fh.write(render(files, a.title, notes, a.collapse, label))
    bps = sum(1 for f in files if f.bp and f.bp[0] == 'bp')
    extra = f', {bps} Blueprints' if bps else ''
    print(f'{a.out}: {len(files)} files{extra}, +{sum(f.adds for f in files)} -{sum(f.dels for f in files)}')


if __name__ == '__main__':
    main()
