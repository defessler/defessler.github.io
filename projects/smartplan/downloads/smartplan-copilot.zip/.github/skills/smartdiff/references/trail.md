# Agent-only mode (`scripts/trail.py`)

`trail.py` exports only the edits the agent made, read from the
session's own record. It never reads the live files, so a teammate's
change, a hand edit or a build step in the same tree can't leak into the
review.

## Scope

The boundary is the newest human message, usually the one asking for
the export. Everything is counted in human messages. Tool results,
subagent prompts and harness reminders don't count.

| Flag | Covers |
| --- | --- |
| `--messages 1` (default) | the work done in answer to the message before the boundary |
| `--messages N` | the last N messages before the boundary |
| `--whole-session` | every message before the boundary |
| `--request-id <id>` | moves the boundary to an earlier message |
| `--list-messages` | prints the last 30 human messages with their ids |

## Which session

With no `--session`, it reads the session running it.

- **Copilot CLI**: the folder `~/.copilot/session-state/<id>` named by
  `COPILOT_AGENT_SESSION_ID`.

Pass `--session <folder or .jsonl>` to read any other session.

## Evidence

Each change is rebuilt from the file as it was before the edit plus the
patch the tool recorded. Every removed and context line is checked
against that before-image, so a mismatch is refused, never guessed at.

- **Copilot CLI**: before-images come from `rewind-file-snapshots`,
  hash-checked. Patches come from the `apply_patch`, `edit` and `create`
  results. Which tool runs depends on the model.

Consecutive edits to one file merge into one comparison. A file changed
by hand between two agent edits splits into two, so the hand edit stays
out. A file that ends where it started is dropped.

## Partial results

The run exits 2 and lists a warning per gap when the record can't prove
a change:

- a shell command ran, so command-driven edits may be missing
- a patch didn't match its before-image, or a before-image is missing
- a tool edited files with no supported evidence
- the person changed the agent's proposed edit before accepting it

The page shows what was proved. Treat everything else as unreviewed.
Exit 1 means no export at all, with the cause on stderr.

## Output

One timestamped folder under `--out`, or by default `Saved/smartdiff/`
in an Unreal project and the system temp folder elsewhere:

- `<name>-before.<ext>` and `<name>-after.<ext>` for every change
- `agent-only.diff`, `comparisons.json` and its warnings
- `prompts.md` (the human messages in scope) and `transcript.md`
  (replies and tool calls, with private reasoning left out)
- `index.html`, the same page `diffview.py` renders

The page lists source files only. `--all-files` adds docs and data.
`--notes` takes the same JSON as the main procedure. `--no-open` skips
opening the browser and `--no-html` skips the page.
