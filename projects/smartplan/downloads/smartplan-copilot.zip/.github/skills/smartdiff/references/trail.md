# Agent-only mode (`scripts/trail.py`)

`trail.py` exports only the agent's own edits, read from the session
record. It never reads live files, so a change made before the agent's
first edit to a file, or after its last, can't leak in. One made between
two agent edits can, and the run names it (see Partial results).

## Scope

The boundary is the newest human message, usually the export request.
Messages are counted as human messages only. Tool results, subagent
prompts and harness reminders don't count.

| Flag | Covers |
| --- | --- |
| `--messages 1` (default) | the work done in answer to the message before the boundary |
| `--messages N` | the last N messages before the boundary |
| `--whole-session` | every message before the boundary |
| `--request-id <id>` | moves the boundary to an earlier message |
| `--list-messages` | prints the last 30 human messages with their ids |

## Which session

With no `--session`, it reads the session running it.

- **Copilot CLI**: the folder `~/.copilot/session-state/<id>` named by
  `COPILOT_AGENT_SESSION_ID`.

Pass `--session <folder or .jsonl>` to read any other session.

## Evidence

Each change is rebuilt from the pre-edit file plus the recorded patch.
Every removed and context line is checked against that before-image.
A mismatch is refused, never guessed at.

- **Copilot CLI**: before-images come from `rewind-file-snapshots`,
  hash-checked. Patches come from the `apply_patch`, `edit` and `create`
  results. Which tool runs depends on the model.

Each file is one comparison for the whole range: the file before the
first agent edit against the file after the last, however many messages
touched it. The page shows where the work ended up, never one diff per
prompt. A file that ends where it started is dropped.

## Partial results

The run exits 2 and lists a warning per gap when the record can't prove
a change:

- a shell command ran, so command-driven edits may be missing
- a patch didn't match its before-image, or a before-image is missing
- a tool edited files with no supported evidence
- the person changed the agent's proposed edit before accepting it
- the file changed between two agent edits (a hand edit, a formatter).
  That change is inside the file's comparison, so check it by hand

The page shows what was proved, and it marks each file that changed
between two agent edits with a banner. Treat the rest as unreviewed.
Exit 1 means no export, with the cause on stderr.

## Output

One timestamped folder under `--out`, by default `Saved/smartdiff/` in an
Unreal project and the system temp folder elsewhere:

- `<name>-before.<ext>` and `<name>-after.<ext>` for every change
- `agent-only.diff`, `comparisons.json` and its warnings
- `prompts.md` (the human messages in scope) and `transcript.md`
  (replies and tool calls, private reasoning left out)
- `index.html`, the same page `diffview.py` renders

The page lists source files only. `--all-files` adds docs and data.
`--notes` takes the same JSON as the main procedure, and `--review`
the same smartreview report, shown as comments on their lines. `--no-open` skips
opening the browser and `--no-html` skips the page.
