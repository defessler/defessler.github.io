---
name: smartdiff
description: Render this session's changes (git or Perforce), or only the agent's own edits read from its session record, as a self-contained HTML diff review with per-file intent notes. Unreal Blueprint assets get a semantic diff of graphs, nodes, wires, variables and defaults. Use when asked to review, export, or show the session diff.
---

# smartdiff — session diff review, Blueprints included

One self-contained HTML page per change set: split or unified view,
intraline highlights, per-file intent notes, Rider-style dark palette
(green added, blue modified, grey removed). Unreal Blueprints, which a
text diff calls "binary", get a semantic diff. Python stdlib only. No
network requests.

## Procedure

`<work>` is a scratch folder outside the repo (or ignored by it), so
`git add -N .` doesn't pick up outputs.

```
- [ ] 1. Diff captured to <work>/session.diff
- [ ] 2. Blueprints exported (only if the change set touches .uasset)
- [ ] 3. Notes written to <work>/notes.json
- [ ] 4. Rendered
- [ ] 5. Reported path and totals
```

1. **Capture the diff** into `<work>/session.diff`:
   - Git: `git add -N . && git diff -U5 > <work>/session.diff`
   - Perforce, all opened files: `p4 diff -du5 > <work>/session.diff`
   - Perforce, one changelist:
     `p4 -F %depotFile% opened -c <CL> | p4 -x - diff -du5 > <work>/session.diff`
   - Files opened for add aren't in `p4 diff` output. Append each with
     `git diff --no-index -U5 /dev/null <localPath> >> <work>/session.diff`

2. **Export Blueprints** when any `.uasset` changed:
   `python <this skill dir>/scripts/bp_prepare.py --project <Game.uproject> --out <work>/bp --run`
   Add `--p4` (and `-c <CL>`) for Perforce. It lists changed assets,
   pulls each old revision (git `HEAD`, smudging Git LFS pointers, or p4
   `#have`), then runs `scripts/bp_export.py` in a headless
   `UnrealEditor-Cmd` to dump both revisions as T3D text. Expect 30 to 90
   seconds. It needs the engine the `.uproject` names (launcher install,
   or pass `--editor`) and a C++ project's editor binaries built. Read
   `<work>/bp/export.log` when an asset comes back empty.
   - The old revision is staged under `Content/__SmartDiffOld/` while it
     loads (the engine won't load a package outside a content root), then
     removed. Close the editor first so it doesn't pick up the staged
     copy. If the run is killed, delete that folder.
   - Levels (`.umap`) are skipped, so Level Blueprints aren't covered
     yet. Other asset types show their class name only.

3. **Write `<work>/notes.json`**: a `_summary` of what the change set
   does and why (2 to 3 sentences), then one or two sentences per file on
   intent, keyed by file name or path suffix. Say why, not what. Skip
   obvious files.

4. **Render**:
   `python <this skill dir>/scripts/diffview.py <work>/session.diff --notes <work>/notes.json --title "<short change-set title>" -o <work>/session-diff.html`
   Add `--blueprints <work>/bp` when step 2 ran.

5. **Report** the output path and the totals the script prints. Don't
   open the file unless asked.

## Agent-only mode

Use this when the tree mixes the agent's edits with other changes, or
for one message's work. It rebuilds each change from the session record
(the file before each edit plus the patch the tool applied), never from
live files, and finds the running session itself:

`python <this skill dir>/scripts/trail.py --messages 1 --out <work>/trail`

`--messages N` covers the last N human messages before the newest,
`--whole-session` all of them. Add `--notes` as in step 3. Exit 2 means
partial: a shell command ran, or some evidence didn't check out. Say so
when reporting. Scope flags, evidence and outputs:
`references/trail.md`.

## What the Blueprint diff shows

Nodes match across revisions by `NodeGuid`, so a moved node isn't a
change. Per graph it lists added and removed nodes, changed pin defaults
and node properties, and added and removed wires as
`Node.pin → Node.pin`. Layout-only moves collapse to one count. Above the
graphs: variables (matched by `VarGuid`, so a rename reads as a rename),
components and other subobjects, Blueprint settings, class defaults.
Compiler-generated graphs are filtered out.

Each graph is drawn at the saved node positions: added green, removed a
dashed red ghost, changed blue. Box sizes are estimates. Big graphs open
on the change. Drag to pan, scroll to zoom. **Before** and **After**
show either side alone.

## The page

`j` and `k` step through files, `v` switches split and unified, `b` or
the chevron hides the file list, `e` and `c` expand and collapse every
file, `a` expands every run of omitted lines. Expanding needs whole
files: trail mode has them, and `diffview.py --git-context <repo>` reads
them from git. Theme defaults to dark. Choices persist per browser.

## Family fit and tiering

`smartdiff` is an **optional** companion seat, like `smartreview`, outside
the tiering loop. It pairs with `smartreview` (render, then review) and
`smartwiki` (the same change for a non-engineer audience).

Tiering (see `smartroute`): run inline when the change set fits one
context. Capture, export and render are free scripts. The notes are the
judgment step and fit **Mid**, or the seat that wrote the change.

## Changelog

the repo's commit log (source repo only, so a path and not a
link) — kept out of the shipped plugin to keep this body lean.
