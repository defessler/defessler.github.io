# smartplan overview

One family, one policy: route each model to the work it's good at.

## The skills

smartplan, its part skills, and five companions ship in
`.github/skills/`.

- `smartplan` - The entry point and router. It decides the route and
  loads each part it needs. A part that's switched off is skipped, and
  smartplan says what it gave up.
- The parts, one feature each, so you can switch any one off:
  `smartflow` (fan-out, the human gate, run artifacts), `smartroute`
  (class-to-tier mapping and the model registry), `smartcost` (the
  quality and cost dial), `smartbrief` (briefs for Cheap leaves),
  `smartexec` (the cheap executor's instructions, DONE with pasted
  evidence or BLOCKED), `smartcheck` (independent verify),
  `smartcheck-cpp` (its C++ gamedev layer).
- `smartreview` - Code review ranked into game-breaking bugs, best
  practices, and conventions against a swappable standards doc (C++
  gamedev by default: Unreal, custom engine, or vanilla). A second doc
  reviews web UI against a condensed form of hallmark's anti-slop gates.
- `smartwiki` - Turns a commit, PR, or changelist (Git or Perforce)
  into a stakeholder wiki page.
- `smartvoice` - Optional house voice, resolved per user
  (`voice-profiles/<username>.md`, then a generic profile, else off).
- `smartdiagram` - Curated interactive architecture diagrams with
  click-to-inspect invariants.
- `smartdiff` - A session's changes as one HTML review page with intent
  notes. Unreal Blueprints get a semantic diff of graphs and variables.
  Agent-only mode shows just the agent's own edits, read from the
  session record rather than the working tree.

Switch a part off in your skill list, or with the installer's
enable and disable menu, and smartplan runs without it. Its Parts table
says what each part adds and what you get with it off.

You invoke only `/smartplan <task>`. One dial, `{{MODE}}`, tunes the
planner seat, floors, verification, effort, and fan-out width. It runs
`max-quality`, `high-quality`, `balanced`, `budget`, or `max-savings`.
The human gate, no unverified merges, and honest reporting never change.
See `smartcost/references/modes.md`.

The shipped default is **`max-savings`**. Copilot meters AI credits per
token. On this family's own benchmarks, max-savings measured equal quality
at 54% of balanced's cost on mechanical work and 32% on judgment work.

This bundle also ships **tool-locked agent seats**. The verifier has no
file-editing tools, only read access plus a shell to re-run acceptance.
The scout has nothing but read/search. All eight seats are pinned in
`.github/agents/`: planner, three implementer tiers, two verifiers, scout,
and an Unreal reviewer.

The mechanical half of verification (acceptance, scope, and the extra
oracle inputs used to grade output) belongs in a script you keep in your
own project, where it costs no model calls at all.

## The setup script

`.github/skills/smartplan/scripts/smart-plan-setup.cmd` (Command Prompt) and `.github/skills/smartplan/scripts/smart-plan-setup.ps1`
(PowerShell) are one interactive installer. The `.cmd` just launches
the `.ps1`. The menu covers:

1. Install selected skills into another project (`.github\skills\`)
2. Install personally for Copilot CLI (`~\.copilot\skills\` and the seven agent profiles)
3. Enable / disable skills - per skill or all of them, as a reversible `SKILL.md ↔ SKILL.md.off` rename
4. Status - what is installed and enabled where

It runs from a checkout or a Copilot export and never edits
skill content or git history. smartplan-quickstart.md covers macOS/Linux
(§ 1) and fill-once configuration (§ 2).

## The model-tiering strategy

> Plan with the strong model. Implement with the cheaper model. Escalate
> on failure, not on a hunch.

- **Route by regime first.** A regime is a task's scale and risk. Work
  one strong context can hold runs **inline**. Fan-out (parallel
  executor calls) is for work beyond one context, rework-prone
  execution, batches that have a deadline, and merges needing an independent
  check.
- **Two seats.** The planner defaults to Opus-class, since a planning
  flaw repeats in every executor. The implementer starts at its task
  class's *floor*, the cheapest tier that reliably lands it
  (`smartroute/references/routing.md`).
- **Floors.** Mechanical, verifier-checkable leaves (single tasks like
  renames) floor at Haiku-class, correctness-sensitive work at
  Sonnet-class. Opus-class is the reserve for cross-cutting leaves and
  escalations. `smartroute/references/model-classes.md` has the roster.
- **Cheap tiers are safe only behind a verifier.** Every Cheap-tier
  result gets an independent smartcheck in a fresh context, from a
  verifier never weaker than the executor.
- **Fail-twice escalation.** Two failures on a leaf escalate exactly one
  tier, with an evidence report.
- **The seat is the ceiling.** Nothing dispatches above the session's
  model until you say yes. One yes covers that tier for the session.
- **A human gates the plan.** You review it before any fan-out, when a
  flaw costs one read, not N rebuilds.
- **Repeated deterministic work leaves the ladder.** It moves into a
  script at accept time.

## Measured, not asserted

**Does the skill work?** Seven scenarios on Haiku 4.5, Sonnet 5, and Opus 5, three judges per response. **62 of 63 runs passed with it. 4 of 21 without**, a baseline run once per case against three times. The no-skill arm was only told to skip the skill. The eval stands in for the vendor's early-access eval harness.

**Does fan-out pay?** Only in its own regimes. On one-context work it costs **1.5–2.9×** a single inline pass at equal quality, at one, five, or twelve leaves (T14/T19/T20/T21) and under credit billing.

**What does the skill itself cost?** **1.05× in Copilot credits on a real Epic Lyra task** against a bare session, at quality parity under a UE5.8 compile gate.

**What else is measured.** Batch verification cut the verify cost by 68%. Each leaf still got its own verdict. The C++ layer caught hidden undefined behavior that compiles clean and passes a desk check.

**Honest scope.** Tiering lowers the *bill*, not the token count. Read the bill off the provider's console.
The full policy and its caveats live in `.github/skills/smartplan/SKILL.md`.
Copilot depth (seat pinning, credit levers, the model roster) is in
`.github/skills/smartplan/references/copilot.md`.
