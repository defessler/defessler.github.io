# smartplan on ZCode

ZCode reads this file at `~/.zcode/AGENTS.md` (user-global) and at
`AGENTS.md` in the Workspace root, searching upward from the working
directory to the project root. One workspace file resolves. ZCode does not
merge `AGENTS.md` across directory levels or expand `@import` / `@include`
(read 2026-09-15). It does **not** read `CLAUDE.md` at runtime — that file
is consumed once during onboarding as a migration source only.

## Routing

Route every coding or implementation task by regime. A plainly one-context,
non-risky task runs inline without loading the skill body. Invoke
`$smartplan` only when a fan-out signal holds: a working set beyond one
context, two inline fix attempts that already failed against the same
signature, a verify-gated class (C++ shared blind spots, security), or a
wall-clock-bound batch. Independent verify still gates risky merges at any
size.

## What differs on this harness

- **The tiering lever is a per-agent pin, not a per-call parameter.**
  Subagents live at `~/.zcode/agents/<name>.md`, or in `.zcode/agents/`
  under the working directory (read from the working directory only,
  unprobed). There is **no per-call override**. An escalation means
  addressing a different seat rather than raising a parameter. The
  documented frontmatter keys are `name`, `description`, `model`,
  `thoughtLevel`, `color`, `tools`, `disallowedTools`, `maxTurns`,
  `injectAgentsMd` and `mcpServers`.
- **The shipped seats inherit your primary model until you pin them.**
  ZCode reads the `model` values `inherit`, `main`, `sonnet`, `opus` and
  `haiku` as no model. A bare ID such as `glm-5.3` inherits too. Neither
  raises an error. So every seat in `agents/` runs on the primary
  session's model. The tiers collapse to one. To pin a seat, write
  `model: <providerId>/<modelId>` using the provider ID from your own ZCode
  provider config, optionally suffixed `$<level>` for the thought level.
  Pin the newest version of each model line your provider serves. A
  qualified value that doesn't resolve stops the dispatch rather than
  falling back. The seats' `effort:` key isn't read here. Settings can
  also give the built-in `Explore` a dedicated cheap model, which makes a
  scout tier with no seat file. (Code-read against ZCode 3.14.3, not yet
  probed with a live dispatch.)
- **Seats get this file by default.** Custom subagents inject the user and
  workspace `AGENTS.md` unless they set `injectAgentsMd: false`, which
  saves tokens on leaf seats that don't route. A custom `tools` list is
  exhaustive. A seat without `Skill` on it can't invoke a skill.
- **Foreground subagents block.** Launched together they run in parallel and
  the main task waits for all of them. That makes a foreground wave a
  barrier rather than a pipeline. A background mode exists where the main
  task does not wait. Background `Explore` subagents are read-only.
- **A dynamic workflow tiers per subagent from 3.15.1.** `agent(name,
  { model })` names a model per subagent, ahead of the run-level
  `subagent_model` and the session model. Before 3.15.1 a run is
  single-tier, so a tiered wave needs separate runs or seats. Workflow
  subagents can't start a nested workflow.
- **Goal Mode is a verify gate you already have.** At the end of every round
  ZCode runs a separate check for whether the objective was met, demanding
  artifact evidence rather than a confident reply, and auto-starts another
  round if not. Reach for `/goal` before rebuilding that loop by hand. It is
  same-context self-checking, so it does not replace an independent verifier
  on risky merges.
- **Schedule mechanical work off-peak.** On the GLM Coding Plan, peak hours
  are Mon-Fri 14:00-18:00 UTC+8. Off-peak (weekends included) bills at 50%
  of standard credits and peak at 1x. That 2x clock spread on the same
  model makes timing a first-class cost lever. Timing buys nothing from
  2026-09-25 to 2026-10-07, when every hour bills off-peak. Until
  2026-10-07, GLM-5.3-Flash also costs zero quota through ZCode 3.10+ from
  23:00 to 09:00 UTC+8 (read 2026-09-22).
- **Idle-time tasks run free of plan quota**, their foreground subagents
  and compaction included. They reject background subagents. An idle
  wave runs foreground. They're rolling out in batches, need a personal
  Coding Plan (not Start Plan or an API key), and start when the server
  decides. The server also assigns their model. An idle run can't be
  tiered. Anything you type into the session still bills.
- **On the GLM Coding Plan, name GLM-5.3 or GLM-5.3-Flash directly.** The
  plan FAQ documents only those two as callable (read 2026-09-22).
- **ZCode is not GLM-only.** It drives Anthropic directly, among other
  providers. A Claude ladder is reachable. Prefer that configuration if
  the tiering policy should mean what it means elsewhere. ZCode 3.14.3's
  Anthropic catalog stops at Opus 5 and Fable 5.1. Opus 5.5 needs a
  hand-added `claude-opus-5-5`. A hand-added model defaults to a 200K
  context window until you set it.

Depth on demand: `skills/smartplan/references/zcode.md`.
