---
name: smartcheck-cpp
description: smartplan part. The C++ gamedev layer over smartcheck (ownership, UB, hot paths, threading, determinism) under an Engine Profile. Load when verifying a C++ diff.
user-invocable: false
---

# smartcheck-cpp — part of smartplan

The C++ gamedev layer over `smartcheck`. Load `smartcheck` first, then
read [`references/cpp-gamedev-check.md`](references/cpp-gamedev-check.md)
whole and apply it under its Engine Profile.

When this skill is off, smartcheck runs alone and the verdict names the
missing C++ layer on a C++ diff.
