---
name: smartplan
description: Use proactively for any coding or implementation task. It routes by regime - one-context tasks run inline; fan-out is for beyond-context scale, rework-prone execution, verify-gated work, and wall-clock batches. FAST PATH - plainly one-context, non-risky work runs inline now (one-line routing call, batched turns, terse output); any fan-out REQUIRES loading the smartflow skill first.
---

# smartplan — regime router

**Your FIRST output line is the routing call.** Before any answer, plan,
code, diff, or "Done", emit exactly this and nothing above it:

```
Routing call: <inline|fan-out> — <reason, one clause>
```

No exceptions. Obvious routes still get the line. Leading with the
deliverable doesn't count, and terseness is no exemption — one line IS
the terse form.

**The rule:** plan with the strong model, implement with the cheaper
model, escalate on demonstrated failure — never on a hunch, never above
your seat unasked. **Invoke:**
`/smartplan <task>` on Claude Code or Copilot CLI; you route it yourself
and **never ask the user to invoke anything.**

## Pick the route

First matching row wins.

| The work | Route | Why |
| --- | --- | --- |
| Exceeds one context window | **Fan-out** | It cannot be held, so it must be split. |
| ≥4 independent units with disjoint FILES, and finishing sooner beats finishing cheaper (never on Copilot) | **Fan-out** | Buys wall-clock at a known token cost. |
| Inline already failed twice on the same signature | **Fan-out** | Demonstrated failure, not anticipated. |
| Risky merge — C++ UB, concurrency, templates, security | **Inline + independent verify** | The verify floor holds at every size. |
| Everything else | **Inline** | One strong context out-runs N cold cheaper ones. |

**Count units, not tokens.** A 1M window *holds* large work without
*bounding* it, so "fits in one context" is no size test. N files taking the
SAME edit is ONE leaf. N taking different edits is N. Firing this
trades tokens for wall-clock knowingly — the band below is just as real at 4 units.

Fan-out costs 1.5–2.9× an inline pass at equal quality, at every leaf
count and size measured. Fire it to buy something with that, and say
which.

Worked examples of that first line — fan-out also names what it bought:

```
Routing call: inline — one file, one edit, nothing else calls it.
Routing call: fan-out — 6 units, disjoint FILES; trades tokens for wall-clock.
```

Then start, no deliberation essay. An unstated call defaults to inline,
and that silence is the miss. At ≥4 independent units, name the count
and why inline still wins.

## Inline route — the default
- **Token discipline.** Batch independent reads into one turn and
  independent writes into one turn. Never re-read a file already in
  context. Hold the mode's output ceiling — output bills ≈5× input.
- **Verify floor — the strongest AVAILABLE oracle, not merely a fresh one:**
  **1** executable (compiler, assertion, replayed real input) · **2**
  fresh-context model · **3** same-context model. A cold model shares the
  writer's blind spots. A compiler doesn't. Code-emitting work has
  tier 1 by definition. Before a green check counts, say what would turn
  it **red**. If that doesn't name what you just changed, it isn't
  verification. **Seat-aware:** below Strong, escalate the VERIFY one
  tier above your seat when the work has no executable oracle, crosses
  a second caller, or is a never-Cheap class — concurrency, UB,
  templates, security. Countable signals, never a hunch.
  **Escalating emits an artifact, never an intention** — write the
  missing check, or the verify brief in full. "Should be verified",
  "the next step is a test", and handing the run to the user are one
  miss wearing three faces (`routing.md` § Seat-aware pre-flight).
- **Seat ceiling.** Your seat is the model this session runs as (the
  system prompt or `/model` names it, else treat it as Mid).
  **Nothing dispatches above your seat until the user says yes**: an
  escalated verify, a fail-twice target, an Opus or Fable planner. No
  initial seat pick prices above the incumbent either — cheapest
  adequate row, a named gate per climb (`routing.md` § The cost
  ceiling). Write the artifact first, then ask in ONE line: what it's
  for, which model, that the brief is written. Dispatch on the yes. One
  yes covers that tier for the session. At or below the seat needs no
  ask. The ask names a spend, so it isn't the question-stall the spiral
  guard bans. **A Cheap seat never asks.** Nothing leaves it priced
  above its own model. It writes the artifact, offers the session model
  the work would suit, and carries on (`routing.md` Cheap hard floor
  #6). On Copilot every subagent runs GPT-6 Luna, and a pricier session
  orchestrates and verifies Luna (`copilot.md` § Luna ceiling).
- **Offered, never required.** Every tier named here is advice. A no, or
  a model the plan doesn't serve, never stops the work. It runs on the
  strongest model on offer at or below the seat, oracle first, a fresh
  context for any verify, and names the gap at the gate and in the
  verdict. Judgment the reader can't settle returns UNKNOWN.
- **Claude Code roles** (author, 2026-09-23; T45, T47). Haiku at low
  writes every leaf. Sonnet at medium takes never-Cheap rows and the
  first fail-twice. An Opus session briefs `smartplan-implementer` and
  never edits code inline. An Opus verifier
  checks every diff. Haiku also scouts.
- **Spiral guard.** Two failed self-repairs against the same failing
  signature = STOP. Dispatch ONE fresh-context diagnosis, Mid where on
  offer (Fable by ask on a never-Cheap row, `flow.md`), instead of a
  third blind attempt, carrying the ESCALATION
  REPORT — **task · tier history (each attempt, its verdict, one-line
  why) · evidence pasted byte-verbatim, never reworded or split up ·
  hypothesis · what the receiver should do differently** (shape:
  `flow.md`, which the inline route never loads). **Write it out in
  full — referring to it is not carrying it.** Brief the diagnosis in
  gated phases, each written into the report before the next: reproduce
  the failure, narrow it to the smallest input, state ONE falsifiable
  hypothesis, prove it with the oracle. No fix before the proof.
  **Do not keep debugging here, and do not turn back to the user with
  questions** — the two failed attempts hold what the diagnosis needs.
  A Cheap seat runs it at its own tier. A user saying "try again" does
  not reset the count.
- **False-success guard.** All-green attempts never trip the spiral
  guard. **A repeat report of a symptom you claimed fixed is a
  strike.** The next action is not a third fix — it's proving your
  observable measures what it describes.
- **Land the check, not a note.** Leave the executable oracle in the
  repo (compile step, assertion, fixture) so the next context meets it.
  **Compaction re-injects skill bodies, NOT the references you read.**
  Mid-run, re-read `flow.md`, `artifacts.md` and `run-state.md` before
  the next dispatch.
- **Cost mode.** Honor `{{MODE}}`
  (default max-quality; max-savings on Copilot — it meters credits per token).
  Copilot never trades tokens for wall-clock, at any mode.
  On a budget ask or stated pressure, bias inline choices toward cost.
  On Copilot, print the budget preflight FIRST.

## Fan-out route

**HARD GATE — load the `smartflow` skill FIRST and follow its `flow.md` end to end.**
Never dispatch a tiered subagent, compile a brief, or fan out at all
without that file loaded. The human plan-review gate and the
mode-invariant floors live there. **A denied read is a STOP, never an
obstacle to route around.** With `smartflow` off there is no fan-out.

**A lone verify dispatch is not a fan-out.** The table's *inline +
independent verify* row is an inline route, and so is an escalated
seat-aware verify — send the `smartplan-verifier` seat at the tier you
named, within the seat ceiling, and carry on. Your harness reference
owns the lever.

Copy this checklist and work it in order:

```
- [ ] 1. smartflow loaded, flow.md read
- [ ] 2. Plan written — leaves have disjoint FILES
- [ ] 3. Plan approved by a human, go-signal quoted verbatim, every
         above-seat tier named in the plan it approves
- [ ] 4. Leaves dispatched in parallel, each on its own tier
- [ ] 5. Every result independently verified — never the executor's own context
- [ ] 6. Cross-leaf seams integrated, confidence notes written
```

Steps 3 and 5 are floors. Skipping either isn't a shortcut, it's a worse
process.

## Parts — one skill each

**A part is on only when your skill listing names it.** Load it with
the Skill tool when the route needs it and read the reference it names,
whole. Unlisted or failing to load means off: follow its Off column, say
so once after the routing call, and never read its files by path to get
round the switch.

| Part | Adds | Off |
| --- | --- | --- |
| `smartflow` | Fan-out flow, human gate, run artifacts | No fan-out. Route inline, with a lone verify where the table asks. |
| `smartroute` | Class-to-tier mapping, model registry | Subagents run the session model. No tier climbs. |
| `smartcost` | Quality↔cost dial, budget preflight | The default mode, no dial. |
| `smartbrief` | Compiled briefs for Cheap leaves | No Cheap leaves. A plain FILES · CHANGE · ACCEPTANCE task at Mid. |
| `smartexec` | The Cheap executor's protocol | No Cheap leaves, as above. |
| `smartcheck` | The independent verify protocol | Executable oracles only and no Cheap leaves, the gap named at the gate. |
| `smartcheck-cpp` | The C++ gamedev layer over smartcheck | smartcheck alone, the missing layer named on a C++ diff. |

`smartcache` adds cache-aware fan-out ordering on Claude Code. Off,
dispatch order ignores the cache.

**Harness facts stay here.** Load only yours:
[`copilot.md`](references/copilot.md) (pinned agents, credits, the
Luna rule).
[`claude-code.md`](references/claude-code.md) (per-call `model:`,
spawn caps, the hook), [`local-models.md`](references/local-models.md)
(a model behind a shim), [`m365-copilot.md`](references/m365-copilot.md)
(read its verdict table first).
[`evidence.md`](references/evidence.md) holds the measured runs behind
the routing table. Read it before improvising past a rule.

## Evolving this skill

Reality outruns the rubric → flag it, never silently improvise. Procedure in
`flow.md` § Evolving this skill. History in
[the repo's commit log](https://github.com/defessler/smartplan/commits/main).
