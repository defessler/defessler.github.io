# Quality↔cost modes — one dial over every discretionary knob

*Load from flow.md § Quality↔cost mode. The dial biases the judgment
calls the flow already makes; it never overrides the invariants at the
bottom. Model names and prices below are illustrative — `model-classes.md`
is the registry and wins on any drift.*

## Contents

- Setting it
- The matrix
- The caveman register (output-side language compression)
- Mode-invariant floors (no mode may dial these)
- Harness mapping
- Measured economics + budget personas (Copilot, live 2026-07-13)
- Honest note
- Budget preflight (budget / max-savings — print before the work)

## Setting it

Resolution order (first wins): an explicit per-invocation ask
(`/smartplan --mode budget …`, or plain words — "budget mode", "max
quality for this one") → a brief's MODE line (per-leaf override,
`brief.md` § Dispatch) → the `{{MODE}}` token set once for the project →
the shipped default — **max-quality** here, **max-savings** on Copilot CLI.
A non-default mode is recorded per leaf in `run-state.md`'s note column;
the floors below don't move, whatever the default is.

**The default follows the harness.** Copilot meters credits per token.
It ships the savings end of the dial, **max-savings**, which measured
equal quality at **54%** of balanced's cost on a 5-leaf mechanical wave
(T8, before balanced gained sampling of its own) and at **32%** on
judgment-class work (T13). The Copilot export ships it hard-coded. It
samples the verify on homogeneous waves of five or more and says so at
the gate (§ Honest note). On T27's 3-leaf wave, budget ran slightly
cheaper (13.6 vs ~14.4 cr). Step up to `budget` for a narrow wave, or
to `balanced` wherever every leaf should keep its model verify.

On Claude Code the default is **max-quality**, by the author's choice.
A subscription carries no per-token bill inside plan limits. Its
five-hour and weekly windows are a meter of their own, though. Fast mode
draws usage credits at $8/$40 per MTok on Opus 5.5 ($10/$50 on Opus 5 and
4.8), and a Fable-class seat can draw them
too, depending on plan and seat tier — so max-quality's extras (Opus
planner, one-strike escalation, 3-verifier panel) spend real headroom.
The 2026-09-07 cost audit measured budget at parity and proposed it on
both harnesses. The author kept max-quality here. Step down per
invocation when a session races a cap, and say so at the gate.

## The matrix

| Knob | **max-quality** (default) | high-quality | balanced | budget | **max-savings** (default on Copilot) |
| --- | --- | --- | --- | --- | --- |
| Planner seat | Opus; Fable only for the toughest decomposition, by ask (plans and diagnoses only) | Opus, no drop-down | Opus default, drop on fit | Sonnet default; Opus only for cross-cutting or ambiguous plans | Sonnet always; flag when a plan needed more |
| Implementer floor | Sonnet for mechanical, Opus for correctness-sensitive | Today's floors; doubt rounds up to Mid | Class floors (`routing.md`) | Cheap wherever the check is scriptable, incl. borderline-mechanical | Cheap for anything checkable; Mid only via fail-twice |
| Verify | Verifier one tier above executor (capped at Strong — Strong leaves get a fresh cross-family Strong verifier, never Fable), no session-diff exception; 3-verifier decorrelated panel on correctness-sensitive leaves | No session-diff exception; Strong verify on Mid leaves | `check.md` tiering + the documented session-diff exception; credit-billed harness → check.md's credit-billed default (script-first, sampled batch) | Exception preferred where legal; script pre-checks first, script-only where scriptable | Script checks wherever scriptable; on Copilot, Cheap leaves take a fresh Luna's scripted acceptance (`@smartplan-verifier-cheap`, same-model, noted in the verdict, UNKNOWN on judgment) unless the leaf is unsuitable for it; single Mid-verifier cap (an escalated-to-Mid leaf keeps its Strong/cross-family verifier — `check.md` hard rule); sampling on homogeneous waves ≥5 — verify ⌈N/3⌉, all on any failure (**accepts silent-failure risk on unsampled leaves; said out loud at the gate**) |
| Escalation | One strike escalates | fail-twice (canonical) | fail-twice | fail-twice | fail-twice |
| Effort | high everywhere, xhigh/max only on a measured gain | high on plan + verify | Harness defaults; low on Cheap leaves | low on Cheap + mechanical Mid | low everywhere but the plan turn |
| Output register | Full prose allowed (templates still apply) | Terse templates (`check.md` § Verdict budget) | Terse templates + telegraphic agent-consumed prose (caveman *lite*) | Caveman *full* on all agent-consumed prose | Caveman *ultra* — fragments |
| Fan-out | ≤3 leaves/wave, extra Integrate attention | 3–5 | 3–5 (flow default) | Size to survive caps; wider cheap waves | No wall-clock fan-out: Copilot never trades tokens for time (only scale, rework or a verify gate fans out); width stops paying past ≥5 (T27); batch/sample the verify |
| Inline output ceiling | No ceiling (templates apply) | One-paragraph close | One-paragraph close | Routing line + diffs only; echo-free edits (never reprint file content); ≤3-line close; no offers/retro | Same as budget, fragments allowed |

**On Claude Code the Mid implementer pins Haiku at `effort: low`**
(T47, 2026-10-19). A never-Cheap leaf or a fail-twice escalation
dispatches it with `model: sonnet` and `effort: medium`, Sonnet's T44
setting, since the low pin otherwise rides the model override. The
Strong verifier pins `high`. A pin beats `/effort` and ultracode
(`claude-code.md`, probed 2026-09-22). Haiku leaves run low, Sonnet
leaves and an Opus escalation medium (passed per call), and Strong
verify high, in every mode. The cheaper Effort cells land on
the plan turn (stock Opus 5.5 runs medium). Set it with `--effort` at
launch, since `/effort` saves per model.
Budget's mechanical Mid lands only as a workflow `agent()` effort.

**Inline output ceiling — the narration cap.**
Output bills ≈5× input, so the ceiling row above is a hard cap on the
session's own narration during inline work: at budget and below, the
routing line and the diffs ARE the deliverable — never reprint file
contents after an edit, close in ≤3 lines, skip offers and retros. It
narrows the gap against a bare session without closing it: T29 measured
**1.12× at budget**, verdict "<1× at budget: NOT met" (k=1). The one
sub-1× point on record is T30's 0.88×, and that session routed off the
skill *description* and never loaded this body — so <1× is a routing
result, not a ceiling result.

## The caveman register (output-side language compression)

Levels borrowed from the upstream skill (github.com/juliusbrussee/caveman
— *lite* / *full* / *ultra*; upstream claims ~65% avg output reduction,
range 22–87%, and itself warns the savings are **output-only** and go
**net-negative on already-terse text**). Application here, at every mode:
the fixed DONE/BLOCKED/verdict **templates never change register** —
they're already terse contracts; the register applies to **prose whose
only reader is another model seat** (scout packs, report narration,
investigation notes). Code, paths, commands, errors, and quoted evidence
stay byte-verbatim at every level — invariant, not a mode choice.
Human-facing turns are never telegraphic; only `max-quality` changes the
*agent-facing* register (back to full prose, for maximum executor
comprehension on the hardest work).

Quality evidence: the register has now run live with zero measured
quality loss — T7 (register-compliant fragments, verifier-confirmed),
T8 (5-leaf × 2 arms = 50-case hidden oracle, 25/25 per arm), T13
(judgment-class, 2 matched pairs, 11/11 per arm). On template-bound micro-leaves it saves ≈nothing (upstream's own
net-negative-on-terse warning, observed) — its value is on prose-heavy
packs/reports, still upstream-claimed rather than measured here. So apply
it only there; don't spend instruction budget forcing *ultra* onto
micro-leaves where it can't pay.

## Mode-invariant floors (no mode may dial these)

- The **human plan gate** and verbatim AUTHORIZATION quoting.
- **Never merge unverified** — max-savings may swap a model verifier for
  a script/sample only where `check.md` § Tiering already permits a
  scripted check; a zero-verification merge doesn't exist at any mode.
- **Shared-blind-spot classes keep the full tiered verifier at every
  mode** — C++ UB, concurrency, templates, security. No mode scripts,
  batches or samples these away, and budget/max-savings' script-only and
  ⌈N/3⌉ rows don't reach them (`check.md` § Credit-billed default,
  `SKILL.md` § Verify floor). They never take a Cheap implementer
  either (`routing.md` floor table + hard floor #5).
- **Honesty rules** — the development repo's claim ledger discipline, no fabricated evidence,
  acceptance re-runs over pasted claims.
- **Attempt bookkeeping** — strikes persist in `run-state.md` at every
  mode.
- **The seat ceiling** — no mode dispatches above the session seat
  unasked (`SKILL.md` § Seat ceiling). max-quality's Opus floors and
  Fable planner are asks on any seat below them, and a fail-twice climb above
  the seat is the same ask at every mode. A Cheap seat doesn't ask
  at all. Nothing leaves it priced above its own model (`routing.md`
  Cheap hard floor #6). **The cost ceiling binds at every mode too**:
  no initial pick prices above the incumbent, whatever the dial says
  (`routing.md` § The cost ceiling). The modes move floors and verify
  machinery, never that invariant.
- **Offered, never required.** No floor here demands a model the user
  declines or the plan doesn't serve. It falls to the strongest on
  offer, named at the gate (`routing.md`).
- **Byte-verbatim code/paths/errors** in every register.

## Harness mapping

- **Claude Code (§A):** floors move via per-call `model:`; effort via
  `effort:`; the panel is 3 concurrent verifier dispatches, cross-family
  when the roster allows.
- **Copilot (§B):** floors pick among `@smartplan-implementer-cheap` /
  `-implementer` / `-implementer-reserve`; effort via `--effort` or
  `subagents.agents.<name>.effortLevel`, since dispatch ignores a seat's
  `reasoningEffort:`; budget modes lean on `/limits` soft caps
  (`copilot.md`). **Confirm the Opus pin actually lands** rather than
  pre-emptively degrading (T30 saw a gate move). A refusal prints a
  downgrade warning. Say so at the gate rather than presenting the mode
  as landed. **Route the
  verify cross-family on price either way**: `check.md` § Tiering sends
  every Mid leaf to a Strong verifier, and the pinned Gemini 3.8 Flash
  (0.75/3.75, `check.md` § Family decorrelation) is the price-sensitive
  pick, never a silent Sonnet-judging-Sonnet self-check. Panel
  concurrency rides the plan's subagent cap. It may partially serialize
  on Pro.

## Measured economics + budget personas (Copilot, live 2026-07-13)

T27 ran all five modes end to end on one canonical 3-leaf mechanical wave
(k=1, Pro+, the development repo's benchmark records) — **this replaces T7's projected 5-mode
table for this shape of task**. Measured credits, balanced at its
corrected cost (the original run wrongly gave it budget's script-only
free ride):

| Mode | cr/wave | vs balanced | Pro 1,500/mo | Pro+ 7,000/mo |
| --- | --- | --- | --- | --- |
| max-quality | 87.6 | 386% | ~17 waves | ~80 |
| high-quality | 54.5 | 240% | ~28 | ~128 |
| **balanced** | 22.7 | 100% | ~66 | ~308 |
| budget | 13.6 | **60%** | ~110 | ~514 |
| max-savings | ~14.4 *(clean est.)* | 63% | ~104 | ~486 |

Personas: **flat-subscription (Claude Code)** → any mode; `max-quality`
ships as the default there by the author's choice, and the rate windows
are what it spends. **~$40/mo ≈ Copilot Pro+
(7,000 cr)** → every mode lands incl. real Opus rows; max-savings default,
budget for narrow waves, balanced where per-leaf model verify is wanted.
**Copilot Pro (1,500 cr)** → max-savings default, budget for narrow
waves; max-quality/high-quality run Pro-degraded **only if the Opus pin
actually refuses** (mapping above). On T8 the unsampled leaves hid
nothing, and a real false-BLOCKED surfaced regardless of sampling, since
BLOCKED always does.

## Honest note

budget/max-savings **increase silent-failure exposure by design** — the
matrix trades verification strength for spend, and the sampling row says
so at the gate rather than burying it. If a max-savings wave bounces past
routing.md's ~20–30% breakeven, the mode is costing more than balanced
would: say so and recommend stepping up one mode. Quality parity is
**measured** on the two classes above (T8, T13 — zero delta each); the
≥90% bar holds for mechanisms, costs, and those classes, and
novel-ambiguity judgment stays the one unmeasured frontier.

The max-savings-vs-balanced cost figure is **not one number** — quote the
right one: **63%** (T27, 3-leaf mechanical, against balanced's corrected
verify); **54%** (T8, 5-leaf mechanical, 50-case hidden oracle); **32%**
(T13, judgment-class, 2 matched pairs). All three are measured, and T7's
old ~40% projection is retired. The gap mostly closes past ≥5 leaves: in
T27's no-failure steady state balanced and max-savings landed ~23 vs ~22
cr, both sampling ⌈N/3⌉.

## Budget preflight (budget / max-savings — print before the work)

On an **explicit** `budget`/`max-savings` ask or a stated tight budget,
print this first, then run the column for the mode in force, max-savings
when the ask names none (a standing default alone doesn't re-print it).
It confirms the **launch levers the skill can't set itself** (the
human's, at session start):

1. **Model:** `gpt-6-luna` ($0.10/$0.50), never Auto: the Luna
   ceiling (`copilot.md`). Any tiered wave takes explicit per-agent
   pins. Never Opus/Fable for a whole session.
2. **Cap leaves, not the orchestrator:** `--max-ai-credits` bounds a
   runaway repair, but a cap can suppress skill loading (T25) — cap leaves.
3. **Warm cache:** `--resume` for repairs; minimal context (re-read every
   turn).
4. **Effort/output:** `--effort low` on mechanical turns; terse output
   (≈5× input).
5. **No wall-clock buys:** independent units alone stay inline on
   Copilot, whatever the mode. Speed is never worth extra credits.

Full human-facing guide: `docs/copilot-on-a-budget.md`.
