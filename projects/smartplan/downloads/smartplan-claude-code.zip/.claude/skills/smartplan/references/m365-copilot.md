# smartplan §D deep reference — Microsoft 365 Copilot: what fits, what can't

> Facts verified 2026-08-12 against `learn.microsoft.com`, the raw
> declarative-agent JSON schemas at `developer.microsoft.com`, and Microsoft's
> published pricing, re-read 2026-09-29. Nothing here is measured — no
> Microsoft surface is installed on this machine, so every claim is read
> rather than observed. The product became Microsoft Copilot in August
> 2026. Learn uses the new name, pricing pages the old.

Load this only when the target is a Microsoft 365 Copilot surface. **Read the
verdict first — most of this family does not ship here, and knowing which
half does saves a wasted build.**

## Contents

- The verdict, up front
- Declarative agents — why the family barely fits
- Copilot Studio — the documented Skills feature
- Hard limits (declarative agents)
- MCP
- There is a CLI — two, in fact
- Money
- What smartplan actually becomes here

## The verdict, up front

M365 Copilot is not one surface. It is four delivery targets with different
rules, and smartplan's fit differs sharply across them:

| Target | Can it carry smartplan? | Why |
| --- | --- | --- |
| **Declarative agent** (M365 Copilot) | **Maybe, preview** | 8,000-char base instructions, one inline string, no frontier-model pick. Custom skills add SKILL.md and progressive disclosure, Frontier Preview only |
| **Copilot Studio — GitHub Copilot harness** | **Yes, partially** | Ships a real `SKILL.md` Skills feature and a per-agent model picker |
| **Copilot Studio — standard harness** | Policy only, no skills | Has model choice and a `reason` escalation keyword, but its "Skills" is a different, legacy feature |
| **Copilot Cowork** | **Maybe — documented, unprobed** | Microsoft documents `atk import openplugin` converting Claude plugin packages with skills copied verbatim, `references/` and `scripts/` included (2026-09-21) |

So the honest shape is **a mapping doc plus a narrow export for the GitHub
Copilot harness.** The *declarative-agent* path was closed by structure. It
reopens only through the custom-skills preview below.

**But "M365 is closed to this family" is now too strong.** Microsoft's Cowork
customization page documents a fourth path: "If your file is a Claude or other
compatible plugin package, Cowork automatically converts it into a publishable
package, including any bundled skills and external connectors it contains."
<!-- claim:m365-cowork-converts-claude-packages --> The same page accepts a
bare `.md` holding a single `SKILL.md` (1 MB cap), or a `.zip`/`.skill`
archive with `SKILL.md` at its root (10 MB compressed, 50 MB uncompressed,
100 files).

This is a **documented path, still unprobed here**. The plugin-development
page (ms.date 2026-09-21) documents `atk import openplugin`, which reads a
Claude Code plugin's `.claude-plugin/plugin.json`, `.mcp.json` and `skills/`
directory. Skills are "Copied verbatim - identical format," with per-skill
`references/` (on demand) and `scripts/` under the same three layers:
frontmatter always, SKILL.md body on trigger, references on demand. It names
the Agent Skills open standard and lists `commands/`, `agents/`, `hooks/`,
`settings.json` and `bin/` as **not converted**. Probe before any export doc
promises it. The 100-file cap is about twice the release bundle's file
count. Import needs `atk` 1.1.12+. A package holds up to 20 skills, a skill
up to 20 companion files (above smartplan's 15) at 5 MB each and 10 MB
total. Each `name` must be kebab-case and match its folder.
`atk export openplugin --manifest-kind claude-plugin` exports back out.
Import also needs `--privacy-url` and `--terms-url` and emits a `devPreview`
manifest (read 2026-09-29).

## Declarative agents — why the family barely fits

**The manifest root is a closed set of exactly 15 keys**, from the raw v1.8
schema (53,896 bytes): `id`, `version`, `name`, `description`, `disclaimer`,
`instructions`, `capabilities`, `behavior_overrides`,
`conversation_starters`, `actions`, `user_overrides`, `editorial_answers`,
`worker_agents`, `$schema`, `sensitivity_label`. The docs pin it shut:
*"Unrecognized or extraneous properties in any JSON object make the entire
document invalid."*

- **Manifest file:** referenced from the app manifest's
  `copilotAgents.declarativeAgents[].file`. Docs show `declarativeAgent1.json`.
  Copilot Studio exports `declarativeAgent.json`.
- **Schema URI:** `https://developer.microsoft.com/json-schemas/copilot/declarative-agent/v1.8/schema.json`,
  and the manifest sets `"version": "v1.8"`. **v1.8 is current** — v1.9 and
  v2.0 both return 404. v1.8 added `EmailActions` and `MeetingActions`.
- **Shipping unit:** a `.zip` holding `manifest.json` (the Microsoft 365 app
  manifest), a 192×192 `color.png` and a 32×32 `outline.png`.

**`instructions` is a single String with `maxLength` 8000.** The docs and
schema agree, and Copilot Studio's quotas page lists "Instructions for a
Copilot agent | 8,000 characters".

**The file-reference mechanism is authoring-time only.** The Agents Toolkit
template ships `"instructions": "$[file('instruction.txt')]"`, and the
tutorial says the file's contents *"are inserted in the `instructions`
property in the agent's manifest during provisioning."* So: **no *runtime*
file reference, only a token that inlines at provisioning, and the
8,000-character cap applies to the expanded string.** It buys editor
ergonomics, not headroom, and never progressive disclosure.

**Don't route around the cap through knowledge.** The "Write effective
instructions" page carries an Important callout naming XPIA
(cross-prompt-injection) classifiers, runtime truncation, attack-surface
expansion and governance bypass, closing with *"the platform makes no
guarantee they will be honored as agent instructions."*
This family needs a `references/` tree loaded on demand. A declarative
agent has one 8,000-character string and no way to defer anything. `flow.md`
alone is about 20KB. Custom skills (preview, Frontier
Preview tenants, ms.date 2026-09-03) close that half: a `SKILL.md` directory
with progressive disclosure, 8 per agent, 20,000 characters each, folders
three deep.
<!-- claim:m365-da-custom-skills-preview -->

### The model-selection nuance

"Declarative agents expose no model selection" is **wrong**, though the
practical conclusion survives. There is no top-level `model` property, but
the schema defines a **`ScenarioModels`** capability holding a required
`models` array whose each entry has a required string `id`. The TypeSpec
reference gives real syntax:
`op scenarioModels is AgentCapabilities.ScenarioModels<Models = [{ id: "model-id" }]>;`
with examples like `{ id: "financial-forecasting-model-v3" }`.

Three qualifiers put it back in its box:

1. **These are not frontier models.** The schema calls them "tenant/task
   specific models" and the docs "task-specific models", identified by opaque
   tenant-scoped IDs. You cannot select Opus over Sonnet with it.
2. **They come from Microsoft Copilot Tuning**, whose overview page is
   titled "(early access preview)" and limits availability to customers in
   early access programs.
3. **It first appears in v1.4**, not v1.8 (v1.0/1.2/1.3 have zero
   occurrences).

The overview table's actual wording is *"Limited to Copilot's orchestrator
and models."* — possessive, with a trailing period. Quote it exactly.

### The one real tiering dial on this surface

`behavior_overrides.default_response_mode`, a closed enum of exactly three
members in sentence case with literal spaces:

| Value | Behavior |
| --- | --- |
| `Auto` | Orchestrator picks per query. **The default if unspecified.** |
| `Quick response` | Low-latency, speed over reasoning depth |
| `Think deeper` | Reasoning mode, higher latency |

It is an **effort** tier, not a model ID, **per-agent**, not per-call, and
advisory — the property is prefixed `default_` because *"users can always
override this value through the model selector UI."* Microsoft published a
1.8 known issue voiding it under @mention, then removed the note without
saying it was fixed. Open the agent directly.

Map smartplan's effort axis onto it and stop. It can't express a model
ladder. The cost ceiling (`routing.md`) has nothing to bind here: no
dispatch carries a model price, and `reason` below is vendor-gated.

### Multi-agent — `worker_agents`

Narrower than it first reads:

- **Referenced by title ID only.** The 1.6 Worker agent object has one
  property: `id`, "the title ID of the application that contains the
  declarative agent" — a single letter, an underscore, and a GUID. In v1.8
  `id` became Optional with *"You must specify either `id` or `file`, but not
  both."*
- **Selection uses three signals, not two:** *"based on the connected agent's
  `name`, `description`, and `conversation_starters` in the manifest"*, and
  only a conversation starter's `text` field counts. These are runtime
  ranking signals, never manifest fields on the worker entry.
- **DA-to-DA only, text-only payloads** (adaptive cards are a partial
  exception), the user must have each connected agent installed, and **no
  parallel-dispatch guarantee is documented either way.**
- **Still preview** on the 1.8 page.

Description-level routing is what this family already uses, so *selection*
ports. Dispatch economics don't: with no documented parallelism and no
per-worker model, fan-out here buys separation of concerns, not tiering.

## Copilot Studio — the documented Skills feature

### Three harnesses, not two

The current "Choose a harness" page documents **three**: the **GitHub Copilot
harness**, the **standard harness**, and the **Copilot chat harness**.
`agents-experience/overview`'s no-transfer sentence names the pair it
covers, GitHub Copilot and standard (updated 2026-09-22). Nothing published
addresses the Copilot chat harness either way.

### The Skills feature — real, and its specifics are thinner than they look

**Confirmed:** the GitHub Copilot harness ships Skills, and a package is a
**ZIP containing a `SKILL.md` with YAML front matter (`name`, `description`)
and Markdown instructions, plus optional supporting files.**

Every load-bearing specific fails at the Copilot Studio source, and four are
traps:

1. **The frontmatter allowlist is not published.** Copilot Studio names only
   `name` and `description` and never says the set is exhaustive. The
   six-key table (adding `license`, `compatibility`, `metadata`,
   `allowed-tools`, with 64- and 1,024-character caps) exists **only on
   Microsoft's Visual Studio and SSMS pages**, which document a different
   surface. Don't cite it here.
2. **Whether extra keys are rejected is undocumented** — at Microsoft and at
   agentskills.io. Publish no claim in either direction.
3. **Subdirectories inside the ZIP are not documented.** Copilot Studio says
   "supporting files", never subdirectories. The
   `scripts/`/`references/`/`assets/` layout appears only on the VS and SSMS
   pages, where it describes a directory discovered **on disk** from
   `.github/skills/` or `.claude/skills/`, not a ZIP upload. **So this
   family's `references/` tree is unproven here.**
4. **The "Skills | 100 per agent" quota is a name collision, not a limit on
   these skills.** That row sits on a page banner-scoped to the **standard**
   harness. (The "Azure Bot Framework skills" gloss belongs to another
   table's Messages RPM row. The case rests on the banner alone, which is
   enough for the hedge.) Citing it as a cap on `SKILL.md` skills is wrong.

The name rule is wrongly framed: *"Use only lowercase letters, numbers, and
hyphens. Don't start or end the name with a hyphen"* describes the **UI Name
field** on the create and edit forms, not `SKILL.md` frontmatter validation.
Copilot Studio also omits the 64-character maximum and the
no-consecutive-hyphens rule the spec carries elsewhere.

**"Shape-compatible with Anthropic Agent Skills" is half supported.**
skills-overview (ms.date 2026-09-09) links agentskills.io and names the open
spec and progressive disclosure. It never mentions Anthropic,
`.claude/skills` or a `references/` subtree. Treat the tree as a hypothesis
to test on upload, not a fact.

### Model selection, per harness

- **GitHub Copilot harness:** *"Select the Build tab. In the components
  panel, select the Model list. Select the model you want. Select Save to
  apply the change."*
- **Standard harness:** Overview → Model, on a page bannered "This article
  describes features used in agents or agent flows powered by the standard
  harness." A doc that says "Copilot Studio exposes a dropdown at Overview →
  Model" is wrong for one of the three harnesses. Qualify it.

Published availability (GitHub Copilot harness table, ms.date 2026-11-06,
read 2026-11-11) lists twenty models: **Claude Opus 5.5, Opus 5 and Opus
4.8**, **Claude Fable 5 and Fable 5.1** (no Fable 5.2), Claude Sonnet 5.5,
Sonnet 5 and Sonnet 4.6, Haiku 5.5, GPT-6 Astra, GPT-6 Sol, GPT-6.1 Sol,
GPT-6.1 Terra, GPT-5.6 Terra, GPT-6 Luna and Grok 4.6 (all GA), GPT-5.6
Sol, GPT-5.6 Luna and GPT-5 Chat (retiring 2026-11-12 to GPT-6.1 Sol or
GPT-6 Luna), and Mistral Medium 3.5 (Experimental). GPT-5.5 Chat retired
2026-10-31. EU/EFTA tenants with cross-region data movement off keep GPT-5
Chat to 2026-11-30. By region (read 2026-10-13),
both Fables and Sonnet 5 skip Australia and Saudi Arabia, and in the US
column all three read "GA (early access environment)". A standard-release
US tenant lacks all three. The standard harness keeps its own table
(ms.date 2026-09-18), where GPT-5.5 Chat is default and Claude stops at Opus
4.7. Opus 4.6, GPT-4.1 and Grok 4.1 Fast live there too. A policy-only port
there gets an older Claude ladder.

On the GitHub harness, **Opus 5 is live. So are both Fables, except in
Australia, Saudi Arabia and standard-release US tenants.** Fable 5 also
needs an admin's separate "Anthropic models with Data Retention" opt-in,
outside Microsoft's DPA, with Anthropic keeping most inputs and outputs up
to 30 days. Fable 5.1 gets Anthropic as subprocessor only "for certain
organizations" (`connect-to-ai-subprocessor`, updated 2026-10-31). EU/EFTA
and UK tenants must opt in to any Anthropic model. Copilot Studio also needs
Power Platform's external-models switch. Of the government clouds only
non-federal GCC can opt in (since 2026-07-22). So the ladder exists
here from the 2026-11-06 table: Opus 5.5 on top, Sonnet 5.5 in the
middle, and Haiku 5.5 and GPT-6 Luna as Cheap rungs. Microsoft's Copilot
blog announced Opus 5.5 and GPT-6 Sol from 2026-09-22 across Word, Excel,
PowerPoint, Chat, Cowork and Copilot Studio, by license, access and
region, and the Learn roster now carries both. Researcher offers only an unversioned
"Claude". Seat by capability class against what's actually offered. Say
so at the gate.

### `reason` — step-level escalation, heavily gated

The standard harness escalates a step to a reasoning model when the literal
keyword **`reason`** is in the agent instructions:
*"An agent can use deep reasoning models for multiple tasks or steps, but
each one must contain the keyword reason."*

This is the closest thing on the Microsoft surface to per-call tiering,
expressed in natural language inside instruction text, not a config field.
Four gates:

1. **Preview.** The page is titled "Add a deep reasoning model for complex
   tasks (preview)" and says it is prerelease documentation.
2. **Two switches:** generative orchestration must be on *and* deep-reasoning
   access enabled for that agent, then Settings → **Deep reasoning
   (preview)** turned on.
3. **Region-limited** to the United States and the EU excluding the UK.
4. **The model is Azure OpenAI o3**, not the agent's selected primary model.
   These are explicitly separate settings.

The keyword is not the only trigger — *"Your agent determines which
tasks or steps benefit from a deep reasoning model. You can also tell your
agents to use deep reasoning."*

### Multi-agent in Copilot Studio

Child (inline) agents, connected Copilot Studio agents, and external agents
over **A2A**, plus Microsoft Foundry agents, Fabric Data agents and
Microsoft 365 Agents SDK agents (all preview). **Fan-out is prompt-directed,
not a platform primitive** — the recommended parent instruction is literally
*"Invoke both child agents… Wait for both child agents to return their
findings… Combine."*

## Hard limits (declarative agents)

`instructions` 8,000 chars · `name` 100 · `description` 1,000 · unspecified
strings 4,000 · `conversation_starters` max 12 · `actions` 1–10 · embedded
knowledge files max 10 at 1 MB each · disclaimer 500 chars · group mailboxes
max 25 · meetings `items_by_id` max 5.

Plugin side: **up to 5 plugins are always injected into the prompt. Beyond 5
it switches to semantic matching on the plugin description alone**, and
quality degrades past ~10 functions/tools. That matches the
tool-count-degradation Anthropic documents for tool selection. Note it when
sizing an MCP-heavy agent.

## MCP

Supported, but **only inside declarative agents as plugin actions** — never
in bare Microsoft 365 Copilot. The plugin manifest is `ai-plugin.json` with
`schema_version: "v2.4"`. v2.4 added `RemoteMCPServer` as a Runtime `type`
alongside `OpenApi` and `LocalPlugin`, carrying a `url` and optional
`mcp_tool_description`. Auth: `None`, `OAuthPluginVault`, `ApiKeyPluginVault`.
Copilot resolves MCP tools dynamically at runtime by default, or a developer
pins a fixed set. Requires Agents Toolkit 6.12.0+. Copilot Studio also lists
MCP servers as a Tools source.

## There is a CLI — two, in fact

- **Microsoft 365 Agents Toolkit CLI** — binary `atk`, installed with
  `npm install -g @microsoft/m365agentstoolkit-cli`. Covers
  new/add/provision/deploy/package/validate/publish/preview/install/uninstall.
  `atk new -c declarative-agent` scaffolds one directly.
- **Work IQ Dev Tools** — binary `wiqd`, official Microsoft
  (github.com/microsoft/wiqd, docs and downloads only), a preview at npm
  `latest` 0.17.0 (2026-09-28), with
  `wiqd agent create|validate|provision|package|eval` and a preview
  `wiqd plugin` tree. `create` pins manifest 1.29. `import` reads Claude,
  Cursor and Open Plugin sources. So far it only validates, shows and lists
  them.

`atk` is what an export script targets: it packages and validates the ZIP.

## Money

- **M365 Copilot (Enterprise add-on):** $30.00 user/month paid yearly, or
  $31.50 paid monthly on an annual commitment.
- **M365 Copilot Business (SMB):** $18.00 user/month paid yearly on
  promotional pricing **through 2026-12-31**, first year only (regular
  $21.00), or $25.20
  billed monthly. <!-- RECHECK:2026-12-31 -->
- **Bundles:** Business Premium with Copilot $32.00 paid yearly ($38.40
  monthly), Business Standard with Copilot $23.50 ($28.20), read 2026-09-22.
- **Copilot Chat** is included at no extra cost with an eligible M365 license.
- **Copilot Cowork** bills by usage (responses, tool and skill calls,
  images, browser tasks), more at higher effort. Access comes from a Cost
  Management spending policy that selects Cowork, not from the license.
  Even a one-credit limit grants it.
- **Copilot Studio capacity pack:** $200.00/pack/month for 25,000 Copilot
  Credits, tenant-wide, replenished each billing period.

Published credit rates: classic answer 1 · generative answer 2 · agent
action 5 · tenant graph grounding 10 · agent flow actions 13 per 100 · AI
tools basic 1 / standard 15 per 10 responses (0.1 / 1.5 per 1,000 tokens),
premium 10 per 1,000 tokens, content processing 8 per page. **Reasoning
models bill twice** — the feature rate plus "Text and generative AI tools
(premium)" at 10 credits per 1,000 tokens. Prompt-cache reads are free.
Cache writes bill as input. Overage disables custom agents at
125% of prepaid capacity.

**With an M365 Copilot add-on license there are "No extra charges for
accessing or using extensibility features (Copilot connectors, agents,
plugins)."** Declarative agents incur no hosting cost — Microsoft hosts them.
Custom engine agents you host yourself.

Pay-as-you-go is **$0.01 per Copilot Credit** in all 37 regions the Azure
page's price data lists (read 2026-09-22). A browserless read shows "$-".
The GitHub Copilot harness, the one Copilot Studio harness that carries
SKILL.md skills, is credit-billed from build time. Learn says an M365
Copilot license covers building it. Microsoft's pricing page puts it under
standalone Copilot Studio instead. A one-year Copilot Credit Pre-Purchase
Plan saves up to 20% (5% to 20% over nine tiers, 300,000 to 300,000,000
credits), per microsoft.com's Copilot Studio pricing page and its September
2026 Licensing Guide. Unused credits expire. An Agent Pre-Purchase Plan
pools Copilot Studio and Foundry usage at $1 per Agent Commit Unit (100
credits), 5% to 15% off.

## What smartplan actually becomes here

Say this at the gate rather than implying more:

- **The policy ports. The machinery doesn't.** Plan-then-execute, the
  spiral guard, the verify floor and the honesty rules are prose and
  survive intact in a `SKILL.md` on the GitHub Copilot harness.
- **Tiering degrades to two coarse dials:** a per-agent model pick from a
  Copilot Studio roster, and a three-way effort mode. The roster lists
  Haiku 5.5 and Opus 5.5 from 2026-11-06, and no Fable 5.2. There is no
  per-call override anywhere on this surface.
  Pick the newest version of a line the roster lists
  (`model-classes.md` § How to edit).
- **Independent verify has no dispatch lever.** Nothing here lets you send a
  diff to a *different* model and get a verdict back under your control.
  `flow.md`'s verifier seat has no home on M365. Say so rather than
  pretending a `reason` step is a smartcheck.
- **Nothing here is measured, and on this machine nothing can be.** No
  T-record exists for any Microsoft surface. Checked directly on
  2026-08-12: no `atk`, no `wiqd`, no `@microsoft/*` toolkit package, and
  no toolkit directory or tenant-login trace under the user profile. So
  this page is documentation-only **by necessity rather than by choice**.
  The one runnable Microsoft surface here is this repo's own tenant
  agents, and none exercises this family. Never describe a claim on this
  page as observed.
