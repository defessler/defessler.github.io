# smartplan §A deep reference — Claude Code dispatch mechanics

*Load on demand from flow.md §A — when actually dispatching a wave on
Claude Code, wiring enforcement, or making a caching/budget call. Not part
of the per-invocation read.*

## Contents

- The lever, precisely
- Opus 5 and 5.5 seats: two gaps that read as model failure
- Whether the tier lands — contested; say so and route around it
- Caching-aware fan-out
- Adjacent primitives (know when NOT to use them)
- Mechanical enforcement (optional)
- Structural tool-lockdown (shipped seats)
- Cost levers (researched 2026-07-13 — sources: the development repo's research notes)

## The lever, precisely

- **Resolution order** (documented, v2.1.251+): per-call `model:` param >
  subagent frontmatter > `CLAUDE_CODE_SUBAGENT_MODEL` env var > session
  model. Before v2.1.251 the env var came first and beat both.
  <!-- claim:cc-subagent-model-resolution-order --> Since v2.1.196
  `inherit` is **identical to unset** (re-verified 2026-08-12).
- **Per-leaf lever = per-call `model:`.** It takes only the aliases
  `sonnet`, `opus`, `haiku` and `fable` (2.1.280 schema). A full id goes in
  seat frontmatter or the env var. **Standing default:**
  `CLAUDE_CODE_SUBAGENT_MODEL=sonnet` in the settings `env` block, so a
  leaf or workflow `agent()` with no per-call or frontmatter model can't
  silently inherit the session (priciest) model. Probed 2026-09-23 on
  2.1.280: an unnamed dispatch ran Sonnet under a Haiku session, and a
  per-call `haiku` still won. That supersedes #43869's ignored-entry report
  (2.1.263). A Bash-tool `export` never reaches the running harness.
  `CLAUDE_CODE_SUBAGENT_MODEL_FORCE=1` (v2.1.257) pins every leaf, verifier
  and named seat included, and drops `model` from the Agent schema and
  workflow `agent()` opts, so no dispatch can name a tier. Never set it for
  a verified wave. `CLAUDE_CODE_WORKFLOW_SUBAGENT_MODEL` (2.1.296, read
  from the binary, unprobed) is a workflow-scoped `_FORCE`: set, it beats
  `opts.model` and the seat's `model:`. Never set it for a tiered one.
  The swap is subagent-scoped and cache-safe. Switching the **main**
  session's model, or its effort on most models, mid-run busts *its*
  prompt cache (`caching.md`).
- **Effort has a per-dispatch knob from 2.1.292.** An ad-hoc `Agent()`
  call takes `effort` beside `model`, and it beats the seat's pin
  (probed 2026-10-08 on 2.1.294: a `low` seat ran `high`). Otherwise a
  seat's frontmatter `effort:` carries it, or an `agent()` opt in a
  workflow script. The Mid implementer pins `low` on Haiku (T47), so a
  Sonnet dispatch of it passes `effort: medium`. The verifier pins `high`,
  the Cheap seats `low` (live on Haiku 5.5 on the API, Haiku 4.5
  elsewhere, no effort dial). A pin beats `/effort` and
  `--effort ultracode`'s xhigh. It also rides a per-call `model:`, so a
  per-call `model:` on the low-pinned implementer passes `effort: medium`
  too, for a Sonnet or Opus escalation and a failed Cheap leaf alike. A
  bare `model:` would run it at low. Only `CLAUDE_CODE_EFFORT_LEVEL`,
  `auto` included, outranks a pin. A `maxEffortLevel` cap clamps one. An
  unpinned seat takes an explicit session level, else its own model's
  saved level or default. From 2.1.316 `CLAUDE_CODE_SUBAGENT_EFFORT` sets
  it when nothing else names one (changelog only, unprobed).
  Both links re-probed 2026-11-11 on 2.1.322. Fable 5.2, Opus 5.5, Sonnet
  5.5 and Haiku 5.5 default to **medium**, the rest high (Opus 4.7 xhigh). A
  legacy top-level `effortLevel` setting no longer reaches Opus 5.5.
  <!-- claim:cc-agent-call-effort-param -->
- **Naming your seat** for SKILL.md § Seat ceiling: the system prompt's
  model line, or `/model` and `/status`. A per-call `model:` above it
  waits on the user's yes. The brief doesn't. A Haiku seat sends no
  `model:` above Haiku at all (`routing.md` Cheap hard floor #6).
- **`opus` means Opus 5.5 from v2.1.280** on the Anthropic API, Claude
  Platform on AWS, Bedrock and Google Cloud (Foundry keeps Opus 4.6).
  `default` is Opus 5.5 on every paid plan, Pro included. A subagent's
  `opus` takes the session's own Opus when one is running.
  **Newest version first** (`model-classes.md` § How to edit): keep the
  session on `default` or `opus` and seats on the aliases, which move with
  each release. A full id like `claude-opus-5` freezes one. Where an alias
  lags (`sonnet` is 4.6 on Platform on AWS, 4.5 on Bedrock, Google Cloud
  and Foundry, and `haiku` 4.5 off the API), point it at the newest id
  with `ANTHROPIC_DEFAULT_SONNET_MODEL` or `_OPUS_MODEL`. 2.1.280 is
  the floor for Opus 5.5. `sonnet` is Sonnet 5.5 on the API from 2.1.284,
  `haiku` Haiku 5.5 on the API from 2.1.293 (2026-10-07), Haiku 4.5
  on AWS, Bedrock, Google Cloud and Foundry.
- **`/fast` is not a cheap tier.** Fast mode runs Opus with faster output,
  same model (Opus 5.5/5, 4.8 until 2026-11-30, 5.5 the default at
  $8/$40). It buys latency, never budget. Its header is part of the cache
  key. The first enable per conversation re-reads the history uncached at
  fast-mode rates (later toggles keep it). On Sonnet or Haiku it
  switches the session to Opus, which stays after `/fast` goes off.
  <!-- claim:cc-fast-mode-is-not-a-model-downgrade -->
- **A seat's window is sized by its own model, not yours.** The current
  aliases all carry 1M. A legacy pin like Haiku 4.5 gives 200k. The
  beyond-one-context argument holds only where the seats' windows match.
- **Fan-out:** subagents run **background-by-default** (since v2.1.198).
  Fire every Agent call, then watch the agent panel.
- **Auto mode (permissions) is the built-in starting mode on every plan
  and provider** (2.1.283+). Its classifier runs **Sonnet 5** unless
  Anthropic sets one server-side, pinned after first-request validation,
  and bills as token usage on API and Enterprise. From 2.1.278 Enterprise,
  API, cloud-platform and `ANTHROPIC_BASE_URL` gateway sessions ask the
  server to fold those checks into session requests where rollout has
  reached them (`/status` shows an `Auto mode server` row). A
  header-stripping gateway falls back to billed local calls. The opt-out
  `CLAUDE_CODE_AUTO_MODE_SERVER=0` isn't read on a direct API connection.
  A subscription keeps the local classifier. Three consecutive or 20 total
  blocks pause auto mode.
- **Isolation:** parallel edit leaves get `isolation: worktree`, a
  temporary git worktree each, auto-cleaned when unchanged, so a stray
  shared-file touch can't clobber a sibling. Worktrees do NOT share the
  prompt cache (`caching.md`), so isolate only leaves that really edit in
  parallel. Read-only and scout dispatches stay
  same-directory.
- **A `fork` can't be down-tiered — `model` is ignored, nothing errors.**
  It always runs the *session* model on the parent's warm prefix, so on an
  Opus session every fork is an Opus leaf. Fork is a **context** lever,
  never a cost one: use it for audit/synthesis that needs the whole
  session, and dispatch a normal subagent to route down.
  <!-- claim:cc-fork-ignores-model-override -->
- **Same-tier retry = resume, not re-dispatch:** a completed subagent sent
  a `SendMessage` auto-resumes in the background with its full history, so
  flow.md's one same-tier retry rides the executor's warm cache. Tier-safe
  on ≥2.1.211. A resumed agent with MCP tools loaded keeps that cache only
  from 2.1.277, a resumed fork from 2.1.280. The §B analog is `--resume`.
- **Hard ceilings:** **20 concurrent** (v2.1.217;
  `CLAUDE_CODE_MAX_CONCURRENT_SUBAGENTS`; exempt under ultracode). A
  resume takes a fresh slot unchecked, so a retry burst can pass 20.
  `--max-budget-usd` (print mode only) halts running background subagents
  at the cap. **Depth 3** since v2.1.219
  (`CLAUDE_CODE_MAX_SUBAGENT_SPAWN_DEPTH`). At the limit a seat does the
  work itself and returns one summary. Workflows carry their own caps: 16
  concurrent by default (fewer on fewer CPUs, 1 to 256 via
  `CLAUDE_CODE_WORKFLOW_MAX_CONCURRENT_AGENTS` on 2.1.269+), 1,000
  agents/run, size guideline <10 (<5 on Pro), and a Large workflow warning
  past 25 agents or a projected 1.5M tokens. On v2.1.271+ an interactive
  subscription workflow pauses at a usage limit and resumes after the
  reset. Size waves to these as `routing.md` sizes to credit caps.

## Opus 5 and 5.5 seats: two gaps that read as model failure

- **Auto mode is miscalibrated.** `tengu_auto_mode_config.severityByModel`
  ships no `claude-opus-5` or `claude-opus-5-5` entry (#80977, open but
  stale-labelled, re-read in this box's `.claude.json` 2026-09-22). So it
  falls to a stricter default blocking routine actions 4.8 allowed. Use
  plan mode or allow-rules.
  <!-- claim:cc-automode-missing-opus5-thresholds -->
- **On Opus 5 the system prompt can carry a don't-dispatch section:** use
  Agent, a workflow or deep research only when the user, a CLAUDE.md or a
  skill asks. 2.1.280 gates it on capability `opus_5_prompt_bundle`,
  absent on Opus 5.5 unless server-side prompt text adds it (code-read
  2026-09-22). A skill's or CLAUDE.md's routing policy already asks.
  **The plan gate's approval does too.** Quote it and dispatch. A separate
  `## Delegating to subagents` section, on any model when
  `tengu_thistle_grebe` (server-side, or env `CLAUDE_CODE_THISTLE_GREBE`)
  is `counter_steer`, says to work inline unless delegation clearly pays,
  which agrees with route-inline-first. It read `default` here on
  2026-09-22. Log it as a confound. So is `ultrathink` in an interactive
  prompt (xhigh for that turn on the API, 2.1.311 terminal, 2.1.316 VS
  Code). `CLAUDE_CODE_DISABLE_ULTRATHINK=1` turns it off.
  <!-- claim:cc-opus5-dont-dispatch-injection -->

## Whether the tier lands — contested; say so and route around it

Issue **#43869** ("all mechanisms resolve to the parent model") is **open**
(date of record: the development repo's claim ledger) and reports the per-call `model:`,
frontmatter and env-var levers each ignored on some paths.
<!-- claim:cc-issue-43869-open -->

**`/usage` is the in-harness oracle.** Its Session block prints a
`Usage by model:` breakdown: per-model token counts plus a dollar figure
computed locally at list rates (or an org's managed `modelPricing`). On Max
or Pro the dollars aren't a bill, but on Anthropic's endpoint the **model
attribution is real**, so the #43869 check is free and offline: dispatch a
cheap-tier wave, then look for a line for that model. An all-Opus
breakdown after a Haiku wave is the failure. Behind a rerouting gateway
the client's accounting names the alias you asked for, not the model
served (cost-state read 2026-09-22, `/usage` untested). Read the
provider's monitor there.

**Never grep the transcript for it.** #43869 repros disagree on what a
subagent's JSONL `model` field records: the requested model in one, the
served one in a 2.1.233 repro that put the request in `meta.json`
(third-party, unprobed here). If that holds, `meta.json` against the
JSONL is a free offline detector. Until a local probe settles it,
transcript metadata proves nothing. Nor brief a seat to quote its system
prompt or model line as proof: Opus 5.5 refuses that as
`reasoning_extraction` (#96139). One separate path *does* warn: an
`availableModels` substitution prints an interactive-only warning naming
the requested and the substituted model, so check for it before calling it
a #43869 hit.

**Check `/tasks` first.** The task list and agent detail dialogs print
the **model each subagent actually ran at, plus its effort when the seat
pins one** (for an inheriting seat, which shows none, read
`$CLAUDE_EFFORT` in its Bash). That is a sharper #43869 oracle than
`/usage`, which stays a cross-check. A PostToolUse hook on `Agent` logs
`resolvedModel` (the start model) and, from 2.1.212, `modelsUsed` after a
mid-run swap: harness resolution per dispatch, blind to the server side.
In auto mode (2.1.271+) the report arrives via `SubagentHandback`, which
edits nothing and passes the classifier first. Match that too.

**A second silent de-tiering path:** fallback chains cover subagents
(v2.1.247). A chain from `--fallback-model` or a `fallbackModel` settings
array (max 3, turn-scoped, availability-only, never shrinking context at
compaction) can move a pinned leaf mid-wave while the session model reads
unchanged. Neither startup nor `/status` shows one. The parent-side error
text names the model and `modelsUsed` records the swap. Track it like #43869.

**Partial fixes:** v2.1.211 (resume and follow-up), v2.1.222 (the
allowlist case) and v2.1.316 (a leaf on a parent leaf's model stays put
when woken). #43869 stays open, so treat "the cheap tier landed" as
unconfirmed until `/tasks` shows the model (or `/usage` the line).

**Measurement hazard: the safety fallback.** A content-flagged request
re-runs on a different model and the **session continues** there. It can
fire on the first request, which carries your CLAUDE.md and git status
(`--safe-mode` isolates your customizations). The map (read 2026-09-29): on
Opus 5.5, Fable 5.1 and Fable 5, biology falls to Opus 5 and cybersecurity
to Opus 4.8. Opus 5.5's frontier-LLM-development flag falls to Opus 5. On
Opus 5, cybersecurity falls to 4.8 and biology refuses. On Sonnet 5.5,
cybersecurity falls to Sonnet 5 and biology refuses. `reasoning_extraction`
refuses everywhere. From Opus 5.5 a fallback is down in capability but up
in price. `CLAUDE_CODE_DISABLE_REFUSAL_FALLBACK=1` (2.1.312) is a second
off switch. Custom deployment names fall back too. Set
`switchModelsOnFlag: false` in any benchmark harness: an interactive flag
then asks and a `-p` main-thread flag ends the turn. A flagged subagent or
workflow leaf still re-serves on the fallback (2.1.280 code read plus
#91923, unprobed). From 2.1.318 a subagent stops instead when the
setting is "Ask each time" (changelog, unprobed). Check OTel `subagent_completed`'s `model_swapped` and
`final_model`.

**The #43869-immune fallback — `opusplan`.** `/model opusplan` is native
(Opus 5.5 in plan mode, Sonnet for execution, in the *main* session), with
no subagent routing, so the contested levers never enter. It captures most
of the core rule (strong plans, cheaper implements) with zero routing
risk, minus the fan-out and the Cheap floor.

## Caching-aware fan-out

Each fresh subagent pays a *cold* cache-write at a **5-minute
TTL**, liftable to an hour via `subagentPromptCacheTtl`,
`CLAUDE_CODE_SUBAGENT_PROMPT_CACHE_TTL`, or per-agent `experimental.cacheTtl`,
though a subscription running on usage credits ignores the per-agent `1h`
(see `caching.md`). Weigh leaf count against per-spawn cache cost.
Prefer a `fork` for a leaf that needs full context. Policy: `caching.md`.

Three dispatch rules (each live-measured 2026-07-11):

- **End the turn while a wave is in flight.** Completions re-invoke the
  orchestrator. An idle no-op wait turn re-reads the entire session context
  at cache price. Measured: ~30 wait turns at ~150k cost about as much as
  a 10-dispatch probe wave. Scheduled tasks, cross-session messages
  (`crossSessionInbound: hold`) and `/goal` check-ins
  (`CLAUDE_CODE_GOAL_CHECKIN_MINUTES=0`) start idle turns that resend it too.
- **Shared prefix first, brief last.** Build every same-wave prompt as
  [identical protocol + conventions][per-leaf brief at the end].
  Byte-identical prefixes in a concurrent wave cache-hit within the
  TTL, so leaves 2–N read the shared payload at 0.1× once the first
  starts streaming (stagger per flow.md step 3, where it pays). Workflow
  siblings share it only when model, effort, agent type, tools, output
  schema and working directory all match.
- **Tell Mid-or-stronger subagents to read the protocol. Paste it only for
  Cheap.** Orchestrator output prices ≈5× input. One "read
  `references/check.md` and follow it" line beats pasting ~4k tokens into
  each verifier prompt, and the file then caches across verifiers. A Cheap
  executor may skip a read instruction. Haiku keeps the attached payload.

## Adjacent primitives (know when NOT to use them)

- **Agent Teams** (`CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS=1`, experimental):
  teammates **fall back to the lead's model**, so an unconfigured teammate
  lands on the lead's *priciest* one. Precedence, first match winning: the
  model your spawn prompt names · a subagent definition's `model:` (where
  `inherit` picks the lead's) · `CLAUDE_CODE_SUBAGENT_MODEL` when set to
  anything but `inherit` · the lead's current model. Name the model in the
  spawn prompt to be sure. Reserve teams for adversarial /
  competing-hypothesis review. Subagent fan-out stays the default.
  **A live hazard:** with teams enabled, an Agent call carrying a `name`
  launches a *teammate*, which reports via idle notification, not the
  result the Integrate step waits for. Claude may add a name itself.
  A seat dispatched by `subagent_type` alone, a fork, or a call passing
  `isolation` stays a subagent, as does every named call under
  `claude -p` or the SDK. Setting the variable to `0` in settings `env`
  reverts without a restart. Teammates inherit the lead's *effort*.
  `TeammateIdle`/`TaskCompleted` hooks (exit 2 blocks) enforce
  smartcheck-before-done.
- **Advisor** (flow.md § Reach for the built-in): a seat inherits it.
  Check `advisorModel` before a Cheap wave.
- **Dynamic workflows** (scripted `pipeline()`/`parallel()`, schemas,
  resumable, auto-planned at `/effort ultracode`, v2.1.203+): the
  graduation for heavy runs. Pro switches them on in `/config`. **Never
  reach for one unprompted.** The tool's contract lists five opt-ins: the
  `ultracode` keyword, ultracode on for the session, the user asking, a
  skill or slash command *the user* invoked that says to, or a named or
  saved workflow the user asked for. A skill the model loaded itself,
  smartplan included, isn't one. Nor is "this task would benefit". Ask
  first. Agent dispatch stays the default engine. <!-- claim:cc-workflow-requires-user-opt-in -->
  A script's `agent()` opts are the **only per-call effort dial** (`model`
  + `effort: low|…|max`). The tool's script reference says to *omit*
  `model` and inherit the session. The workflows docs' cost section says to
  ask for a smaller model on stages that don't need the strongest.
  <!-- claim:cc-workflow-guidance-omit-model -->
  It's an **execution engine** for step-3 at scale, not a policy
  replacement: a workflow takes no mid-run user input beyond permission
  prompts, so gate BEFORE the script runs, route tiers in the script, and
  ride the verify floor as scripted stages. Its agents inherit the session's
  permission mode. A definition's `permissionMode` counts only from
  default, dontAsk or plan mode. In auto mode the classifier reads an
  `agent()` prompt as computed text, not a user request, so a leaf's
  destructive or outward action can't lean on its brief. The launch itself
  carries a mode-dependent approval prompt. Security sweeps → Anthropic's
  **Claude Security** plugin, which already ships this shape.

## Mechanical enforcement (optional)

`docs/enforcement-hook.md`: a PreToolUse hook +
`Agent(model:…)` deny rules turn "trust the bill" into a guardrail. A wired
warn-only instance lives in the source repo at `.claude/settings.json` +
`.claude/hooks/`, described on that page. Its note rides exit-0 JSON
(`systemMessage`, `additionalContext`), since exit-0 stderr reaches only
the debug log. Flip to hard-deny via the one-line opt-in shown in that
reference. The same instance wires a `SessionStart` hook on matcher
`compact` (`rearm-after-compact.sh`). When a `run-state.md` sits at the
project root it tells Claude to re-read `flow.md`, `artifacts.md` and
`run-state.md`, the references compaction drops.

## Structural tool-lockdown (shipped seats)

Per-call `model:` tiers *which* model runs, not what a seat may touch. On
an ad-hoc `Agent()` call the seat rules are prompt-only. This repo ships a
tool-locked quartet at `.claude/agents/` that enforces the seat at the
tool layer: `smartplan-scout` (`tools: Read, Glob, Grep`),
`smartplan-verifier` (no `Write`/`Edit`/`NotebookEdit`),
`smartplan-implementer`, and `smartplan-implementer-cheap`.
Dispatch via `subagent_type`. Copy the files into another project's
`.claude/agents/` to reuse them. This closes only the *tool-permission*
half. A seat's `model:` frontmatter is still subject to the contested
resolution order (#43869, above), so confirm the tier with `/tasks`,
cross-checked against `/usage`'s per-model lines.

## Cost levers (researched 2026-07-13 — sources: the development repo's research notes)

- **Fork plumbing** (tier caveat above, for `subagent_type: fork` and
  `/subtask`): **forking is on by default since v2.1.232** in an
  interactive session, and since v2.1.302 in `-p`, the Agent SDK, the
  desktop app and VS Code too (headless arm read 2026-10-20). Claude can
  pick a fork unprompted, so the caveat hits dispatches you never asked
  for. `CLAUDE_CODE_FORK_SUBAGENT=0` turns that off. An arm that must not
  fork needs it. Untyped Agent calls still resolve general-purpose.
  `/subtask` is the in-session fork (v2.1.212). `/fork` copies the session
  into a new background one. A `context: fork` skill is no fork despite
  the name: it starts a fresh subagent with no history, tiered by its own
  `model:` frontmatter, background-by-default since v2.1.218
  (`background: false` opts out). Sibling forks stop cross-launching
  from 2.1.307.
- **Explore and Plan skip CLAUDE.md and git status** (docs) but run the
  session model (Explore capped at Opus on the API), ignore a bare
  `CLAUDE_CODE_SUBAGENT_MODEL`, and can't be resumed. On Opus 5.5
  that's a small context at Opus prices. Prefer the scout.
  On 2.1.271+ a seat's `omitClaudeMd: true` drops user, project and local
  CLAUDE.md too (git status still loads).
- **Standing-load knobs:** `skillOverrides` takes four states:
  `on` (the default), `off`, `name-only` (description leaves every
  turn's context) and `user-invocable-only`. **Plugin skills are exempt
  from `skillOverrides`** (re-verified 2026-08-12).
  `disable-model-invocation: true` removes a description entirely.
  `skillListingBudgetFraction` / `skillListingMaxDescChars` cap the whole
  listing. `/skill-doctor` (2.1.252+) reports per-skill context cost and
  usage.
- **2.1.277 reads `AGENTS.md` directly when a project has no
  `CLAUDE.md`** (toggle under Project instructions in `/config`, on
  every provider and telemetry setting from 2.1.281). On Windows the
  docs still recommend an `@AGENTS.md` import in `CLAUDE.md`, which
  doesn't double-read.
- **claude.ai skill sync (2.1.275) is a new standing-load surface:**
  skills and plugins enabled on the claude.ai account sync into terminal
  sessions by default, landing in `~/.claude/skills/synced/` (~10-minute
  refresh, collisions invoke as `/anthropic-skills:<name>`). Opt out via
  `syncClaudeAiSkills` / `syncClaudeAiPlugins`.
- **Env vars:** `ANTHROPIC_DEFAULT_MODEL` (v2.1.236+) is a **fifth link in
  the session-model precedence chain**, below `/model`, `--model` and
  `ANTHROPIC_MODEL`, and it can silently repoint new sessions. Check it
  before trusting a tiering measurement on a shared box. `best` and `fable`
  are **moving targets by design**. From 2.1.321 `best` is `opus` and
  `fable` is Fable 5.2 (5.1 needs `claude-fable-5-1`), so never pin a
  benchmark arm to either. `ANTHROPIC_DEFAULT_HAIKU_MODEL`
  (background-task model. Helper agents come pre-seated cheap: statusline
  setup on Sonnet, the docs guide on Haiku),
  `CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC` (the documented traffic lever,
  which reaches model-adjacent calls only indirectly. No switch suppresses
  background model calls specifically).
- **Compaction:** `/autocompact` (saved as `autoCompactWindow`, 100K to
  1M), `--autocompact` per launch, or `CLAUDE_CODE_AUTO_COMPACT_WINDOW`,
  which wins (from 2.1.312 a subagent's `autoCompactWindow` can lower
  it, never raise it, changelog only). From 2.1.304 it takes `k` and `M`
  suffixes (`500k`, `1M`). A bare number is still raw tokens. `500` clamps
  to 100K with a warning. An unusable value is ignored with a warning, and
  the next source applies. `CLAUDE_AUTOCOMPACT_PCT_OVERRIDE` can only lower
  the threshold, subagents included. Subagent frontmatter takes
  `autoCompactWindow` (2.1.296). Earlier compaction shrinks per-turn
  re-reads, but each compact busts the prefix. Measure first.
