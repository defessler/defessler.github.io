---
name: smartbrief
description: smartplan part. Compiles the BRIEF a Cheap leaf runs from (files, change, acceptance, allow list). Load when smartplan hands a leaf to a cheap executor.
user-invocable: false
---

# smartbrief — part of smartplan

How to compile a brief for a Cheap leaf. Read
[`references/brief.md`](references/brief.md) whole before writing one.
The executor runs the brief under `smartexec`'s protocol, and
`smartcheck` verifies the result.

When this skill is off, smartplan sends no Cheap leaves. A leaf gets a
plain FILES · CHANGE · ACCEPTANCE task at the Mid tier instead.
