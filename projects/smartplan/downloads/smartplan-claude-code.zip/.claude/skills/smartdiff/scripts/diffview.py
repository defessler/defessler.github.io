#!/usr/bin/env python3
"""diffview: render a unified diff (git, diff -u, or `p4 diff -du`) as one
self-contained HTML page. Python stdlib only; the output makes no network requests.

  git diff -U5 | python diffview.py -o review.html
  python diffview.py session.diff -o review.html --title "Grapple tuning" --notes notes.json
  python diffview.py session.diff --blueprints work/bp -o review.html

notes.json (optional):  {"_summary": "Why this change set exists.",
                         "GrappleComponent.cpp": "Note shown above that file."}
Keys match a full path or a path suffix. `backticks` render as code.

--blueprints reads the folder bp_prepare.py and bp_export.py fill, and shows
each changed Blueprint as a semantic diff (graphs, nodes, links, pin defaults,
variables, components, class defaults) instead of "binary file".
"""
import argparse, difflib, html, json, os, re, sys
from datetime import datetime

HUNK_RE = re.compile(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@ ?(.*)$')
CODE_EXT = {'.h', '.hpp', '.hh', '.inl', '.c', '.cc', '.cpp', '.cxx', '.cs',
            '.ush', '.usf', '.hlsl', '.js', '.ts', '.java'}
SYNTAX = re.compile(r'''
   (?P<com>//.*$|/\*.*?\*/|/\*.*$|^\s*\*(?:\s|/|$).*$)
  |(?P<str>"(?:\\.|[^"\\])*"?|'(?:\\.|[^'\\])*'?)
  |(?P<pp>^\s*\#\s*\w+)
  |(?P<mac>\b(?:UCLASS|USTRUCT|UENUM|UFUNCTION|UPROPERTY|UINTERFACE|UMETA|UPARAM|GENERATED_BODY|
      GENERATED_UCLASS_BODY|TEXT|LOCTEXT|NSLOCTEXT|check|checkf|checkSlow|ensure|ensureMsgf|
      ensureAlways|verify|UE_LOG|UE_CLOG|DECLARE_\w+|DEFINE_\w+|IMPLEMENT_\w+|TRACE_\w+|SCOPE_\w+)\b)
  |(?P<kw>\b(?:alignas|auto|bool|break|case|catch|char|class|const|constexpr|consteval|continue|
      default|delete|do|double|else|enum|explicit|extern|false|final|float|for|friend|if|inline|
      int|int8|int16|int32|int64|uint8|uint16|uint32|uint64|long|mutable|namespace|new|noexcept|
      nullptr|operator|override|private|protected|public|return|short|signed|sizeof|static|
      static_cast|dynamic_cast|reinterpret_cast|const_cast|struct|switch|template|this|throw|
      true|try|typedef|typename|union|unsigned|using|virtual|void|volatile|while|co_await|
      co_return|co_yield)\b)
  |(?P<fn>\b[A-Za-z_]\w*(?=\s*\())
  |(?P<type>\b[UAFTEIS][A-Z][A-Za-z0-9]*[a-z]\w*\b)
  |(?P<num>\b(?:0x[\da-fA-F]+|\d+\.?\d*(?:[eE][+-]?\d+)?)[fFuUlL]*\b)
''', re.M | re.X)
TOKENS = re.compile(r'\w+|\s+|[^\w\s]')
ASSET_EXT = ('.uasset', '.umap')


class FileDiff:
    def __init__(self, old=None, new=None):
        self.old, self.new = old, new
        self.status, self.binary = 'modified', False
        self.hunks, self.adds, self.dels, self.mods = [], 0, 0, 0
        self.bp = None  # Blueprint diff sections, when --blueprints covers this file

    @property
    def path(self):
        p = (self.old or self.new) if self.status == 'deleted' else (self.new or self.old)
        return (p or '(unnamed)').replace('\\', '/')


def clean_path(p):
    p = p.split('\t')[0].strip()
    if p == '/dev/null':
        return None
    if p[:2] in ('a/', 'b/'):
        p = p[2:]
    return re.sub(r'#\d+$', '', p)


def parse(text):
    files, cur, hunk, orem, nrem = [], None, None, 0, 0

    def start(old=None, new=None):
        nonlocal cur, hunk
        cur, hunk = FileDiff(old, new), None
        files.append(cur)

    for raw in text.splitlines():
        if hunk is not None and (orem > 0 or nrem > 0):
            tag, body = raw[:1], raw[1:].expandtabs(4)
            if tag in (' ', ''):
                hunk['lines'].append((' ', body)); orem -= 1; nrem -= 1; continue
            if tag == '-':
                hunk['lines'].append(('-', body)); orem -= 1; cur.dels += 1; continue
            if tag == '+':
                hunk['lines'].append(('+', body)); nrem -= 1; cur.adds += 1; continue
            if tag == '\\':
                continue
        if raw.startswith('\\'):
            continue
        if raw.startswith('diff --git '):
            m = re.match(r'diff --git a/(.*) b/(.*)$', raw)
            start(*(m.groups() if m else ()))
        elif raw.startswith('==== '):  # p4 diff -du header
            m = re.match(r'^==== (.+?)(?:#\d+)? - (.+?) ====', raw)
            start(m.group(1), m.group(1)) if m else start()
            if '(binary)' in raw or raw.rstrip().endswith('binary'):
                cur.binary = True
        elif raw.startswith('--- ') or raw.startswith('+++ '):
            if cur is None or cur.hunks:
                start()
            p = clean_path(raw[4:])
            if raw[0] == '-':
                if p is None: cur.status = 'added'
                elif cur.old is None: cur.old = p
            else:
                if p is None: cur.status = 'deleted'
                elif cur.new is None: cur.new = p
        elif raw.startswith('@@'):
            m = HUNK_RE.match(raw)
            if not m:
                continue
            if cur is None:
                start()
            a, b, c, d, ctx = m.groups()
            hunk = {'os': int(a), 'oc': int(b or 1), 'ns': int(c), 'nc': int(d or 1),
                    'ctx': ctx.strip().expandtabs(4), 'lines': []}
            orem, nrem = hunk['oc'], hunk['nc']
            cur.hunks.append(hunk)
        elif cur is not None:
            if raw.startswith('new file mode'): cur.status = 'added'
            elif raw.startswith('deleted file mode'): cur.status = 'deleted'
            elif raw.startswith('rename from '): cur.status, cur.old = 'renamed', raw[12:]
            elif raw.startswith('rename to '): cur.new = raw[10:]
            elif raw.startswith('Binary files') or raw.startswith('GIT binary patch'): cur.binary = True
    return [f for f in files if f.hunks or f.binary or f.status != 'modified']


# ---------------------------------------------------------------- Blueprints

def split_top(s, sep=','):
    """Split on sep outside quotes and parentheses."""
    out, depth, q, cur = [], 0, False, []
    for ch in s:
        if ch == '"':
            q = not q
        elif not q and ch == '(':
            depth += 1
        elif not q and ch == ')':
            depth -= 1
        if ch == sep and not q and depth == 0:
            out.append(''.join(cur)); cur = []
        else:
            cur.append(ch)
    if cur:
        out.append(''.join(cur))
    return [x for x in out if x.strip()]


def kv(item):
    k, _, v = item.partition('=')
    return k.strip(), v.strip()


def unq(v):
    return v[1:-1] if len(v) >= 2 and v[0] == v[-1] == '"' else v


def struct(v):
    """(A=1,B="x") -> {'A': '1', 'B': 'x'}"""
    v = v.strip()
    if v.startswith('(') and v.endswith(')'):
        v = v[1:-1]
    return {k: unq(x) for k, x in map(kv, split_top(v))}


def parse_t3d(text):
    """Return {relpath: obj}. relpath drops the package so revisions line up:
    '' is the root object, 'EventGraph.K2Node_CallFunction_0' a node."""
    objs, stack = {}, []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith('Begin Object'):
            name = re.search(r'\bName="([^"]*)"', s)
            name = name.group(1) if name else '?'
            cls = re.search(r'\bClass=(\S+)', s)
            ep = re.search(r'\bExportPath="([^"]*)"', s)
            key = None
            if ep:
                inner = ep.group(1)
                if not cls and "'" in inner:
                    cls = re.match(r"([^']+)'", inner)
                path = inner.split("'")[1] if "'" in inner else inner
                key = path.split(':', 1)[1] if ':' in path else ''
            if key is None:
                key = '.'.join([o['name'] for o in stack[1:]] + [name]) if stack else ''
            o = objs.setdefault(key, {'name': name, 'cls': '', 'props': {}, 'pins': [],
                                      'parent': stack[-1]['key'] if stack else None, 'key': key})
            if cls:
                o['cls'] = cls.group(1).rsplit('.', 1)[-1]
            stack.append(o)
        elif s.startswith('End Object'):
            if stack:
                stack.pop()
        elif stack and s.startswith('CustomProperties Pin'):
            body = s[s.index('(') + 1:s.rindex(')')] if '(' in s else ''
            stack[-1]['pins'].append({k: v for k, v in map(kv, split_top(body))})
        elif stack and '=' in s and not s.startswith('CustomProperties'):
            k, v = kv(s)
            stack[-1]['props'][k] = v
    return objs


def short_ref(v):
    """/Script/CoreUObject.Class'/Script/Engine.Actor' -> Actor"""
    v = unq(v)
    m = re.match(r"^[\w/.]+'([^']*)'$", v)
    if m:
        v = m.group(1)
    if v.startswith('/') and ' ' not in v:
        v = re.split(r'[.:/]', v)[-1]
    return v


def short_val(v, limit=90):
    v = short_ref(v) if v else v
    return v if len(v) <= limit else v[:limit - 1] + '…'


def node_title(o):
    c, p = o['cls'], o['props']
    ref = lambda k, f='MemberName': struct(p[k]).get(f, '') if k in p else ''
    if c in ('K2Node_CallFunction', 'K2Node_CallArrayFunction', 'K2Node_CallParentFunction',
             'K2Node_PromotableOperator', 'K2Node_CommutativeAssociativeBinaryOperator',
             'K2Node_CallMaterialParameterCollectionFunction', 'K2Node_Message'):
        return ref('FunctionReference') or c
    if c in ('K2Node_VariableGet', 'K2Node_VariableSet'):
        return ('Get ' if c.endswith('Get') else 'Set ') + ref('VariableReference')
    if c == 'K2Node_Event':
        return 'Event ' + (ref('EventReference') or unq(p.get('CustomFunctionName', '')))
    if c == 'K2Node_CustomEvent':
        return 'Custom Event ' + unq(p.get('CustomFunctionName', ''))
    if c in ('K2Node_FunctionEntry', 'K2Node_FunctionResult'):
        return 'Entry' if c.endswith('Entry') else 'Return'
    if c == 'K2Node_IfThenElse':
        return 'Branch'
    if c == 'K2Node_Knot':
        return 'Reroute'
    if c == 'K2Node_DynamicCast':
        return 'Cast To ' + short_ref(p.get('TargetType', '?'))
    if c == 'K2Node_MacroInstance' and 'MacroGraphReference' in p:
        return short_ref(struct(p['MacroGraphReference']).get('MacroGraph', 'Macro'))
    if c == 'EdGraphNode_Comment':
        return 'Comment "' + short_val(unq(p.get('NodeComment', '')), 40) + '"'
    if c in ('K2Node_SpawnActorFromClass', 'K2Node_ConstructObjectFromClass', 'K2Node_CreateWidget'):
        return c.replace('K2Node_', '')
    if 'InputAction' in p:
        return 'Input ' + short_ref(p['InputAction'])
    return re.sub(r'^(K2Node_|EdGraphNode_|AnimGraphNode_|MaterialGraphNode_)', '', c) or o['name']


NODE_NOISE = {'NodePosX', 'NodePosY', 'NodeWidth', 'NodeHeight', 'NodeGuid', 'ErrorType',
              'ErrorMsg', 'bHasCompilerMessage', 'bCommentBubblePinned', 'bCommentBubbleVisible',
              'AdvancedPinDisplay', 'bCommentBubbleMakeVisible'}
ROOT_SKIP = re.compile(r'^(NewVariables|UbergraphPages|FunctionGraphs|MacroGraphs|'
                       r'DelegateSignatureGraphs|IntermediateGeneratedGraphs|LastEditedDocuments|'
                       r'EventGraphs|CategorySorting|GeneratedClass|SkeletonGeneratedClass|'
                       r'ThumbnailInfo|BlueprintGuid|SimpleConstructionScript|InheritableComponentHandler|'
                       r'BlueprintSystemVersion|Status|bCachedDependenciesUpToDate|CachedDependencies|'
                       r'CachedUDSDependencies|CompileStatus|bLegacyGeneratedClassIsAuthoritative|'
                       r'BookmarkNodes|Bookmarks)\b')
CDO_SKIP = re.compile(r'^(UberGraphFrame|RootComponent|DefaultSceneRoot|BlueprintCreatedComponents)\b')


def pin_default(p):
    for k in ('DefaultValue', 'DefaultObject', 'DefaultTextValue'):
        if k in p and unq(p[k]) not in ('', 'None'):
            return unq(p[k])
    return ''


def graph_model(objs, gkey):
    nodes = {o['key']: o for o in objs.values() if o['parent'] == gkey}
    by_name = {o['name']: o for o in nodes.values()}
    model, edges = {}, set()
    for o in nodes.values():
        nid = o['props'].get('NodeGuid', o['name'])
        pins = {}
        for p in o['pins']:
            if p.get('bHidden') == 'True' and not p.get('LinkedTo'):
                continue
            pins[unq(p.get('PinName', '?'))] = p
        model[nid] = {'title': node_title(o), 'cls': o['cls'], 'props': o['props'], 'pins': pins,
                      'pos': (o['props'].get('NodePosX'), o['props'].get('NodePosY'))}
    for o in nodes.values():
        nid = o['props'].get('NodeGuid', o['name'])
        for p in o['pins']:
            if p.get('Direction') != '"EGPD_Output"' and p.get('Direction') != 'EGPD_Output':
                continue
            for link in split_top(p.get('LinkedTo', '()').strip('()')):
                parts = link.split()
                if len(parts) != 2 or parts[0] not in by_name:
                    continue
                tgt = by_name[parts[0]]
                tpin = next((unq(q.get('PinName', '?')) for q in tgt['pins'] if q.get('PinId') == parts[1]), '?')
                edges.add((nid, unq(p.get('PinName', '?')), tgt['props'].get('NodeGuid', tgt['name']), tpin))
    return model, edges


def label(model_a, model_b, nid):
    n = model_b.get(nid) or model_a.get(nid)
    return n['title'] if n else nid[:8]


def diff_graph(oa, ob, ga, gb):
    """Rows of (kind, html) for one graph. kind is add, del, mod or info."""
    ma, ea = graph_model(oa, ga) if ga is not None else ({}, set())
    mb, eb = graph_model(ob, gb) if gb is not None else ({}, set())
    rows, moved = [], 0
    E = lambda s: html.escape(s, quote=False)
    for nid in mb.keys() - ma.keys():
        rows.append(('add', f'Node <b>{E(mb[nid]["title"])}</b>'))
    for nid in ma.keys() - mb.keys():
        rows.append(('del', f'Node <b>{E(ma[nid]["title"])}</b>'))
    for nid in ma.keys() & mb.keys():
        a, b = ma[nid], mb[nid]
        changes = []
        for k in sorted((a['props'].keys() | b['props'].keys()) - NODE_NOISE):
            va, vb = a['props'].get(k, ''), b['props'].get(k, '')
            if va != vb:
                changes.append(f'{E(k)}: <s>{E(short_val(va)) or "∅"}</s> → {E(short_val(vb)) or "∅"}')
        for pn in sorted(a['pins'].keys() | b['pins'].keys()):
            pa, pb = a['pins'].get(pn), b['pins'].get(pn)
            if pa is None:
                changes.append(f'pin <code>{E(pn)}</code> added')
            elif pb is None:
                changes.append(f'pin <code>{E(pn)}</code> removed')
            elif pin_default(pa) != pin_default(pb):
                changes.append(f'<code>{E(pn)}</code>: <s>{E(short_val(pin_default(pa))) or "∅"}</s>'
                               f' → {E(short_val(pin_default(pb))) or "∅"}')
        if changes:
            rows.append(('mod', f'Node <b>{E(b["title"])}</b>: ' + '; '.join(changes)))
        elif a['pos'] != b['pos']:
            moved += 1
    fmt = lambda e, ma_, mb_: (f'<b>{E(label(ma_, mb_, e[0]))}</b>.<code>{E(e[1])}</code> → '
                               f'<b>{E(label(ma_, mb_, e[2]))}</b>.<code>{E(e[3])}</code>')
    for e in sorted(eb - ea):
        rows.append(('add', 'Wire ' + fmt(e, ma, mb)))
    for e in sorted(ea - eb):
        rows.append(('del', 'Wire ' + fmt(e, ma, mb)))
    if moved:
        rows.append(('info', f'{moved} node{"s" if moved != 1 else ""} moved (layout only)'))
    order = {'del': 0, 'mod': 1, 'add': 2, 'info': 3}
    return sorted(rows, key=lambda r: order[r[0]])


def variables(objs):
    out = {}
    for k, v in (objs.get('', {}).get('props') or {}).items():
        if k.startswith('NewVariables('):
            s = struct(v)
            out[s.get('VarGuid', s.get('VarName'))] = s
    return out


def var_type(s):
    t = struct(s.get('VarType', '()'))
    base = t.get('PinSubCategoryObject') and short_ref(t['PinSubCategoryObject']) or \
        t.get('PinSubCategory') or t.get('PinCategory', '?')
    cont = t.get('ContainerType')
    return f'{cont}<{base}>' if cont and cont != 'None' else base


def prop_rows(pa, pb, skip):
    rows = []
    E = lambda s: html.escape(s, quote=False)
    for k in sorted(pa.keys() | pb.keys()):
        if skip.match(k):
            continue
        va, vb = pa.get(k), pb.get(k)
        if va == vb:
            continue
        if va is None:
            rows.append(('add', f'<code>{E(k)}</code> = {E(short_val(vb))}'))
        elif vb is None:
            rows.append(('del', f'<code>{E(k)}</code> = {E(short_val(va))}'))
        else:
            rows.append(('mod', f'<code>{E(k)}</code>: <s>{E(short_val(va))}</s> → {E(short_val(vb))}'))
    return rows


def is_graph(o):
    return o['cls'].endswith('Graph') and o['cls'] not in ('BlueprintGeneratedClass',)


def bp_diff(old, new):
    """old/new are (meta, objs, cdo_objs) or None. Returns [(section title, status, rows)]."""
    om, oa, ca = old or ({}, {}, {})
    nm, ob, cb = new or ({}, {}, {})
    E = lambda s: html.escape(s, quote=False)
    sections = []

    va, vb = variables(oa), variables(ob)
    rows = []
    for g in vb.keys() - va.keys():
        rows.append(('add', f'<b>{E(vb[g].get("VarName", "?"))}</b> : {E(var_type(vb[g]))}'))
    for g in va.keys() - vb.keys():
        rows.append(('del', f'<b>{E(va[g].get("VarName", "?"))}</b> : {E(var_type(va[g]))}'))
    for g in va.keys() & vb.keys():
        a, b, ch = va[g], vb[g], []
        if a.get('VarName') != b.get('VarName'):
            ch.append(f'renamed from {E(a.get("VarName", "?"))}')
        if var_type(a) != var_type(b):
            ch.append(f'type <s>{E(var_type(a))}</s> → {E(var_type(b))}')
        for k in ('DefaultValue', 'Category', 'PropertyFlags', 'RepNotifyFunc', 'ReplicationCondition'):
            if a.get(k) != b.get(k):
                ch.append(f'{k} <s>{E(short_val(a.get(k) or "∅"))}</s> → {E(short_val(b.get(k) or "∅"))}')
        if ch:
            rows.append(('mod', f'<b>{E(b.get("VarName", "?"))}</b>: ' + '; '.join(ch)))
    if rows:
        sections.append(('Variables', None, rows))

    def graphs(meta, objs):
        authored = set(meta.get('graphs') or [])
        out = {}
        for k, o in objs.items():
            if not is_graph(o):
                continue
            top = o if o['parent'] == '' else None
            if top is not None and authored and o['name'] not in authored:
                continue
            if not authored and re.search(r'(_MERGED$|^ExecuteUbergraph_)', o['name']):
                continue
            if top is None:  # a nested graph (collapsed node, state machine): keep if its root graph is kept
                root = k.split('.')[0]
                if root not in objs or (authored and objs[root]['name'] not in authored):
                    continue
            out[k] = o
        return out
    ga, gb = graphs(om, oa), graphs(nm, ob)
    for k in sorted(ga.keys() | gb.keys(), key=lambda x: (x.count('.'), x.lower())):
        st = 'added' if k not in ga else 'deleted' if k not in gb else None
        rows = diff_graph(oa, ob, k if k in ga else None, k if k in gb else None)
        if st or rows:
            title = k.replace('.', ' › ')
            sections.append((f'Graph {title}', st, rows))

    def in_graph(o, objs):  # graph nodes, compiler graphs and their contents are covered above or noise
        while o is not None:
            if is_graph(o):
                return True
            o = objs.get(o['parent']) if o['parent'] is not None else None
        return False
    other_a = {k: o for k, o in oa.items() if k and not in_graph(o, oa)}
    other_b = {k: o for k, o in ob.items() if k and not in_graph(o, ob)}
    rows = []
    for k in sorted(other_b.keys() - other_a.keys()):
        rows.append(('add', f'<b>{E(other_b[k]["name"])}</b> ({E(other_b[k]["cls"])})'))
    for k in sorted(other_a.keys() - other_b.keys()):
        rows.append(('del', f'<b>{E(other_a[k]["name"])}</b> ({E(other_a[k]["cls"])})'))
    for k in sorted(other_a.keys() & other_b.keys()):
        sub = prop_rows(other_a[k]['props'], other_b[k]['props'], re.compile(r'^$^'))
        for kind, text in sub:
            rows.append((kind, f'<b>{E(other_b[k]["name"])}</b> {text}'))
    if rows:
        sections.append(('Components and subobjects', None, rows))

    rows = prop_rows(oa.get('', {}).get('props', {}), ob.get('', {}).get('props', {}), ROOT_SKIP)
    if om.get('parent') != nm.get('parent') and old and new:
        rows.insert(0, ('mod', f'Parent class <s>{E(om.get("parent") or "?")}</s> → {E(nm.get("parent") or "?")}'))
    if rows:
        sections.append(('Blueprint settings', None, rows))
    rows = prop_rows(ca.get('', {}).get('props', {}), cb.get('', {}).get('props', {}), CDO_SKIP)
    if rows and old and new:
        sections.append(('Class defaults', None, rows))
    return sections


def load_side(folder, flat):
    meta_f = os.path.join(folder, flat + '.json')
    if not os.path.exists(meta_f):
        return None
    with open(meta_f, encoding='utf-8') as fh:
        meta = json.load(fh)
    read = lambda fn: parse_t3d(open(fn, encoding='utf-8', errors='replace').read()) \
        if os.path.exists(fn) else {}
    return meta, read(os.path.join(folder, flat + '.t3d')), read(os.path.join(folder, flat + '.cdo.t3d'))


def attach_blueprints(files, folder):
    with open(os.path.join(folder, 'manifest.json'), encoding='utf-8') as fh:
        man = json.load(fh)
    for a in man.get('assets', []):
        rel = a['file'].replace('\\', '/')
        old, new = load_side(os.path.join(folder, 'old'), a['flat']), load_side(os.path.join(folder, 'new'), a['flat'])
        f = next((x for x in files if x.path == rel or x.path.endswith('/' + rel)), None)
        if f is None:
            f = FileDiff(None if a['status'] == 'added' else rel, None if a['status'] == 'deleted' else rel)
            f.status = a['status'] if a['status'] in ('added', 'deleted') else 'modified'
            f.binary = True
            files.append(f)
        meta = (new or old or ({},))[0]
        if meta and meta.get('class') and 'Blueprint' not in meta['class']:
            f.bp = ('asset', meta['class'])
            continue
        if old is None and new is None:
            f.bp = ('missing', None)
            continue
        f.bp = ('bp', meta, bp_diff(old, new))
        for _, _, rows in f.bp[2]:
            for kind, _ in rows:
                if kind == 'add': f.adds += 1
                elif kind == 'del': f.dels += 1
                elif kind == 'mod': f.mods += 1
    return files


def render_bp(f):
    kind = f.bp[0]
    if kind == 'asset':
        return f'<p class="empty-msg">{html.escape(f.bp[1])} asset. Only Blueprints get a semantic diff.</p>'
    if kind == 'missing':
        return '<p class="empty-msg">No Blueprint export found. Check the bp_export log.</p>'
    meta, sections = f.bp[1], f.bp[2]
    head = (f'<p class="bp-head"><span class="bp-tag">{html.escape(meta.get("class", "Blueprint"))}</span>'
            f' parent <code>{html.escape(meta.get("parent") or "?")}</code></p>')
    if not sections:
        return head + '<p class="empty-msg">No semantic changes. The file changed but its graphs, variables and defaults did not.</p>'
    sign = {'add': '+', 'del': '−', 'mod': '~', 'info': '·'}
    out = [head]
    for title, st, rows in sections:
        badge = f' <span class="st st-{st}">{"Added" if st == "added" else "Removed"}</span>' if st else ''
        out.append(f'<div class="bp-sec"><h3>{html.escape(title)}{badge}</h3><ul class="bp">')
        out.extend(f'<li class="{k}"><span class="sg">{sign[k]}</span><span>{t}</span></li>' for k, t in rows)
        if not rows:
            out.append('<li class="info"><span class="sg">·</span><span>Empty graph</span></li>')
        out.append('</ul></div>')
    return ''.join(out)


# ---------------------------------------------------------------- text diff

def intraline(a, b):
    ta, tb = TOKENS.findall(a), TOKENS.findall(b)
    sm = difflib.SequenceMatcher(None, ta, tb, autojunk=False)
    if not a.strip() or not b.strip() or sm.ratio() < 0.5:
        return None, None
    pa, pb = [0], [0]
    for t in ta: pa.append(pa[-1] + len(t))
    for t in tb: pb.append(pb[-1] + len(t))
    ma, mb = [False] * len(a), [False] * len(b)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag != 'equal':
            for x in range(pa[i1], pa[i2]): ma[x] = True
            for x in range(pb[j1], pb[j2]): mb[x] = True
    return ma, mb


def code(text, lang, mark=None):
    n = len(text)
    cls = [None] * n
    if lang:
        for m in SYNTAX.finditer(text):
            for i in range(m.start(), m.end()):
                cls[i] = m.lastgroup
    out, i = [], 0
    while i < n:
        c, mk, j = cls[i], bool(mark and mark[i]), i
        while j < n and cls[j] == c and bool(mark and mark[j]) == mk:
            j += 1
        seg = html.escape(text[i:j], quote=False)
        if c: seg = f'<span class="t-{c}">{seg}</span>'
        if mk: seg = f'<mark>{seg}</mark>'
        out.append(seg)
        i = j
    return ''.join(out)


def rows_for(h, lang):
    """Rows: ('ctx', o, n, html) or ('chg', [(left, right)]), where each side is
    (line no, html, kind) or None. kind is 'mod' for a paired line, else 'del' or 'add'."""
    rows, o, n, ls, i = [], h['os'], h['ns'], h['lines'], 0
    while i < len(ls):
        if ls[i][0] == ' ':
            rows.append(('ctx', o, n, code(ls[i][1], lang))); o += 1; n += 1; i += 1
            continue
        dels, adds = [], []
        while i < len(ls) and ls[i][0] == '-': dels.append(ls[i][1]); i += 1
        while i < len(ls) and ls[i][0] == '+': adds.append(ls[i][1]); i += 1
        aligned = []  # (left or None, right or None), each side (line no, html, kind)
        for di, ai in align(dels, adds):
            if di is not None and ai is not None:
                dm, am = intraline(dels[di], adds[ai])
                aligned.append(((o + di, code(dels[di], lang, dm), 'mod'), (n + ai, code(adds[ai], lang, am), 'mod')))
            elif di is not None:
                aligned.append(((o + di, code(dels[di], lang), 'del'), None))
            else:
                aligned.append((None, (n + ai, code(adds[ai], lang), 'add')))
        rows.append(('chg', aligned))
        o += len(dels); n += len(adds)
    return rows


def similar(a, b):
    return difflib.SequenceMatcher(None, TOKENS.findall(a), TOKENS.findall(b), autojunk=False).ratio()


def align(dels, adds, cutoff=0.5):
    """Pair removed and added lines that look alike, in order. Unpaired lines
    stay pure removals or additions, as in Rider's diff."""
    out, i, j = [], 0, 0
    while i < len(dels) and j < len(adds):
        best = max(range(j, len(adds)), key=lambda k: similar(dels[i], adds[k]))
        if similar(dels[i], adds[best]) < cutoff:
            out.append((i, None)); i += 1
            continue
        out.extend((None, k) for k in range(j, best))
        out.append((i, best)); i, j = i + 1, best + 1
    out.extend((k, None) for k in range(i, len(dels)))
    out.extend((None, k) for k in range(j, len(adds)))
    return out


def hunk_row(h, span, lang):
    fn = f' <span class="fn">{code(h["ctx"], lang)}</span>' if h['ctx'] else ''
    return (f'<tr class="hunk"><td colspan="{span}"><span class="at">@@ -{h["os"]},{h["oc"]} '
            f'+{h["ns"]},{h["nc"]} @@</span>{fn}</td></tr>')


def tables(f, lang):
    sp, un = [], []
    for h in f.hunks:
        sp.append(hunk_row(h, 4, lang)); un.append(hunk_row(h, 3, lang))
        for r in rows_for(h, lang):
            if r[0] == 'ctx':
                _, o, n, c = r
                sp.append(f'<tr><td class="ln">{o}</td><td class="cd">{c}</td><td class="ln">{n}</td><td class="cd">{c}</td></tr>')
                un.append(f'<tr><td class="ln">{o}</td><td class="ln">{n}</td><td class="cd">{c}</td></tr>')
                continue
            empty = '<td class="ln e"></td><td class="cd e"></td>'
            for L, R in r[1]:
                left = f'<td class="ln {L[2]}">{L[0]}</td><td class="cd {L[2]} o">{L[1]}</td>' if L else empty
                right = f'<td class="ln {R[2]}">{R[0]}</td><td class="cd {R[2]} n">{R[1]}</td>' if R else empty
                sp.append(f'<tr>{left}{right}</tr>')
            un.extend(f'<tr><td class="ln {k}">{o}</td><td class="ln {k}"></td><td class="cd {k} o">{c}</td></tr>'
                      for o, c, k in (L for L, _ in r[1] if L))
            un.extend(f'<tr><td class="ln {k}"></td><td class="ln {k}">{n}</td><td class="cd {k} n">{c}</td></tr>'
                      for n, c, k in (R for _, R in r[1] if R))
    if f.status in ('added', 'deleted'):  # one side is empty, so skip the split layout
        return f'<table class="d"><colgroup><col class="c-ln"><col class="c-ln"><col></colgroup>{"".join(un)}</table>'
    cols4 = '<colgroup><col class="c-ln"><col><col class="c-ln"><col></colgroup>'
    cols3 = '<colgroup><col class="c-ln"><col class="c-ln"><col></colgroup>'
    return (f'<table class="d v-split">{cols4}{"".join(sp)}</table>'
            f'<table class="d v-uni">{cols3}{"".join(un)}</table>')


def prose(text):
    paras = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]
    fmt = lambda p: re.sub(r'`([^`]+)`', r'<code>\1</code>', html.escape(p, quote=False))
    return ''.join(f'<p>{fmt(p)}</p>' for p in paras)


def find_note(notes, path):
    for k, v in notes.items():
        if k != '_summary' and (path == k or path.endswith('/' + k) or path.endswith(k)):
            return v
    return None


def mass(f, biggest):
    total = f.adds + f.dels + f.mods
    w = max(2.0, 100.0 * total / biggest) if total else 0
    a = 100.0 * f.adds / total if total else 0
    m = 100.0 * f.mods / total if total else 0
    return (f'<span class="mass" aria-hidden="true"><span class="fill" style="width:{w:.1f}%">'
            f'<span class="ma" style="width:{a:.1f}%"></span><span class="mm" style="width:{m:.1f}%"></span>'
            f'<span class="md"></span></span></span>')


def counts(f):
    mod = f' <span class="pm">~{f.mods}</span>' if f.mods else ''
    return f'<span class="pa">+{f.adds}</span> <span class="pd">−{f.dels}</span>{mod}'


def split_path(p):
    d, _, b = p.rpartition('/')
    return (html.escape(d + '/') if d else ''), html.escape(b)


def render(files, title, notes, collapse):
    paths = [f.path for f in files]
    prefix = ''
    if len(paths) > 1:
        prefix = os.path.commonprefix(paths)
        prefix = prefix[:prefix.rfind('/') + 1]
    rel = lambda p: p[len(prefix):] if prefix else p
    biggest = max([f.adds + f.dels + f.mods for f in files] + [1])
    adds, dels = sum(f.adds for f in files), sum(f.dels for f in files)
    label_ = {'added': 'Added', 'deleted': 'Deleted', 'renamed': 'Renamed'}

    nav, body = [], []
    for i, f in enumerate(files):
        d, b = split_path(rel(f.path))
        lang = os.path.splitext(f.path)[1].lower() in CODE_EXT
        st = f'<span class="st st-{f.status}">{label_[f.status]}</span>' if f.status in label_ else ''
        bp_tag = '<span class="st st-bp">Blueprint</span>' if f.bp and f.bp[0] == 'bp' else ''
        nav.append(f'<li><a href="#f{i}"><span class="nb">{b}</span><span class="nc">{counts(f)}</span>'
                   f'<span class="nd">{d}</span>{mass(f, biggest)}</a></li>')
        sub = (f'<div class="ren">Renamed from <code>{html.escape(f.old.replace(chr(92), "/"))}</code></div>'
               if f.status == 'renamed' and f.old else '')
        note = find_note(notes, f.path)
        note_html = f'<div class="note">{prose(note)}</div>' if note else ''
        if f.bp:
            content = render_bp(f)
        elif f.binary:
            hint = ' Pass <code>--blueprints</code> for a Blueprint diff.' if f.path.lower().endswith(ASSET_EXT) else ''
            content = f'<p class="empty-msg">Binary file, no text diff.{hint}</p>'
        elif not f.hunks:
            content = '<p class="empty-msg">No content changes.</p>'
        else:
            content = tables(f, lang)
        big = f.adds + f.dels + f.mods > collapse
        hint = '<p class="empty-msg">Large diff collapsed. Open the header to show it.</p>' if big else ''
        body.append(
            f'<details class="file" id="f{i}"{"" if big else " open"}><summary>'
            f'<span class="path"><span class="dir">{d}</span><span class="base">{b}</span></span>{st}{bp_tag}'
            f'<span class="cnt">{counts(f)}</span>'
            f'</summary>{sub}{note_html}<div class="scroll">{content}</div></details>{hint if big else ""}')

    summary = notes.get('_summary')
    where = f' in <code>{html.escape(prefix)}</code>' if prefix else ''
    plural = 's' if len(files) != 1 else ''
    return TEMPLATE.format(
        title=html.escape(title), css=CSS.replace('/*LIGHT*/', LIGHT), js=JS,
        meta=(f'{len(files)} file{plural} changed{where}'
              f'<span class="tot"><span class="pa">+{adds}</span> <span class="pd">−{dels}</span></span>'),
        when=datetime.now().strftime('%b %d, %Y at %H:%M'),
        summary=f'<div class="summary">{prose(summary)}</div>' if summary else '',
        nav=''.join(nav), body=''.join(body) or '<p class="empty-msg">The diff is empty.</p>')


# Dark is the default and follows a Rider-style editor diff: green for added
# lines, blue for modified lines, grey for removed ones.
LIGHT = '''--bg:#f2f3f5;--surface:#fff;--ink:#1e1f22;--muted:#6c707e;--line:#dfe1e5;--accent:#3574f0;
--add-bg:#e3f2e6;--add-ln:#cfe8d5;--add-mark:#a8d8b4;--add-ink:#2f7d3e;
--mod-bg:#e3ecfb;--mod-ln:#cddcf6;--mod-mark:#a9c3ee;--mod-ink:#2c5fb8;
--del-bg:#eceef1;--del-ln:#dfe2e6;--del-mark:#c9cdd3;--del-ink:#6c707e;
--hunk:#eef1f6;--empty:#f6f7f9;--t-kw:#0033b3;--t-type:#00807f;--t-fn:#b8560b;--t-str:#067d17;
--t-com:#8c8c8c;--t-num:#1750eb;--t-mac:#871094;--t-pp:#9e880d;color-scheme:light;'''

CSS = '''
:root{--bg:#191a1c;--surface:#1e1f22;--ink:#bcbec4;--muted:#7a7e85;--line:#2b2d30;--accent:#548af7;
--add-bg:#294436;--add-ln:#2f4d3c;--add-mark:#3d6a50;--add-ink:#6aab73;
--mod-bg:#2c4258;--mod-ln:#32506b;--mod-mark:#3f6589;--mod-ink:#7aa7e0;
--del-bg:#2e2f33;--del-ln:#35363a;--del-mark:#46484d;--del-ink:#8c9098;
--hunk:#24262a;--empty:#1b1c1f;--t-kw:#6c95eb;--t-type:#4fb2c4;--t-fn:#e8955a;--t-str:#c9a26d;
--t-com:#7a7e85;--t-num:#2aacb8;--t-mac:#c77dbb;--t-pp:#b3ae60;
--mono:"JetBrains Mono","Cascadia Code","SF Mono",ui-monospace,Menlo,Consolas,monospace;
--sans:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color-scheme:dark}
:root[data-theme="light"]{/*LIGHT*/}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 var(--sans)}
code{font:12.5px var(--mono);background:var(--hunk);padding:.05em .35em;border-radius:4px}
.pa{color:var(--add-ink)}.pd{color:var(--del-ink)}.pm{color:var(--mod-ink)}
.top{max-width:112rem;margin:0 auto;padding:2rem 1.5rem 1.25rem;display:flex;flex-wrap:wrap;gap:1rem 2rem;align-items:end;justify-content:space-between}
.top h1{margin:0;font-size:1.55rem;font-weight:650;letter-spacing:-.015em}
.meta{margin:.3rem 0 0;color:var(--muted)}.tot{font:12.5px var(--mono);margin-left:.75rem}.meta .when{display:block;font-size:12.5px}
.ctl{display:flex;gap:.5rem;align-items:center}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:7px;overflow:hidden;background:var(--surface)}
button{font:inherit;font-size:13px;color:var(--ink);background:var(--surface);border:0;padding:.35rem .8rem;cursor:pointer}
.seg button+button{border-left:1px solid var(--line)}
.seg button[aria-pressed="true"],#files[aria-pressed="true"]{background:var(--mod-ln);color:var(--ink)}
#theme,#files{border:1px solid var(--line);border-radius:7px}
button:focus-visible,a:focus-visible,summary:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.summary{max-width:112rem;margin:0 auto;padding:0 1.5rem 1rem}
.summary p,.note p{margin:0 0 .5rem;max-width:72ch}
.wrap{max-width:112rem;margin:0 auto;padding:0 1.5rem 3rem;display:grid;grid-template-columns:16.5rem minmax(0,1fr);gap:1.5rem}
body.nofiles .wrap{grid-template-columns:minmax(0,1fr)}body.nofiles nav{display:none}body.nofiles .keys{grid-column:1}
nav{position:sticky;top:1rem;align-self:start;max-height:calc(100vh - 2rem);overflow:auto}
nav ul{list-style:none;margin:0;padding:0}
nav a{display:grid;grid-template-columns:1fr auto;gap:.1rem .5rem;padding:.5rem .6rem;border-radius:7px;color:inherit;text-decoration:none}
nav a:hover{background:var(--surface)}
.nb{font:600 12.5px var(--mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.nc{font:12px var(--mono)}
.nd{grid-column:1/-1;font-size:11.5px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:rtl;text-align:left}
.mass{grid-column:1/-1;display:block;height:3px;margin-top:.3rem;background:var(--line);border-radius:2px}
.fill{display:flex;height:100%;border-radius:2px;overflow:hidden}
.ma{background:var(--add-ink)}.mm{background:var(--mod-ink)}.md{flex:1;background:var(--del-ink)}
.file{background:var(--surface);border:1px solid var(--line);border-radius:9px;margin:0 0 1.25rem;overflow:clip}
.file>summary{position:sticky;top:0;z-index:2;display:flex;align-items:center;gap:.75rem;padding:.6rem .9rem;background:var(--surface);border-bottom:1px solid var(--line);cursor:pointer;list-style:none}
.file:not([open])>summary{border-bottom:0}
.file>summary::-webkit-details-marker{display:none}
.file>summary::before{content:"";width:0;height:0;border:5px solid transparent;border-left-color:var(--muted);transform:translateX(3px);flex:none}
.file[open]>summary::before{transform:translate(0,3px) rotate(90deg)}
.path{font:13px var(--mono);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dir{color:var(--muted)}.base{font-weight:650}
.st{font-size:11.5px;padding:.05rem .45rem;border-radius:99px;border:1px solid currentColor;flex:none}
.st-added{color:var(--add-ink)}.st-deleted{color:var(--del-ink)}.st-renamed,.st-bp{color:var(--mod-ink)}
.cnt{margin-left:auto;font:12.5px var(--mono);flex:none}
.ren{padding:.5rem .9rem 0;color:var(--muted);font-size:13px}
.note{margin:.75rem .9rem 0;padding:.6rem .8rem;border-left:3px solid var(--accent);background:var(--hunk);border-radius:0 6px 6px 0}
.note p:last-child{margin-bottom:0}
.scroll{overflow-x:auto}
.d{width:100%;border-collapse:collapse;table-layout:fixed;font:12.5px/1.6 var(--mono)}
.c-ln{width:3.6rem}
.d td{vertical-align:top;padding:0}
.ln{color:var(--muted);text-align:right;padding:0 .6rem!important;font-size:11.5px;user-select:none;-webkit-user-select:none}
.v-split td:nth-child(3){border-left:1px solid var(--line)}
.cd{white-space:pre-wrap;overflow-wrap:anywhere;padding:0 .8rem 0 1.5rem!important;position:relative}
.cd.add{background:var(--add-bg)}.cd.del{background:var(--del-bg)}.cd.mod{background:var(--mod-bg)}
.ln.add{background:var(--add-ln);color:var(--add-ink)}.ln.del{background:var(--del-ln);color:var(--del-ink)}.ln.mod{background:var(--mod-ln);color:var(--mod-ink)}
.cd.add::before,.cd.del::before,.cd.mod::before{position:absolute;left:.55rem;user-select:none}
.cd.add::before{content:"+";color:var(--add-ink)}.cd.del::before{content:"−";color:var(--del-ink)}
.cd.mod.o::before{content:"−";color:var(--mod-ink)}.cd.mod.n::before{content:"+";color:var(--mod-ink)}
.e{background:var(--empty)}
mark{background:none;color:inherit;border-radius:3px}
.add mark{background:var(--add-mark)}.del mark{background:var(--del-mark)}.mod mark{background:var(--mod-mark)}
.hunk td{background:var(--hunk);color:var(--muted);padding:.3rem .8rem!important;font-size:12px}
.hunk .fn{color:var(--ink);margin-left:.5rem}
.t-kw{color:var(--t-kw)}.t-pp{color:var(--t-pp)}.t-type{color:var(--t-type)}.t-fn{color:var(--t-fn)}.t-str{color:var(--t-str)}
.t-com{color:var(--t-com);font-style:italic}.t-num{color:var(--t-num)}.t-mac{color:var(--t-mac)}
.empty-msg{color:var(--muted);padding:.75rem .9rem;margin:0}
.bp-head{margin:0;padding:.75rem .9rem 0;color:var(--muted);font-size:13px}
.bp-tag{color:var(--mod-ink);font-weight:600}
.bp-sec{padding:.5rem .9rem .25rem}
.bp-sec h3{margin:.25rem 0 .4rem;font:600 13px var(--mono);display:flex;gap:.5rem;align-items:center}
ul.bp{list-style:none;margin:0 0 .5rem;padding:0;font:12.5px/1.6 var(--mono);border:1px solid var(--line);border-radius:6px;overflow:hidden}
ul.bp li{display:flex;gap:.6rem;padding:.15rem .7rem;overflow-wrap:anywhere}
ul.bp li+li{border-top:1px solid var(--line)}
ul.bp .sg{flex:none;width:.8rem;text-align:center}
ul.bp .add{background:var(--add-bg)}ul.bp .add .sg{color:var(--add-ink)}
ul.bp .del{background:var(--del-bg)}ul.bp .del .sg{color:var(--del-ink)}
ul.bp .mod{background:var(--mod-bg)}ul.bp .mod .sg{color:var(--mod-ink)}
ul.bp .info{color:var(--muted)}
ul.bp b{font-weight:600;color:var(--ink)}ul.bp s{color:var(--muted)}
ul.bp code{background:none;padding:0}
.keys{grid-column:2;color:var(--muted);font-size:12.5px;margin:0}
kbd{font:11.5px var(--mono);border:1px solid var(--line);border-bottom-width:2px;border-radius:4px;padding:0 .3rem;background:var(--surface)}
body:not(.unified) .v-uni,body.unified .v-split{display:none}
@media (max-width:1100px){.wrap{grid-template-columns:minmax(0,1fr)}nav{position:static;max-height:none}
  nav ul{display:grid;grid-template-columns:repeat(auto-fill,minmax(14rem,1fr));gap:.25rem}.keys{grid-column:1}}
@media (max-width:820px){.v-split{display:none!important}.v-uni{display:table!important}.seg{display:none}}
@media (prefers-reduced-motion:no-preference){.file>summary::before{transition:transform .12s}}
'''

JS = '''(()=>{const b=document.body,r=document.documentElement,
g=k=>{try{return localStorage.getItem(k)}catch(e){return null}},s=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const view=v=>{b.classList.toggle('unified',v==='unified');document.querySelectorAll('[data-view]').forEach(x=>x.setAttribute('aria-pressed',x.dataset.view===v));s('diffview.view',v)};
view(g('diffview.view')||'split');document.querySelectorAll('[data-view]').forEach(x=>x.onclick=()=>view(x.dataset.view));
const fb=document.getElementById('files');
const files=on=>{b.classList.toggle('nofiles',!on);fb.setAttribute('aria-pressed',on);s('diffview.files',on?'1':'0')};
files(g('diffview.files')!=='0');fb.onclick=()=>files(b.classList.contains('nofiles'));
const t=g('diffview.theme');if(t)r.dataset.theme=t;
document.getElementById('theme').onclick=()=>{const n=r.dataset.theme==='light'?'dark':'light';r.dataset.theme=n;s('diffview.theme',n)};
const fs=[...document.querySelectorAll('.file')];
addEventListener('keydown',e=>{if(e.metaKey||e.ctrlKey||e.altKey||/INPUT|TEXTAREA/.test(e.target.tagName))return;
if(e.key==='j'||e.key==='k'){let i=-1;fs.forEach((f,j)=>{if(f.getBoundingClientRect().top<=12)i=j});
const f=fs[Math.max(0,Math.min(fs.length-1,i+(e.key==='j'?1:-1)))];if(f){f.open=true;f.scrollIntoView({block:'start'})}}
if(e.key==='v')view(b.classList.contains('unified')?'split':'unified');
if(e.key==='f')files(b.classList.contains('nofiles'))})})();'''

TEMPLATE = '''<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title>
<style>{css}</style></head><body>
<header class="top"><div><h1>{title}</h1><p class="meta">{meta}<span class="when">Generated {when}</span></p></div>
<div class="ctl"><button id="files" title="Show or hide the file list (f)">Files</button>
<span class="seg" role="group" aria-label="Diff layout"><button data-view="split">Split</button><button data-view="unified">Unified</button></span>
<button id="theme" title="Switch light or dark">Theme</button></div></header>
{summary}
<div class="wrap"><nav aria-label="Changed files"><ul>{nav}</ul></nav><main>{body}</main>
<p class="keys"><kbd>j</kbd> <kbd>k</kbd> next and previous file, <kbd>v</kbd> switch split and unified, <kbd>f</kbd> show or hide files</p></div>
<script>{js}</script></body></html>'''


def main():
    ap = argparse.ArgumentParser(description='Render a unified diff as styled, self-contained HTML.')
    ap.add_argument('diff', nargs='?', help='diff file (reads stdin if omitted)')
    ap.add_argument('-o', '--out', default='diff.html')
    ap.add_argument('--title', default='Changes')
    ap.add_argument('--notes', help='JSON of per-file notes, plus optional "_summary"')
    ap.add_argument('--blueprints', help='folder filled by bp_prepare.py and bp_export.py')
    ap.add_argument('--collapse', type=int, default=800, help='collapse files with more changed lines')
    a = ap.parse_args()
    try:
        run(a)
    except (OSError, ValueError) as e:  # json.JSONDecodeError is a ValueError
        sys.exit(f'diffview: {e}')


def run(a):
    if a.blueprints and not os.path.isfile(os.path.join(a.blueprints, 'manifest.json')):
        raise OSError(f'{a.blueprints} has no manifest.json. Run bp_prepare.py first.')
    if a.diff:
        with open(a.diff, encoding='utf-8', errors='replace') as fh:
            text = fh.read()
    elif not sys.stdin.isatty():
        sys.stdin.reconfigure(encoding='utf-8', errors='replace')
        text = sys.stdin.read()
    else:
        text = ''
    notes = {}
    if a.notes:
        with open(a.notes, encoding='utf-8') as fh:
            notes = json.load(fh)
    files = parse(text)
    if a.blueprints:
        attach_blueprints(files, a.blueprints)
    with open(a.out, 'w', encoding='utf-8') as fh:
        fh.write(render(files, a.title, notes, a.collapse))
    bps = sum(1 for f in files if f.bp and f.bp[0] == 'bp')
    extra = f', {bps} Blueprints' if bps else ''
    print(f'{a.out}: {len(files)} files{extra}, +{sum(f.adds for f in files)} -{sum(f.dels for f in files)}')


if __name__ == '__main__':
    main()
