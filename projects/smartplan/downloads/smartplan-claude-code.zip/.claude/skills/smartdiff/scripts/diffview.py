#!/usr/bin/env python3
"""diffview: render a unified diff (git, diff -u, `p4 diff -du`, or `p4 describe -du`) as one
self-contained HTML page. Python stdlib only; the output makes no network requests.

  git diff -U5 | python diffview.py -o review.html
  python diffview.py session.diff -o review.html --title "Grapple tuning" --notes notes.json
  python diffview.py session.diff --blueprints work/bp -o review.html

notes.json (optional):  {"_summary": "Why this change set exists.",
                         "GrappleComponent.cpp": "Note shown above that file."}
Keys match a full path or a path suffix. `backticks` render as code.

--blueprints reads the folder bp_prepare.py and bp_export.py fill, and shows
each changed Blueprint as a semantic diff (graphs, nodes, links, pin defaults,
variables, components, class defaults) instead of "binary file".

--git-context REPO reads each file whole (HEAD and the working tree) so the
page can expand the lines between hunks. trail.py does the same from the
session record.

--review FILE shows smartreview's findings as comments under the line each
names. FILE is the report as written (its "- <file>:<line> — ..." rows under
BREAKING, PRACTICE and CONVENTION) or JSON: [{"file", "line", "severity",
"text", "side": "old" for a removed line, "fix"}]. A finding on a line the
diff doesn't show sits above its file, and one on no file in the diff sits
above the file list.
"""
import argparse, difflib, html, itertools, json, os, re, subprocess, sys
from datetime import datetime
from html import unescape

HUNK_RE = re.compile(r'^@@ -(\d+)(?:,(\d+))? \+(\d+)(?:,(\d+))? @@ ?(.*)$')
CODE_EXT = {'.h', '.hpp', '.hh', '.hxx', '.inl', '.c', '.cc', '.cpp', '.cxx', '.cs',
            '.ush', '.usf', '.hlsl', '.js', '.jsx', '.ts', '.tsx', '.java', '.py'}
CPP_EXT = {'.c', '.cc', '.cpp', '.cxx', '.h', '.hh', '.hpp', '.hxx', '.inl'}
SYNTAX = re.compile(r'''
   (?P<com>//.*$|/\*.*?\*/|/\*.*$|^\s*\*(?:\s|/|$).*$)
  |(?P<str>"(?:\\.|[^"\\])*"?|'(?:\\.|[^'\\])*'?)
  |(?P<pp>^\s*\#\s*\w+)
  |(?P<mac>\b(?:\w+_API|WITH_[A-Z0-9_]+|UCLASS|USTRUCT|UENUM|UFUNCTION|UPROPERTY|UINTERFACE|UMETA|UPARAM|GENERATED_BODY|
      GENERATED_UCLASS_BODY|TEXT|LOCTEXT|NSLOCTEXT|check|checkf|checkSlow|ensure|ensureMsgf|
      ensureAlways|verify|UE_LOGF|UE_LOGFMT|UE_LOG|UE_CLOG|DECLARE_\w+|DEFINE_\w+|IMPLEMENT_\w+|TRACE_\w+|SCOPE_\w+)\b)
  |(?P<kw>\b(?:alignas|auto|bool|break|case|catch|char|class|const|constexpr|consteval|continue|
      default|delete|do|double|else|enum|explicit|extern|false|final|float|for|friend|if|inline|
      int|int8|int16|int32|int64|uint8|uint16|uint32|uint64|long|mutable|namespace|new|noexcept|
      nullptr|operator|override|private|protected|public|return|short|signed|sizeof|static|
      static_cast|dynamic_cast|reinterpret_cast|const_cast|struct|switch|template|this|throw|
      true|try|typedef|typename|union|unsigned|using|virtual|void|volatile|while|co_await|
      co_return|co_yield)\b)
  |(?P<type>\b[UAFTEIS][A-Z][A-Za-z0-9]*[a-z]\w*\b)
  |(?P<num>\b(?:0x[\da-fA-F]+|\d+\.?\d*(?:[eE][+-]?\d+)?)[fFuUlL]*\b)
  |(?P<fn>\b[A-Za-z_]\w*(?=\s*\())
''', re.M | re.X)
TOKENS = re.compile(r'\w+|\s+|[^\w\s]')
PY_SYNTAX = re.compile(r'''(?P<com>\#[^\n]*)|(?P<str>"(?:\\.|[^"\\])*"?|'(?:\\.|[^'\\])*'?)
    |(?P<kw>\b(?:and|as|assert|async|await|break|class|continue|def|del|elif|else|except|False|finally|for|from|if|import|in|is|lambda|None|not|or|pass|raise|return|True|try|while|with|yield)\b)
    |(?P<num>\b\d+(?:\.\d+)?\b)''', re.X)
FORMAT_SPEC = re.compile(r'%(?:\d+\$)?[-+#0]*(?:\d+|\*)?(?:\.(?:\d+|\*))?(?:hh|ll|[hljztL])?[diuoxXfFeEgGaAcspn]')
PREPROC_CONDITION = re.compile(r'^\s*#\s*(?:if|elif)\b')
PREPROC_DEFINED = re.compile(r'\bdefined\b')
ASSET_EXT = ('.uasset', '.umap')
# File-type badges in each file header, next to the Blueprint one.
LANG_NAME = {**dict.fromkeys(('.h', '.hpp', '.hh', '.hxx', '.inl', '.c', '.cc', '.cpp', '.cxx'), 'C++'),
             '.c': 'C', '.cs': 'C#', '.ush': 'HLSL', '.usf': 'HLSL', '.hlsl': 'HLSL',
             '.js': 'JavaScript', '.jsx': 'JavaScript', '.mjs': 'JavaScript', '.ts': 'TypeScript',
             '.tsx': 'TypeScript', '.java': 'Java', '.py': 'Python', '.sh': 'Shell', '.ps1': 'PowerShell',
             '.bat': 'Batch', '.cmd': 'Batch', '.md': 'Markdown', '.json': 'JSON', '.yml': 'YAML',
             '.yaml': 'YAML', '.toml': 'TOML', '.ini': 'INI', '.xml': 'XML', '.html': 'HTML', '.css': 'CSS',
             '.lua': 'Lua', '.rs': 'Rust', '.go': 'Go', '.cmake': 'CMake', '.uproject': 'JSON',
             '.uplugin': 'JSON', '.umap': 'Level', '.uasset': 'Asset'}


class FileDiff:
    def __init__(self, old=None, new=None):
        self.old, self.new = old, new
        self.status, self.binary = 'modified', False
        self.hunks, self.adds, self.dels, self.mods = [], 0, 0, 0
        self.bp = None  # Blueprint diff sections, when --blueprints covers this file
        self.review, self.placed = [], set()  # review findings, and which ones sit on a shown line
        self.gapped = False  # trail: the file changed between two agent edits
        self.empty_msg = ''  # shown instead of "No content changes." when set

    @property
    def path(self):
        p = (self.old or self.new) if self.status == 'deleted' else (self.new or self.old)
        return (p or '(unnamed)').replace('\\', '/')


GAP_NOTE = ('This file changed between two agent edits, outside the recorded edits. '
            'That change is included below, so check it by hand.')
QUOTED_NAME = r'"(?:[^"\\]|\\.)*"'
C_ESCAPES = {'\\': '\\', '"': '"', 'a': '\a', 'b': '\b', 'f': '\f', 'n': '\n', 'r': '\r', 't': '\t', 'v': '\v'}


def split_lines(text):
    """Lines of text, split on LF and CRLF only. str.splitlines() also breaks on
    form feeds, vertical tabs, U+2028 and other separators that a content line
    can hold, and every line after one would then be numbered wrong."""
    parts = text.replace('\r\n', '\n').split('\n')
    if parts[-1] == '':
        parts.pop()
    return parts


def read_text(path):
    """A diff or review file as text. A UTF-16 BOM (PowerShell 5.1's `>` writes one)
    decodes as UTF-16, a UTF-8 BOM as utf-8-sig, and anything else as UTF-8."""
    with open(path, 'rb') as fh:
        raw = fh.read()
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return raw.decode('utf-16', errors='replace')
    if raw[:3] == b'\xef\xbb\xbf':
        return raw.decode('utf-8-sig', errors='replace')
    return raw.decode('utf-8', errors='replace')


def load_notes(path):
    with open(path, encoding='utf-8') as fh:
        notes = json.load(fh)
    if not isinstance(notes, dict):
        raise ValueError(f'{path} must hold a JSON object of per-file notes.')
    return notes


def unquote_path(p):
    """Undo git's C quoting of a name with unusual bytes, then decode the bytes as
    UTF-8. A name that isn't wrapped in double quotes comes back unchanged."""
    if len(p) < 2 or p[0] != '"' or p[-1] != '"':
        return p
    body, out, i = p[1:-1], bytearray(), 0
    while i < len(body):
        ch = body[i]
        if ch == '\\' and i + 1 < len(body):
            octal = body[i + 1:i + 4]
            if len(octal) == 3 and all(c in '01234567' for c in octal):
                out.append(int(octal, 8) & 0xFF)
                i += 4
                continue
            if body[i + 1] in C_ESCAPES:
                out += C_ESCAPES[body[i + 1]].encode('utf-8')
                i += 2
                continue
        out += ch.encode('utf-8')
        i += 1
    return out.decode('utf-8', errors='replace')


def header_names(rest):
    """Old and new names from the text after `diff --git `, without their a/ and b/
    prefixes. Git C-quotes a name that holds unusual bytes, so either can arrive quoted."""
    m = re.match(rf'({QUOTED_NAME}) ({QUOTED_NAME}|.+)$', rest) or re.match(rf'(.+?) ({QUOTED_NAME})$', rest)
    if m:
        old, new = (unquote_path(x) for x in m.groups())
        return (old[2:] if old.startswith('a/') else old), (new[2:] if new.startswith('b/') else new)
    m = re.match(r'a/(.*) b/(.*)$', rest)
    return m.groups() if m else ()


def clean_path(p):
    p = unquote_path(p.split('\t')[0].strip())
    if p == '/dev/null':
        return None
    if p[:2] in ('a/', 'b/'):
        p = p[2:]
    return re.sub(r'#\d+$', '', p)


def parse(text):
    files, cur, hunk, orem, nrem, from_git = [], None, None, 0, 0, False

    def start(old=None, new=None, git=False):
        nonlocal cur, hunk, from_git
        cur, hunk, from_git = FileDiff(old, new), None, git
        files.append(cur)

    for raw in split_lines(text):
        if hunk is not None and (orem > 0 or nrem > 0):
            tag, body = raw[:1], raw[1:].expandtabs(4)
            if tag in (' ', ''):
                hunk['lines'].append((' ', body)); orem -= 1; nrem -= 1; continue
            if tag == '-':
                hunk['lines'].append(('-', body)); orem -= 1; cur.dels += 1; continue
            if tag == '+':
                hunk['lines'].append(('+', body)); nrem -= 1; cur.adds += 1; continue
            if tag == '\\':
                continue
        if raw.startswith('\\'):
            continue
        if raw.startswith('diff --git '):
            start(*header_names(raw[len('diff --git '):]), git=True)
        elif raw.startswith('==== '):
            # `p4 diff -du` writes "==== //depot/f#3 - <local> ====". `p4 describe
            # -du` writes "==== //depot/f#3 (text) ====", with no ---/+++ lines
            # after it, so this header is the only place its name appears.
            m = re.match(r'^==== (.+?)#\d+ - (.+?) ====', raw) or \
                re.match(r'^==== (.+?)(?:#\d+)? \(([\w+]+)\) ====\s*$', raw)
            start(m.group(1), m.group(1)) if m else start()
            if '(binary)' in raw or raw.rstrip().endswith('binary') or \
                    (m and ' - ' not in raw and 'binary' in m.group(2)):
                cur.binary = True
        elif raw.startswith('--- ') or raw.startswith('+++ '):
            if cur is None or cur.hunks:
                start()
            # The ---/+++ names win over a `diff --git` line, which splits wrongly
            # when a path holds " b/". A p4 header's own names stay as they are.
            p = clean_path(raw[4:])
            if raw[0] == '-':
                if p is None: cur.status = 'added'
                elif from_git or cur.old is None: cur.old = p
            else:
                if p is None: cur.status = 'deleted'
                elif from_git or cur.new is None: cur.new = p
        elif raw.startswith('@@'):
            m = HUNK_RE.match(raw)
            if not m:
                continue
            if cur is None:
                start()
            a, b, c, d, ctx = m.groups()
            hunk = {'os': int(a), 'oc': int(b or 1), 'ns': int(c), 'nc': int(d or 1),
                    'ctx': ctx.strip().expandtabs(4), 'lines': []}
            orem, nrem = hunk['oc'], hunk['nc']
            cur.hunks.append(hunk)
        elif cur is not None:
            if raw.startswith('new file mode'): cur.status = 'added'
            elif raw.startswith('deleted file mode'): cur.status = 'deleted'
            elif raw.startswith('rename from '): cur.status, cur.old = 'renamed', raw[12:]
            elif raw.startswith('rename to '): cur.new = raw[10:]
            elif raw.startswith('Binary files') or raw.startswith('GIT binary patch'): cur.binary = True
    return [f for f in files if f.hunks or f.binary or f.status != 'modified']


# ---------------------------------------------------------------- Blueprints

def split_top(s, sep=','):
    """Split on sep outside quotes and parentheses. Inside quotes a backslash
    escapes the character after it, so \\" doesn't end the string."""
    out, depth, q, cur, i = [], 0, False, [], 0
    while i < len(s):
        ch = s[i]
        if q and ch == '\\' and i + 1 < len(s):
            cur.append(s[i:i + 2]); i += 2
            continue
        if ch == '"':
            q = not q
        elif not q and ch == '(':
            depth += 1
        elif not q and ch == ')':
            depth -= 1
        if ch == sep and not q and depth == 0:
            out.append(''.join(cur)); cur = []
        else:
            cur.append(ch)
        i += 1
    if cur:
        out.append(''.join(cur))
    return [x for x in out if x.strip()]


def kv(item):
    k, _, v = item.partition('=')
    return k.strip(), v.strip()


def unq(v):
    return re.sub(r'\\(["\\])', r'\1', v[1:-1]) if len(v) >= 2 and v[0] == v[-1] == '"' else v


def struct(v):
    """(A=1,B="x") -> {'A': '1', 'B': 'x'}"""
    v = v.strip()
    if v.startswith('(') and v.endswith(')'):
        v = v[1:-1]
    return {k: unq(x) for k, x in map(kv, split_top(v))}


def parse_t3d(text):
    """Return {relpath: obj}. relpath drops the package so revisions line up:
    '' is the root object, 'EventGraph.K2Node_CallFunction_0' a node."""
    objs, stack = {}, []
    for line in text.splitlines():
        s = line.strip()
        if s.startswith('Begin Object'):
            name = re.search(r'\bName="([^"]*)"', s)
            name = name.group(1) if name else '?'
            cls = re.search(r'\bClass=(\S+)', s)
            ep = re.search(r'\bExportPath="([^"]*)"', s)
            key = None
            if ep:
                inner = ep.group(1)
                if not cls and "'" in inner:
                    cls = re.match(r"([^']+)'", inner)
                path = inner.split("'")[1] if "'" in inner else inner
                key = path.split(':', 1)[1] if ':' in path else ''
            if key is None:
                key = '.'.join([o['name'] for o in stack[1:]] + [name]) if stack else ''
            o = objs.setdefault(key, {'name': name, 'cls': '', 'props': {}, 'pins': [],
                                      'parent': stack[-1]['key'] if stack else None, 'key': key})
            if cls:
                o['cls'] = cls.group(1).rsplit('.', 1)[-1]
            stack.append(o)
        elif s.startswith('End Object'):
            if stack:
                stack.pop()
        elif stack and s.startswith('CustomProperties Pin'):
            body = s[s.index('(') + 1:s.rindex(')')] if '(' in s else ''
            stack[-1]['pins'].append({k: v for k, v in map(kv, split_top(body))})
        elif stack and '=' in s and not s.startswith('CustomProperties'):
            k, v = kv(s)
            stack[-1]['props'][k] = v
    return objs


def short_ref(v):
    """/Script/CoreUObject.Class'/Script/Engine.Actor' -> Actor"""
    v = unq(v)
    m = re.match(r"^[\w/.]+'([^']*)'$", v)
    if m:
        v = m.group(1)
    if v.startswith('/') and ' ' not in v:
        v = re.split(r'[.:/]', v)[-1]
    return v


def short_val(v, limit=90):
    v = short_ref(v) if v else v
    return v if len(v) <= limit else v[:limit - 1] + '…'


def spaced(name):
    """OnComponentBeginOverlap -> On Component Begin Overlap, as the editor titles it."""
    return re.sub(r'(?<=[a-z0-9])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])', ' ', name)


def event_name(member, parent=''):
    """The editor's name for an overridden event. T3D saves the function
    (ReceiveBeginPlay), the editor shows its DisplayName (BeginPlay). Engine
    events mostly drop a Receive or K2_ prefix. Component events and End Play
    take spaces."""
    name = re.sub(r'^(?:Receive|K2_)(?=[A-Z])', '', member)
    if name == 'EndPlay' or (name != member and short_ref(parent).strip('"').endswith('Component')):
        name = spaced(name)
    return name


def node_title(o):
    c, p = o['cls'], o['props']
    ref = lambda k, f='MemberName': struct(p[k]).get(f, '') if k in p else ''
    if c == 'K2Node_ComponentBoundEvent':
        return (spaced(unq(p.get('DelegatePropertyName', ''))) or 'Component Event') + \
            f' ({unq(p.get("ComponentPropertyName", "?"))})'
    if c == 'K2Node_ActorBoundEvent':
        return (spaced(unq(p.get('DelegatePropertyName', ''))) or 'Actor Event') + \
            f' ({short_ref(p.get("EventOwner", "?")).rsplit(".", 1)[-1]})'
    if c == 'K2Node_InputAction':
        return 'InputAction ' + unq(p.get('InputActionName', '?'))
    if c == 'K2Node_InputAxisEvent':
        return 'InputAxis ' + unq(p.get('InputAxisName', '?'))
    if c in ('K2Node_InputKey', 'K2Node_InputAxisKeyEvent'):
        key = unq(p.get('InputKey', p.get('AxisKey', '?')))
        return spaced(struct(key).get('KeyName', key) if key.startswith('(') else key)
    if c in ('K2Node_CallFunction', 'K2Node_CallArrayFunction', 'K2Node_CallParentFunction',
             'K2Node_PromotableOperator', 'K2Node_CommutativeAssociativeBinaryOperator',
             'K2Node_CallMaterialParameterCollectionFunction', 'K2Node_Message'):
        return ref('FunctionReference') or c
    if c in ('K2Node_VariableGet', 'K2Node_VariableSet'):
        return ('Get ' if c.endswith('Get') else 'Set ') + ref('VariableReference')
    if c == 'K2Node_Event':
        member = ref('EventReference')
        return 'Event ' + (event_name(member, ref('EventReference', 'MemberParent')) if member
                           else unq(p.get('CustomFunctionName', '')))
    if c == 'K2Node_CustomEvent':
        return 'Custom Event ' + unq(p.get('CustomFunctionName', ''))
    if c in ('K2Node_FunctionEntry', 'K2Node_FunctionResult'):
        return 'Entry' if c.endswith('Entry') else 'Return'
    if c == 'K2Node_IfThenElse':
        return 'Branch'
    if c == 'K2Node_Knot':
        return 'Reroute'
    if c == 'K2Node_DynamicCast':
        return 'Cast To ' + short_ref(p.get('TargetType', '?'))
    if c == 'K2Node_MacroInstance' and 'MacroGraphReference' in p:
        return short_ref(struct(p['MacroGraphReference']).get('MacroGraph', 'Macro'))
    if c == 'EdGraphNode_Comment':
        return 'Comment "' + short_val(unq(p.get('NodeComment', '')), 40) + '"'
    if c in ('K2Node_SpawnActorFromClass', 'K2Node_ConstructObjectFromClass', 'K2Node_CreateWidget'):
        return c.replace('K2Node_', '')
    if 'InputAction' in p:
        return 'Input ' + short_ref(p['InputAction'])
    return re.sub(r'^(K2Node_|EdGraphNode_|AnimGraphNode_|MaterialGraphNode_)', '', c) or o['name']


NODE_NOISE = {'NodePosX', 'NodePosY', 'NodeWidth', 'NodeHeight', 'NodeGuid', 'ErrorType',
              'ErrorMsg', 'bHasCompilerMessage', 'bCommentBubblePinned', 'bCommentBubbleVisible',
              'AdvancedPinDisplay', 'bCommentBubbleMakeVisible'}
# A material expression's layout, identity and owner. material_model drops
# these itself, so a Blueprint node's own Material or Function property still diffs.
MATERIAL_NOISE = {'MaterialExpressionEditorX', 'MaterialExpressionEditorY', 'MaterialExpressionGuid',
                  'ExpressionGUID', 'Material', 'Function', 'SizeX', 'SizeY'}
KNOT_CLS = ('K2Node_Knot', 'MaterialExpressionReroute')
ROOT_SKIP = re.compile(r'^(NewVariables|UbergraphPages|FunctionGraphs|MacroGraphs|'
                       r'DelegateSignatureGraphs|IntermediateGeneratedGraphs|LastEditedDocuments|'
                       r'EventGraphs|CategorySorting|GeneratedClass|SkeletonGeneratedClass|'
                       r'ThumbnailInfo|BlueprintGuid|SimpleConstructionScript|InheritableComponentHandler|'
                       r'BlueprintSystemVersion|Status|bCachedDependenciesUpToDate|CachedDependencies|'
                       r'CachedUDSDependencies|CompileStatus|bLegacyGeneratedClassIsAuthoritative|'
                       r'BookmarkNodes|Bookmarks)\b')
CDO_SKIP = re.compile(r'^(UberGraphFrame|RootComponent|DefaultSceneRoot|BlueprintCreatedComponents)\b')


def pin_default(p):
    for k in ('DefaultValue', 'DefaultObject', 'DefaultTextValue'):
        if k in p and unq(p[k]) not in ('', 'None'):
            return unq(p[k])
    return ''


def set_to(v):
    """' = value' for a row that adds or removes something, '' when it had no value."""
    v = unq(v or '')
    return f' = {html.escape(short_val(v), quote=False)}' if v not in ('', 'None') else ''


def prop_list(props, limit=8):
    """': k = v; k = v' for an added or removed subobject, capped so one row stays readable."""
    E = lambda s: html.escape(s, quote=False)
    items = [f'<code>{E(k)}</code> = {E(short_val(v))}' for k, v in sorted(props.items()) if v not in ('', 'None')]
    more = f'; and {len(items) - limit} more' if len(items) > limit else ''
    return ': ' + '; '.join(items[:limit]) + more if items else ''


def graph_model(objs, gkey):
    nodes = {o['key']: o for o in objs.values() if o['parent'] == gkey}
    by_name = {o['name']: o for o in nodes.values()}
    model, edges = {}, set()
    for o in nodes.values():
        nid = o['props'].get('NodeGuid', o['name'])
        pins = {}
        for p in o['pins']:
            if p.get('bHidden') == 'True' and not p.get('LinkedTo'):
                continue
            pins[unq(p.get('PinName', '?'))] = p
        model[nid] = {'title': node_title(o), 'cls': o['cls'], 'props': o['props'], 'pins': pins,
                      'pos': (o['props'].get('NodePosX'), o['props'].get('NodePosY'))}
    for o in nodes.values():
        nid = o['props'].get('NodeGuid', o['name'])
        for p in o['pins']:
            if p.get('Direction') != '"EGPD_Output"' and p.get('Direction') != 'EGPD_Output':
                continue
            for link in split_top(p.get('LinkedTo', '()').strip('()')):
                parts = link.strip().rsplit(None, 1)  # a Control Rig node's name has spaces, a pin id never does
                if len(parts) != 2 or parts[0] not in by_name:
                    continue
                tgt = by_name[parts[0]]
                tpin = next((unq(q.get('PinName', '?')) for q in tgt['pins'] if q.get('PinId') == parts[1]), '?')
                edges.add((nid, unq(p.get('PinName', '?')), tgt['props'].get('NodeGuid', tgt['name']), tpin))
    return model, edges


def expr_ref(v):
    """"/Script/Engine.MaterialExpressionMultiply'M_X:MaterialExpressionMultiply_0'" -> MaterialExpressionMultiply_0"""
    v = unq(v)
    m = re.search(r"'([^']*)'$", v)
    return re.split(r'[:.]', m.group(1) if m else v)[-1]


def material_inputs(props):
    """{pin name: (source object name, output index)} for every property that
    names an expression: A=(Expression=...), or a function call's or custom
    node's FunctionInputs(0)=(Input=(Expression=...,InputName="UVs"))."""
    out = {}
    for k, v in props.items():
        if not v.startswith('('):
            continue
        s = struct(v)
        name = unq(s.get('InputName', ''))
        if 'Expression' not in s and s.get('Input', '').startswith('('):
            s = struct(s['Input'])
            name = name or unq(s.get('InputName', ''))
        if s.get('Expression') and s['Expression'] != 'None':
            out[name or k] = (expr_ref(s['Expression']), num(s.get('OutputIndex', '0')))
    return out


def expr_title(o):
    c, p = re.sub(r'^MaterialExpression', '', o['cls']), o['props']
    # Constant3Vector keeps its digit attached, as the material editor writes it.
    sp = lambda s: re.sub(r'(?<=[a-z])(?=[A-Z])|(?<=[A-Z])(?=[A-Z][a-z])', ' ', s)
    if 'ParameterName' in p:
        return f'{sp(c)} {unq(p["ParameterName"])}'
    if c == 'MaterialFunctionCall' and 'MaterialFunction' in p:
        return short_ref(p['MaterialFunction'])
    for k in ('InputName', 'OutputName'):
        if c.startswith('Function') and k in p:
            return f'{sp(c)} {unq(p[k])}'
    return sp(c) or o['name']


def material_model(objs):
    """A Material or Material Function as the same (model, edges) graph_model
    returns. Its saved form has no editor graph: every expression is a subobject
    with a GUID and an editor position, and each input names the expression it
    reads. The material's outputs (BaseColor and the rest) sit on its editor-only
    data, and draw as one Output node."""
    exprs = {o['name']: o for o in objs.values() if 'MaterialExpressionGuid' in o['props']}
    model, edges, wired_out = {}, set(), {}
    ids = {name: o['props']['MaterialExpressionGuid'] for name, o in exprs.items()}
    out_pin = lambda i: 'Out' if i == 0 else f'Out {i}'
    def add(nid, title, cls, pos, inputs, props):
        # Only wired inputs are saved, so a pin here is a wire, never a setting of its own.
        pins = {pn: {'PinName': pn, 'Direction': ''} for pn in inputs}
        model[nid] = {'title': title, 'cls': cls, 'props': props, 'pins': pins, 'pos': pos, 'wire_pins': True}
        for pn, (src, idx) in inputs.items():
            if src in ids:
                edges.add((ids[src], out_pin(idx), nid, pn))
                wired_out.setdefault(ids[src], set()).add(out_pin(idx))
    for name, o in exprs.items():
        p = o['props']
        # Inputs are wires, not settings. A constant typed into an input (ConstA) stays a setting.
        props = {k: v for k, v in p.items() if 'Expression=' not in v and k not in MATERIAL_NOISE}
        comment = o['cls'] == 'MaterialExpressionComment'
        cls = 'EdGraphNode_Comment' if comment else o['cls']
        title = f'Comment "{short_val(unq(p.get("Text", "")), 40)}"' if comment else expr_title(o)
        add(ids[name], title, cls, (p.get('MaterialExpressionEditorX', '0'), p.get('MaterialExpressionEditorY', '0')),
            material_inputs(p), props)
        if comment:
            model[ids[name]].update(size=(num(p.get('SizeX'), 400), num(p.get('SizeY'), 200)),
                                    note=unq(p.get('Text', '')))
    root = objs.get('', {'props': {}})
    for o in objs.values():  # the outputs: editor-only data in UE5, the material itself before that
        if o['name'] in exprs:
            continue
        ins = material_inputs(o['props'])
        if ins:
            add('MaterialOutput', 'Output', 'MaterialOutput',
                (root['props'].get('EditorX', '0'), root['props'].get('EditorY', '0')), ins, {})
            break
    for nid, outs in wired_out.items():
        for pn in sorted(outs | {'Out'}):
            model[nid]['pins'].setdefault(pn, {'PinName': pn, 'Direction': 'EGPD_Output'})
    for nid, n in model.items():
        if n['cls'] not in ('EdGraphNode_Comment', 'MaterialOutput'):
            n['pins'].setdefault('Out', {'PinName': 'Out', 'Direction': 'EGPD_Output'})
    return model, edges


def label(model_a, model_b, nid):
    n = model_b.get(nid) or model_a.get(nid)
    return n['title'] if n else nid[:8]


def is_knot(n):
    return bool(n) and n['cls'] in KNOT_CLS


def logical_edges(model, edges):
    """Wires as the graph means them. A chain through reroute nodes becomes one
    wire from its real source pin to its real target pin, so rerouting a wire
    doesn't read as a new connection. Returns {wire: the physical edges on its path}.
    A chain that ends on a reroute with nothing after it connects nothing. A
    loop among reroutes counts all its edges as part of the route, which keeps
    this linear where listing each simple path would be exponential."""
    outs = {}
    for e in edges:
        outs.setdefault(e[0], []).append(e)
    found = {}
    for e in edges:
        if is_knot(model.get(e[0])):
            continue
        # Every physical edge reachable from e through reroutes, visited once,
        # so a diamond of reroutes costs its size, not its number of paths.
        reach, ends, todo = {e}, [], [e]
        while todo:
            cur = todo.pop()
            if is_knot(model.get(cur[2])):
                for nxt in outs.get(cur[2], ()):
                    if nxt not in reach:
                        reach.add(nxt)
                        todo.append(nxt)
            else:
                ends.append(cur)
        into = {}
        for x in reach:
            into.setdefault(x[2], []).append(x)
        for end in ends:
            # The edges on some path to this end: walk back from it inside reach.
            path, back = {end}, [end]
            while back:
                cur = back.pop()
                for prev in into.get(cur[0], ()) if is_knot(model.get(cur[0])) else ():
                    if prev not in path:
                        path.add(prev)
                        back.append(prev)
            found.setdefault((e[0], e[1], end[2], end[3]), set()).update(path)
    return found


def signature(n):
    """What a node is, apart from where it sits and which object it is."""
    return (n['cls'], n['title'], tuple(sorted((k, v) for k, v in n['props'].items() if k not in NODE_NOISE)),
            tuple(sorted((pn, pin_default(p)) for pn, p in n['pins'].items())))


def pair_recreated(ma, ea, mb, eb):
    """{new id: old id} for nodes removed and added with the same settings. A cut
    and paste, or a delete and re-add, gives a node a new NodeGuid, which
    would otherwise show as a removed node, an added one and every wire twice.
    A pair needs the same signature and either a wire to the same pin of a node
    both sides share, or to be the only removed and the only added node with
    that signature. Pairing repeats, so a pasted chain pairs out from its
    reconnected ends."""
    gone = [n for n in ma if n not in mb and not is_knot(ma[n])]
    new = [n for n in mb if n not in ma and not is_knot(mb[n])]
    if not gone or not new:
        return {}
    groups = {}
    for g in gone:
        groups.setdefault(signature(ma[g]), ([], []))[0].append(g)
    for n in new:
        groups.setdefault(signature(mb[n]), ([], []))[1].append(n)
    groups = [v for v in groups.values() if v[0] and v[1]]
    if not groups:
        return {}

    def neighbours(model, edges):
        out = {}
        for s, sp, t, tp in logical_edges(model, edges):
            out.setdefault(s, set()).add((t, sp, tp, 'out'))
            out.setdefault(t, set()).add((s, tp, sp, 'in'))
        return out
    na, nb = neighbours(ma, ea), neighbours(mb, eb)
    pos = lambda n: (num(n['pos'][0]), num(n['pos'][1]))
    dist = lambda a, b: (pos(a)[0] - pos(b)[0]) ** 2 + (pos(a)[1] - pos(b)[1]) ** 2
    mapping, kept = {}, ma.keys() & mb.keys()
    while True:
        taken, known = set(mapping.values()), kept | set(mapping.values())
        cands = []
        for gs, ns in groups:
            gs_ = [g for g in gs if g not in taken]
            ns_ = [n for n in ns if n not in mapping]
            unique = len(gs_) == 1 and len(ns_) == 1
            for g in gs_:
                for n in ns_:
                    theirs = {(mapping.get(o, o), a, b, d) for o, a, b, d in nb.get(n, ())}
                    shared = sum(1 for x in na.get(g, ()) if x in theirs and x[0] in known)
                    if shared or unique:
                        cands.append((-shared, dist(ma[g], mb[n]), g, n))
        before = len(mapping)
        for _, _, g, n in sorted(cands):
            if g not in taken and n not in mapping:
                mapping[n] = g
                taken.add(g)
        if len(mapping) == before:
            return mapping


def remap(model, edges, mapping):
    m = lambda i: mapping.get(i, i)
    return {m(k): v for k, v in model.items()}, {(m(s), sp, m(t), tp) for s, sp, t, tp in edges}


def classify(ma, mb, ea, eb):
    """How each physical wire and node changed, judged by logical connections.
    A physical wire on the new side is '' (it was there before), 'add' (it
    carries a new connection) or 'path' (a new route for a connection that
    already existed). On the old side it is '', 'del' or 'path' the same way."""
    la, lb = logical_edges(ma, ea), logical_edges(mb, eb)
    added, removed = lb.keys() - la.keys(), la.keys() - lb.keys()
    p_add = set().union(*(lb[w] for w in added))
    p_del = set().union(*(la[w] for w in removed))
    # A physical wire that also carries a kept connection is a route, not new:
    # on a reroute trunk shared by an old and a new connection, only the new
    # branch draws as added.
    keep_b = set().union(*(lb[w] for w in lb.keys() & la.keys()))
    keep_a = set().union(*(la[w] for w in la.keys() & lb.keys()))
    new_st = {e: '' if e in ea else 'add' if e in p_add and e not in keep_b else 'path' for e in eb}
    old_st = {e: '' if e in eb else 'del' if e in p_del and e not in keep_a else 'path' for e in ea}
    moved = {nid for nid in ma.keys() & mb.keys() if ma[nid]['pos'] != mb[nid]['pos']}
    rerouted = set()
    for w in la.keys() & lb.keys():
        knots = {e[2] for e in lb[w]} - {w[2]}
        if la[w] != lb[w] or knots & moved:
            rerouted.add(w)
    touching = lambda nid, st: {s for e, s in st.items() if nid in (e[0], e[2])}
    knot_new, knot_old = {}, {}
    # A new reroute is added only if all it carries is new. A removed one is a
    # ghost if it carried any lost connection, so that red wire has an end to draw from.
    for nid, n in mb.items():
        if is_knot(n):
            knot_new[nid] = ('add' if touching(nid, new_st) == {'add'} else 'path') if nid not in ma else \
                'mv' if nid in moved else ''
    for nid, n in ma.items():
        if is_knot(n):
            knot_old[nid] = ('del' if 'del' in touching(nid, old_st) else 'path') if nid not in mb else \
                'mv' if nid in moved else ''
    return {'added': added, 'removed': removed, 'new': new_st, 'old': old_st, 'moved': moved,
            'rerouted': rerouted, 'knot_new': knot_new, 'knot_old': knot_old}


def diff_graph(oa, ob, ga, gb):
    """(rows, svg) for one graph. Rows are (kind, html), kind add, del, mod or info.
    svg is a drawing of the graph with the changes marked, or '' when it has no nodes."""
    return diff_models(graph_model(oa, ga) if ga is not None else ({}, set()),
                       graph_model(ob, gb) if gb is not None else ({}, set()))


def diff_models(old, new):
    """diff_graph for any two (model, edges) pairs, whichever reader built them.
    Nodes match by id, then a node re-created with a new id pairs with the one
    it replaced. Wires compare as logical connections, with reroute chains
    collapsed, so a node that moved or a wire that took a new route is a
    layout change, not a new connection."""
    ma, ea = old
    mb, eb = new
    mapping = pair_recreated(ma, ea, mb, eb)
    if mapping:
        mb, eb = remap(mb, eb, mapping)
    recreated = set(mapping.values())
    kc = classify(ma, mb, ea, eb)
    rows, moved, changed = [], 0, {}
    E = lambda s: html.escape(s, quote=False)
    def values(n):  # an added or removed node says what its pins were set to
        if n.get('wire_pins'):  # a material expression keeps its settings in properties
            return prop_list({k: v for k, v in n['props'].items() if k not in NODE_NOISE and k != 'ParameterName'})
        vals = [f'<code>{E(pn)}</code> = {E(short_val(pin_default(p)))}'
                for pn, p in sorted(n['pins'].items()) if pin_default(p)]
        return ': ' + '; '.join(vals) if vals else ''
    for nid in mb.keys() - ma.keys():
        if not is_knot(mb[nid]):  # a reroute carries no meaning of its own, its wires say it
            rows.append(('add', f'Node <b>{E(mb[nid]["title"])}</b>{values(mb[nid])}'))
    for nid in ma.keys() - mb.keys():
        if not is_knot(ma[nid]):
            rows.append(('del', f'Node <b>{E(ma[nid]["title"])}</b>{values(ma[nid])}'))
    for nid in ma.keys() & mb.keys():
        a, b = ma[nid], mb[nid]
        changes, pins_changed = [], set()
        for k in sorted((a['props'].keys() | b['props'].keys()) - NODE_NOISE):
            va, vb = a['props'].get(k, ''), b['props'].get(k, '')
            if va != vb:
                changes.append(f'{E(k)}: <s>{E(short_val(va)) or "∅"}</s> → {E(short_val(vb)) or "∅"}')
        for pn in sorted(a['pins'].keys() | b['pins'].keys()):
            pa, pb = a['pins'].get(pn), b['pins'].get(pn)
            if a.get('wire_pins') and (pa is None or pb is None):
                continue  # the wire rows already say it
            if pa is None or pb is None or pin_default(pa) != pin_default(pb):
                pins_changed.add(pn)
            if pa is None:
                changes.append(f'pin <code>{E(pn)}</code> added' + set_to(pin_default(pb)))
            elif pb is None:
                changes.append(f'pin <code>{E(pn)}</code> removed' + set_to(pin_default(pa)))
            elif pin_default(pa) != pin_default(pb):
                changes.append(f'<code>{E(pn)}</code>: <s>{E(short_val(pin_default(pa))) or "∅"}</s>'
                               f' → {E(short_val(pin_default(pb))) or "∅"}')
        if changes:
            rows.append(('mod', f'Node <b>{E(b["title"])}</b>: ' + '; '.join(changes)))
            changed[nid] = (unescape(re.sub(r'<[^>]+>', '', '; '.join(changes))), pins_changed)
        elif a['pos'] != b['pos'] and not is_knot(a) and nid not in recreated:
            moved += 1
    fmt = lambda e, ma_, mb_: (f'<b>{E(label(ma_, mb_, e[0]))}</b>.<code>{E(e[1])}</code> → '
                               f'<b>{E(label(ma_, mb_, e[2]))}</b>.<code>{E(e[3])}</code>')
    for e in sorted(kc['added']):
        rows.append(('add', 'Wire ' + fmt(e, ma, mb)))
    for e in sorted(kc['removed']):  # a removed wire names its nodes as they were, a renamed event included
        rows.append(('del', 'Wire ' + fmt(e, mb, ma)))
    plural = lambda n, word: f'{n} {word}{"s" if n != 1 else ""}'
    if moved:
        rows.append(('info', f'{plural(moved, "node")} moved (layout only)'))
    if recreated:
        rows.append(('info', f'{plural(len(recreated), "node")} re-created with a new ID and the same settings '
                             '(a cut and paste), compared as the node it replaced'))
    if kc['rerouted']:
        rows.append(('info', f'{plural(len(kc["rerouted"]), "wire")} rerouted, same connections (layout only)'))
    order = {'del': 0, 'mod': 1, 'add': 2, 'info': 3}
    return sorted(rows, key=lambda r: order[r[0]]), graph_svg(ma, mb, ea, eb, changed, recreated)


# ---------------------------------------------------------------- graph drawing
# A simplified Blueprint editor view: nodes at their saved positions, pins
# colored by type, wires as curves. T3D saves no size for most nodes, so boxes
# are sized from the title and pin labels. Close to the editor, not exact.

PIN_COLORS = {'exec': 'var(--ink)', 'bool': '#c4262e', 'byte': '#18a090', 'enum': '#18a090',
              'int': '#1fe3af', 'int64': '#acd7c0', 'real': '#9ef04a', 'float': '#9ef04a',
              'double': '#9ef04a', 'string': '#f04ad0', 'name': '#c88cff', 'text': '#e67fb3',
              'object': '#00a8f4', 'softobject': '#7fd6ff', 'class': '#9b5cf0', 'softclass': '#c8a2ff',
              'interface': '#d8f0a0', 'delegate': '#ff5050', 'mcdelegate': '#ff5050', 'struct': '#3a7bd5'}
STRUCT_COLORS = {'Vector': '#f5c400', 'Rotator': '#a0b4ff', 'Transform': '#ff8a2a'}
EVENT_CLS = ('K2Node_Event', 'K2Node_CustomEvent', 'K2Node_ComponentBoundEvent', 'K2Node_ActorBoundEvent',
             'K2Node_InputAction', 'K2Node_InputKey', 'K2Node_EnhancedInputAction')
# Close to the editor's own metrics at 1:1 zoom: a 30-unit title bar, 24-unit
# pin rows. Widths are estimated from text, since T3D saves no node size.
G_HEAD, G_ROW, G_KNOT = 30, 24, 12
TITLE_CH, LABEL_CH = 7.6, 6.6
GRID_IDS = itertools.count()


def pin_info(p):
    """(category, color, is_output, is_linked) for one raw pin."""
    cat = unq(p.get('PinType.PinCategory', ''))
    sub = short_ref(p.get('PinType.PinSubCategoryObject', '')) if cat == 'struct' else ''
    color = STRUCT_COLORS.get(sub) or PIN_COLORS.get(cat, 'var(--muted)')
    return cat, color, 'Output' in p.get('Direction', ''), bool(p.get('LinkedTo', '()').strip('()'))


def head_color(n):
    c = n['cls']
    if c in EVENT_CLS:
        return '#9a2a2a'
    if c in ('K2Node_FunctionEntry', 'K2Node_FunctionResult'):
        return '#6a3d9a'
    if c == 'K2Node_DynamicCast':
        return '#22766e'
    if c.startswith('K2Node_Variable'):
        return '#3d4a57'
    if c.startswith('K2Node_Call') or c in ('K2Node_Message', 'K2Node_PromotableOperator',
                                             'K2Node_CommutativeAssociativeBinaryOperator'):
        impure = any(pin_info(p)[0] == 'exec' for p in n['pins'].values())
        return '#2c5d9c' if impure else '#3f7a3a'
    return '#4b5058'


def num(v, default=0):
    try:
        return int(float(unq(v)))
    except (TypeError, ValueError):
        return default


def node_box(n, wired=()):
    """Geometry for one node: x, y, w, h, kind, pin rows and pin anchors by name.
    wired names the pins a drawn wire touches, so they draw filled even when
    only the other end of the link carries LinkedTo."""
    x, y = num(n['pos'][0]), num(n['pos'][1])
    box = {'x': x, 'y': y, 'kind': 'node', 'ins': [], 'outs': [], 'anchors': {}, 'title': n['title']}
    if 'from' in n:  # a moved node remembers where it was, for its hover trail
        box['from'] = (num(n['from'][0]), num(n['from'][1]))
    if is_knot(n):
        # A reroute is a small dot that both wires meet at its center.
        box.update(kind='knot', w=G_KNOT, h=G_KNOT)
        for pn in n['pins']:
            box['anchors'][pn] = (x + G_KNOT // 2, y + G_KNOT // 2)
        return box
    if n['cls'] == 'EdGraphNode_Comment':
        w, h = n.get('size') or (num(n['props'].get('NodeWidth'), 400), num(n['props'].get('NodeHeight'), 200))
        box.update(kind='comment', w=w, h=h,
                   title=short_val(unq(n['props'].get('NodeComment', n.get('note', ''))), 60))
        return box
    gone = n.get('gone', ())
    for pn, p in n['pins'].items():
        cat, color, out, linked = pin_info(p)
        linked = linked or pn in wired
        lab = '' if cat == 'exec' and pn in ('execute', 'then', 'exec') and pn not in gone else \
            'Return Value' if pn == 'ReturnValue' else 'Target' if pn == 'self' else pn
        dv = '' if linked or out or pn in gone else short_val(pin_default(p), 14)
        box['outs' if out else 'ins'].append((pn, lab, dv, color, cat, linked, pn in gone))
    width = lambda side: max([len(r[1]) + (len(r[2]) + 1 if r[2] else 0) for r in side] or [0])
    w = max(len(box['title']) * TITLE_CH + 32, (width(box['ins']) + width(box['outs'])) * LABEL_CH + 60, 120)
    box['w'] = int(min(w, 380))
    box['h'] = G_HEAD + max(len(box['ins']), len(box['outs'])) * G_ROW + 8
    for i, r in enumerate(box['ins']):
        box['anchors'][r[0]] = (x, y + G_HEAD + G_ROW * i + G_ROW // 2)
    for i, r in enumerate(box['outs']):
        box['anchors'][r[0]] = (x + box['w'], y + G_HEAD + G_ROW * i + G_ROW // 2)
    return box


def svg_node(b, state, tip, pins_changed):
    A = lambda s: html.escape(str(s), quote=True)
    x, y, w, h = b['x'], b['y'], b['w'], b['h']
    cls = f'n {state}'.strip()
    out = [f'<g class="{cls}"><title>{A(tip)}</title>']
    if 'from' in b and b['kind'] != 'knot':
        # Hidden until hover: the outline where the node was, and a line to where it is.
        ox, oy = b['from']
        out.append(f'<g class="tr"><rect x="{ox}" y="{oy}" width="{w}" height="{h}" rx="6"/>'
                   f'<path d="M{ox + w // 2} {oy + h // 2}L{x + w // 2} {y + h // 2}"/></g>')
    if b['kind'] == 'comment':
        out.append(f'<rect class="cm" x="{x}" y="{y}" width="{w}" height="{h}" rx="4"/>'
                   f'<text class="ct" x="{x + 8}" y="{y + 16}">{A(b["title"])}</text></g>')
        return ''.join(out)
    if b['kind'] == 'knot':
        r = w // 2
        out.append(f'<circle class="kn" cx="{x + r}" cy="{y + r}" r="{r - 1}" '
                   f'style="fill:{b.get("color", "var(--muted)")}"/></g>')
        return ''.join(out)
    hc = b['hc']
    chars = max(4, int((w - 24) / TITLE_CH))
    title = b['title'] if len(b['title']) <= chars else b['title'][:chars - 1] + '…'
    out.append(f'<rect class="nb" x="{x}" y="{y}" width="{w}" height="{h}" rx="6"/>'
               f'<path d="M{x} {y + G_HEAD}V{y + 6}q0 -6 6 -6H{x + w - 6}q6 0 6 6V{y + G_HEAD}Z" fill="{hc}"/>'
               f'<text class="nt" x="{x + 10}" y="{y + 20}">{A(title)}</text>')
    for side, rows in (('in', b['ins']), ('out', b['outs'])):
        for i, (pn, lab, dv, color, cat, linked, gone) in enumerate(rows):
            px = x if side == 'in' else x + w
            py = y + G_HEAD + G_ROW * i + G_ROW // 2
            fill = color if linked else 'none'
            pc = (' on' if linked else '') + (' gone' if gone else '')
            if cat == 'exec':
                tx = px + (10 if side == 'in' else -10)
                out.append(f'<path class="pin{pc}" d="M{tx - 5} {py - 6}H{tx}L{tx + 5} {py}L{tx} {py + 6}H{tx - 5}Z" '
                           f'fill="{fill}" stroke="{color}" stroke-width="1.5"/>')
            else:
                cx = px + (10 if side == 'in' else -10)
                out.append(f'<circle class="pin{pc}" cx="{cx}" cy="{py}" r="5" fill="{fill}" stroke="{color}" '
                           f'stroke-width="1.5"/>')
            if not lab and not dv:
                continue
            chg = ' chg' if pn in pins_changed else ''
            tc = ' class="gone"' if gone else ''
            if side == 'in':
                dv_html = f'<tspan class="dv{chg}"> {A(dv)}</tspan>' if dv else ''
                out.append(f'<text{tc} x="{x + 20}" y="{py + 4}">{A(lab)}{dv_html}</text>')
            else:
                out.append(f'<text{tc} x="{x + w - 20}" y="{py + 4}" text-anchor="end">{A(lab)}</text>')
    out.append('</g>')
    return ''.join(out)


def draw_layer(name, items, wires, models, spare=None):
    """One view of a graph. items are (nid, node, state, tip, changed pins), wires
    are (edge, state). models resolve a wire's source pin for its color. spare
    holds boxes from the other revision, for a pin a ghost wire still names."""
    wired = {}
    for e, _ in wires:
        wired.setdefault(e[0], set()).add(e[1])
        wired.setdefault(e[2], set()).add(e[3])
    boxes, meta = {}, {}
    for nid, n, state, tip, pins in items:
        b = node_box(n, wired.get(nid, ()))
        b['hc'] = head_color(n)
        boxes[nid], meta[nid] = b, (state, tip, pins)

    def anchor(nid, pin, side):
        for src in (boxes.get(nid), (spare or {}).get(nid)):
            if src and pin in src['anchors']:
                return src['anchors'][pin]
        b = boxes[nid]
        return (b['x'] + (b['w'] if side == 'out' else 0), b['y'] + G_HEAD // 2)
    paths = []
    for e, state in sorted(wires, key=lambda t: (t[1] != 'del', t[0])):
        if e[0] not in boxes or e[2] not in boxes:
            continue
        src = next((m[e[0]]['pins'][e[1]] for m in models if e[1] in m.get(e[0], {}).get('pins', {})), None)
        cat, color = pin_info(src)[:2] if src else ('', 'var(--muted)')
        (x1, y1), (x2, y2) = anchor(e[0], e[1], 'out'), anchor(e[2], e[3], 'in')
        dx = max(40, abs(x2 - x1) // 2)
        cls = ' '.join(c for c in ('w', 'x' if cat == 'exec' else '', state) if c)
        paths.append(f'<path class="{cls}" stroke="{color}" d="M{x1} {y1}C{x1 + dx} {y1} {x2 - dx} {y2} {x2} {y2}"/>')
        for k in (e[0], e[2]):
            if boxes[k]['kind'] == 'knot' and cat != 'wildcard':
                boxes[k].setdefault('color', color)
    order = sorted(boxes, key=lambda i: (boxes[i]['kind'] != 'comment', meta[i][0] != 'del'))
    nodes = [svg_node(boxes[i], *meta[i]) for i in order]
    comments = [s for i, s in zip(order, nodes) if boxes[i]['kind'] == 'comment']
    rest = [s for i, s in zip(order, nodes) if boxes[i]['kind'] != 'comment']
    svg = f'<g class="L L-{name}">' + ''.join(comments + paths + rest) + '</g>'
    return boxes, svg


def graph_svg(ma, mb, ea, eb, changed, recreated=()):
    """Inline SVG of one graph in three switchable views: Changes (the new layout
    with removed nodes and wires as ghosts beside their old neighbors), Before (the old
    graph at its old layout) and After (the new graph alone). Big graphs open
    on the changed area. A moved node draws with a dotted outline and shows where
    it was on hover. A wire that only took a new route draws dotted, and only a
    wire that carries a new or lost connection draws as added or removed."""
    if not ma and not mb:
        return ''
    kc = classify(ma, mb, ea, eb)
    TIPS = {'add': ' (added)', 'del': ' (removed)', 'mv': ' (moved, layout only)', 'path': ' (route only)'}
    tip = lambda n, nid, st: n['title'] + TIPS.get(st, '') + \
        (' (re-created with a new ID)' if nid in recreated else '') + \
        (': ' + changed[nid][0] if nid in changed else '')
    pins = lambda nid: changed.get(nid, ('', set()))[1]

    def st_new(nid):
        if is_knot(mb[nid]):
            return kc['knot_new'][nid]
        return 'add' if nid not in ma else 'mod' if nid in changed else 'mv' if nid in kc['moved'] else ''

    def st_old(nid):
        if is_knot(ma[nid]):
            return kc['knot_old'][nid]
        return 'del' if nid not in mb else 'mod' if nid in changed else 'mv' if nid in kc['moved'] else ''
    trail = lambda nid, n: {**n, 'from': ma[nid]['pos']} if nid in kc['moved'] and nid not in changed else n
    after_items = [(nid, n, st_new(nid), tip(n, nid, st_new(nid)), pins(nid)) for nid, n in mb.items()]
    before_items = [(nid, n, st_old(nid), tip(n, nid, st_old(nid)), pins(nid)) for nid, n in ma.items()]
    # Changes shows the new wires, and of the old ones only those that carried a
    # lost connection. An old route for a connection that still exists is gone.
    wires_all = list(kc['new'].items()) + [(e, s) for e, s in kc['old'].items() if s == 'del']
    # Changes draws the new layout, so a removed node can't keep its old
    # coordinates: when the kept nodes around it moved, it would land far from
    # them with its dashed wires stretched across the graph. Each ghost moves
    # with the wired neighbor that moved least (a node that moved far usually
    # went to a new job, and an average lands between the two), else with the
    # nearest kept node.
    pos = lambda n: (num(n['pos'][0]), num(n['pos'][1]))
    shift = {nid: (pos(mb[nid])[0] - pos(n)[0], pos(mb[nid])[1] - pos(n)[1]) for nid, n in ma.items() if nid in mb}
    gone = [nid for nid in ma if nid not in mb]
    near = {nid: set() for nid in gone}
    for e in ea:
        if e[0] in near:
            near[e[0]].add(e[2])
        if e[2] in near:
            near[e[2]].add(e[0])
    for _ in range(len(gone) + 1):
        todo = [g for g in gone if g not in shift]
        if not todo:
            break
        for g in todo:
            ds = [shift[k] for k in near[g] if k in shift]
            if ds:
                shift[g] = min(ds, key=lambda d: d[0] ** 2 + d[1] ** 2)
    kept = [k for k in ma if k in mb]
    for g in gone:
        if g not in shift:
            gx, gy = pos(ma[g])
            k = min(kept, key=lambda k: (pos(ma[k])[0] - gx) ** 2 + (pos(ma[k])[1] - gy) ** 2, default=None)
            shift[g] = shift[k] if k else (0, 0)
    moved = lambda n, d: {**n, 'pos': (str(pos(n)[0] + d[0]), str(pos(n)[1] + d[1]))}
    # A ghost often lands where its replacement now sits. Step it up or down
    # to the nearest spot clear of live nodes and other ghosts.
    taken = [node_box(n) for n in mb.values() if n['cls'] != 'EdGraphNode_Comment']
    hit = lambda a, b: a['x'] < b['x'] + b['w'] and b['x'] < a['x'] + a['w'] and \
        a['y'] < b['y'] + b['h'] and b['y'] < a['y'] + a['h']
    for g in gone:
        if ma[g]['cls'] == 'EdGraphNode_Comment':
            continue
        base = shift[g]
        for k in range(13):
            dy = (k + 1) // 2 * 32 * (1 if k % 2 else -1)
            b = node_box(moved(ma[g], (base[0], base[1] + dy)))
            if not any(hit(b, t) for t in taken):
                shift[g] = (base[0], base[1] + dy)
                taken.append(b)
                break
    ghosts = [(nid, moved(n, shift[nid]), st, t, p) for nid, n, st, t, p in before_items if st == 'del']
    # A kept node that lost a pin still shows it in Changes, struck through,
    # so a removed wire from that pin starts somewhere visible.
    def with_lost(nid, n):
        lost = {pn: p for pn, p in ma.get(nid, {}).get('pins', {}).items() if pn not in n['pins']}
        return {**n, 'pins': {**n['pins'], **lost}, 'gone': set(lost)} if lost else n
    change_items = [(nid, with_lost(nid, trail(nid, n)), *rest) for nid, n, *rest in after_items]
    spare = {nid: node_box(moved(n, shift.get(nid, (0, 0)))) for nid, n in ma.items()}
    layers = [draw_layer('changes', change_items + ghosts, wires_all, (mb, ma), spare)]
    both = bool(ma) and bool(mb)
    if both:
        layers.append(draw_layer('before', before_items, list(kc['old'].items()), (ma,)))
        layers.append(draw_layer('after', after_items, list(kc['new'].items()), (mb,)))
    boxes = {}
    for bx, _ in layers:
        for nid, b in bx.items():
            boxes[f'{len(boxes)}'] = b
    # Open on what changed in meaning. Moves and new routes count only when
    # nothing else changed.
    state = lambda nid: st_new(nid) if nid in mb else 'del'
    real = lambda st: st in ('add', 'del', 'mod')
    focus_boxes = [b for nid, b in layers[0][0].items()
                   if real(state(nid)) or any(nid in (e[0], e[2]) for e, s in wires_all if real(s))] or \
        [b for nid, b in layers[0][0].items() if state(nid) or any(nid in (e[0], e[2]) for e, s in wires_all if s)]

    def bbox(bs, pad):
        return (min(b['x'] for b in bs) - pad, min(b['y'] for b in bs) - pad,
                max(b['x'] + b['w'] for b in bs) + pad, max(b['y'] + b['h'] for b in bs) + pad)
    if not boxes:  # e.g. a deleted graph that held only reroutes, which draw as nothing
        return ''
    x0, y0, x1, y1 = bbox(list(boxes.values()), 40)
    full = f'{x0} {y0} {x1 - x0} {y1 - y0}'
    fb = (x0, y0, x1, y1)
    note = ''
    count = len(layers[0][0])
    if (x1 - x0 > 2600 or y1 - y0 > 1600) and focus_boxes:
        x0, y0, x1, y1 = bbox(focus_boxes, 240)
        shown = sum(1 for b in layers[0][0].values()
                    if b['x'] < x1 and b['x'] + b['w'] > x0 and b['y'] < y1 and b['y'] + b['h'] > y0)
        note = (f'<p class="bpg-note">Starts on the changed area, {shown} of {count} nodes. '
                f'Drag or zoom out, or press All, to see the rest.</p>')
    w, h = x1 - x0, y1 - y0
    scale = max(0.6, min(1.0, 1100 / w))
    # Editor-style grid in graph units, so it pans and zooms with the nodes:
    # a faint line every 16 units, a stronger one every 128. Sized far past the
    # graph so a drag or a full zoom-out never runs off its edge.
    gid = f'bpg{next(GRID_IDS)}'
    span = max(fb[2] - fb[0], fb[3] - fb[1], w, h) * 6
    gx, gy = (fb[0] + fb[2]) / 2 - span / 2, (fb[1] + fb[3]) / 2 - span / 2
    body = [f'<defs><pattern id="{gid}m" width="16" height="16" patternUnits="userSpaceOnUse">'
            f'<path class="g1" d="M16 0H0V16" vector-effect="non-scaling-stroke"/></pattern>'
            f'<pattern id="{gid}" width="128" height="128" patternUnits="userSpaceOnUse">'
            f'<rect width="128" height="128" fill="url(#{gid}m)"/>'
            f'<path class="g2" d="M128 0H0V128" vector-effect="non-scaling-stroke"/></pattern></defs>'
            f'<rect class="grid" x="{gx:.0f}" y="{gy:.0f}" width="{span:.0f}" height="{span:.0f}" fill="url(#{gid})"/>']
    body += [svg for _, svg in layers]
    has_mv = any(st_new(nid) == 'mv' for nid in mb)
    has_path = any(s == 'path' for s in kc['new'].values())
    legend = ('<p class="bpg-key"><span class="k-add">added</span><span class="k-del">removed</span>'
              '<span class="k-mod">changed</span>'
              + ('<span class="k-mv">moved, layout only</span>' if has_mv else '')
              + ('<span class="k-path">new route, same connection</span>' if has_path else '')
              + ' Drag to pan, scroll to zoom, double-click to reset. Hover a node for its changes'
              + (', or a moved node for where it was' if has_mv else '') + '.</p>')
    views = ('<span class="bpg-views" role="group" aria-label="Graph view">'
             '<button type="button" data-l="changes" aria-pressed="true" title="New layout, removed parts as ghosts">Changes</button>'
             '<button type="button" data-l="before" aria-pressed="false" title="The old graph at its old layout">Before</button>'
             '<button type="button" data-l="after" aria-pressed="false" title="The new graph alone">After</button></span>'
             if both else '')
    tools = (f'<div class="bpg-tools">{views}<button type="button" data-z="in" title="Zoom in">+</button>'
             '<button type="button" data-z="out" title="Zoom out">−</button>'
             '<button type="button" data-z="fit" title="Back to the starting view">Fit</button>'
             '<button type="button" data-z="all" title="Show the whole graph">All</button></div>')
    return (f'<div class="bpg" data-l="changes">{tools}<svg viewBox="{x0} {y0} {w} {h}" data-full="{full}" width="100%" '
            f'height="{min(560, max(160, int(h * scale)))}" role="img" aria-label="Graph drawing">'
            f'{"".join(body)}</svg></div>' + note + legend)


def variables(objs):
    out = {}
    for k, v in (objs.get('', {}).get('props') or {}).items():
        if k.startswith('NewVariables('):
            s = struct(v)
            out[s.get('VarGuid', s.get('VarName'))] = s
    return out


def var_type(s):
    t = struct(s.get('VarType', '()'))
    base = t.get('PinSubCategoryObject') and short_ref(t['PinSubCategoryObject']) or \
        t.get('PinSubCategory') or t.get('PinCategory', '?')
    cont = t.get('ContainerType')
    return f'{cont}<{base}>' if cont and cont != 'None' else base


def prop_rows(pa, pb, skip):
    rows = []
    E = lambda s: html.escape(s, quote=False)
    for k in sorted(pa.keys() | pb.keys()):
        if skip.match(k):
            continue
        va, vb = pa.get(k), pb.get(k)
        if va == vb:
            continue
        if va is None:
            rows.append(('add', f'<code>{E(k)}</code> = {E(short_val(vb))}'))
        elif vb is None:
            rows.append(('del', f'<code>{E(k)}</code> = {E(short_val(va))}'))
        else:
            rows.append(('mod', f'<code>{E(k)}</code>: <s>{E(short_val(va))}</s> → {E(short_val(vb))}'))
    return rows


def graph_parents(objs):
    """Keys of the objects that hold nodes (children with a NodeGuid)."""
    return {o['parent'] for o in objs.values() if 'NodeGuid' in o['props']}


def is_graph(o, parents=()):
    """A graph holds nodes, or is an empty one whose class says graph. The
    first test needs no class name, so a plugin's graph class reads as a graph
    whatever it's called."""
    return o['key'] in parents or (o['cls'].endswith('Graph') and o['cls'] not in ('BlueprintGeneratedClass',))


def authored_graphs(meta, objs):
    """{key: graph object} for the graphs a person made, compiler output left out."""
    authored = set(meta.get('graphs') or [])
    parents, out = graph_parents(objs), {}
    for k, o in objs.items():
        if not is_graph(o, parents):
            continue
        top = o if o['parent'] == '' else None
        if top is not None and authored and o['name'] not in authored:
            continue
        if re.search(r'(_MERGED$|^ExecuteUbergraph_)', o['name']):
            continue
        if top is None:  # a nested graph (collapsed node, state machine): keep if its root graph is kept
            root = k.split('.')[0]
            if root not in objs or (authored and objs[root]['name'] not in authored):
                continue
        out[k] = o
    return out


def side_reader(meta):
    """(reader, status) for one side's record. A record from before schema 2
    came from the old exporter, which wrote a graph list for Blueprints only."""
    if 'schema' not in meta:
        if 'graphs' in meta:
            return 'blueprint', 'ok' if meta.get('t3d', True) else 'export_failed'
        return None, 'unsupported'
    return meta.get('reader'), meta.get('status', 'ok')


def side_stats(side, reader):
    """(graphs, nodes, wires) one reader captured from one side."""
    meta, objs, _ = side
    if reader == 'material':
        m, e = material_model(objs)
        return (1 if m else 0), len(m), len(e)
    g = authored_graphs(meta, objs)
    models = [graph_model(objs, k) for k in g]
    return len(g), sum(len(m) for m, _ in models), sum(len(e) for _, e in models)


MATERIAL_ROOT_SKIP = re.compile(r'^(StateId|LightingGuid|EditorOnlyData|ReferencedTextureGuids|'
                                r'CachedExpressionData|ThumbnailInfo|ExpressionCollection|EditorX|EditorY)\b')
ASSET_ROOT_SKIP = re.compile(r'^(ThumbnailInfo|AssetImportData)\b')


def bp_diff(old, new, reader='blueprint'):
    """old/new are (meta, objs, cdo_objs) or None. Returns [(section title, status, rows)].
    reader names what read both sides, which picks the sections that apply."""
    om, oa, ca = old or ({}, {}, {})
    nm, ob, cb = new or ({}, {}, {})
    E = lambda s: html.escape(s, quote=False)
    sections = []
    if reader == 'material':
        rows, svg = diff_models(material_model(oa), material_model(ob))
        if rows:
            sections.append(('Material graph', None, rows, svg))
        rows = prop_rows(oa.get('', {}).get('props', {}), ob.get('', {}).get('props', {}), MATERIAL_ROOT_SKIP)
        if rows:
            sections.append(('Asset properties', None, rows))
        return sections

    va, vb = variables(oa), variables(ob)
    rows = []
    for g in vb.keys() - va.keys():
        rows.append(('add', f'<b>{E(vb[g].get("VarName", "?"))}</b> : {E(var_type(vb[g]))}'
                            + set_to(vb[g].get('DefaultValue'))))
    for g in va.keys() - vb.keys():
        rows.append(('del', f'<b>{E(va[g].get("VarName", "?"))}</b> : {E(var_type(va[g]))}'
                            + set_to(va[g].get('DefaultValue'))))
    for g in va.keys() & vb.keys():
        a, b, ch = va[g], vb[g], []
        if a.get('VarName') != b.get('VarName'):
            ch.append(f'renamed from {E(a.get("VarName", "?"))}')
        if var_type(a) != var_type(b):
            ch.append(f'type <s>{E(var_type(a))}</s> → {E(var_type(b))}')
        for k in ('DefaultValue', 'Category', 'PropertyFlags', 'RepNotifyFunc', 'ReplicationCondition'):
            if a.get(k) != b.get(k):
                ch.append(f'{k} <s>{E(short_val(a.get(k) or "∅"))}</s> → {E(short_val(b.get(k) or "∅"))}')
        if ch:
            rows.append(('mod', f'<b>{E(b.get("VarName", "?"))}</b>: ' + '; '.join(ch)))
    if rows:
        sections.append(('Variables', None, rows))

    ga, gb = authored_graphs(om, oa), authored_graphs(nm, ob)
    for k in sorted(ga.keys() | gb.keys(), key=lambda x: (x.count('.'), x.lower())):
        st = 'added' if k not in ga else 'deleted' if k not in gb else None
        rows, svg = diff_graph(oa, ob, k if k in ga else None, k if k in gb else None)
        if st or rows:
            title = k.replace('.', ' › ') or (ga.get(k) or gb.get(k))['name']
            sections.append((f'Graph {title}', st, rows, svg))

    def in_graph(o, objs, parents):  # graph nodes, compiler graphs and their contents are covered above or noise
        while o is not None:
            if is_graph(o, parents) or 'NodeGuid' in o['props']:
                return True
            o = objs.get(o['parent']) if o['parent'] is not None else None
        return False
    # The root holding nodes itself mustn't hide every other subobject.
    pa_, pb_ = graph_parents(oa) - {''}, graph_parents(ob) - {''}
    other_a = {k: o for k, o in oa.items() if k and not in_graph(o, oa, pa_)}
    other_b = {k: o for k, o in ob.items() if k and not in_graph(o, ob, pb_)}
    rows = []
    for k in sorted(other_b.keys() - other_a.keys()):
        rows.append(('add', f'<b>{E(other_b[k]["name"])}</b> ({E(other_b[k]["cls"])})'
                            + prop_list(other_b[k]['props'])))
    for k in sorted(other_a.keys() - other_b.keys()):
        rows.append(('del', f'<b>{E(other_a[k]["name"])}</b> ({E(other_a[k]["cls"])})'
                            + prop_list(other_a[k]['props'])))
    for k in sorted(other_a.keys() & other_b.keys()):
        sub = prop_rows(other_a[k]['props'], other_b[k]['props'], re.compile(r'^$^'))
        for kind, text in sub:
            rows.append((kind, f'<b>{E(other_b[k]["name"])}</b> {text}'))
    bp = reader == 'blueprint'
    if rows:
        sections.append(('Components and subobjects' if bp else 'Subobjects', None, rows))

    rows = prop_rows(oa.get('', {}).get('props', {}), ob.get('', {}).get('props', {}),
                     ROOT_SKIP if bp else ASSET_ROOT_SKIP)
    if bp and om.get('parent') != nm.get('parent') and old and new:
        rows.insert(0, ('mod', f'Parent class <s>{E(om.get("parent") or "?")}</s> → {E(nm.get("parent") or "?")}'))
    if rows:
        sections.append(('Blueprint settings' if bp else 'Asset properties', None, rows))
    rows = prop_rows(ca.get('', {}).get('props', {}), cb.get('', {}).get('props', {}), CDO_SKIP)
    if rows and old and new:
        sections.append(('Class defaults', None, rows))
    return sections


def load_side(folder, flat):
    meta_f = os.path.join(folder, flat + '.json')
    if not os.path.exists(meta_f):
        return None
    with open(meta_f, encoding='utf-8') as fh:
        meta = json.load(fh)
    def read(fn):
        if not os.path.exists(fn):
            return {}
        with open(fn, encoding='utf-8', errors='replace') as fh:
            return parse_t3d(fh.read())
    return meta, read(os.path.join(folder, flat + '.t3d')), read(os.path.join(folder, flat + '.cdo.t3d'))


def attach_blueprints(files, folder):
    with open(os.path.join(folder, 'manifest.json'), encoding='utf-8') as fh:
        man = json.load(fh)
    for a in man.get('assets', []):
        rel = a['file'].replace('\\', '/')
        old, new = load_side(os.path.join(folder, 'old'), a['flat']), load_side(os.path.join(folder, 'new'), a['flat'])
        f = next((x for x in files if x.path == rel or x.path.endswith('/' + rel)), None)
        if f is None:
            f = FileDiff(None if a['status'] == 'added' else rel, None if a['status'] == 'deleted' else rel)
            f.status = a['status'] if a['status'] in ('added', 'deleted') else 'modified'
            f.binary = True
            files.append(f)
        f.bp = compare_asset(a['status'], old, new)
        if f.bp[0] != 'bp':
            continue
        for _, _, rows, *_ in f.bp[2]:
            for kind, _ in rows:
                if kind == 'add': f.adds += 1
                elif kind == 'del': f.dels += 1
                elif kind == 'mod': f.mods += 1
    return files


def compare_asset(status, old, new):
    """One asset's result. ('bp', meta, sections, notes) when every side the
    change has was read, ('failed', problems) when one wasn't, so a failed read
    can't pass for an asset that didn't change, and ('asset', class) when no
    reader supports it."""
    problems, sides = [], {'old': old, 'new': new}
    for side in ('old', 'new'):
        if (side == 'old' and status == 'added') or (side == 'new' and status == 'deleted'):
            sides[side] = None  # this revision doesn't exist, so it's not a failure
            continue
        got = sides[side]
        if got is None:
            problems.append(f'The {side} revision has no export. Check export.log for this asset.')
            continue
        reader, st = side_reader(got[0])
        why = got[0].get('error')
        if st == 'load_failed':
            problems.append(f"The editor couldn't load the {side} revision" + (f': {why}' if why else '.'))
        elif st == 'export_failed':
            problems.append(f"The {reader} reader couldn't export the {side} revision"
                            + (f': {why}' if why else '.'))
    if problems:
        return ('failed', problems)
    old, new = sides['old'], sides['new']
    readers = {s: side_reader(x[0])[0] for s, x in sides.items() if x}
    meta = (new or old)[0]
    used = {r for r in readers.values() if r}
    if not used:
        return ('asset', meta.get('class') or '?')
    if len(used) > 1:
        return ('failed', [f'The two revisions were read by different readers ({", ".join(sorted(used))}), '
                           'so they can\'t be compared.'])
    reader, notes = used.pop(), []
    for s, r in readers.items():
        if r is None:  # e.g. a Behavior Tree saved before anyone opened its graph
            notes.append(f'The {s} revision held nothing the {reader} reader could read, '
                         'so everything on the other side shows as added or removed.')
            sides[s] = ({}, {}, {})
    old, new = sides['old'], sides['new']
    meta = dict(meta, reader=reader)
    shown = next(sides[s] for s in ('new', 'old') if readers.get(s))  # the counts come from a side that was read
    meta['captured'] = side_stats(shown, reader)
    return ('bp', meta, bp_diff(old, new, reader), notes)


def render_bp(f):
    kind = f.bp[0]
    if kind == 'asset':
        return (f'<p class="empty-msg">{html.escape(f.bp[1])} asset. No graph reader supports this type, '
                'so only its name is shown.</p>')
    if kind == 'failed':
        items = ''.join(f'<li>{html.escape(p)}</li>' for p in f.bp[1])
        return (f'<div class="bp-fail"><p>Not compared. Nothing below means this asset is unchanged.</p>'
                f'<ul>{items}</ul></div>')
    meta, sections, notes = f.bp[1], f.bp[2], f.bp[3]
    g, n, w = meta['captured']
    plural = lambda k, word: f'{k} {word}{"s" if k != 1 else ""}'
    parent = (f' parent <code>{html.escape(meta.get("parent") or "?")}</code>'
              if meta['reader'] == 'blueprint' else '')
    head = (f'<p class="bp-head"><span class="bp-tag">{html.escape(meta.get("class", "Blueprint"))}</span>{parent}'
            f' · {html.escape(meta["reader"])} reader, {plural(g, "graph")}, {plural(n, "node")}, '
            f'{plural(w, "wire")}</p>')
    head += ''.join(f'<p class="bp-note">{html.escape(x)}</p>' for x in notes)
    if not sections:
        if not n:
            return head + ('<p class="empty-msg">No semantic changes, and the reader found no nodes. '
                           'If this asset has a graph, its reader may not see it.</p>')
        return head + '<p class="empty-msg">No semantic changes. The file changed but its graphs, variables and defaults did not.</p>'
    sign = {'add': '+', 'del': '−', 'mod': '~', 'info': '·'}
    out = [head]
    for title, st, rows, *svg in sections:
        badge = f' <span class="st st-{st}">{"Added" if st == "added" else "Removed"}</span>' if st else ''
        out.append(f'<div class="bp-sec"><h3>{html.escape(title)}{badge}</h3>')
        if svg and svg[0]:
            out.append(svg[0])
        out.append('<ul class="bp">')
        out.extend(f'<li class="{k}"><span class="sg">{sign[k]}</span><span>{t}</span></li>' for k, t in rows)
        if not rows:
            out.append('<li class="info"><span class="sg">·</span><span>Empty graph</span></li>')
        out.append('</ul></div>')
    return ''.join(out)


# ---------------------------------------------------------------- text diff

def intraline(a, b):
    ta, tb = TOKENS.findall(a), TOKENS.findall(b)
    sm = difflib.SequenceMatcher(None, ta, tb, autojunk=False)
    if not a.strip() or not b.strip() or sm.ratio() < 0.5:
        return None, None
    pa, pb = [0], [0]
    for t in ta: pa.append(pa[-1] + len(t))
    for t in tb: pb.append(pb[-1] + len(t))
    ma, mb = [False] * len(a), [False] * len(b)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag != 'equal':
            for x in range(pa[i1], pa[i2]): ma[x] = True
            for x in range(pb[j1], pb[j2]): mb[x] = True
    return ma, mb


def code(text, lang, mark=None):
    n = len(text)
    cls = [None] * n
    if lang:
        syntax = PY_SYNTAX if lang == '.py' else SYNTAX
        for m in syntax.finditer(text):
            token = m.lastgroup
            if token == 'fn' and lang in CPP_EXT:
                prefix = text[:m.start()]
                if re.search(r'\b[UAFTEIS][A-Z]\w*::$', prefix):
                    token = 'sfn'
                elif not prefix.endswith(('->', '.')):
                    token = 'gfn'
            for i in range(m.start(), m.end()):
                cls[i] = token
            if m.lastgroup == 'str' and lang in CPP_EXT:
                for spec in FORMAT_SPEC.finditer(m.group()):
                    if spec.start() and m.group()[spec.start() - 1] == '%':
                        continue
                    for i in range(m.start() + spec.start(), m.start() + spec.end()):
                        cls[i] = 'fmt'
        if lang in CPP_EXT and PREPROC_CONDITION.match(text):
            for m in PREPROC_DEFINED.finditer(text):
                if all(cls[i] in (None, 'fn') for i in range(m.start(), m.end())):
                    for i in range(m.start(), m.end()):
                        cls[i] = 'pp'
    out, i = [], 0
    while i < n:
        c, mk, j = cls[i], bool(mark and mark[i]), i
        while j < n and cls[j] == c and bool(mark and mark[j]) == mk:
            j += 1
        seg = html.escape(text[i:j], quote=False)
        if c: seg = f'<span class="t-{c}">{seg}</span>'
        if mk: seg = f'<mark>{seg}</mark>'
        out.append(seg)
        i = j
    return ''.join(out)


def similar(a, b):
    return difflib.SequenceMatcher(None, TOKENS.findall(a), TOKENS.findall(b), autojunk=False).ratio()


ALIGN_WINDOW, ALIGN_MAX = 32, 2000  # adds searched ahead per removed line, and the block size past which nothing pairs


def align(dels, adds, cutoff=0.5):
    """Pair removed and added lines that look alike, in order. Unpaired lines
    stay pure removals or additions, so an inserted line never sits beside an
    unrelated removed one. Pairing is quadratic, so a block over ALIGN_MAX
    lines on either side stays unpaired."""
    if len(dels) > ALIGN_MAX or len(adds) > ALIGN_MAX:
        return [(i, None) for i in range(len(dels))] + [(None, k) for k in range(len(adds))]
    out, i, j = [], 0, 0
    while i < len(dels) and j < len(adds):
        stop = min(len(adds), j + ALIGN_WINDOW)
        best = max(range(j, stop), key=lambda k: similar(dels[i], adds[k]))
        if similar(dels[i], adds[best]) < cutoff:
            out.append((i, None)); i += 1
            continue
        out.extend((None, k) for k in range(j, best))
        out.append((i, best)); i, j = i + 1, best + 1
    out.extend((k, None) for k in range(i, len(dels)))
    out.extend((None, k) for k in range(j, len(adds)))
    return out


def rows_for(h, lang):
    """Rows: ('ctx', o, n, html) or ('chg', [(left, right)]), each side
    (line no, html) or None."""
    rows, o, n, ls, i = [], h['os'], h['ns'], h['lines'], 0
    while i < len(ls):
        if ls[i][0] == ' ':
            rows.append(('ctx', o, n, code(ls[i][1], lang))); o += 1; n += 1; i += 1
            continue
        dels, adds = [], []
        while i < len(ls) and ls[i][0] == '-': dels.append(ls[i][1]); i += 1
        while i < len(ls) and ls[i][0] == '+': adds.append(ls[i][1]); i += 1
        pairs = []
        for di, ai in align(dels, adds):
            dm, am = intraline(dels[di], adds[ai]) if di is not None and ai is not None else (None, None)
            pairs.append(((o + di, code(dels[di], lang, dm)) if di is not None else None,
                          (n + ai, code(adds[ai], lang, am)) if ai is not None else None))
        rows.append(('chg', pairs))
        o += len(dels); n += len(adds)
    return rows


def hunk_row(h, span, lang, gap=None, count=0):
    fn = f' <span class="fn">{code(h["ctx"], lang)}</span>' if h['ctx'] else ''
    control = (f' <button type="button" aria-expanded="false">Show {count} omitted line{"s" if count != 1 else ""}</button>'
               if gap else '')
    gap_attr = f' data-gap="{html.escape(gap, quote=True)}"' if gap else ''
    return (f'<tr class="hunk{" expandable" if gap else ""}"{gap_attr}>'
            f'<td colspan="{span}"><span class="at">@@ -{h["os"]},{h["oc"]} +{h["ns"]},{h["nc"]} @@</span>{fn}{control}</td></tr>')


def omitted_rows(before, after, os_, oe, ns, ne, lang, gap):
    sp, un = [], []
    old, new = before[os_:oe], after[ns:ne]
    for i in range(max(len(old), len(new))):
        left = code(old[i].expandtabs(4), lang) if i < len(old) else None
        right = code(new[i].expandtabs(4), lang) if i < len(new) else None
        old_num, new_num = os_ + i + 1, ns + i + 1
        lcell = f'<td class="ln">{old_num}</td><td class="cd">{left}</td>' if left is not None else '<td class="ln e"></td><td class="cd e"></td>'
        rcell = f'<td class="ln">{new_num}</td><td class="cd">{right}</td>' if right is not None else '<td class="ln e"></td><td class="cd e"></td>'
        sp.append(f'<tr class="omitted" data-gap="{gap}" hidden>{lcell}{rcell}</tr>')
        if left is not None and right is not None and old[i] == new[i]:
            un.append(f'<tr class="omitted" data-gap="{gap}" hidden><td class="ln">{old_num}</td><td class="ln">{new_num}</td><td class="cd">{left}</td></tr>')
        else:
            if left is not None:
                un.append(f'<tr class="omitted" data-gap="{gap}" hidden><td class="ln del">{old_num}</td><td class="ln del"></td><td class="cd del">{left}</td></tr>')
            if right is not None:
                un.append(f'<tr class="omitted" data-gap="{gap}" hidden><td class="ln add"></td><td class="ln add">{new_num}</td><td class="cd add">{right}</td></tr>')
    return sp, un


def tables(f, lang):
    sp, un = [], []
    before, after = getattr(f, 'before_lines', None), getattr(f, 'after_lines', None)
    old_end = new_end = 0
    empty = '<td class="ln e"></td><td class="cd e"></td>'
    # Review comments go right under the line they name, on its own side in
    # the split view. A comment on a line the hunks don't show goes in the
    # block above the file instead (render does that from f.placed).
    at = {}
    for x in f.review:
        at.setdefault(('old' if f.status == 'deleted' else x['side'], x['line']), []).append(x)

    def said(side, n):
        xs = at.get((side, n), []) if n is not None else []
        f.placed.update(id(x) for x in xs)
        return ''.join(comment_html(x) for x in xs)

    def rc_split(old_html, new_html):
        if not old_html and not new_html:
            return
        cell = lambda h: f'<td colspan="2" class="rcc">{h}</td>' if h else '<td colspan="2" class="rce"></td>'
        sp.append(f'<tr class="rc">{cell(old_html)}{cell(new_html)}</tr>')

    def rc_uni(h):
        if h:
            un.append(f'<tr class="rc"><td colspan="3" class="rcc">{h}</td></tr>')
    for index, h in enumerate(f.hunks):
        old_hunk_start = h['os'] - 1 if h['oc'] else h['os']
        new_hunk_start = h['ns'] - 1 if h['nc'] else h['ns']
        old_start = max(old_end, old_hunk_start)
        new_start = max(new_end, new_hunk_start)
        is_last = index == len(f.hunks) - 1
        tail_old = len(before) - (old_hunk_start + h['oc']) if is_last and before is not None else 0
        tail_new = len(after) - (new_hunk_start + h['nc']) if is_last and after is not None else 0
        count = max(old_start - old_end, new_start - new_end) + max(tail_old, tail_new)
        gap = f'{f.anchor}-gap-{index}' if count and before is not None and after is not None else None
        sp.append(hunk_row(h, 4, lang, gap, count)); un.append(hunk_row(h, 3, lang, gap, count))
        if gap:
            left, right = omitted_rows(before, after, old_end, old_start, new_end, new_start, lang, gap)
            sp.extend(left); un.extend(right)
        for r in rows_for(h, lang):
            if r[0] == 'ctx':
                _, o, n, c = r
                sp.append(f'<tr><td class="ln">{o}</td><td class="cd">{c}</td><td class="ln">{n}</td><td class="cd">{c}</td></tr>')
                un.append(f'<tr><td class="ln">{o}</td><td class="ln">{n}</td><td class="cd">{c}</td></tr>')
                old_said, new_said = said('old', o), said('new', n)
                rc_split(old_said, new_said)
                rc_uni(old_said + new_said)
                continue
            for L, R in r[1]:
                left = f'<td class="ln del">{L[0]}</td><td class="cd del">{L[1]}</td>' if L else empty
                right = f'<td class="ln add">{R[0]}</td><td class="cd add">{R[1]}</td>' if R else empty
                sp.append(f'<tr>{left}{right}</tr>')
                rc_split(said('old', L and L[0]), said('new', R and R[0]))
            for o, c in (L for L, _ in r[1] if L):
                un.append(f'<tr><td class="ln del">{o}</td><td class="ln del"></td><td class="cd del">{c}</td></tr>')
                rc_uni(said('old', o))
            for n, c in (R for _, R in r[1] if R):
                un.append(f'<tr><td class="ln add"></td><td class="ln add">{n}</td><td class="cd add">{c}</td></tr>')
                rc_uni(said('new', n))
        old_end, new_end = old_hunk_start + h['oc'], new_hunk_start + h['nc']
        if gap and is_last:
            left, right = omitted_rows(before, after, old_end, len(before), new_end, len(after), lang, gap)
            sp.extend(left); un.extend(right)
    if f.status in ('added', 'deleted'):  # one side is empty, so skip the split layout
        return f'<table class="d"><colgroup><col class="c-ln"><col class="c-ln"><col></colgroup>{"".join(un)}</table>'
    cols4 = '<colgroup><col class="c-ln"><col><col class="c-ln"><col></colgroup>'
    cols3 = '<colgroup><col class="c-ln"><col class="c-ln"><col></colgroup>'
    return (f'<table class="d v-split">{cols4}{"".join(sp)}</table>'
            f'<table class="d v-uni">{cols3}{"".join(un)}</table>')


def git_context(files, repo):
    """Give each text file its whole before and after so the page can expand
    the lines between hunks. Old side from HEAD, new side from the working
    tree. A file whose hunks don't match both exactly keeps hunks only."""
    top = subprocess.run(['git', '-C', repo, 'rev-parse', '--show-toplevel'], capture_output=True, text=True)
    if top.returncode:
        raise OSError(f'{repo} is not inside a git work tree')
    root = top.stdout.strip()
    rev = subprocess.run(['git', '-C', root, 'rev-parse', '--short', 'HEAD'], capture_output=True, text=True)
    for f in files:
        if f.binary or f.bp or not f.hunks or f.status == 'renamed':
            continue
        try:
            after = [] if f.status == 'deleted' else \
                split_lines(open(os.path.join(root, f.new or f.old), encoding='utf-8', newline='').read())
        except (OSError, UnicodeError):
            continue
        before = []
        if f.status != 'added':
            r = subprocess.run(['git', '-C', root, 'show', f'HEAD:{f.old or f.new}'], capture_output=True)
            if r.returncode:
                continue
            before = split_lines(r.stdout.decode('utf-8', 'replace'))
        if all(hunk_matches(h, before, after) for h in f.hunks):
            f.before_lines, f.after_lines = before, after
    return f'git {rev.stdout.strip()} + working tree' if rev.returncode == 0 else None


def hunk_matches(h, before, after):
    old = [b for t, b in h['lines'] if t in ' -']
    new = [b for t, b in h['lines'] if t in ' +']
    o = h['os'] - 1 if h['oc'] else h['os']
    n = h['ns'] - 1 if h['nc'] else h['ns']
    return ([x.expandtabs(4) for x in before[o:o + len(old)]] == old and
            [x.expandtabs(4) for x in after[n:n + len(new)]] == new)


def prose(text):
    paras = [p.strip() for p in re.split(r'\n\s*\n', text) if p.strip()]
    fmt = lambda p: re.sub(r'`([^`]+)`', r'<code>\1</code>', html.escape(p, quote=False))
    return ''.join(f'<p>{fmt(p)}</p>' for p in paras)


def find_note(notes, path):
    """The note whose key is the whole path or a suffix at a '/' boundary. When
    more than one key matches, the longest one wins."""
    hits = [k for k in notes if k != '_summary' and (path == k or path.endswith('/' + k))]
    return notes[max(hits, key=len)] if hits else None


# ---------------------------------------------------------------- review comments
# smartreview's findings, shown as comments under the line each one names.

REVIEW_HEAD = re.compile(r'^[\s#*]*(BREAKING|PRACTICE|CONVENTION)\b')
REVIEW_END = re.compile(r'^[\s#*]*(Checklist|Categories swept|Ambiguous)\b')
# The file name may hold spaces but no colon past a drive letter, so a row
# citing "a.py:5-7, :9" or "Foo.cpp:12: x" takes the first line it names.
REVIEW_ROW = re.compile(r'^\s*[-*]\s+`?(?P<file>(?:[A-Za-z]:)?[^`:]+?):(?P<line>\d+)(?:[-–]\d+)?`?'
                        r'\s*(?:[—–:]|-+)?\s*(?P<text>.*)$')


def load_review(path):
    """Findings as [{file, line, side, sev, text}]. Reads smartreview's report
    as written (the "- <file>:<line> — ..." rows under each category heading),
    or JSON: a list, or {"findings": [...]}, of {file, line, severity, text}
    with optional side ("old" for a removed line) and fix."""
    raw = read_text(path)
    out = []
    if raw.lstrip()[:1] in ('[', '{'):
        data = json.loads(raw)
        items = data.get('findings', []) if isinstance(data, dict) else data
        if not isinstance(items, list):
            raise ValueError(f'{path}: "findings" must be a list of review comments.')
        for x in items:
            if not isinstance(x, dict) or not x.get('file'):
                continue
            text = x.get('text') or x.get('summary') or x.get('message') or ''
            if x.get('failure_scenario'):
                text += f' {x["failure_scenario"]}'
            if x.get('fix'):
                text += f' → {x["fix"]}'
            out.append({'file': str(x['file']), 'line': num(str(x.get('line') or 0), 0),
                        'side': 'old' if x.get('side') == 'old' else 'new',
                        'sev': str(x.get('severity') or x.get('category') or 'NOTE').upper(), 'text': text.strip()})
        return out
    sev, last = None, None
    for line in split_lines(raw):
        if REVIEW_HEAD.match(line):
            sev, last = REVIEW_HEAD.match(line).group(1), None
            continue
        if REVIEW_END.match(line):
            sev, last = None, None
            continue
        m = REVIEW_ROW.match(line)
        if m and sev:
            out.append({'file': m.group('file'), 'line': int(m.group('line')), 'side': 'new', 'sev': sev,
                        'text': m.group('text').strip()})
            last = out[-1]
        elif not line.strip():
            last = None
        elif last is not None and line[:1].isspace() and line.lstrip()[:1] not in ('-', '*', '#'):
            # An indented line that isn't a bullet continues the finding above it.
            last['text'] = f"{last['text']} {line.strip()}".strip()
        else:
            last = None
    return out


def attach_review(files, findings):
    """Give each file its findings. A finding goes to the file whose path it
    matches exactly, else to the one file whose path it is a suffix of (or that
    is a suffix of it). When two or more files fit, the finding goes unmatched
    and says which files it could mean. Returns the findings that name no file."""
    norm = lambda p: re.sub(r'^\./', '', p.replace('\\', '/')).casefold()
    unmatched = []
    for x in findings:
        fp = norm(x['file'])
        exact = [f for f in files if norm(f.path) == fp]
        loose = [f for f in files if norm(f.path).endswith('/' + fp) or fp.endswith('/' + norm(f.path))]
        if exact:
            exact[0].review.append(x)
        elif len(loose) == 1:
            loose[0].review.append(x)
        elif loose:
            names = ' or '.join(f.path for f in loose)
            unmatched.append(dict(x, text=f"{x['text']} (The path could mean {names}.)"))
        else:
            unmatched.append(x)
    return unmatched


def comment_html(x, at=False):
    sev = x['sev'].lower() if x['sev'] in ('BREAKING', 'PRACTICE', 'CONVENTION') else 'other'
    text = re.sub(r'`([^`]+)`', r'<code>\1</code>', html.escape(x['text'], quote=False))
    n = x['line']
    where = html.escape(x['file']) + (f':{n}' if n else '') if at == 'file' else f'line {n}' if at and n else ''
    where = f'<span class="rv-at">{where}</span>' if where else ''
    return f'<div class="rv rv-{sev}"><span class="rv-sev">{html.escape(x["sev"])}</span>{where}<span>{text}</span></div>'


def comment_block(xs, heading, at=True):
    if not xs:
        return ''
    body = ''.join(comment_html(x, at) for x in sorted(xs, key=lambda x: (x['file'], x['line'])))
    return f'<div class="rv-file"><p class="rv-h">{heading}</p>{body}</div>'


def mass(f, biggest):
    total = f.adds + f.dels + f.mods
    w = max(2.0, 100.0 * total / biggest) if total else 0
    a = 100.0 * f.adds / total if total else 0
    m = 100.0 * f.mods / total if total else 0
    return (f'<span class="mass" aria-hidden="true"><span class="fill" style="width:{w:.1f}%">'
            f'<span class="ma" style="width:{a:.1f}%"></span><span class="mm" style="width:{m:.1f}%"></span>'
            f'<span class="md"></span></span></span>')


def counts(f):
    mod = f' <span class="pm">~{f.mods}</span>' if f.mods else ''
    return f'<span class="pa">+{f.adds}</span> <span class="pd">-{f.dels}</span>{mod}'


def split_path(p):
    d, _, b = p.rpartition('/')
    return (html.escape(d + '/') if d else ''), html.escape(b)


def render(files, title, notes, collapse, changelist=None, unmatched=(), warnings=()):
    paths = [f.path for f in files]
    prefix = ''
    if len(paths) > 1:
        prefix = os.path.commonprefix(paths)
        prefix = prefix[:prefix.rfind('/') + 1]
    rel = lambda p: p[len(prefix):] if prefix else p
    biggest = max([f.adds + f.dels + f.mods for f in files] + [1])
    adds, dels = sum(f.adds for f in files), sum(f.dels for f in files)
    label_ = {'added': 'Added', 'deleted': 'Deleted', 'renamed': 'Renamed'}

    nav, body = [], []
    for i, f in enumerate(files):
        if not getattr(f, 'anchor', None):
            f.anchor = f'f{i}'
        d, b = split_path(rel(f.path))
        lang = os.path.splitext(f.path)[1].lower()
        if lang not in CODE_EXT:
            lang = None
        st = f'<span class="st st-{f.status}">{label_[f.status]}</span>' if f.status in label_ else ''
        ext = os.path.splitext(f.path)[1].lower()
        if f.bp and f.bp[0] == 'bp':
            kind = 'Blueprint' if f.bp[1]['reader'] == 'blueprint' else f.bp[1].get('class') or 'Graph asset'
            bp_tag = f'<span class="st st-bp">{html.escape(kind)}</span>'
        elif os.path.basename(f.path) == 'CMakeLists.txt' or ext in LANG_NAME:
            bp_tag = f'<span class="st st-lang">{LANG_NAME.get(ext, "CMake")}</span>'
        else:
            bp_tag = ''
        n_rv = len(f.review)
        worst = ' breaking' if any(x['sev'] == 'BREAKING' for x in f.review) else ''
        rv_words = f'{n_rv} comment{"s" if n_rv != 1 else ""}'
        rv_tag = f'<span class="st st-rv{worst}" title="Review comments">{rv_words}</span>' if n_rv else ''
        rv_nav = f'<span class="nr{worst}">{rv_words}</span>' if n_rv else ''
        nav.append(f'<li><a href="#{f.anchor}"><span class="nb">{b}</span><span class="nc">{counts(f)}</span>'
                   f'<span class="nd">{d}</span>{mass(f, biggest)}{rv_nav}</a></li>')
        sub = (f'<div class="ren">Renamed from <code>{html.escape(f.old.replace(chr(92), "/"))}</code></div>'
               if f.status == 'renamed' and f.old else '')
        note = find_note(notes, f.path)
        note_html = f'<div class="note">{prose(note)}</div>' if note else ''
        if f.bp:
            content = render_bp(f)
        elif f.binary:
            hint = ' Pass <code>--blueprints</code> for a Blueprint diff.' if f.path.lower().endswith(ASSET_EXT) else ''
            content = f'<p class="empty-msg">Binary file, no text diff.{hint}</p>'
        elif not f.hunks:
            content = f'<p class="empty-msg">{html.escape(f.empty_msg or "No content changes.")}</p>'
        else:
            content = tables(f, lang)
        loose = [x for x in f.review if id(x) not in f.placed]
        lined = bool(f.hunks) and not f.bp and not f.binary  # a Blueprint or binary file has no lines to name
        rv_html = comment_block(loose, 'Review comments on lines this diff doesn’t show' if lined else 'Review comments',
                                at=lined)
        big = f.adds + f.dels + f.mods > collapse and not n_rv  # a file with comments always opens
        hint = '<p class="empty-msg">Large diff collapsed. Open the header to show it.</p>' if big else ''
        gap_html = f'<div class="warn in-file">{GAP_NOTE}</div>' if f.gapped else ''
        body.append(
            f'<details class="file" id="{f.anchor}"{"" if big else " open"}><summary>'
            f'<span class="path"><span class="dir">{d}</span><span class="base">{b}</span></span>{st}{bp_tag}{rv_tag}'
            f'<span class="cnt">{counts(f)}</span>'
            f'</summary>{sub}{gap_html}{note_html}{rv_html}<div class="scroll">{content}</div></details>{hint if big else ""}')

    warn_html = ''
    if warnings:
        items = ''.join(f'<li>{html.escape(w)}</li>' for w in warnings)
        warn_html = (f'<div class="summary"><div class="warn"><p>Partial export. The record couldn’t prove '
                     f'everything below:</p><ul>{items}</ul></div></div>')
    summary = notes.get('_summary')
    where = f' in <code>{html.escape(prefix)}</code>' if prefix else ''
    plural = 's' if len(files) != 1 else ''
    n_review = sum(len(f.review) for f in files) + len(unmatched)
    n_breaking = sum(x['sev'] == 'BREAKING' for f in files for x in f.review) + \
        sum(x['sev'] == 'BREAKING' for x in unmatched)
    review_meta = (f'<span class="tot">{n_review} review comment{"s" if n_review != 1 else ""}'
                   f'{f", <span class=pd>{n_breaking} breaking</span>" if n_breaking else ""}</span>' if n_review else '')
    loose_page = comment_block(list(unmatched), 'Review comments on files not in this diff', 'file')
    key_list = (('jk', 'Next or previous file'), ('e', 'Expand all'), ('c', 'Collapse all'),
                ('b', 'File list'), ('v', 'Split or unified'), ('a', 'Omitted code')) + \
        ((('np', 'Next or previous comment'),) if n_review else ())
    keys = ('<ul class="keys" aria-label="Keyboard shortcuts">'
            + ''.join(f'<li>{"".join(f"<kbd>{k}</kbd>" for k in ks)}<span>{label}</span></li>'
                      for ks, label in key_list)
            + '</ul>')
    return TEMPLATE.format(
        title=html.escape(title), css=CSS.replace('/*DARK*/', DARK), js=JS, graph_js=GRAPH_JS,
        meta=(f'{len(files)} file{plural} changed{where}'
              f'<span class="tot"><span class="pa">+{adds}</span> <span class="pd">-{dels}</span></span>{review_meta}'),
        when=datetime.now().strftime('%b %d, %Y at %H:%M'),
        changelist=f' · {html.escape(changelist)}' if changelist else '',
        summary=warn_html + (f'<div class="summary">{prose(summary)}</div>' if summary else '') +
                (f'<div class="summary">{loose_page}</div>' if loose_page else ''),
        nav=''.join(nav), body=''.join(body) or '<p class="empty-msg">The diff is empty.</p>', keys=keys)


DARK = '''--bg:#17191c;--surface:#1e1e1e;--ink:#dcdcdc;--muted:#858b93;--line:#343a40;--accent:#569cd6;
--add-bg:rgba(63,185,104,.14);--add-ln:rgba(63,185,104,.2);--add-mark:#3a5b79;--add-ink:#62cd87;
--del-bg:rgba(236,83,104,.14);--del-ln:rgba(236,83,104,.2);--del-mark:#69475b;--del-ink:#f27d8e;
--mod-bg:rgba(86,156,214,.14);--mod-ink:#79b8ea;
--hunk:#252a30;--empty:#1d2024;--t-kw:#569cd6;--t-type:#00b3b3;--t-str:#d69d85;--t-fmt:#80ff80;--t-com:#559b45;
--t-num:#b5cea8;--t-pp:#bd63c5;--t-fn:#ff8000;--t-sfn:#ffaa00;--t-gfn:#add8e6;
--sb:#464d56;--sb-hover:#5d6670;--grid1:rgba(255,255,255,.055);--grid2:rgba(255,255,255,.12);color-scheme:dark;'''

CSS = '''
:root{--bg:#f3f5f8;--surface:#fff;--ink:#1c232c;--muted:#68717d;--line:#dde2e8;--accent:#2d68a2;
--add-bg:#e9f6ed;--add-ln:#d4efdc;--add-mark:#a9e1bb;--add-ink:#1a7a3a;
--del-bg:#fdecee;--del-ln:#f8d7dc;--del-mark:#f2b3bc;--del-ink:#b3233a;
--mod-bg:#e8f0fa;--mod-ink:#2d68a2;
--hunk:#edf2f8;--empty:#f6f7f9;--t-kw:#7036d6;--t-type:#0e7672;--t-str:#94570f;--t-fmt:#137c32;--t-com:#7a8491;
--t-num:#1f68b0;--t-pp:#7d39bf;--t-fn:#a44200;--t-sfn:#975500;--t-gfn:#18567d;
--sb:#c3cad3;--sb-hover:#a3acb8;--grid1:rgba(20,40,70,.07);--grid2:rgba(20,40,70,.15);
--mono:"JetBrains Mono","Cascadia Code","SF Mono",ui-monospace,Menlo,Consolas,monospace;
--sans:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif;color-scheme:light}
@media (prefers-color-scheme:dark){:root:not([data-theme="light"]){/*DARK*/}}
:root[data-theme="dark"]{/*DARK*/}
*{box-sizing:border-box}
*{scrollbar-width:thin;scrollbar-color:var(--sb) transparent}
@supports not (scrollbar-color:auto){
::-webkit-scrollbar{width:10px;height:10px}::-webkit-scrollbar-track,::-webkit-scrollbar-corner{background:transparent}
::-webkit-scrollbar-thumb{background:var(--sb);border-radius:6px;border:2px solid transparent;background-clip:padding-box}
::-webkit-scrollbar-thumb:hover{background:var(--sb-hover);border:2px solid transparent;background-clip:padding-box}}
body{margin:0;background:var(--bg);color:var(--ink);font:14px/1.5 var(--sans)}
code{font:12.5px var(--mono);background:var(--hunk);padding:.05em .35em;border-radius:4px}
.pa{color:var(--add-ink)}.pd{color:var(--del-ink)}.pm{color:var(--mod-ink)}
.top{padding:2rem 1.5rem 1.25rem;display:flex;flex-wrap:wrap;gap:1rem 2rem;align-items:end;justify-content:space-between}
.top h1{margin:0;font-size:1.55rem;font-weight:650;letter-spacing:-.015em}
.meta{margin:.3rem 0 0;color:var(--muted)}.tot{font:12.5px var(--mono);margin-left:.75rem}.meta .when{display:block;font-size:12.5px}
.ctl{display:flex;gap:.5rem;align-items:center}
.seg{display:inline-flex;border:1px solid var(--line);border-radius:7px;overflow:hidden;background:var(--surface)}
button{font:inherit;font-size:13px;color:var(--ink);background:var(--surface);border:0;padding:.35rem .8rem;cursor:pointer}
.seg button+button{border-left:1px solid var(--line)}
.seg button[aria-pressed="true"]{background:var(--ink);color:var(--surface)}
#theme{border:1px solid var(--line);border-radius:7px}
button:focus-visible,a:focus-visible,summary:focus-visible{outline:2px solid var(--accent);outline-offset:2px}
.summary{padding:0 1.5rem 1rem}
.summary p,.note p{margin:0 0 .5rem}
.wrap{padding:0 1.5rem 3rem;display:grid;grid-template-columns:16.5rem 1.125rem minmax(0,1fr);gap:1.5rem .75rem}
.wrap.nav-hidden{grid-template-columns:1.125rem minmax(0,1fr)}
.wrap.nav-hidden nav{display:none}
.wrap.nav-hidden .keys{grid-column:2}
nav{position:sticky;top:1rem;align-self:start;max-height:calc(100vh - 2rem);overflow:auto}
#sidebar{position:sticky;top:1rem;align-self:start;display:grid;place-items:center;width:1.125rem;height:1.5rem;padding:0;border:1px solid var(--line);border-radius:5px;color:var(--muted)}
#sidebar:hover{background:var(--hunk);color:var(--accent)}
#sidebar::before{content:"";width:.5rem;height:.625rem;background:currentColor;clip-path:polygon(0 0,25% 0,100% 50%,25% 100%,0 100%,75% 50%);transform:rotate(180deg)}
.wrap.nav-hidden #sidebar::before{transform:none}
nav ul{list-style:none;margin:0;padding:0}
nav a{display:grid;grid-template-columns:1fr auto;gap:.1rem .5rem;padding:.5rem .6rem;border-radius:7px;color:inherit;text-decoration:none}
nav a:hover{background:var(--surface)}
.nb{font:600 12.5px var(--mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.nc{font:12px var(--mono)}
.nd{grid-column:1/-1;font-size:11.5px;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;direction:rtl;text-align:left}
.mass{grid-column:1/-1;display:block;height:3px;margin-top:.3rem;background:var(--line);border-radius:2px}
.fill{display:flex;height:100%;border-radius:2px;overflow:hidden}
.ma{background:var(--add-ink)}.mm{background:var(--mod-ink)}.md{flex:1;background:var(--del-ink)}
.file{background:var(--surface);border:1px solid var(--line);border-radius:9px;margin:0 0 1.25rem;overflow:clip}
.file>summary{position:sticky;top:0;z-index:2;display:flex;align-items:center;gap:.75rem;padding:.6rem .9rem;background:var(--surface);border-bottom:1px solid var(--line);cursor:pointer;list-style:none}
.file:not([open])>summary{border-bottom:0}
.file>summary::-webkit-details-marker{display:none}
.file>summary::before{content:"";width:0;height:0;border:5px solid transparent;border-left-color:var(--muted);transform:translateX(3px);flex:none}
.file[open]>summary::before{transform:translate(0,3px) rotate(90deg)}
.path{font:13px var(--mono);min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.dir{color:var(--muted)}.base{font-weight:650}
.st{font-size:11.5px;padding:.05rem .45rem;border-radius:99px;border:1px solid currentColor;flex:none}
.st-added{color:var(--add-ink)}.st-deleted{color:var(--del-ink)}.st-renamed,.st-bp{color:var(--accent)}
.st-lang{color:var(--muted)}
.cnt{margin-left:auto;font:12.5px var(--mono);flex:none}
.ren{padding:.5rem .9rem 0;color:var(--muted);font-size:13px}
.note{margin:.75rem .9rem;padding:.6rem .8rem;border-left:3px solid var(--accent);background:var(--hunk);border-radius:0 6px 6px 0}
.note p:last-child{margin-bottom:0}
.warn{margin:.5rem 0 1rem;padding:.5rem .8rem;border-left:3px solid #c98a1b;background:var(--hunk);border-radius:0 6px 6px 0}
.warn p{margin:0 0 .25rem}.warn ul{margin:0;padding-left:1.25rem}.warn.in-file{margin:.75rem .9rem 0}
.rc td{padding:0!important;background:var(--surface)}.v-split .rc td+td{border-left:1px solid var(--line)}
.rv{margin:.35rem .7rem .35rem 1.5rem;padding:.4rem .7rem;border:1px solid var(--line);border-left:3px solid var(--muted);border-radius:0 6px 6px 0;background:var(--hunk);font:13px/1.5 var(--sans);white-space:normal;overflow-wrap:anywhere}
.rv-breaking{border-left-color:var(--del-ink)}.rv-practice{border-left-color:#c98a1b}.rv-convention{border-left-color:var(--accent)}
.rv-sev{font:600 11px var(--mono);margin-right:.55rem;color:var(--muted)}.rv-breaking .rv-sev{color:var(--del-ink)}
.rv-practice .rv-sev{color:#c98a1b}.rv-convention .rv-sev{color:var(--accent)}
.rv-at{font:11.5px var(--mono);color:var(--muted);margin-right:.55rem}
.rv.on{outline:2px solid var(--accent);outline-offset:1px}
.rv-file{margin:.75rem .9rem}.rv-file .rv{margin:.35rem 0}.summary .rv-file{margin:0}
.rv-h{margin:0 0 .2rem;font-size:12.5px;color:var(--muted)}
.st-rv{color:var(--accent)}.st-rv.breaking{color:var(--del-ink)}
.nr{grid-column:1/-1;font-size:11.5px;color:var(--accent)}.nr.breaking{color:var(--del-ink)}
.scroll{overflow-x:auto}
.d{width:100%;border-collapse:collapse;table-layout:fixed;font:12.5px/1.6 var(--mono)}
.c-ln{width:3.6rem}
.d td{vertical-align:top;padding:0}
.ln{color:var(--muted);text-align:right;padding:0 .6rem!important;font-size:11.5px;user-select:none;-webkit-user-select:none}
.v-split td:nth-child(3){border-left:1px solid var(--line)}
.cd{white-space:pre-wrap;overflow-wrap:anywhere;padding:0 .8rem 0 1.5rem!important;position:relative}
.cd.add{background:var(--add-bg)}.cd.del{background:var(--del-bg)}
.ln.add{background:var(--add-ln);color:var(--add-ink)}.ln.del{background:var(--del-ln);color:var(--del-ink)}
.cd.add::before,.cd.del::before{position:absolute;left:.55rem;user-select:none}
.cd.add::before{content:"+";color:var(--add-ink)}.cd.del::before{content:"-";color:var(--del-ink)}
.e{background:var(--empty)}
mark{background:none;color:inherit;border-radius:3px}
.add mark{background:var(--add-mark)}.del mark{background:var(--del-mark)}
.hunk td{position:relative;background:var(--hunk);color:var(--muted);padding:.3rem .8rem!important;font-size:12px}
.hunk .fn{color:var(--ink);margin-left:.5rem}
.hunk.expandable{cursor:pointer}
.hunk.expandable:hover td{filter:brightness(1.1)}
.hunk button{position:absolute;left:50%;top:50%;transform:translate(-50%,-50%);padding:0;background:transparent;color:var(--accent);font:inherit;white-space:nowrap}
.d tr[hidden]{display:none!important}
.t-kw{color:var(--t-kw)}.t-pp,.t-mac{color:var(--t-pp)}.t-type{color:var(--t-type)}.t-str{color:var(--t-str)}
.t-com{color:var(--t-com)}.t-fmt{color:var(--t-fmt)}.t-num{color:var(--t-num)}.t-fn{color:var(--t-fn)}
.t-sfn{color:var(--t-sfn)}.t-gfn{color:var(--t-gfn)}
.empty-msg{color:var(--muted);padding:.75rem .9rem;margin:0}
.bp-head{margin:0;padding:.75rem .9rem 0;color:var(--muted);font-size:13px}
.bp-tag{color:var(--accent);font-weight:600}
.bp-note{margin:.3rem .9rem 0;color:var(--muted);font-size:12.5px}
.bp-fail{margin:.75rem .9rem;padding:.5rem .8rem;border:1px solid var(--del-ink);border-radius:6px;background:var(--del-bg)}
.bp-fail p{margin:0 0 .3rem;font-weight:600}.bp-fail ul{margin:0;padding-left:1.2rem}
.bp-sec{padding:.5rem .9rem .25rem}
.bp-sec h3{margin:.25rem 0 .4rem;font:600 13px var(--mono);display:flex;gap:.5rem;align-items:center}
ul.bp{list-style:none;margin:0 0 .5rem;padding:0;font:12.5px/1.6 var(--mono);border:1px solid var(--line);border-radius:6px;overflow:hidden}
ul.bp li{display:flex;gap:.6rem;padding:.15rem .7rem;overflow-wrap:anywhere}
ul.bp li+li{border-top:1px solid var(--line)}
ul.bp .sg{flex:none;width:.8rem;text-align:center}
ul.bp .add{background:var(--add-bg)}ul.bp .add .sg{color:var(--add-ink)}
ul.bp .del{background:var(--del-bg)}ul.bp .del .sg{color:var(--del-ink)}
ul.bp .mod{background:var(--mod-bg)}ul.bp .mod .sg{color:var(--mod-ink)}
.bpg{position:relative;overflow:hidden;margin:.6rem 0 .3rem;border:1px solid var(--line);border-radius:6px;background:var(--empty)}
.bpg .g1{fill:none;stroke:var(--grid1);stroke-width:1}.bpg .g2{fill:none;stroke:var(--grid2);stroke-width:1}
.bpg svg{display:block;cursor:grab;user-select:none;touch-action:none}.bpg.dragging svg{cursor:grabbing}
.bpg-tools{position:absolute;top:.4rem;right:.4rem;display:flex;gap:.25rem;z-index:1}
.bpg-tools button{min-width:1.8rem;padding:.15rem .45rem;font:12px var(--sans);color:var(--ink);background:var(--surface);border:1px solid var(--line);border-radius:5px;cursor:pointer}
.bpg-tools button:hover{border-color:var(--accent);color:var(--accent)}
.bpg-views{display:flex;margin-right:.35rem}.bpg-views button{border-radius:0;margin-left:-1px}
.bpg-views button:first-child{border-radius:5px 0 0 5px}.bpg-views button:last-child{border-radius:0 5px 5px 0}
.bpg-views button[aria-pressed="true"]{background:var(--accent);border-color:var(--accent);color:#fff}
.bpg .L{display:none}.bpg[data-l="changes"] .L-changes,.bpg[data-l="before"] .L-before,.bpg[data-l="after"] .L-after{display:inline}
.bpg text{font:11px system-ui,sans-serif;fill:var(--ink)}.bpg .nt{font-size:12px;font-weight:600;fill:#fff}
.bpg .dv{fill:var(--muted)}.bpg .dv.chg{fill:var(--mod-ink);font-weight:600}
.bpg .nb{fill:var(--surface);stroke:var(--line);stroke-width:1.2}
.bpg .add .nb{stroke:var(--add-ink);stroke-width:2.5}.bpg .mod .nb{stroke:var(--mod-ink);stroke-width:2.5}
.bpg .del{opacity:.5}.bpg .del .nb{stroke:var(--del-ink);stroke-width:2.5;stroke-dasharray:6 4}
.bpg .kn{stroke:none}.bpg .add .kn{stroke:var(--add-ink);stroke-width:2}.bpg .del .kn{stroke:var(--del-ink);stroke-width:2}
.bpg .mod .kn{stroke:var(--mod-ink);stroke-width:2}
.bpg .pin.gone{stroke:var(--del-ink);stroke-dasharray:2 2;fill:none}.bpg text.gone{fill:var(--del-ink);text-decoration:line-through}
.bpg .cm{fill:var(--mod-bg);stroke:var(--line)}.bpg .ct{font-size:13px;font-weight:600}
.bpg .w{fill:none;stroke-width:1.6;opacity:.85}.bpg .w.x{stroke-width:2.4}
.bpg .w.add{stroke:var(--add-ink);stroke-width:3;opacity:1}.bpg .w.del{stroke:var(--del-ink);stroke-dasharray:6 4;opacity:.8}
.bpg .w.path{stroke-dasharray:1 5;stroke-linecap:round;stroke-width:2.6;opacity:.95}
.bpg .mv .nb{stroke:var(--muted);stroke-width:1.8;stroke-dasharray:3 3}.bpg .mv .kn,.bpg .path .kn{stroke:var(--muted);stroke-width:2;stroke-dasharray:2 2}
.bpg .tr{display:none;pointer-events:none}.bpg .n.mv:hover .tr{display:inline}
.bpg .tr rect{fill:none;stroke:var(--muted);stroke-width:1.5;stroke-dasharray:3 3}.bpg .tr path{stroke:var(--muted);stroke-width:1.5;stroke-dasharray:2 4;fill:none}
.bpg-note,.bpg-key{margin:.2rem 0 .5rem;font-size:12px;color:var(--muted)}
.bpg-key span{margin-right:.8rem;padding-left:1rem;position:relative}
.bpg-key span::before{content:"";position:absolute;left:0;top:.15em;width:.7rem;height:.7rem;border-radius:2px;border:2px solid}
.bpg-key .k-add::before{border-color:var(--add-ink)}.bpg-key .k-del::before{border-color:var(--del-ink);border-style:dashed}
.bpg-key .k-mod::before{border-color:var(--mod-ink)}.bpg-key .k-mv::before{border-color:var(--muted);border-style:dashed}
.bpg-key .k-path::before{border:0;border-top:3px dotted var(--muted);border-radius:0;height:0;top:.55em}
ul.bp .info{color:var(--muted)}
ul.bp b{font-weight:600}ul.bp s{color:var(--muted)}
ul.bp code{background:none;padding:0}
.keys{grid-column:3;display:flex;flex-wrap:wrap;gap:.4rem;list-style:none;margin:0;padding:0;color:var(--muted);font-size:12px}
.keys li{display:inline-flex;align-items:center;gap:.2rem;padding:.2rem .55rem .2rem .3rem;border:1px solid var(--line);border-radius:99px;background:var(--surface)}
.keys li span{margin-left:.25rem}
.top .keys{margin:.75rem 0 0}
kbd{display:inline-block;min-width:1.25rem;text-align:center;font:600 11px/1.5 var(--mono);color:var(--ink);border:1px solid var(--line);border-bottom-width:2px;border-radius:5px;padding:0 .3rem;background:var(--empty)}
.d,code,.nb,.nd,.path,.keys,kbd,ul.bp{font-variant-ligatures:none}
body:not(.unified) .v-uni,body.unified .v-split{display:none}
@media (max-width:1100px){.wrap{grid-template-columns:1.125rem minmax(0,1fr)}nav{grid-column:1/-1;position:static;max-height:none}
  nav ul{display:grid;grid-template-columns:repeat(auto-fill,minmax(14rem,1fr));gap:.25rem}.keys{grid-column:2}}
@media (max-width:820px){.v-split{display:none!important}.v-uni{display:table!important}.seg.layout{display:none}}
@media (prefers-reduced-motion:no-preference){.file>summary::before{transition:transform .12s}}
'''

JS = '''(()=>{const b=document.body,r=document.documentElement,
g=k=>{try{return localStorage.getItem(k)}catch(e){return null}},s=(k,v)=>{try{localStorage.setItem(k,v)}catch(e){}};
const view=v=>{b.classList.toggle('unified',v==='unified');document.querySelectorAll('[data-view]').forEach(x=>x.setAttribute('aria-pressed',x.dataset.view===v));s('diffview.view',v)};
view(g('diffview.view')||'split');document.querySelectorAll('[data-view]').forEach(x=>x.onclick=()=>view(x.dataset.view));
const w=document.querySelector('.wrap'),sidebar=document.getElementById('sidebar');
const showFiles=open=>{
w.classList.toggle('nav-hidden',!open);
sidebar.setAttribute('aria-expanded',String(open));
sidebar.setAttribute('aria-label',open?'Collapse file list':'Expand file list');
sidebar.title=sidebar.getAttribute('aria-label');
s('diffview.sidebar',open?'open':'closed')};
const toggleFiles=()=>showFiles(w.classList.contains('nav-hidden'));
showFiles(g('diffview.sidebar')!=='closed');sidebar.onclick=toggleFiles;
const hunks=[...document.querySelectorAll('.hunk.expandable')];
const setGaps=(open,gap)=>document.querySelectorAll('.hunk.expandable,.omitted').forEach(x=>{if(gap&&x.dataset.gap!==gap)return;
if(x.classList.contains('omitted'))x.hidden=!open;
else{const button=x.querySelector('button');button.setAttribute('aria-expanded',String(open));
button.textContent=button.textContent.replace(/^(Show|Hide)/,open?'Hide':'Show')}});
hunks.forEach(row=>row.addEventListener('click',()=>setGaps(row.querySelector('button').getAttribute('aria-expanded')!=='true',row.dataset.gap)));
const t=g('diffview.theme');if(t)r.dataset.theme=t;
document.getElementById('theme').onclick=()=>{const c=r.dataset.theme||(matchMedia('(prefers-color-scheme: dark)').matches?'dark':'light'),n=c==='dark'?'light':'dark';r.dataset.theme=n;s('diffview.theme',n)};
const fs=[...document.querySelectorAll('.file')];
const fold=open=>{const top=fs.find(f=>f.getBoundingClientRect().bottom>12);fs.forEach(f=>f.open=open);
if(top&&!open&&top.getBoundingClientRect().top<0)top.scrollIntoView({block:'start'})};
document.querySelectorAll('[data-fold]').forEach(x=>x.onclick=()=>fold(x.dataset.fold==='open'));
let ri=-1;const said=d=>{const rs=[...document.querySelectorAll('.rv')].filter(x=>{const v=x.closest('.v-split,.v-uni');return !v||getComputedStyle(v).display!=='none'});
if(!rs.length)return;document.querySelectorAll('.rv.on').forEach(x=>x.classList.remove('on'));
ri=(ri+d+rs.length)%rs.length;const x=rs[ri],f=x.closest('details');if(f)f.open=true;
x.classList.add('on');x.scrollIntoView({block:'center'})};
addEventListener('keydown',e=>{if(e.metaKey||e.ctrlKey||e.altKey||/INPUT|TEXTAREA/.test(e.target.tagName))return;
if(e.key==='n'||e.key==='p')said(e.key==='n'?1:-1);
if(e.key==='j'||e.key==='k'){let i=-1;fs.forEach((f,j)=>{if(f.getBoundingClientRect().top<=12)i=j});
const f=fs[Math.max(0,Math.min(fs.length-1,i+(e.key==='j'?1:-1)))];if(f){f.open=true;f.scrollIntoView({block:'start'})}}
if(e.key==='v')view(b.classList.contains('unified')?'split':'unified');
if(e.key==='b'||e.key==='f')toggleFiles();
if(e.key==='e'||e.key==='c')fold(e.key==='e');
if(e.key==='a'&&hunks.length){e.preventDefault();if(e.target.matches('.hunk button'))e.target.blur();
setGaps(hunks.some(x=>x.querySelector('button').getAttribute('aria-expanded')!=='true'))}})})();'''

# Graph drawings: left-drag pans, the wheel zooms at the pointer, double-click
# or Fit returns to the starting view. The view is the SVG viewBox, so text
# and lines stay sharp at any zoom.
GRAPH_JS = '''(()=>{document.querySelectorAll('.bpg').forEach(box=>{const svg=box.querySelector('svg');if(!svg)return;
const home=svg.getAttribute('viewBox').split(' ').map(Number),full=(svg.dataset.full||'').split(' ').map(Number);
let v=home.slice(),drag=null;const maxW=Math.max(home[2]*4,full[2]*1.2||0),minW=home[2]/10;
const set=()=>svg.setAttribute('viewBox',v.join(' '));
const pt=e=>{const m=svg.getScreenCTM();return m?new DOMPoint(e.clientX,e.clientY).matrixTransform(m.inverse()):{x:0,y:0}};
const zoom=(f,p)=>{const w=Math.min(maxW,Math.max(minW,v[2]*f));f=w/v[2];
v=[p.x-(p.x-v[0])*f,p.y-(p.y-v[1])*f,v[2]*f,v[3]*f];set()};
const mid=()=>({x:v[0]+v[2]/2,y:v[1]+v[3]/2});
svg.addEventListener('pointerdown',e=>{if(e.button!==0)return;drag=pt(e);svg.setPointerCapture(e.pointerId);box.classList.add('dragging')});
svg.addEventListener('pointermove',e=>{if(!drag)return;const p=pt(e);v[0]-=p.x-drag.x;v[1]-=p.y-drag.y;set()});
const end=e=>{drag=null;box.classList.remove('dragging')};
svg.addEventListener('pointerup',end);svg.addEventListener('pointercancel',end);
svg.addEventListener('wheel',e=>{e.preventDefault();zoom(Math.pow(1.0015,e.deltaY),pt(e))},{passive:false});
const fit=()=>{v=home.slice();set()};svg.addEventListener('dblclick',fit);
box.querySelectorAll('[data-l]').forEach(b=>b.onclick=()=>{box.dataset.l=b.dataset.l;
box.querySelectorAll('[data-l]').forEach(x=>x.setAttribute('aria-pressed',x===b))});
box.querySelectorAll('[data-z]').forEach(b=>b.onclick=()=>{const z=b.dataset.z;
if(z==='fit')fit();else if(z==='all'&&full.length===4){v=full.slice();set()}else zoom(z==='in'?0.8:1.25,mid())})})})();'''

TEMPLATE = '''<!doctype html><html lang="en" data-theme="dark"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>{title}</title>
<style>{css}</style></head><body>
<header class="top"><div><h1>{title}</h1><p class="meta">{meta}<span class="when">Generated {when}{changelist}</span></p>{keys}</div>
<div class="ctl"><span class="seg" role="group" aria-label="Files"><button data-fold="open" title="Expand all files (e)">Expand all</button><button data-fold="shut" title="Collapse all files (c)">Collapse all</button></span>
<span class="seg layout" role="group" aria-label="Diff layout"><button data-view="split">Split</button><button data-view="unified">Unified</button></span>
<button id="theme" title="Switch light or dark">Theme</button></div></header>
{summary}
<div class="wrap"><nav id="files-nav" aria-label="Changed files"><ul>{nav}</ul></nav>
<button id="sidebar" type="button" aria-controls="files-nav" aria-expanded="true" aria-label="Collapse file list" title="Collapse file list"></button>
<main>{body}</main>
{keys}</div>
<script>{js}</script><script>{graph_js}</script></body></html>'''


def main():
    ap = argparse.ArgumentParser(description='Render a unified diff as styled, self-contained HTML.')
    ap.add_argument('diff', nargs='?', help='diff file (reads stdin if omitted)')
    ap.add_argument('-o', '--out', default='diff.html')
    ap.add_argument('--title', default='Changes')
    ap.add_argument('--notes', help='JSON of per-file notes, plus optional "_summary"')
    ap.add_argument('--blueprints', help='folder filled by bp_prepare.py and bp_export.py')
    ap.add_argument('--git-context', metavar='REPO', help='read whole files from this git repo so the page can expand omitted lines')
    ap.add_argument('--collapse', type=int, default=800, help='collapse files with more changed lines')
    ap.add_argument('--review', help="smartreview's report (as written, or JSON findings), shown as comments on their lines")
    a = ap.parse_args()
    try:
        run(a)
    except (OSError, ValueError) as e:  # json.JSONDecodeError is a ValueError
        sys.exit(f'diffview: {e}')


def run(a):
    if a.blueprints and not os.path.isfile(os.path.join(a.blueprints, 'manifest.json')):
        raise OSError(f'{a.blueprints} has no manifest.json. Run bp_prepare.py first.')
    if a.diff:
        text = read_text(a.diff)
    elif not sys.stdin.isatty():
        sys.stdin.reconfigure(encoding='utf-8', errors='replace')
        text = sys.stdin.read()
    else:
        text = ''
    notes = load_notes(a.notes) if a.notes else {}
    files = parse(text)
    if a.blueprints:
        attach_blueprints(files, a.blueprints)
    label = git_context(files, a.git_context) if a.git_context else None
    findings = load_review(a.review) if a.review else []
    unmatched = attach_review(files, findings)
    with open(a.out, 'w', encoding='utf-8') as fh:
        fh.write(render(files, a.title, notes, a.collapse, label, unmatched))
    read = [f for f in files if f.bp and f.bp[0] == 'bp']
    bps = sum(1 for f in read if f.bp[1]['reader'] == 'blueprint')
    extra = f', {bps} Blueprints' if bps else ''
    if len(read) > bps:
        extra += f', {len(read) - bps} other graph assets'
    failed = [f for f in files if f.bp and f.bp[0] == 'failed']
    if failed:
        extra += f', {len(failed)} assets not compared (export failed, see the page)'
    if a.review:
        inline = sum(len(f.placed) for f in files)
        extra += f', {len(findings)} review comments ({inline} on a shown line, {len(unmatched)} on no file in the diff)'
    print(f'{a.out}: {len(files)} files{extra}, +{sum(f.adds for f in files)} -{sum(f.dels for f in files)}')


if __name__ == '__main__':
    main()
