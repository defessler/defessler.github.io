#!/usr/bin/env python3
"""bp_read: read Unreal assets straight from their .uasset files, with no
editor, and write the same export bp_export.py writes. Python stdlib only.

  python bp_read.py <manifest.json>          # what bp_prepare.py and trail.py stage
  python bp_read.py --dump <asset.uasset>    # one file's T3D, to stdout

For each asset in the manifest it reads the old revision (old_file), and the
new one from new_file or the working tree (<project dir>/<file>). Output per
side, under <out>/<side>/, matches bp_export.py's:
  <flat>.json      {"schema": 2, "reader", "status", "package", "class", "source": "file", ...}
  <flat>.t3d       the asset and its subobjects (graphs, nodes, pins, components)
  <flat>.cdo.t3d   a Blueprint's class default object
The T3D is written the way the editor writes it, close enough for diffview.py.
Both sides of an asset always come from one reader, so the two can't disagree
on format.

The readers pick an asset by what it holds, never by its class name's text:
  blueprint  a root with ParentClass and GeneratedClass (Anim and Widget Blueprints too)
  material   expressions with a MaterialExpressionGuid
  edgraph    any other asset that saves graph nodes with pins
Beyond the editor's export, the generated class's subobjects (component
templates, the construction script's nodes, a Widget Blueprint's widget tree)
are written too, so a changed component shows.

A value it can't decode (a plugin struct with its own binary form) is written
as a hash of its bytes, so a change to it still shows as a change. An object
it can't read at all is written with one SmartDiffUnread property, the same
way, and listed under "unread" in the .json. Only a root it can't read fails
the asset (status export_failed), and then bp_export.py in the editor is the
fallback. Layouts follow the UE 5.8 source: PackageFileSummary.cpp,
ObjectResource.cpp, PropertyTag.cpp, EdGraphPin.cpp, TextHistory.cpp.
"""
import argparse, hashlib, json, os, struct, sys

SCHEMA = 2
TAG = 0x9E2A83C1
# EUnrealEngineObjectUE5Version
OPTIONAL_RESOURCES, LARGE_WORLD_COORDINATES = 1003, 1004
REMOVE_EXPORT_PACKAGE_GUID, TRACK_EXPORT_IS_INHERITED = 1005, 1006
SOFTPATH_NO_ASSET_FNAMES, SOFTPATH_LIST = 1007, 1008
SCRIPT_SERIALIZATION_OFFSET, TAG_EXTENSIONS, TAG_COMPLETE_TYPE = 1010, 1011, 1012
PACKAGE_SAVED_HASH = 1016
MIN_UE4 = 516  # VER_UE4_ADDED_PACKAGE_SUMMARY_LOCALIZATION_ID, older summaries differ
PKG_FILTER_EDITOR_ONLY, PKG_UNVERSIONED = 0x80000000, 0x2000
# Custom version GUIDs, as four uint32 in hex, and the versions that move a field.
FORTNITE_MAIN = '601D1886AC644F84AA16D3DE0DEAC7D6'  # 192 UTF-8 soft paths, 260 FText dev notes
UE5_MAIN = '697DD581E64F41ABAA4A51ECBEB7B628'       # 50 EdGraphPinSourceIndex
UE5_RELEASE = 'D89B5E4224BD4D468412ACA8DF641779'    # 36 pin types save single precision
CONTAINERS = {0: 'None', 1: 'Array', 2: 'Set', 3: 'Map'}
DIRECTIONS = {0: 'EGPD_Input', 1: 'EGPD_Output'}
PIN_BITS = ('bHidden', 'bNotConnectable', 'bDefaultValueIsReadOnly', 'bDefaultValueIsIgnored',
            'bAdvancedView', 'bOrphanedPin')
GRAPH_LISTS = ('UbergraphPages', 'FunctionGraphs', 'MacroGraphs', 'DelegateSignatureGraphs')


class ReadError(Exception):
    pass


# What a malformed file can raise while it's read: that file's failure, never a crash.
BAD_DATA = (ReadError, struct.error, ValueError, IndexError, OverflowError, RecursionError, MemoryError)
NAME_SIZE = 1024  # UE's longest FName
# A T3D this many times its .uasset (or 64 MB) means a crafted file, not a real asset.
OUTPUT_RATIO, OUTPUT_FLOOR = 50, 64 * 2 ** 20


class R:
    """Little-endian reads over bytes, as FArchive writes them. A bool is 4 bytes."""

    def __init__(self, data, pos=0, end=None):
        self.d, self.p, self.end = data, pos, len(data) if end is None else end

    def take(self, n):
        if n < 0 or self.p + n > self.end:
            raise ReadError(f'read of {n} bytes runs past the data at {self.p}')
        b = self.d[self.p:self.p + n]
        self.p += n
        return b

    def unpack(self, fmt):
        return struct.unpack('<' + fmt, self.take(struct.calcsize('<' + fmt)))

    def i8(self): return self.unpack('b')[0]
    def u8(self): return self.take(1)[0]
    def i16(self): return self.unpack('h')[0]
    def u16(self): return self.unpack('H')[0]
    def i32(self): return self.unpack('i')[0]
    def u32(self): return self.unpack('I')[0]
    def i64(self): return self.unpack('q')[0]
    def u64(self): return self.unpack('Q')[0]
    def f32(self): return self.unpack('f')[0]
    def f64(self): return self.unpack('d')[0]

    def b32(self):
        v = self.u32()
        if v > 1:
            raise ReadError(f'bad bool {v} at {self.p - 4}')
        return bool(v)

    def guid(self):
        return ''.join(f'{x:08X}' for x in self.unpack('4I'))

    def fstr(self):
        n = self.i32()
        if n == 0:
            return ''
        if n > 0:
            return self.take(n)[:-1].decode('latin-1')
        if n == -2 ** 31:
            raise ReadError('bad string length')
        return self.take(-n * 2)[:-2].decode('utf-16-le', errors='replace')

    def utf8(self):
        n = self.i32()
        if n < 0:  # written as a wide string
            self.p -= 4
            return self.fstr()
        return self.take(n).rstrip(b'\0').decode('utf-8', errors='replace')


def quote(s):
    return '"' + s.replace('\\', '\\\\').replace('"', '\\"').replace('\n', '\\n').replace('\r', '\\r') \
        .replace('\t', '\\t') + '"'


def num(v):
    return f'{v:.6f}'


def opaque(kind, data):
    return f'<binary {kind}, {len(data)} bytes, #{hashlib.sha1(data).hexdigest()[:10]}>'


class Type:
    """A property's type as FPropertyTypeName holds it: a name and its parameters.
    StructProperty(Vector(/Script/CoreUObject)), ArrayProperty(IntProperty)."""
    __slots__ = ('name', 'params')

    def __init__(self, name, params=()):
        self.name, self.params = name, list(params)

    def param(self, i=0):
        return self.params[i] if i < len(self.params) else None

    def __str__(self):
        return self.name + (f'({",".join(map(str, self.params))})' if self.params else '')


class Package:
    def __init__(self, data, package=None):
        self.data = data
        r = R(data)
        if r.u32() != TAG:
            raise ReadError('not an Unreal package (bad magic)')
        legacy = r.i32()
        if legacy > -7:
            raise ReadError(f'package summary version {legacy} is older than UE 4.x editor assets')
        if legacy != -4:
            r.i32()  # UE3 version
        self.ue4 = r.i32()
        self.ue5 = r.i32() if legacy <= -8 else 0
        r.i32()  # licensee version
        if self.ue4 == 0 and self.ue5 == 0:
            raise ReadError('unversioned package (cooked), not an editor asset')
        if self.ue4 < MIN_UE4:
            raise ReadError(f'UE4 package version {self.ue4} is older than this reader supports ({MIN_UE4})')
        if self.ue5 >= PACKAGE_SAVED_HASH:
            r.take(20)
            r.i32()  # TotalHeaderSize
        self.custom = {}
        for _ in range(r.i32()):
            g = r.guid()
            self.custom[g] = r.i32()
        if self.ue5 < PACKAGE_SAVED_HASH:
            r.i32()  # TotalHeaderSize
        self.saved_name = r.fstr()
        self.flags = r.u32()
        if self.flags & (PKG_FILTER_EDITOR_ONLY | PKG_UNVERSIONED):
            raise ReadError('cooked package (editor-only data stripped), not an editor asset')
        name_count, name_off = r.i32(), r.i32()
        soft_count = soft_off = 0
        if self.ue5 >= SOFTPATH_LIST:
            soft_count, soft_off = r.i32(), r.i32()
        r.fstr()  # LocalizationId
        r.i32(); r.i32()  # gatherable text
        exp_count, exp_off = r.i32(), r.i32()
        imp_count, imp_off = r.i32(), r.i32()
        for n, what in ((name_count, 'names'), (exp_count, 'exports'), (imp_count, 'imports')):
            if not 0 <= n < 10 ** 7:
                raise ReadError(f'bad {what} count {n}')
        self.lwc = self.ue5 >= LARGE_WORLD_COORDINATES
        self.tags_v2 = self.ue5 >= TAG_COMPLETE_TYPE
        rn = R(data, name_off)
        self.names = []
        for _ in range(name_count):
            self.names.append(rn.fstr())
            if len(self.names[-1]) > NAME_SIZE:
                raise ReadError(f'a name of {len(self.names[-1])} characters, over UE\'s {NAME_SIZE}')
            rn.take(4)  # two uint16 hashes
        ri = R(data, imp_off)
        self.imports = []
        for _ in range(imp_count):
            imp = {'class_package': self.fname(ri), 'class': self.fname(ri), 'outer': ri.i32(), 'name': self.fname(ri)}
            self.fname(ri)  # PackageName
            if self.ue5 >= OPTIONAL_RESOURCES:
                ri.b32()
            self.imports.append(imp)
        re_ = R(data, exp_off)
        self.exports = []
        for _ in range(exp_count):
            e = {'class': re_.i32(), 'super': re_.i32(), 'template': re_.i32(), 'outer': re_.i32(),
                 'name': self.fname(re_), 'flags': re_.u32(), 'size': re_.i64(), 'off': re_.i64()}
            re_.b32(); re_.b32(); re_.b32()  # forced export, not for client, not for server
            if self.ue5 < REMOVE_EXPORT_PACKAGE_GUID:
                re_.take(16)
            if self.ue5 >= TRACK_EXPORT_IS_INHERITED:
                re_.b32()
            re_.u32()  # package flags
            re_.b32(); re_.b32()  # not always loaded for editor game, is asset
            if self.ue5 >= OPTIONAL_RESOURCES:
                re_.b32()
            for _ in range(5):
                re_.i32()  # dependency counts
            e['ss'] = e['se'] = 0
            if self.ue5 >= SCRIPT_SERIALIZATION_OFFSET:
                e['ss'], e['se'] = re_.i64(), re_.i64()
            if e['size'] < 0 or e['off'] < 0 or e['off'] + e['size'] > len(data):
                raise ReadError(f'export {e["name"]} lies outside the file (a cooked or split package?)')
            self.exports.append(e)
        spans = sorted((e['off'], e['off'] + e['size']) for e in self.exports if e['size'])
        if any(a[1] > b[0] for a, b in zip(spans, spans[1:])):
            raise ReadError('two exports share bytes, which no saved package does')
        # Names and paths are where a small file can write a big T3D, so they count against a budget.
        self.budget = max(OUTPUT_FLOOR, OUTPUT_RATIO * len(data))
        self.soft_paths = []
        if soft_count:
            rs = R(data, soft_off)
            self.soft_paths = [self.soft_path_inline(rs) for _ in range(soft_count)]
        self.package = package or self.saved_name or '/Temp/Unknown'
        self._paths, self.ctx = {}, 0

    def cv(self, guid):
        return self.custom.get(guid, 0)

    # ------------------------------------------------------------- names, objects
    def fname(self, r):
        i, n = r.i32(), r.i32()
        if not 0 <= i < len(self.names):
            raise ReadError(f'name index {i} out of range')
        s = self.names[i]
        self.spend(len(s))
        return s if n == 0 else f'{s}_{n - 1}'

    def spend(self, n):
        self.budget = getattr(self, 'budget', OUTPUT_FLOOR) - n
        if self.budget < 0:
            raise ReadError(f'the T3D would be over {OUTPUT_RATIO} times the file\'s size, so the file is malformed')

    def ename(self, r):
        """An FName the editor writes as text: None is empty."""
        s = self.fname(r)
        return '' if s == 'None' else s

    def resource(self, idx):
        if idx > 0 and idx <= len(self.exports):
            return self.exports[idx - 1]
        if idx < 0 and -idx <= len(self.imports):
            return self.imports[-idx - 1]
        if idx == 0:
            return None
        raise ReadError(f'object index {idx} out of range')

    def obj_name(self, idx):
        res = self.resource(idx)
        return res['name'] if res else None

    def path(self, idx):
        """Full object path: /Script/Engine.Actor, /Game/A/B.B:EventGraph.K2Node_0.
        Charged on every return, the first build included, whoever keeps it."""
        if idx in self._paths:
            self.spend(len(self._paths[idx]))
            return self._paths[idx]
        chain, i = [], idx
        while i:
            res = self.resource(i)
            chain.append(res['name'])
            i = res['outer']
            if len(chain) > 64:
                raise ReadError('outer chain loops')
        chain.reverse()
        if idx > 0:  # an export: the package is the file itself, named the way the manifest names it
            chain.insert(0, self.package)
        out = chain[0]
        for depth, part in enumerate(chain[1:]):
            out += ('.' if depth == 0 else ':' if depth == 1 else '.') + part
        self.spend(len(out))  # at most 64 names of NAME_SIZE, so one build stays small
        self._paths[idx] = out
        return out

    def class_path(self, idx):
        res = self.resource(idx)
        if res is None:
            return '/Script/CoreUObject.Object'
        if idx < 0:
            return f'{res["class_package"]}.{res["class"]}'
        return self.path(res['class']) if res['class'] else '/Script/CoreUObject.Class'

    def class_name(self, e):
        res = self.resource(e['class'])
        return res['name'] if res else 'Class'

    def ref(self, idx):
        """An object reference as the editor exports it: "Class'Path'", or None.
        An object in this package is named the way T3D names it, relative to the
        object being read when it's inside it, else without the package."""
        if idx == 0:
            return 'None'
        path = self.path(idx)
        if idx > 0:
            ctx = self.path(self.ctx) if self.ctx else None
            if ctx and path.startswith(ctx) and path[len(ctx):len(ctx) + 1] in ('.', ':'):
                path = path[len(ctx) + 1:]
            elif path.startswith(self.package + '.'):
                path = path[len(self.package) + 1:]
        out = quote(f"{self.class_path(idx)}'{path}'")
        self.spend(len(out))
        return out

    # ------------------------------------------------------------------ text
    def ftext(self, r):
        r.u32()  # flags
        h = r.i8()
        if h == -1:
            return f'INVTEXT({quote(r.fstr())})' if r.b32() else '""'
        if h == 0:  # Base
            ns, key, src = r.fstr(), r.fstr(), r.fstr()
            if self.cv(FORTNITE_MAIN) >= 260:  # AddDevNotesToFText
                r.fstr()
            return f'NSLOCTEXT({quote(ns)}, {quote(key)}, {quote(src)})'
        if h in (1, 2):  # NamedFormat, OrderedFormat
            fmt, args = self.ftext(r), []
            for _ in range(r.i32()):
                name = r.fstr() if h == 1 else None
                t = r.i8()
                v = self.ftext(r) if t == 4 else str(r.i64()) if t == 0 else str(r.u64()) if t == 1 else \
                    num(r.f32()) if t == 2 else num(r.f64()) if t == 3 else str(r.u8()) if t == 5 else None
                if v is None:
                    raise ReadError(f'format argument type {t}')
                args.append(f'{quote(name)}, {v}' if name is not None else v)
            return f'LOCGEN_FORMAT_{"NAMED" if h == 1 else "ORDERED"}({", ".join([fmt] + args)})'
        if h == 9:  # Transform: source text and how it's transformed
            src = self.ftext(r)
            return f'LOCGEN_TOUPPER({src})' if r.u8() == 1 else f'LOCGEN_TOLOWER({src})'
        if h == 11:  # StringTableEntry
            table = self.fname(r)
            return f'LOCTABLE({quote(table)}, {quote(r.fstr())})'
        raise ReadError(f'FText history {h} is not read')

    # ------------------------------------------------------------- soft paths
    def soft_path_inline(self, r):
        if self.ue5 < SOFTPATH_NO_ASSET_FNAMES:
            asset, sub = self.fname(r), r.fstr()
        else:
            pkg, name = self.fname(r), self.fname(r)
            asset = '' if pkg == 'None' else pkg + ('.' + name if name != 'None' else '')
            sub = r.utf8() if self.cv(FORTNITE_MAIN) >= 192 else r.fstr()
        if asset in ('', 'None'):
            return ''
        return asset + (':' + sub if sub else '')

    def soft_path(self, r):
        if self.soft_paths:
            i = r.i32()
            if not 0 <= i < len(self.soft_paths):
                raise ReadError(f'soft object path index {i} out of range')
            return self.soft_paths[i]
        return self.soft_path_inline(r)

    # --------------------------------------------------------- property tags
    def type_tree(self, r):
        name, count = self.fname(r), r.i32()
        if not 0 <= count < 64:
            raise ReadError(f'bad type parameter count {count}')
        return Type(name, [self.type_tree(r) for _ in range(count)])

    def tag(self, r):
        """One FPropertyTag, or None at the end of the list."""
        name = self.fname(r)
        if name == 'None':
            return None
        t = {'name': name, 'index': 0, 'bool': False, 'native': False, 'skipped': False}
        if self.tags_v2:
            t['type'] = self.type_tree(r)
            t['size'], flags = r.i32(), r.u8()
            if flags & 0x01:
                t['index'] = r.i32()
            if flags & 0x02:
                r.take(16)  # property guid
            if flags & 0x04:
                self.tag_extensions(r)
            t['native'], t['bool'], t['skipped'] = bool(flags & 0x08), bool(flags & 0x10), bool(flags & 0x20)
        else:
            kind = self.fname(r)
            t['size'], t['index'] = r.i32(), r.i32()
            params = []
            if kind == 'StructProperty':
                params = [Type(self.fname(r))]
                r.take(16)  # struct guid
            elif kind == 'BoolProperty':
                t['bool'] = bool(r.u8())
            elif kind in ('ByteProperty', 'EnumProperty'):
                enum = self.fname(r)
                params = [Type(enum)] if enum != 'None' else []
            elif kind in ('ArrayProperty', 'SetProperty', 'OptionalProperty'):
                params = [Type(self.fname(r))]
            elif kind == 'MapProperty':
                params = [Type(self.fname(r)), Type(self.fname(r))]
            t['type'] = Type(kind, params)
            if r.u8():
                r.take(16)  # property guid
            if self.ue5 >= TAG_EXTENSIONS:
                self.tag_extensions(r)
            t['native'] = None  # not recorded before UE 5.4, known structs decide
        if t['size'] < 0 or r.p + t['size'] > r.end:
            raise ReadError(f'property {name} size {t["size"]} runs past its object')
        return t

    def tag_extensions(self, r):
        ext = r.u8()
        if ext & 0x02:
            r.u8(); r.b32()  # override operation, experimental overridable logic
        if ext & 0x04:
            r.b32()  # experimental external objects

    def props(self, r):
        """[(name, value)] for a tagged property list. A top-level array or a
        static array element becomes Name(i), the way T3D writes them."""
        out = []
        while True:
            t = self.tag(r)
            if t is None:
                return out
            start = r.p
            end = start + t['size']
            key = t['name'] if t['index'] == 0 else f'{t["name"]}({t["index"]})'
            if t['skipped']:
                r.p = end
                continue
            if t['type'].name == 'BoolProperty':
                out.append((key, 'True' if t['bool'] else 'False'))
                r.p = end
                continue
            sub = R(self.data, start, end)
            try:
                if t['type'].name == 'ArrayProperty' and t['index'] == 0:
                    items = self.array(sub, t['type'], t['native'])
                    if sub.p != end:
                        raise ReadError('array ended early')
                    for i, v in enumerate(items):
                        key = f'{t["name"]}({i})'
                        self.spend(len(key))  # one long name, a key per element
                        out.append((key, v))
                else:
                    v = self.item(sub, t['type'], t['native'])
                    if sub.p != end:
                        raise ReadError(f'value ended {end - sub.p} bytes early')
                    out.append((key, v))
            except BAD_DATA:
                out.append((key, opaque(str(t['type']), self.data[start:end])))
            r.p = end

    def array(self, r, t, native):
        inner = t.param() or Type('None')
        n = r.i32()
        if not 0 <= n <= r.end - r.p:
            raise ReadError(f'bad array count {n}')
        if not self.tags_v2 and inner.name == 'StructProperty':
            it = self.tag(r)  # an inner tag names the struct
            inner = it['type'] if it else inner
        return [self.item(r, inner, native) for _ in range(n)]

    def item(self, r, t, native=None):
        """One value of type t as T3D writes it. Every value is charged to the
        budget as it's made, so a short reference to a long cached string
        (a path, a soft path, a name) can't build output the budget never sees."""
        v = self.value(r, t, native)
        self.spend(len(v))
        return v

    def value(self, r, t, native=None):
        k = t.name
        if k == 'BoolProperty':
            return 'True' if r.u8() else 'False'
        if k == 'ByteProperty':
            enum = t.param()
            if enum is not None and enum.name != 'None':
                return self.enum_value(self.fname(r))
            return str(r.u8())
        ints = {'Int8Property': 'i8', 'Int16Property': 'i16', 'IntProperty': 'i32', 'Int64Property': 'i64',
                'UInt16Property': 'u16', 'UInt32Property': 'u32', 'UInt64Property': 'u64'}
        if k in ints:
            return str(getattr(r, ints[k])())
        if k == 'FloatProperty':
            return num(r.f32())
        if k == 'DoubleProperty':
            return num(r.f64())
        if k == 'NameProperty':
            return quote(self.fname(r))
        if k == 'StrProperty':
            return quote(r.fstr())
        if k in ('Utf8StrProperty', 'AnsiStrProperty'):
            return quote(r.utf8())
        if k == 'TextProperty':
            return self.ftext(r)
        if k == 'EnumProperty':
            return self.enum_value(self.fname(r))
        if k in ('ObjectProperty', 'ClassProperty', 'InterfaceProperty', 'WeakObjectProperty', 'ObjectPtrProperty',
                 'ClassPtrProperty'):
            return self.ref(r.i32())
        if k == 'LazyObjectProperty':
            return r.guid()
        if k in ('SoftObjectProperty', 'SoftClassProperty'):
            p = self.soft_path(r)
            return quote(p) if p else 'None'
        if k == 'DelegateProperty':
            obj, fn = r.i32(), self.fname(r)
            return quote(f'{self.path(obj)}.{fn}') if obj else quote(fn)
        if k in ('MulticastDelegateProperty', 'MulticastInlineDelegateProperty', 'MulticastSparseDelegateProperty'):
            out = []
            for _ in range(self.count(r)):
                obj, fn = r.i32(), self.fname(r)
                out.append(quote(f'{self.path(obj)}.{fn}' if obj else fn))
            return '(' + ','.join(out) + ')'
        if k == 'FieldPathProperty':
            names = [self.fname(r) for _ in range(self.count(r))]
            owner = r.i32()
            return quote(':'.join(names) + (f' ({self.path(owner)})' if owner else '')) if names else 'None'
        if k == 'StructProperty':
            return self.struct(r, t.param() or Type('None'), native)
        if k == 'ArrayProperty':
            return '(' + ','.join(self.array(r, t, native)) + ')'
        if k in ('SetProperty', 'MapProperty'):
            kt = t.param(0) or Type('None')
            vt = (t.param(1) or Type('None')) if k == 'MapProperty' else None
            # First what this instance removed from its archetype's entries (-1:
            # it replaces them all), then its own entries. A removal is a change
            # of its own, so it's written too.
            n = r.i32()
            replace = n == -1
            if not replace:
                r.p -= 4
                n = self.count(r)
            removed = [self.item(r, kt, native) for _ in range(max(n, 0))]
            entries = []
            for _ in range(self.count(r)):
                key = self.item(r, kt, native)
                entries.append(f'({key}, {self.item(r, vt, native)})' if vt else key)
            body = '(' + ','.join(entries) + ')'
            if removed:
                body = f'(Removed=({",".join(removed)}),Entries={body})'
            return f'(Replace=True,Entries={body})' if replace else body
        if k == 'OptionalProperty':
            return self.item(r, t.param() or Type('None'), native) if r.b32() else 'None'
        raise ReadError(f'property type {k} is not read')

    def count(self, r):
        n = r.i32()
        if not 0 <= n <= r.end - r.p:
            raise ReadError(f'bad element count {n}')
        return n

    @staticmethod
    def enum_value(v):
        return v.split('::', 1)[1] if '::' in v else v

    # ------------------------------------------------------------- structs
    def struct(self, r, st, native):
        name = st.name
        decode = NATIVE.get(name)
        if native is None:  # before UE 5.4: known structs are binary, the rest tagged
            native = decode is not None
        if not native:
            return '(' + ','.join(f'{k}={v}' for k, v in self.props_nested(r)) + ')'
        if decode is None:
            raise ReadError(f'struct {name} has a binary form this reader doesn\'t know')
        return decode(self, r)

    def props_nested(self, r):
        """A struct's own properties. Unlike the top level, an array stays one
        value, (a,b), the way T3D writes a struct member."""
        out = []
        while True:
            t = self.tag(r)
            if t is None:
                return out
            start, end = r.p, r.p + t['size']
            key = t['name'] if t['index'] == 0 else f'{t["name"]}({t["index"]})'
            if t['skipped']:
                r.p = end
                continue
            if t['type'].name == 'BoolProperty':
                out.append((key, 'True' if t['bool'] else 'False'))
                r.p = end
                continue
            sub = R(self.data, start, end)
            try:
                v = self.item(sub, t['type'], t['native'])
                if sub.p != end:
                    raise ReadError('value ended early')
            except BAD_DATA:
                v = opaque(str(t['type']), self.data[start:end])
            out.append((key, v))
            r.p = end

    def vec(self, r, n, wide):
        f = r.f64 if wide else r.f32
        return [num(f()) for _ in range(n)]

    def pin_type(self, r, as_struct=False):
        """FEdGraphPinType's binary form, as (fields in T3D order)."""
        f = [('PinCategory', quote(self.ename(r))), ('PinSubCategory', quote(self.ename(r))),
             ('PinSubCategoryObject', self.ref(r.i32()))]
        container = r.u8()
        value = '()'
        if container == 3:  # a map's value type
            cat, sub, obj = self.ename(r), self.ename(r), r.i32()
            const, weak, wrapper = r.b32(), r.b32(), r.b32()
            value = (f'(TerminalCategory={quote(cat)},TerminalSubCategory={quote(sub)},'
                     f'TerminalSubCategoryObject={self.ref(obj)},bTerminalIsConst={const},'
                     f'bTerminalIsWeakPointer={weak},bTerminalIsUObjectWrapper={wrapper})')
        ref, weak = r.b32(), r.b32()
        parent, member, mguid = r.i32(), self.fname(r), r.guid()
        mref = []
        if parent:
            mref.append(f'MemberParent={self.ref(parent)}')
        if member != 'None':
            mref.append(f'MemberName={quote(member)}')
        if mguid != '0' * 32:
            mref.append(f'MemberGuid={mguid}')
        const, wrapper = r.b32(), r.b32()
        single = r.b32() if self.cv(UE5_RELEASE) >= 36 else False
        f += [('PinSubCategoryMemberReference', '(' + ','.join(mref) + ')'), ('PinValueType', value),
              ('ContainerType', CONTAINERS.get(container, str(container))), ('bIsReference', str(ref)),
              ('bIsConst', str(const)), ('bIsWeakPointer', str(weak)), ('bIsUObjectWrapper', str(wrapper)),
              ('bSerializeAsSinglePrecisionFloat', str(single))]
        if as_struct:  # a variable's type: only what isn't default, as the editor writes it
            dflt = {'""', 'None', '()', 'False'}
            return '(' + ','.join(f'{k}={v}' for k, v in f if v not in dflt) + ')'
        return f

    def expression_input(self, r, constant=None):
        expr, out = r.i32(), r.i32()
        name = self.fname(r)
        masks = [r.i32() for _ in range(5)]
        parts = [f'Expression={self.ref(expr)}' if expr else 'Expression=None']
        if out:
            parts.append(f'OutputIndex={out}')
        if name != 'None':
            parts.append(f'InputName={quote(name)}')
        if masks[0]:
            parts += [f'Mask={masks[0]}'] + [f'Mask{c}={m}' for c, m in zip('RGBA', masks[1:])]
        if constant:
            use = r.b32()
            value = constant(self, r)
            if use:
                parts += ['UseConstant=True', f'Constant={value}']
        return '(' + ','.join(parts) + ')'

    # --------------------------------------------------------------- objects
    def read_object(self, i):
        """(props, pins or None) for export i. pins is a list for a graph node."""
        e = self.exports[i]
        if self.ue5 >= SCRIPT_SERIALIZATION_OFFSET and e['se'] <= e['ss']:
            raise ReadError('saved in its own binary form, with no tagged properties')
        r = R(self.data, e['off'] + e['ss'], e['off'] + e['size'])
        self.ctx = i + 1  # references are written relative to this object
        if self.ue5 >= TAG_EXTENSIONS:  # class serialization control
            if r.u8() & 0x02:
                r.u8()  # overridden property operation
        props = self.props(r)
        if not any(k == 'NodeGuid' for k, _ in props):
            return props, None  # what follows the properties is the class's own, and not read
        # A graph node: UObject's lazy-pointer guid, then UEdGraphNode's pins.
        if e['se']:
            r.p = e['off'] + e['se']
        if r.b32():
            r.take(16)
        return props, [p for p in (self.pin(r) for _ in range(self.count(r))) if p is not None]

    def pin_ref(self, r):
        if r.b32():
            return None
        return r.i32(), r.guid()

    def pin(self, r):
        """One UEdGraphPin, owned by the node being read, as T3D fields."""
        if r.b32():  # a null pin
            return None
        r.i32(); r.guid()  # the reference to it: owning node and pin id
        r.i32()  # then the pin itself: owning node again
        f = [('PinId', r.guid()), ('PinName', quote(self.fname(r)))]
        friendly = self.ftext(r)
        if friendly != '""':
            f.append(('PinFriendlyName', friendly))
        if self.cv(UE5_MAIN) >= 50:
            r.i32()  # SourceIndex
        tip = r.fstr()
        if tip:
            f.append(('PinToolTip', quote(tip)))
        f.append(('Direction', quote(DIRECTIONS.get(r.u8(), 'EGPD_Input'))))
        f += [('PinType.' + k, v) for k, v in self.pin_type(r)]
        dv, auto, obj, text = r.fstr(), r.fstr(), r.i32(), self.ftext(r)
        if dv:
            f.append(('DefaultValue', quote(dv)))
        if auto:
            f.append(('AutogeneratedDefaultValue', quote(auto)))
        if obj:
            f.append(('DefaultObject', self.ref(obj)))
        if text != '""':
            f.append(('DefaultTextValue', text))
        links = [x for x in (self.pin_ref(r) for _ in range(self.count(r))) if x]
        subs = [x for x in (self.pin_ref(r) for _ in range(self.count(r))) if x]
        link = lambda x: f'{self.obj_name(x[0]) or "None"} {x[1]}'
        if links:
            f.append(('LinkedTo', '(' + ''.join(link(x) + ',' for x in links) + ')'))
        if subs:
            f.append(('SubPins', '(' + ''.join(link(x) + ',' for x in subs) + ')'))
        parent = self.pin_ref(r)
        if parent:
            f.append(('ParentPin', link(parent)))
        through = self.pin_ref(r)
        if through:
            f.append(('ReferencePassThroughConnection', link(through)))
        f.append(('PersistentGuid', r.guid()))
        bits = r.u32()
        f += [(name, 'True' if bits & (1 << n) else 'False') for n, name in enumerate(PIN_BITS)]
        self.spend(sum(len(k) + len(v) + 2 for k, v in f))
        return f


def _vec(n, wide=None, names='XYZW'):
    def read(pkg, r):
        vals = pkg.vec(r, n, pkg.lwc if wide is None else wide)
        return '(' + ','.join(f'{c}={v}' for c, v in zip(names, vals)) + ')'
    return read


def _box(n):
    def read(pkg, r):
        a, b = _vec(n)(pkg, r), _vec(n)(pkg, r)
        return f'(Min={a},Max={b},IsValid={r.u8()})'
    return read


def _ints(names, fmt='i32'):
    return lambda pkg, r: '(' + ','.join(f'{c}={getattr(r, fmt)()}' for c in names) + ')'


def _material_input(constant):
    return lambda pkg, r: pkg.expression_input(r, constant)


_f32 = lambda pkg, r: num(r.f32())
_u32 = lambda pkg, r: str(r.u32())

# Structs saved in their own binary form (WithSerializer, or immutable), by name.
NATIVE = {
    'Guid': lambda pkg, r: r.guid(),
    'Vector': _vec(3), 'Vector3d': _vec(3, True), 'Vector3f': _vec(3, False),
    'Vector2D': _vec(2), 'Vector2d': _vec(2, True), 'Vector2f': _vec(2, False),
    'DeprecateSlateVector2D': _vec(2, False),
    'Vector4': _vec(4), 'Vector4d': _vec(4, True), 'Vector4f': _vec(4, False),
    'Rotator': _vec(3, None, ('Pitch', 'Yaw', 'Roll')), 'Rotator3d': _vec(3, True, ('Pitch', 'Yaw', 'Roll')),
    'Rotator3f': _vec(3, False, ('Pitch', 'Yaw', 'Roll')),
    'Quat': _vec(4), 'Quat4d': _vec(4, True), 'Quat4f': _vec(4, False),
    'Plane': _vec(4), 'Plane4d': _vec(4, True), 'Plane4f': _vec(4, False),
    'Box': _box(3), 'Box3d': _box(3), 'Box2D': _box(2), 'Box2d': _box(2),
    'LinearColor': _vec(4, False, 'RGBA'),
    'Color': lambda pkg, r: '(' + ','.join(f'{c}={v}' for c, v in zip('BGRA', r.take(4))) + ')',
    'IntPoint': _ints('XY'), 'IntVector2': _ints('XY'), 'IntVector': _ints('XYZ'), 'IntVector4': _ints('XYZW'),
    'RichCurveKey': lambda pkg, r: '(InterpMode={},TangentMode={},TangentWeightMode={},'.format(*r.take(3)) +
        ','.join(f'{k}={num(r.f32())}' for k in ('Time', 'Value', 'ArriveTangent', 'ArriveTangentWeight',
                                                  'LeaveTangent', 'LeaveTangentWeight')) + ')',
    'Int64Point': _ints('XY', 'i64'), 'Int64Vector': _ints('XYZ', 'i64'),
    'DateTime': lambda pkg, r: str(r.i64()), 'Timespan': lambda pkg, r: str(r.i64()),
    'FrameNumber': lambda pkg, r: f'(Value={r.i32()})',
    'SoftObjectPath': lambda pkg, r: quote(pkg.soft_path(r)), 'SoftClassPath': lambda pkg, r: quote(pkg.soft_path(r)),
    'TopLevelAssetPath': lambda pkg, r: quote(f'{pkg.fname(r)}.{pkg.fname(r)}'),
    'EdGraphPinType': lambda pkg, r: pkg.pin_type(r, as_struct=True),
    'ExpressionInput': _material_input(None), 'MaterialAttributesInput': _material_input(None),
    'ColorMaterialInput': _material_input(_vec(4, False, 'RGBA')),
    'ScalarMaterialInput': _material_input(_f32),
    'ShadingModelMaterialInput': _material_input(_u32), 'SubstrateMaterialInput': _material_input(_u32),
    'VectorMaterialInput': _material_input(_vec(3, False)), 'Vector2MaterialInput': _material_input(_vec(2, False)),
}


# ------------------------------------------------------------------ assets

def root_index(pkg):
    """The asset's own export: the top-level one named after the package."""
    short = pkg.package.rsplit('/', 1)[-1]
    tops = [i for i, e in enumerate(pkg.exports) if e['outer'] == 0]
    for i in tops:
        if pkg.exports[i]['name'] == short:
            return i
    for i in tops:  # RF_Standalone, the asset a package exists for
        if pkg.exports[i]['flags'] & 0x2 and not pkg.exports[i]['name'].startswith('Default__'):
            return i
    raise ReadError('no asset export in the package')


TYPE_CLASSES = {'Class', 'Function', 'DelegateFunction', 'SparseDelegateFunction', 'ScriptStruct', 'Enum'}


def is_type_object(pkg, e):
    """A class, function or struct: compiled output, saved in its own form
    rather than as tagged properties."""
    if e['class'] == 0:
        return True
    return e['class'] < 0 and pkg.path(e['class']).split('.', 1) == ['/Script/CoreUObject', pkg.obj_name(e['class'])] \
        and pkg.obj_name(e['class']) in TYPE_CLASSES


class Asset:
    """One revision read: its objects in export order, nested by outer."""

    def __init__(self, data, package):
        self.pkg = pkg = Package(data, package)
        self.root = root_index(pkg)
        self.objs, self.unread = {}, []
        e_root = pkg.exports[self.root]
        try:
            self.root_props, _ = pkg.read_object(self.root)  # a root it can't read fails the asset
        except ReadError as err:
            if 'own binary form' not in str(err):
                raise
            self.root_props = []  # nothing tagged to read, so no reader will claim it
        gen = dict(self.root_props).get('GeneratedClass', 'None')
        self.gen = next((i for i, e in enumerate(pkg.exports) if e['outer'] == 0 and gen != 'None' and
                         e['name'] == short(gen)), None)
        if self.gen is None:
            self.gen = next((i for i, e in enumerate(pkg.exports) if e['outer'] == 0 and
                             e['name'] == e_root['name'] + '_C'), None)
        cdo_name = f'Default__{pkg.exports[self.gen]["name"]}' if self.gen is not None else None
        self.cdo = next((i for i, e in enumerate(pkg.exports) if e['outer'] == 0 and e['name'] == cdo_name), None)
        self.children = {}
        for i, e in enumerate(pkg.exports):
            self.children.setdefault(e['outer'] - 1, []).append(i)
        self.objs[self.root] = (self.root_props, None)

    def read(self, i):
        if i in self.objs:
            return self.objs[i]
        try:
            got = self.pkg.read_object(i)
        except BAD_DATA as err:
            e = self.pkg.exports[i]
            raw = self.pkg.data[e['off']:e['off'] + e['size']]
            self.unread.append(f'{self.pkg.path(i + 1)} ({self.pkg.class_name(e)}): {err}')
            got = ([('SmartDiffUnread', quote(opaque(self.pkg.class_name(e), raw)))], None)
        self.objs[i] = got
        return got

    def tree(self, top):
        """Export indices under top that hold data, compiled types left out."""
        out = []
        for c in self.children.get(top, []):
            if not is_type_object(self.pkg, self.pkg.exports[c]):
                out.append(c)
        return out

    def t3d(self, tops, nest_tops=True):
        class Lines(list):  # every line written is charged, so the T3D can't outgrow its budget
            def append(inner, line):
                self.pkg.spend(len(line) + 1)
                list.append(inner, line)
        lines = Lines()

        def emit(i, depth):
            e = self.pkg.exports[i]
            pad = '   ' * depth
            props, pins = self.read(i)
            lines.append(f'{pad}Begin Object Class={self.pkg.class_path(i + 1)} Name={quote(e["name"])} '
                         f'ExportPath={quote(self.pkg.class_path(i + 1) + chr(39) + self.pkg.path(i + 1) + chr(39))}')
            for c in self.tree(i):
                emit(c, depth + 1)
            for k, v in props:
                lines.append(f'{pad}   {k}={v}')
            for p in pins or ():
                lines.append(f'{pad}   CustomProperties Pin (' + ''.join(f'{k}={v},' for k, v in p) + ')')
            lines.append(f'{pad}End Object')
        for t in tops:
            emit(t, 0)
        return '\n'.join(lines) + '\n'

    def everything(self):
        """Every export the main T3D covers, for the readers' tests."""
        seen, todo = [], [self.root] + (self.tree(self.gen) if self.gen is not None else [])
        while todo:
            i = todo.pop()
            seen.append(i)
            todo.extend(self.tree(i))
        return seen

    def reader(self):
        names = lambda i: {k for k, _ in self.read(i)[0]}
        root = names(self.root)
        if 'ParentClass' in root and 'GeneratedClass' in root:
            return 'blueprint'
        every = self.everything()
        if any('MaterialExpressionGuid' in names(i) for i in every):
            return 'material'
        if any(self.read(i)[1] is not None for i in every):
            return 'edgraph'
        return None


def short(v):
    v = v.strip('"')
    if "'" in v:
        v = v.split("'")[1]
    return v.replace(':', '.').rsplit('.', 1)[-1]


def dump(data, package, out_dir, flat):
    """Read one revision and write its .json, .t3d and .cdo.t3d. Returns the record."""
    os.makedirs(out_dir, exist_ok=True)
    meta = {'schema': SCHEMA, 'package': package, 'source': 'file', 'reader': None, 'status': 'unsupported'}
    try:
        a = Asset(data, package)
        pkg = a.pkg
        meta['class'] = pkg.class_name(pkg.exports[a.root])
        meta['engine'] = {'ue4': pkg.ue4, 'ue5': pkg.ue5}
        reader = a.reader()
        meta['reader'] = reader
        if reader:
            tops = [a.root]
            if reader == 'blueprint':
                props = dict(a.root_props)
                meta['parent'] = short(props['ParentClass']) if props.get('ParentClass', 'None') != 'None' else None
                meta['graphs'] = [short(v) for k, v in a.root_props if k.split('(')[0] in GRAPH_LISTS]
                tops += [c for c in a.tree(a.gen)] if a.gen is not None else []
            elif reader == 'edgraph':
                meta['graphs'] = sorted({pkg.exports[pkg.exports[i]['outer'] - 1]['name'] for i in a.everything()
                                         if a.read(i)[1] is not None and pkg.exports[i]['outer'] > 0})
            text = a.t3d([tops[0]])
            # The generated class's subobjects sit beside the root, keyed by their own path.
            text += a.t3d(tops[1:]) if len(tops) > 1 else ''
            with open(os.path.join(out_dir, flat + '.t3d'), 'w', encoding='utf-8', newline='\n') as fh:
                fh.write(text)
            meta['t3d'] = True
            if reader == 'blueprint' and a.cdo is not None:
                with open(os.path.join(out_dir, flat + '.cdo.t3d'), 'w', encoding='utf-8', newline='\n') as fh:
                    fh.write(a.t3d([a.cdo]))
                meta['cdo'] = True
            meta['status'] = 'ok'
        if a.unread:  # capped, a Control Rig alone has thousands of binary link objects
            meta['unread_count'] = len(a.unread)
            meta['unread'] = a.unread[:50]
    except BAD_DATA + (KeyError,) as err:
        meta['status'] = 'export_failed'
        meta['error'] = f'bp_read: {err}. bp_prepare.py --reader editor reads it in the editor instead.'
        meta['t3d'] = False
    with open(os.path.join(out_dir, flat + '.json'), 'w', encoding='utf-8') as fh:
        json.dump(meta, fh, indent=1)
    return meta


def failed(out_dir, flat, package, why):
    os.makedirs(out_dir, exist_ok=True)
    meta = {'schema': SCHEMA, 'package': package, 'source': 'file', 'reader': None,
            'status': 'load_failed', 'error': why}
    with open(os.path.join(out_dir, flat + '.json'), 'w', encoding='utf-8') as fh:
        json.dump(meta, fh, indent=1)
    return meta


def read_manifest(path):
    """Read every asset a manifest lists. Returns [(package, side, record)]."""
    with open(path, encoding='utf-8') as fh:
        man = json.load(fh)
    out = man.get('out') or os.path.dirname(os.path.abspath(path))
    root = os.path.dirname(man['project']) if man.get('project') else None
    done = []
    for a in man.get('assets', []):
        pkg, flat = a['package'], a['flat']
        sides = []
        if a.get('new_file'):
            sides.append(('new', a['new_file']))
        elif a.get('new'):
            sides.append(('new', os.path.join(root, a['file']) if root else None))
        if a.get('old_file'):
            sides.append(('old', a['old_file']))
        for side, src in sides:
            folder = os.path.join(out, side)
            try:
                with open(src, 'rb') as fh:
                    data = fh.read()
            except (OSError, TypeError) as err:
                done.append((pkg, side, failed(folder, flat, pkg, f'could not read the {side} revision: {err}')))
                continue
            done.append((pkg, side, dump(data, pkg, folder, flat)))
    return done


def summary_line(pkg, side, meta):
    st = meta['status']
    extra = f', {meta["unread_count"]} objects read as a hash only' if meta.get('unread_count') else ''
    why = f': {meta["error"]}' if meta.get('error') else ''
    return f'{pkg} ({side}): {meta.get("reader") or "no reader"}, {st}{extra}{why}'


def main(argv=None):
    ap = argparse.ArgumentParser(description='Read Unreal assets from their files for diffview.py, no editor.')
    ap.add_argument('manifest', nargs='?', help="bp_prepare.py's manifest.json")
    ap.add_argument('--dump', metavar='UASSET', help="print one file's T3D and stop")
    ap.add_argument('--package', help='package name for --dump (default: the one saved in the file)')
    a = ap.parse_args(argv)
    if a.dump:
        with open(a.dump, 'rb') as fh:
            asset = Asset(fh.read(), a.package)
        tops = [asset.root] + (asset.tree(asset.gen) if asset.gen is not None else [])
        sys.stdout.write(asset.t3d(tops) + (asset.t3d([asset.cdo]) if asset.cdo is not None else ''))
        for u in asset.unread:
            print(f'unread: {u}', file=sys.stderr)
        return 0
    if not a.manifest:
        ap.error('name a manifest.json, or --dump a .uasset')
    results = read_manifest(a.manifest)
    for pkg, side, meta in results:
        print(summary_line(pkg, side, meta))
    return 1 if any(m['status'] in ('export_failed', 'load_failed') for _, _, m in results) else 0


if __name__ == '__main__':
    sys.exit(main())
