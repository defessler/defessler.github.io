"""bp_export: dump Blueprint assets to T3D text so diffview.py can diff them.

Runs inside the Unreal Editor's Python, usually headless:

  UnrealEditor-Cmd.exe Game.uproject -run=pythonscript -script="bp_export.py <manifest.json>"
      -unattended -nop4 -nosplash -NullRHI

bp_prepare.py writes the manifest and prints that command. For each asset it
exports the working-tree version (by package name) and the old revision (a
copy of the old file, staged under /Game/__SmartDiffOld/ because LoadPackage
won't read a file outside a mounted content root). An asset with "new_file"
in the manifest (a shelved revision) has its new side staged the same way,
instead of loaded from the workspace. The staged copies are removed again at
the end. Output per side, under <out>/<side>/:
  <flat>.json      {"package", "class", "parent", "graphs": [authored graph names]}
  <flat>.t3d       the Blueprint and every subobject (graphs, nodes, pins, components)
  <flat>.cdo.t3d   the class default object (non-default class defaults)
"""
import json, os, shutil, sys
import unreal

STAGE = '__SmartDiffOld'
L = unreal.BlueprintEditorLibrary


def read_text(fn):
    with open(fn, 'rb') as fh:
        raw = fh.read()
    if raw[:2] in (b'\xff\xfe', b'\xfe\xff'):
        return raw.decode('utf-16')
    return raw.decode('utf-8-sig', errors='replace')


def export_t3d(obj, fn):
    t = unreal.AssetExportTask()
    t.object, t.filename = obj, fn
    t.automated, t.prompt, t.replace_identical = True, False, True
    try:
        ok = unreal.Exporter.run_asset_export_task(t)
    except Exception as e:  # noqa: BLE001 - report and keep going
        unreal.log_warning(f'smartdiff: export failed for {obj}: {e}')
        return False
    if ok and os.path.exists(fn):
        text = read_text(fn)  # normalise to UTF-8 for diffview
        with open(fn, 'w', encoding='utf-8', newline='\n') as fh:
            fh.write(text)
    return bool(ok)


def dump(asset, out_dir, flat, package):
    os.makedirs(out_dir, exist_ok=True)
    meta = {'package': package, 'class': asset.get_class().get_name()}
    if isinstance(asset, unreal.Blueprint):
        parent = L.get_blueprint_parent_class(asset)
        meta['parent'] = parent.get_name() if parent else None
        meta['graphs'] = [str(n) for n in L.list_graph_names(asset)]
        meta['t3d'] = export_t3d(asset, os.path.join(out_dir, flat + '.t3d'))
        gen = L.generated_class(asset)
        if gen:
            cdo = unreal.get_default_object(gen)
            meta['cdo'] = export_t3d(cdo, os.path.join(out_dir, flat + '.cdo.t3d'))
    with open(os.path.join(out_dir, flat + '.json'), 'w', encoding='utf-8') as fh:
        json.dump(meta, fh, indent=1)
    return meta


def main():
    if len(sys.argv) < 2:
        unreal.log_error('smartdiff: usage bp_export.py <manifest.json>')
        return
    with open(sys.argv[1], encoding='utf-8') as fh:
        man = json.load(fh)
    out = man['out']
    content = unreal.Paths.convert_relative_path_to_full(unreal.Paths.project_content_dir())
    stage_dir = os.path.join(content, STAGE)
    staged = []

    def dump_staged(src, slot, side, pkg, flat):
        """Copy a revision into the staging folder, load it from there and dump it."""
        base = pkg.rsplit('/', 1)[1]
        dst_dir = os.path.join(stage_dir, slot)
        os.makedirs(dst_dir, exist_ok=True)
        dst = os.path.join(dst_dir, base + os.path.splitext(src)[1])
        shutil.copyfile(src, dst)
        staged.append(dst)
        asset = unreal.load_asset(f'/Game/{STAGE}/{slot}/{base}')
        if not asset:
            unreal.log_warning(f'smartdiff: could not load {side} revision of {pkg}')
            return
        dump(asset, os.path.join(out, side), flat, pkg)
        # Unload so the linker drops its file handle before cleanup.
        package = asset.get_outermost()
        asset = None
        unreal.EditorLoadingAndSavingUtils.unload_packages([package])

    try:
        for i, a in enumerate(man['assets']):
            pkg, flat = a['package'], a['flat']
            # A dot in a package path would read as an object name, so slots are a0, n0, a1...
            if a.get('new_file'):  # a shelved revision, not in the workspace
                dump_staged(a['new_file'], f'n{i}', 'new', pkg, flat)
            elif a.get('new'):
                asset = unreal.load_asset(pkg)
                if asset:
                    dump(asset, os.path.join(out, 'new'), flat, pkg)
                else:
                    unreal.log_warning(f'smartdiff: could not load {pkg}')
            if a.get('old_file'):
                dump_staged(a['old_file'], f'a{i}', 'old', pkg, flat)
    finally:
        if staged:
            unreal.SystemLibrary.collect_garbage()
            for fn in staged:
                if os.path.exists(fn):
                    try:
                        os.remove(fn)
                    except OSError as e:
                        unreal.log_warning(f'smartdiff: remove {fn} by hand: {e}')
            shutil.rmtree(stage_dir, ignore_errors=True)


main()
