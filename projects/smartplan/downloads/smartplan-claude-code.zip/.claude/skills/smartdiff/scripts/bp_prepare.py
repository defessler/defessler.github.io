#!/usr/bin/env python3
"""bp_prepare: find changed Unreal assets, fetch their old revisions, and write
the manifest bp_export.py reads. Python stdlib only.

  python bp_prepare.py --project Game.uproject --out work/bp            # git
  python bp_prepare.py --project Game.uproject --out work/bp --p4 [-c CL]
  python bp_prepare.py --project Game.uproject --out work/bp --p4 -c CL --shelved
  python bp_prepare.py ... --run        # also runs the headless export

Old revisions come from HEAD (git, Git LFS pointers are smudged) or #have (p4).
A shelved changelist has nothing opened, so both sides come from the server:
the revision each file was shelved against, and the shelved file itself
(<depotFile>@=CL). -c on a changelist with nothing opened reads its shelf
without being asked.
Levels (.umap) are listed but not exported. Their Level Blueprint isn't covered yet.
"""
import argparse, json, os, re, subprocess, sys

ASSET_EXT = ('.uasset', '.umap')


def run(cmd, cwd, binary=False, stdin=None):
    r = subprocess.run(cmd, cwd=cwd, capture_output=True, input=stdin)
    if r.returncode:
        raise RuntimeError(f'{" ".join(cmd)} failed: {r.stderr.decode(errors="replace").strip()}')
    return r.stdout if binary else r.stdout.decode('utf-8', errors='replace')


def package_name(rel):
    """Content/A/B.uasset -> /Game/A/B, Plugins/../X/Content/A.uasset -> /X/A."""
    rel = rel.replace('\\', '/')
    stem = os.path.splitext(rel)[0]
    m = re.match(r'(?:.*/)?Plugins/(?:.*/)?([^/]+)/Content/(.+)$', stem)
    if m:
        return f'/{m.group(1)}/{m.group(2)}'
    if stem.startswith('Content/'):
        return '/Game/' + stem[len('Content/'):]
    return None


def git_changes(root):
    out = []
    for line in run(['git', 'diff', '--name-status', '--relative', 'HEAD'], root).splitlines():
        parts = line.split('\t')
        st, path = parts[0][:1], parts[-1]
        if path.lower().endswith(ASSET_EXT):
            out.append((path, {'A': 'added', 'D': 'deleted'}.get(st, 'modified')))
    for path in run(['git', 'ls-files', '--others', '--exclude-standard'], root).splitlines():
        if path.lower().endswith(ASSET_EXT):
            out.append((path, 'added'))
    return out


def git_old(root, rel, dst):
    data = run(['git', 'show', f'HEAD:./{rel}'], root, binary=True)
    if data.startswith(b'version https://git-lfs'):
        data = run(['git', 'lfs', 'smudge'], root, binary=True, stdin=data)
    with open(dst, 'wb') as fh:
        fh.write(data)


def p4_status(action):
    return 'added' if 'add' in action or 'branch' in action else \
           'deleted' if 'delete' in action else 'modified'


def p4_rel(root, depot):
    """Depot path -> path relative to the project, or None when the client
    view doesn't map it or it sits outside the project folder."""
    try:
        lines = run(['p4', '-ztag', '-F', '%path%', 'where', depot], root).strip().splitlines()
    except RuntimeError:
        return None
    if not lines:
        return None
    rel = os.path.relpath(lines[-1], root).replace('\\', '/')
    return None if rel.startswith('..') or os.path.isabs(rel) else rel


def p4_opened(root, cl):
    """[(depotFile, action)] for every opened file, assets or not."""
    cmd = ['p4', '-ztag', '-F', '%depotFile%\t%action%', 'opened']
    if cl:
        cmd += ['-c', cl]
    return [tuple(line.split('\t')) for line in run(cmd + ['./...'], root).splitlines() if '\t' in line]


def p4_shelved(root, cl):
    """[(depotFile, action, rev)] for a shelved changelist. rev is the revision
    the shelved file was based on, so depotFile#rev is the old side and
    depotFile@=CL is the new one."""
    fields = {}
    for line in run(['p4', '-ztag', 'describe', '-S', '-s', cl], root).splitlines():
        m = re.match(r'^\.\.\. (depotFile|action|rev)(\d+) (.*)$', line.rstrip('\r'))
        if m:
            fields.setdefault(int(m.group(2)), {})[m.group(1)] = m.group(3)
    return [(f['depotFile'], f.get('action', 'edit'), f.get('rev', ''))
            for _, f in sorted(fields.items()) if 'depotFile' in f]


def p4_changes(root, cl, shelved=False):
    """[(rel, status, old spec, new spec)], and whether the shelf was read.
    A spec is what `p4 print` takes. A None new spec means the workspace file."""
    opened, shelf, failed = [], [], None
    if not shelved:
        try:
            opened = p4_opened(root, cl)
        except RuntimeError as e:  # a changelist owned by another client can refuse `opened -c`
            if not cl:
                raise
            failed = e
    if cl and not opened:
        # Nothing opened under this changelist here. A shelved one looks like
        # that from any workspace, so read the shelf instead of reporting zero.
        shelf = p4_shelved(root, cl)
        shelved = shelved or bool(shelf)
        if failed and not shelf:
            raise failed
    out, unmapped = [], []
    if shelved:
        for depot, action, rev in shelf:
            if not depot.lower().endswith(ASSET_EXT):
                continue
            rel, st = p4_rel(root, depot), p4_status(action)
            if rel is None:
                unmapped.append(depot)
                continue
            old = f'{depot}#{rev}' if st != 'added' and rev.isdigit() else None
            out.append((rel, 'added' if old is None and st == 'modified' else st, old,
                        None if st == 'deleted' else f'{depot}@={cl}'))
    else:
        for depot, action in opened:
            if not depot.lower().endswith(ASSET_EXT):
                continue
            rel = p4_rel(root, depot)
            if rel is None:
                unmapped.append(depot)
                continue
            out.append((rel, p4_status(action), depot + '#have', None))
    return out, shelved, unmapped


def find_editor(uproject):
    with open(uproject, encoding='utf-8') as fh:
        ver = json.load(fh).get('EngineAssociation', '')
    for base in (os.environ.get('ProgramFiles', r'C:\Program Files'),):
        exe = os.path.join(base, 'Epic Games', f'UE_{ver}', 'Engine', 'Binaries', 'Win64', 'UnrealEditor-Cmd.exe')
        if os.path.exists(exe):
            return exe
    return None


def main():
    ap = argparse.ArgumentParser(description='Prepare old/new Blueprint exports for diffview.')
    ap.add_argument('--project', required=True, help='path to the .uproject')
    ap.add_argument('--out', required=True, help='scratch folder for the export')
    ap.add_argument('--p4', action='store_true', help='use Perforce opened files instead of git')
    ap.add_argument('-c', '--changelist', help='p4 changelist to limit to')
    ap.add_argument('--shelved', action='store_true',
                    help='read the changelist from its shelf (automatic when -c names one with nothing opened)')
    ap.add_argument('--editor', help='UnrealEditor-Cmd.exe (default: launcher install for the project)')
    ap.add_argument('--run', action='store_true', help='run the headless export after preparing')
    a = ap.parse_args()

    uproject = os.path.abspath(a.project)
    root, out = os.path.dirname(uproject), os.path.abspath(a.out)
    src = os.path.join(out, 'src')
    os.makedirs(src, exist_ok=True)
    if a.shelved and not a.changelist:
        sys.exit('--shelved needs -c <CL>.')
    shelved, skipped = False, []
    if a.p4 or a.shelved:
        changes, shelved, skipped = p4_changes(root, a.changelist, a.shelved)
    else:
        changes = [c + (None, None) for c in git_changes(root)]

    assets = []
    for rel, status, old_spec, new_spec in changes:
        pkg = package_name(rel)
        if not pkg or rel.lower().endswith('.umap'):
            skipped.append(rel)
            continue
        flat = pkg.strip('/').replace('/', '.')
        ext = os.path.splitext(rel)[1]
        entry = {'file': rel, 'package': pkg, 'flat': flat, 'status': status,
                 'new': status != 'deleted', 'old_file': None}
        if status != 'added':
            dst = os.path.join(src, flat + ext)
            if old_spec:
                run(['p4', 'print', '-q', '-o', dst, old_spec], root)
            else:
                git_old(root, rel, dst)
            entry['old_file'] = dst
        if new_spec:  # a shelved revision isn't in the workspace, so it gets staged like the old one
            dst = os.path.join(src, 'new', flat + ext)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            run(['p4', 'print', '-q', '-o', dst, new_spec], root)
            entry['new_file'] = dst
        assets.append(entry)

    man = os.path.join(out, 'manifest.json')
    with open(man, 'w', encoding='utf-8') as fh:
        json.dump({'out': out, 'project': uproject, 'assets': assets, 'skipped': skipped}, fh, indent=1)
    editor = a.editor or find_editor(uproject)
    script = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'bp_export.py')
    # UE reads -script="<file> <args>" from the raw command line, so build the
    # string by hand. A list would quote the whole switch and lose the argument.
    fwd = lambda p: p.replace('\\', '/')
    cmd = (f'"{editor or "UnrealEditor-Cmd.exe"}" "{uproject}" -run=pythonscript '
           f'-script="{fwd(script)} {fwd(man)}" -EnablePlugins=PythonScriptPlugin '
           '-unattended -nop4 -nosplash -NullRHI -stdout')
    where = f' from the shelf of changelist {a.changelist}' if shelved else ''
    print(f'{man}: {len(assets)} assets to export{where}, {len(skipped)} skipped '
          '(levels, outside Content, or not in the client view)')
    if not assets:
        return
    if a.run:
        if not editor:
            sys.exit('UnrealEditor-Cmd.exe not found. Pass --editor.')
        with open(os.path.join(out, 'export.log'), 'wb') as log:
            rc = subprocess.run(cmd, stdout=log, stderr=subprocess.STDOUT).returncode
        print(f'export finished with exit code {rc}, log in {os.path.join(out, "export.log")}')
    else:
        print('Run: ' + cmd)


if __name__ == '__main__':
    main()
