---
name: smartflow
description: smartplan part. The fan-out flow (plan, human gate, parallel leaves, verify, integrate) and its run-state and contract shapes. Load before any fan-out.
user-invocable: false
---

# smartflow — part of smartplan

The fan-out half of smartplan. Read
[`references/flow.md`](references/flow.md) whole and follow it end to
end before any dispatch. It holds the human plan-review gate, the
model-role matrix, the canonical fail-twice rule and the per-harness
dispatch notes. [`references/artifacts.md`](references/artifacts.md)
holds the shapes for `run-state.md`, `contracts.md` and the dispatch
board.

When this skill is off, smartplan never fans out. Every route runs
inline, with a lone verify where its table asks for one.
