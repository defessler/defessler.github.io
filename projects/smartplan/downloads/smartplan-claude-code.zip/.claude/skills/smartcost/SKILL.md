---
name: smartcost
description: smartplan part. The quality-cost dial from max-quality to max-savings, its per-knob matrix and the budget preflight. Load when a run names a mode or a budget.
user-invocable: false
---

# smartcost — part of smartplan

The quality↔cost dial. Read [`references/modes.md`](references/modes.md)
whole for the five modes, the per-knob matrix, the budget preflight and
the mode-invariant floors no mode may lower.

When this skill is off, smartplan runs the default mode its Cost mode
rule names for your harness, with no dial.
