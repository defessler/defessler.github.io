# smartreview — project overlay

A standards doc is a whole checklist. Most projects don't want their own.
They want the shipped one plus a few product rules: the Engine set, the
prefix filled in, two rows of their own, one base row turned off. An
overlay holds just that. The base doc keeps getting fixes. The overlay
keeps only what's yours.

## Where it lives

Take the first that exists:

1. A path the project's CLAUDE.md, AGENTS.md or style guide gives for
   `{{STANDARDS}}`.
2. `REVIEW-STANDARDS.md` at the repo root.

A file there with an `Extends:` line is an overlay. One without is a full
standards doc, used on its own as before.

## Shape

```markdown
# <Product> review standards

Extends: cpp-review-standards.md

## Profile
Engine: unreal
UE: 5.9
PREFIX: Ly
MODULE: LyraGame
LOG: LogLyra
Indentation: tabs
Max line length: none
Local-variable case: PascalCase

## Rows
- P1 [P] BREAKING: Every ability that spends a resource checks
  CanCommit before Commit. A miss double-spends on a laggy client.
- P2 [U] PRACTICE: Gameplay tags come from the native tag table, never
  RequestGameplayTag with a literal.

## Changes
- C5 → N/A: every unit in the project is SI, stated in Source/README.md.
- K6 → CONVENTION: the old Utils module is being folded in, file by file.

## Procedure
- Read Config/Tags/*.ini with any change that adds a gameplay tag.
```

- **`Extends:`** names the base doc, a file name in `references/` or a
  path. Load the base in full, then apply the overlay on top.
- **`## Profile`** sets the base doc's selector and tokens, and the
  driver's three knobs. A line here counts as stated, so it beats
  detection. `UE:` beats the engine probe's version. Leave a token out
  and the base doc's rule for it holds.
- **`## Rows`** adds rows. Give each an ID the base doc doesn't use (`P1`,
  `P2`), a tag from the base doc's legend, a severity from its severity
  map, and the failure in one line. An added row runs like a base row:
  PASS, FAIL or N/A, counted in the tally.
- **`## Changes`** changes a base row by ID: a new severity, or `N/A`.
  Each needs a reason after the colon. A row the base doc marks engine-
  or build-enforced (the C++ doc's [U]) can't be relaxed below its
  severity. Say so under Ambiguous rather than applying it.
- **`## Procedure`** adds steps, run after the base doc's own.

## On the report

The Standards line names both:
`Standards: REVIEW-STANDARDS.md over cpp-review-standards.md · Engine: unreal (stated) · UE 5.9 (stated)`.
A finding on an added row cites its ID (`P1`) like any other.
