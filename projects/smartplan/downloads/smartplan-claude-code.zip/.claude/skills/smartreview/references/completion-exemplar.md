# Completion exemplar

A short source file that shows a project's conventions in code, kept open
in an editor tab so inline completions copy it.

## Why it exists

Inline completions (ghost text and next edit suggestions) never read
instruction files. Copilot's custom instructions, `AGENTS.md`, this skill's
standards doc and every resident rule reach Chat and agent sessions only.
Completions read the code around the cursor and related files open in the
editor, so a file in an open tab is the one way conventions reach them.

**Unmeasured.** Vendor docs say open files feed completions, and an issue on
the language server shows they sometimes stay on the focused file anyway. Run
the check in § Proving it works before you rely on it.

## When to build one

When someone asks for a completion exemplar, a conventions exemplar, or a way
to make inline suggestions follow house style. One file per language the
project writes by hand.

## Inputs, all resolved first

- `{{STANDARDS}}` and its profile selector, as the review protocol
  resolves them.
- The three knobs: indentation, max line length, local-variable case.
- Two or three real files the user names as good examples of house style.
  Read them for patterns the standards doc leaves open (comment voice,
  include grouping, blank-line rhythm). Don't pick them from file
  extensions.

If any is unset, ask. Never invent a convention. A guessed knob teaches
every suggestion the wrong style, quietly.

## What goes in it

- **Only correct code.** Completions copy what they see: no bad examples,
  before/after pairs, or commented-out anti-patterns.
- **Every line earns its place.** Aim for 80 to 150 lines. Completions
  take snippets of neighboring files rather than the whole thing, so
  dense beats thorough.
- **Cover each rule the standards doc can show in code**, one instance each:
  - file header, include or import order and grouping
  - naming for types, functions, members, locals, booleans, constants and
    enums
  - indentation, brace placement and line length, from the knobs
  - comment style, matching the project's own voice
  - null and error handling, ownership, and container choice
  - logging, when the doc has logging rules
  - one complete, realistic function that combines the above
- **Rules the doc tags as externally enforced** (the C++ doc's **[U]**) are
  shown exactly as the engine or toolchain requires.
- **Synthetic names only.** Invent a small domain (an inventory, a timer
  queue). Never copy proprietary code.
- **It must parse cleanly**, with every symbol declared in the file or a
  standard header. Red squiggles pull suggestions toward fixing them.

## Where it goes

`docs/conventions-exemplar.<ext>` by default, or the project's docs folder.
Keep it out of every build target (in Unreal, outside `Source/`). The path
doesn't matter to completions, only the open tab.

## Checking it before handing it over

Run this skill's protocol on the exemplar against the same `{{STANDARDS}}`.
It must return zero CONVENTION and zero PRACTICE findings, since each one is
a convention it would teach wrong. Then compile or lint it standalone where
the language allows.

## Using it

Open it in a tab beside the file you're editing, same language, and pin it.
Regenerate it whenever the standards doc or a knob changes.

## Proving it works

A small A/B test, about an hour, that costs completions rather than chat
credits:

1. Pick five function stubs the project needs, each with a one-line intent
   comment.
2. Arm A: only the target file open. Accept the first suggestion for each
   stub and save it.
3. Arm B: same stubs, same completions model, with the exemplar pinned
   beside it.
4. Review both arms with this skill against `{{STANDARDS}}` and compare the
   CONVENTION counts.

If Arm B doesn't cut them, the exemplar isn't reaching completions on that
editor, and there's no reason to maintain it there.
