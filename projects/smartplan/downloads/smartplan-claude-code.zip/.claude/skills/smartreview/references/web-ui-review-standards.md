# smartreview: web UI review standards

A second standards doc for `{{STANDARDS}}`, for HTML and CSS a person
will look at: a landing page, an app screen, a component, or a page one
of this family's renderers writes. Point `{{STANDARDS}}` at this file and
`../SKILL.md` runs as usual: the breaking hunt first, then this checklist,
then one report in three ranked categories.

It's a condensed form of [hallmark](https://github.com/nutlope/hallmark)'s
gates. Hallmark's goal is a page that looks made, not generated. Its core
is a floor that never ships, a tier of model reflexes a page may overrule
with a stated reason, and a fresh-context reviewer with the last word.
That core maps onto smartreview's three categories and its verifier seat,
so it lives here. Hallmark's themes, photo library, linter and build
rotation don't. Install hallmark itself to build pages with them.
Provenance is at the end, and each row cites hallmark's gate number.

## Contents

- Project Profile
- Severity map
- Breaking classes
- Per-file checklist
- Building to this doc
- Hard rules (this doc's additions)
- Provenance

## Project Profile

| Token | Meaning | This project | Shipped |
| --- | --- | --- | --- |
| **Surface** | `component`, `screen` or `page`. Gates which tagged rows run | `component` *(shipped default)* | Set `page` for a landing or marketing page, `screen` for one someone works in (a dashboard, settings, a tool) |
| `{{TOKENS}}` | Where the design tokens live: a `:root` block, a `tokens.css`, a Tailwind config | _fill in_ | `:root` of the reviewed stylesheet |

**Surface** ships at `component`, the narrowest, so rows written for a
marketing page never fire at a widget. The three knobs in the driver
(indentation, line length, local-variable case) apply to CSS and markup
as they do to code, and stay N/A until filled.

### Rule tags

| Tag | Meaning | Active when |
| --- | --- | --- |
| **[G]** | Any UI | Every surface |
| **[L]** | A landing or marketing page: hero, sections, footer | `Surface = page` |
| **[S]** | An app screen, dense and worked in | `Surface = screen` |

Composition: `component` runs [G], `screen` runs [G] and [S], `page`
runs [G] and [L].

**Waivable** is a second, separate mark. A waivable row is a reflex, a
default a model falls into that a page can still choose on purpose. A
FAIL on it is waived only by a comment in the stylesheet's first 40
lines, in the form `/* waive C6 · <reason> */`. The reason has to be
about this page and share a word with it. One under 24 characters, or
boilerplate reused across pages, doesn't count, and the row fails. Rows
without the mark are the floor and can't be waived.

## Severity map

**BREAKING** means someone can't read, reach, operate or trust the
page: text below its contrast threshold, a control a keyboard can't
see, motion with no way to stop it, content that never appears, a page
that scrolls sideways, or a claim nobody made.

**PRACTICE** is a named mechanism that makes the page worse without
breaking it. Most rows here are machine-made tells, the defaults that
make a page read as generated. They cost the page its credibility,
which is what PRACTICE measures here.

**CONVENTION is the default.** Every row not named BREAKING or PRACTICE
is CONVENTION: spacing scale, measure, small craft details.

Two placement rules keep BREAKING honest:

1. **A tell is never BREAKING.** However often a pattern reads as
   machine-made, it doesn't stop anyone using the page.
2. **The failure follows from the row alone.** A display head without
   `overflow-wrap` only breaks with a long enough word, so it's PRACTICE.
   A page that does scroll sideways at 320px is BREAKING.

> BREAKING rows: A6, A7, C1, C10, E1, E2, E4, F2, F3, F4, F6

## Breaking classes

The hunt sweeps these before the checklist, reading what the page does,
not which rule it breaks. Name the class on every BREAKING finding.

| Class | Ask |
| --- | --- |
| **Access** | Can a keyboard user see focus, a low-vision user read it, a motion-sensitive user stop it? |
| **Layout break** | Does anything scroll sideways, overlap, or cover text at any width from 320 to 1920? |
| **Hidden content** | Does anything stay invisible without JavaScript, fail to load, or load too late to matter? |
| **Honesty** | Is every number, quote, logo and confirmation real, and does each form really send? |

## Per-file checklist

Every row is PASS, FAIL or N/A. Hallmark's gate number is in the last
column.

### A. Colour and tokens

| # | FAIL when | Tag | Severity | Hallmark |
| --- | --- | --- | --- | --- |
| A1 | A colour or `font-family` literal appears outside `{{TOKENS}}` | [G] | CONVENTION | 48 |
| A2 | Pure `#000` or `#fff` used as a colour outside the token block | [G] | CONVENTION | 7a |
| A3 | A purple-to-blue, purple-to-pink or cyan-on-dark gradient, `background-clip: text` included | [G] | PRACTICE | 2a |
| A4 | A framework's stock swatch (Tailwind's indigo-500, violet-600, slate-900 and kin) as a token or utility. Waivable | [G] | PRACTICE | 74 |
| A5 | Aurora or mesh blobs, floating blurred orbs, or a coloured glow behind text. Waivable | [G] | PRACTICE | 29 |
| A6 | Text, icon, focus ring or field edge under its contrast threshold: 4.5:1 for body text, 3:1 for large text, icons and rings | [G] | BREAKING | 40 |
| A7 | Button text within about 5% lightness of its fill, or a dark panel whose text tokens don't swap | [G] | BREAKING | 41 |

### B. Type

| # | FAIL when | Tag | Severity | Hallmark |
| --- | --- | --- | --- | --- |
| B1 | Inter, Roboto, Open Sans, Poppins, Lato or a system face as the display face. Waivable | [L] | PRACTICE | 1 |
| B2 | More than three font families | [G] | CONVENTION | 37 |
| B3 | One word or phrase in a heading set apart by italic, colour, weight, highlight or underline | [G] | PRACTICE | 38i, 38iii |
| B4 | An eyebrow: short inert text above a heading that announces it, in any form (stacked, pill, ordinal, category tag) | [G] | PRACTICE | 54 |
| B5 | A label, caption, table head, nav link, tag or chip at 15px or under set in capitals, small caps or with added letter-spacing | [G] | PRACTICE | 67 |
| B6 | Monospace on labels, captions or meta rows when the content isn't code and neither main face is mono. Waivable | [G] | PRACTICE | 64 |
| B7 | Running text under 12px, or multi-line prose leaded under 1.3 | [G] | PRACTICE | 75 |
| B8 | Running prose outside a 45 to 75 character measure | [G] | CONVENTION | 25 |
| B9 | A display head without `overflow-wrap: break-word; min-width: 0` | [G] | PRACTICE | 50 |

### C. Layout

| # | FAIL when | Tag | Severity | Hallmark |
| --- | --- | --- | --- | --- |
| C1 | The page scrolls sideways at any width from 320 to 1920 | [G] | BREAKING | 34 |
| C2 | `overflow-x: hidden` or a `100vw` width where `overflow-x: clip` on `html` and `body` would do | [G] | CONVENTION | 34 |
| C3 | An image-bearing grid track on bare `1fr` rather than `minmax(0, 1fr)` | [G] | PRACTICE | 50 |
| C4 | A card inside a card | [G] | PRACTICE | 4 |
| C5 | The container has no `max-width`, or a grid gains columns at 1920 | [L] [S] | PRACTICE | 44d |
| C6 | The template page: hero, three equal icon-tile columns, a call to action, footer. Waivable | [L] | PRACTICE | 3, 8 |
| C7 | The hero's headline, one sentence and primary action aren't all visible at 1280 x 800, or the hero is sized in `vh` | [L] | PRACTICE | 6a, 44b |
| C8 | More than about 80 words on any one screen at 1440 | [L] | CONVENTION | 58 |
| C9 | A raw `padding`, `margin` or `gap` length where a spacing token exists | [G] | CONVENTION | 24a |
| C10 | Text painted under another element, two `position: sticky; top: 0` elements included | [G] | BREAKING | 56, 73 |
| C11 | A button label or primary nav link wraps at any width from 320 to 1920 | [G] | PRACTICE | 49a |
| C12 | An email sign-up as the last section on a page whose job isn't a newsletter. Waivable | [L] | PRACTICE | 85 |
| C13 | A control outside 44 to 52px tall on a page, or under 32px on a screen without an expanded hit target | [L] [S] | CONVENTION | 39b |

### D. Chrome and copy

| # | FAIL when | Tag | Severity | Hallmark |
| --- | --- | --- | --- | --- |
| D1 | Meta strings joined with middle dots, an arrow glued to link text (`Learn more →`), or decorative status dots | [G] | PRACTICE | 63 |
| D2 | Placeholder names (Jane Doe, Acme) or buzzwords (seamless, robust, empower, supercharge, effortless) | [G] | PRACTICE | 19 |
| D3 | An emoji standing in for an icon | [G] | PRACTICE | 30a |
| D4 | A hand-drawn browser bar or OS title bar. A device or terminal frame with real content inside is waivable | [G] | PRACTICE | 47a, 47b |
| D5 | Decoration text: scroll cues, a `BETA` pill in the hero, rotated text with nothing to say. Waivable | [L] | CONVENTION | 66 |
| D6 | One fact (a price, a date, a count) printed in four or more sections | [L] | CONVENTION | 69 |
| D7 | A decorative `<svg>` or `<canvas>` with neither `aria-hidden="true"` nor a label | [G] | PRACTICE | 33 |

### E. Honesty

| # | FAIL when | Tag | Severity | Hallmark |
| --- | --- | --- | --- | --- |
| E1 | An invented metric, testimonial, logo wall or case-study count | [G] | BREAKING | 46a |
| E2 | A form or control that prints success ("Sent", "You're on the list") with no request behind it | [G] | BREAKING | 70 |
| E3 | A built mock of a product that exists and could be captured instead. Waivable | [L] | PRACTICE | 84 |
| E4 | An `<img>` with no source or one that doesn't load, or `loading="lazy"` on the largest image above the fold | [G] | BREAKING | 28a, 76 |
| E5 | A borrowed photo with no credit on the page | [G] | PRACTICE | 76 |

### F. Motion and interaction

| # | FAIL when | Tag | Severity | Hallmark |
| --- | --- | --- | --- | --- |
| F1 | `transition: all`, or animating `width`, `height`, `top` or `left` | [G] | PRACTICE | 10a |
| F2 | A keyframe or transform transition with no `prefers-reduced-motion: reduce` fallback | [G] | BREAKING | 27 |
| F3 | An interactive element with no `:focus-visible`, an outline removed with nothing in its place, or a focus ring that fades in | [G] | BREAKING | 15, 26a |
| F4 | Content hidden at rest (`opacity: 0`, `visibility: hidden`) that only JavaScript reveals | [G] | BREAKING | 62 |
| F5 | Autoplaying video without `muted` | [G] | PRACTICE | 28a |
| F6 | Auto-rotating content with no pause on hover and focus | [G] | BREAKING | 18 |
| F7 | A focus ring built from `border`, or a border width that shifts between input states | [G] | PRACTICE | 39a |
| F8 | Bounce or overshoot easing on UI state. Waivable | [G] | CONVENTION | 12 |
| F9 | The same hover lift on every card, or more than one hover effect on one element. Waivable | [G] | CONVENTION | 11 |
| F10 | A form control with no `:active` or `:disabled` state | [G] | CONVENTION | 26b |

Checklist: 51 rows.

## Building to this doc

A project can hold its UI to this doc while it's written, not only at
review. When this doc is `{{STANDARDS}}` and you're building UI,
hallmark's order is the part worth keeping:

1. **Read the project first.** Its tokens, fonts, framework and any
   locked design system file win over anything you'd pick.
2. **Never invent a fact.** A number, quote or logo nobody gave is
   absent. A missing picture is a labelled slot, not a stand-in that
   reads as real.
3. **Build from the job.** Name what the visitor came to do and put that
   action where the category puts it.
4. **Hero first.** Build and check the first screen before the rest
   exists.
5. **Review away from the author.** Hand the finished page to the
   `smartplan-verifier` seat with this doc as `{{STANDARDS}}`.

## Hard rules (this doc's additions)

- **Render before you pass a width row.** A6, C1, C5, C7, C8, C10 and
  C11 depend on what the browser paints. Check them in a real browser
  at the stated widths when one is on offer. Without one, file the row
  under Ambiguous with that reason. Never PASS it from reading CSS
  alone.
- **A waiver is evidence, not a verdict.** Read the reason against the
  page. A waiver on a floor row is void and the row fails.
- **Count findings by mechanism.** Twelve labels in tracked capitals from
  one shared class are one B5 finding with twelve lines, not twelve.

## Provenance

Condensed from hallmark v2.0.0 (`nutlope/hallmark` at commit de4999e,
read 2026-11-04): the Floor section of hallmark's skill file and
sections 1 to 5 of its gates reference. Hallmark's Floor and Reflex tiers became this doc's waivable
mark, and its Finish checks and judged clauses fold into CONVENTION.
Gate numbers in the last column are hallmark's, so a row can be traced
back. Rows are paraphrased and regrouped, and some thresholds are
simplified. Hallmark's own file wins on any disagreement about what a
gate means.

Hallmark is used under its MIT licence:

> MIT License. Copyright (c) 2026 Hallmark contributors.
>
> Permission is hereby granted, free of charge, to any person obtaining a
> copy of this software and associated documentation files (the
> "Software"), to deal in the Software without restriction, including
> without limitation the rights to use, copy, modify, merge, publish,
> distribute, sublicense, and/or sell copies of the Software, and to
> permit persons to whom the Software is furnished to do so, subject to
> the following conditions:
>
> The above copyright notice and this permission notice shall be included
> in all copies or substantial portions of the Software.
>
> THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
> OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF
> MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN
> NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
> DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR
> OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE
> USE OR OTHER DEALINGS IN THE SOFTWARE.
