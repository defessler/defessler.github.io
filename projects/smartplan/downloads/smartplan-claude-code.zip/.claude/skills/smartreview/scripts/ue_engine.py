#!/usr/bin/env python3
"""ue_engine.py: is this Unreal code, and which engine version is it for?

smartreview's Unreal profile needs both answers before it reads a line of
code. A `.uproject`'s EngineAssociation is the obvious place to look, but
it's often empty (a project inside a source engine tree, a generated
host) or a build id only one machine knows. So this runs every probe it
has, takes the strongest, and lists the rest as evidence:

  association  the .uproject's EngineAssociation: "5.8", or a build id
               looked up in the registered builds
  engine-tree  an Engine/Build/Build.version in a folder above the project
  modules      the BuildId in the project's Binaries/*/*.modules, matched
               to an installed engine's UnrealEditor.modules
  log          the "Engine Version:" line of the newest Saved/Logs/*.log
  assets       the engine that saved the newest .uasset/.umap files
  uplugin      a plugin descriptor's EngineVersion
  only-install the one engine installed on this machine (weakest)

Usage:
  python ue_engine.py [PATH ...] [--json] [--engine [ID=]DIR ...] [--no-system]

PATH is a changed file or a folder (default: the current folder). The
script walks up from each to find the .uproject, or a .uplugin, or a
Source/*.Build.cs. --engine registers an engine root by hand (the folder
holding Engine/), and --no-system skips the machine's launcher list,
registry and default install folders.

Exit 0: Unreal, version found. 2: Unreal, version unknown. 1: not Unreal.
3: the probe failed or was called wrong, so the answer is unknown. A crash
never exits 1, since 1 would switch every Unreal rule off.
Python stdlib only. Reads files, never writes.
"""
import argparse
import json
import os
import re
import stat
import struct
import sys
from pathlib import Path

VERSION_RE = re.compile(r'^(\d+)\.(\d+)(?:\.(\d+))?$')
LOG_RE = re.compile(rb'Engine Version:\s*(\d+)\.(\d+)\.(\d+)-(\d+)\+\+\+(\S+)')
ASSET_SAMPLE = 48
ASSET_SCAN_CAP = 20000
MAX_DEPTH = 16
HEAD_BYTES = 65536
PACKAGE_TAGS = (b'\xc1\x83\x2a\x9e', b'\x9e\x2a\x83\xc1')
DEFAULT_BASES = (Path('C:/Program Files/Epic Games'), Path('/Users/Shared/Epic Games'))


def mm(v):
    """'5.8.4' -> (5, 8). Anything that isn't a version string -> None."""
    m = VERSION_RE.match(v) if isinstance(v, str) else None
    return (int(m.group(1)), int(m.group(2))) if m else None


def regular(p):
    """A regular file. A FIFO or device named like a descriptor would hang a read."""
    try:
        return stat.S_ISREG(os.stat(p).st_mode)
    except (OSError, ValueError):
        return False


def read_json(p):
    """A JSON object, or None. A file that's missing, unreadable, not JSON,
    nested too deep, or JSON whose root isn't an object all read as None."""
    if not regular(p):
        return None
    try:
        data = json.loads(Path(p).read_text(encoding='utf-8-sig'))
    except (OSError, ValueError, RecursionError):
        return None
    return data if isinstance(data, dict) else None


def text(v):
    """A JSON value used as an id or version: strings and ints only."""
    if isinstance(v, bool):
        return ''
    if isinstance(v, (str, int)):
        return str(v)
    return ''


class Engine:
    def __init__(self, root, ids, source):
        self.root = Path(root)
        self.ids = {i.strip('{}').lower() for i in ids if i}
        self.source = source
        bv = read_json(self.root / 'Engine' / 'Build' / 'Build.version') or {}
        self.version = None
        parts = [bv.get(k, 0) for k in ('MajorVersion', 'MinorVersion', 'PatchVersion')]
        if 'MajorVersion' in bv and all(isinstance(x, int) and not isinstance(x, bool) for x in parts):
            self.version = '%d.%d.%d' % tuple(parts)
        self.branch = text(bv.get('BranchName'))
        self.build_ids = set()
        if text(bv.get('CompatibleChangelist')) not in ('', '0'):
            self.build_ids.add(text(bv['CompatibleChangelist']))
        bins = self.root / 'Engine' / 'Binaries'
        if bins.is_dir():
            for plat in bins.iterdir():
                mod = read_json(plat / 'UnrealEditor.modules') if plat.is_dir() else None
                if mod and text(mod.get('BuildId')):
                    self.build_ids.add(text(mod['BuildId']))

    def valid(self):
        return self.version is not None


def launcher_dat_paths():
    out = []
    pd = os.environ.get('PROGRAMDATA')
    if pd:
        out.append(Path(pd) / 'Epic' / 'UnrealEngineLauncher' / 'LauncherInstalled.dat')
    out.append(Path('/Users/Shared/Epic Games/UnrealEngineLauncher/LauncherInstalled.dat'))
    return out


def install_ini_paths():
    home = Path.home()
    return [home / '.config' / 'Epic' / 'UnrealEngine' / 'Install.ini',
            home / 'Library' / 'Application Support' / 'Epic' / 'UnrealEngine' / 'Install.ini']


def read_install_ini(p):
    pairs, section = [], None
    if not regular(p):
        return pairs
    try:
        lines = Path(p).read_text(encoding='utf-8-sig', errors='replace').splitlines()
    except OSError:
        return pairs
    for line in lines:
        line = line.strip()
        if line.startswith('['):
            section = line.strip('[]').lower()
        elif section == 'installations' and '=' in line:
            k, v = line.split('=', 1)
            pairs.append((k.strip(), v.strip()))
    return pairs


def registry_builds():
    try:
        import winreg
    except ImportError:
        return []
    out = []
    try:
        key = winreg.OpenKey(winreg.HKEY_CURRENT_USER, r'Software\Epic Games\Unreal Engine\Builds')
    except OSError:
        return out
    i = 0
    while True:
        try:
            name, value, _ = winreg.EnumValue(key, i)
        except OSError:
            break
        out.append((name, value))
        i += 1
    return out


def known_engines(extra, system):
    found = {}

    def add(root, ident, source):
        """One bad engine source costs only that source."""
        try:
            add_one(root, ident, source)
        except Exception:
            pass

    def add_one(root, ident, source):
        if isinstance(root, Path):
            root = str(root)
        if not isinstance(root, str) or not root or not isinstance(ident, str):
            return
        root = Path(root)
        if (root / 'Engine').is_dir() is False and root.name.lower() == 'engine':
            root = root.parent
        key = os.path.normcase(str(root.resolve()) if root.exists() else str(root))
        if key in found:
            found[key].ids.add(ident.strip('{}').lower())
            return
        e = Engine(root, [ident], source)
        if e.valid():
            found[key] = e

    for spec in extra:
        ident, _, d = spec.rpartition('=') if '=' in spec else ('', '', spec)
        add(d, ident or Path(d).name, '--engine')
    if system:
        for dat in launcher_dat_paths():
            items = (read_json(dat) or {}).get('InstallationList')
            for it in items if isinstance(items, list) else []:
                if isinstance(it, dict) and re.match(r'^UE_\d+\.\d+$', text(it.get('AppName'))):
                    add(it.get('InstallLocation'), it['AppName'], 'launcher')
        for name, path in registry_builds():
            add(path, name, 'registry')
        for ini in install_ini_paths():
            for name, path in read_install_ini(ini):
                add(path, name, 'Install.ini')
        for base in DEFAULT_BASES:
            if base.is_dir():
                for d in base.glob('UE_*'):
                    add(d, d.name, 'default folder')
    return list(found.values())


def looks_like_project_dir(d):
    """A project folder whose .uproject isn't there (gitignored, generated).
    Content/ plus Plugins/ is a layout other engines copy, so it counts only
    with a real Unreal package inside Content/."""
    if (d / 'Config' / 'DefaultEngine.ini').is_file():
        return True
    if not ((d / 'Content').is_dir() and (d / 'Plugins').is_dir()):
        return False
    return any(is_package(fp) for fp in walk_files(d / 'Content', ('.uasset', '.umap'), cap=2000, limit=5))


def walk_files(top, suffixes, cap=ASSET_SCAN_CAP, limit=None):
    """Files under top with a suffix. Bounded: at most cap entries looked at,
    MAX_DEPTH folders deep, each real folder once (junction loops), and no
    __-prefixed staging folders."""
    out, seen, visited = [], 0, set()
    top = str(top)
    base = top.rstrip('\\/').count(os.sep)
    for root, dirs, names in os.walk(top):
        try:
            real = os.path.normcase(os.path.realpath(root))
        except OSError:
            dirs[:] = []
            continue
        if real in visited or root.count(os.sep) - base >= MAX_DEPTH:
            dirs[:] = []
            continue
        visited.add(real)
        seen += 1
        if seen >= cap:
            return out
        dirs[:] = [x for x in dirs if not x.startswith('__')]
        for n in names:
            seen += 1
            if n.endswith(suffixes):
                out.append(os.path.join(root, n))
                if limit and len(out) >= limit:
                    return out
            if seen >= cap:
                return out
    return out


def is_package(fp):
    if not regular(fp):
        return False
    try:
        with open(fp, 'rb') as fh:
            return fh.read(4) in PACKAGE_TAGS
    except OSError:
        return False


def find_project(paths):
    """Walk up from each path. Returns (kind, file, dir)."""
    plugin = projdir = module = None
    for p in paths:
        p = Path(p).resolve()
        d = p if p.is_dir() else p.parent
        start = d
        for cur in [d, *d.parents]:
            up = sorted(cur.glob('*.uproject'))
            if up:
                return 'project', up[0], cur
            if plugin is None:
                pl = sorted(cur.glob('*.uplugin'))
                if pl:
                    plugin = (pl[0], cur)
            if projdir is None and looks_like_project_dir(cur):
                projdir = cur
            if module is None and (any(cur.glob('*.Build.cs')) or any(cur.glob('*.Target.cs'))):
                module = cur
        if start.is_dir():
            down = sorted(start.glob('*/*.uproject'))
            if down:
                return 'project', down[0], down[0].parent
    if plugin:
        return 'plugin', plugin[0], plugin[1]
    if projdir:
        return 'project-dir', None, projdir
    if module:
        return 'module', None, module
    return None, None, None


def host_of(pdir):
    """The folder holding the Plugins/ folder a plugin sits in, if any."""
    for cur in pdir.parents:
        if cur.name == 'Plugins':
            return cur.parent
    return None


def engine_for(engines, ident=None, version=None, build_id=None):
    for e in engines:
        if ident and ident.strip('{}').lower() in e.ids:
            return e
    for e in engines:
        if build_id and build_id in e.build_ids:
            return e
    if version:
        hits = [e for e in engines if mm(e.version) == mm(version)]
        hits.sort(key=lambda e: e.source != 'launcher')
        if hits:
            return hits[0]
    return None


def asset_versions(content_dirs):
    files = []
    for cdir in content_dirs:
        for fp in walk_files(cdir, ('.uasset', '.umap')):
            try:
                files.append((os.path.getmtime(fp), fp))
            except OSError:
                pass
    files.sort(reverse=True)
    out = []
    for _, fp in files[:ASSET_SAMPLE]:
        v = saved_by(fp)
        if v:
            out.append((v, fp))
    return out


def _engine_version_at(b, s):
    """FEngineVersion whose branch FString starts at s (after its int32 length)."""
    if s < 14:
        return None
    end = b.find(b'\x00', s)
    if end < 0 or end - s > 127:
        return None
    n = struct.unpack_from('<i', b, s - 4)[0]
    if n != end - s + 1:
        return None
    major, minor, patch = struct.unpack_from('<HHH', b, s - 14)
    cl = struct.unpack_from('<I', b, s - 8)[0]
    if not (4 <= major <= 9 and minor <= 60 and patch <= 60):
        return None
    branch = b[s:end].decode('ascii', 'replace')
    return (major, minor, patch, cl, branch, end + 1)


def saved_by(fp):
    """SavedByEngineVersion from a package summary. It's followed directly by
    CompatibleWithEngineVersion, so two valid structs back to back anchor it."""
    if not regular(fp):
        return None
    try:
        with open(fp, 'rb') as fh:
            b = fh.read(HEAD_BYTES)
    except OSError:
        return None
    if len(b) < 4 or b[:4] not in PACKAGE_TAGS:
        return None
    for m in re.finditer(rb'[\x20-\x7e]{1,127}\x00', b):
        first = _engine_version_at(b, m.start())
        if not first:
            continue
        second = _engine_version_at(b, first[5] + 14)
        if second:
            return '%d.%d.%d' % first[:3], first[3], first[4]
    return None


def probe(paths, extra, system):
    kind, pfile, pdir = find_project(paths)
    result = {'unreal': kind is not None, 'kind': kind,
              'project': str(pfile) if pfile else None,
              'root': str(pdir) if pdir else None, 'host': None,
              'version': None, 'from': None, 'engine_root': None,
              'engine_headers': None, 'evidence': [], 'conflicts': []}
    if not kind:
        return result
    ev = result['evidence']

    def add(name, version, note, engine=None):
        ev.append({'probe': name, 'version': version, 'note': note,
                   'engine_root': str(engine.root) if engine else None})

    def guard(name, fn):
        """One probe's crash costs that probe, never the others' answers."""
        try:
            fn()
        except Exception as exc:
            add(name, None, 'probe failed, %s: %s' % (type(exc).__name__, exc))

    engines = []

    def p_engines():
        engines.extend(known_engines(extra, system))

    def p_association():
        data = read_json(pfile) or {}
        assoc = data.get('EngineAssociation')
        if assoc is None:
            add('association', None, 'not set in %s' % pfile.name)
        elif not isinstance(assoc, str):
            add('association', None, 'not a string in %s' % pfile.name)
        elif assoc == '':
            add('association', None, 'empty in %s' % pfile.name)
        elif VERSION_RE.match(assoc):
            e = engine_for(engines, ident='UE_' + assoc, version=assoc)
            if e and mm(e.version) == mm(assoc):
                add('association', e.version, '"%s", installed at %s (%s)' % (assoc, e.root, e.source), e)
            else:
                add('association', assoc, '"%s", no install of it found here' % assoc)
        else:
            e = engine_for(engines, ident=assoc)
            if e:
                add('association', e.version, 'build id %s, registered at %s (%s)' % (assoc, e.root, e.source), e)
            else:
                add('association', None, 'build id %s, not registered on this machine' % assoc)

    def p_engine_tree():
        for cur in [pdir, *pdir.parents]:
            bv = cur / 'Engine' / 'Build' / 'Build.version'
            if bv.is_file():
                e = Engine(cur, [], 'engine tree')
                if e.valid():
                    engines.append(e)
                    add('engine-tree', e.version, 'Build.version at %s' % bv, e)
                break

    dirs = [pdir]
    host = host_of(pdir) if kind == 'plugin' else None
    if host:
        dirs.append(host)
        result['host'] = str(host)

    def p_modules():
        mods = [m for d in dirs for m in sorted((d / 'Binaries').glob('*/*.modules'))]
        for mod in mods:
            data = read_json(mod) or {}
            bid = text(data.get('BuildId'))
            if not bid:
                continue
            e = engine_for(engines, build_id=bid)
            if e:
                add('modules', e.version, 'BuildId %s in %s matches %s' % (bid, mod.name, e.root), e)
            else:
                add('modules', None, 'BuildId %s in %s matches no engine here' % (bid, mod.name))
            break

    def p_log():
        def mtime(lp):
            try:
                return lp.stat().st_mtime
            except OSError:
                return 0

        logs = sorted((lp for d in dirs for lp in (d / 'Saved' / 'Logs').glob('*.log')),
                      key=mtime, reverse=True)
        for lp in logs[:5]:
            if not regular(lp):
                continue
            try:
                with open(lp, 'rb') as fh:
                    m = LOG_RE.search(fh.read(HEAD_BYTES))
            except OSError:
                continue
            if m:
                g = [x.decode('ascii', 'replace') for x in m.groups()]
                v = '%s.%s.%s' % (g[0], g[1], g[2])
                add('log', v, '%s-%s+++%s in %s' % (v, g[3], g[4], lp.name),
                    engine_for(engines, build_id=g[3], version=v))
                break

    def p_assets():
        content = [d / 'Content' for d in dirs if (d / 'Content').is_dir()]
        av = asset_versions(content)
        if av:
            newest = max(av, key=lambda x: tuple(int(n) for n in x[0][0].split('.')))
            mms = sorted({'.'.join(v[0].split('.')[:2]) for v, _ in av})
            add('assets', '.'.join(newest[0][0].split('.')[:2]),
                'newest of %d sampled saved by %s (branch %s)%s' % (
                    len(av), '.'.join(newest[0][0].split('.')[:2]), newest[0][2],
                    ', also ' + ', '.join(mms) if len(mms) > 1 else ''))

    def p_uplugin():
        data = read_json(pfile) or {}
        v = data.get('EngineVersion')
        if mm(v):
            add('uplugin', v, 'EngineVersion in %s' % pfile.name, engine_for(engines, version=v))
        elif v not in (None, ''):
            add('uplugin', None, 'EngineVersion in %s is not a version' % pfile.name)

    def p_only_install():
        installs = {os.path.normcase(str(e.root)): e for e in engines if e.source != 'engine tree'}
        if len(installs) == 1:
            e = next(iter(installs.values()))
            add('only-install', e.version, 'the one engine on this machine, %s (%s)' % (e.root, e.source), e)

    guard('engines', p_engines)
    if kind == 'project':
        guard('association', p_association)
    guard('engine-tree', p_engine_tree)
    guard('modules', p_modules)
    guard('log', p_log)
    guard('assets', p_assets)
    if kind == 'plugin':
        guard('uplugin', p_uplugin)
    guard('only-install', p_only_install)

    for item in ev:
        if item['version']:
            result['version'], result['from'] = item['version'], item['probe']
            break
    if result['version']:
        want = mm(result['version'])
        root = next((i['engine_root'] for i in ev if i['engine_root'] and
                     mm(next((e.version for e in engines if str(e.root) == i['engine_root']), '')) == want), None)
        if not root:
            e = engine_for(engines, version=result['version'])
            root = str(e.root) if e else None
        result['engine_root'] = root
        if root and (Path(root) / 'Engine' / 'Source').is_dir():
            result['engine_headers'] = str(Path(root) / 'Engine' / 'Source')
        for i in ev:
            if not i['version'] or i['probe'] == 'only-install':
                continue
            got = mm(i['version'])
            if got and got != want:
                if i['probe'] == 'assets' and got < want:
                    continue
                result['conflicts'].append('%s says %s, %s says %s' % (
                    result['from'], result['version'], i['probe'], i['version']))
    return result


def standards_line(r):
    if not r['unreal']:
        return None
    if not r['version']:
        return 'Engine: unreal · UE version unknown'
    v = r['version']
    if r['from'] == 'assets' or r['from'] == 'only-install':
        v = '.'.join(v.split('.')[:2])
    tail = '' if r['from'] != 'only-install' else ', an assumption'
    return 'Engine: unreal · UE %s (%s%s)' % (v, r['from'], tail)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split('\n')[0])
    ap.add_argument('paths', nargs='*', default=['.'])
    ap.add_argument('--json', action='store_true')
    ap.add_argument('--engine', action='append', default=[], metavar='[ID=]DIR')
    ap.add_argument('--no-system', action='store_true')
    def usage_error(msg):
        print('ue_engine.py: %s' % msg, file=sys.stderr)
        sys.exit(3)

    ap.error = usage_error
    a = ap.parse_args(argv)
    if hasattr(sys.stdout, 'reconfigure'):
        sys.stdout.reconfigure(encoding='utf-8', errors='backslashreplace')
    try:
        r = probe(a.paths, a.engine, not a.no_system)
        r['standards_line'] = standards_line(r)
        out = render(r, a)
    except Exception as exc:  # never let a crash read as "not Unreal"
        print('ue_engine.py: probe failed, %s: %s' % (type(exc).__name__, exc), file=sys.stderr)
        try:
            print('Unreal: unknown (probe failed). Look for a .uproject, .uplugin or *.Build.cs by hand.')
        except Exception:
            pass
        return 3
    try:
        print(out)
    except Exception as exc:
        print('ue_engine.py: output failed, %s' % type(exc).__name__, file=sys.stderr)
        return 3
    return 1 if not r['unreal'] else (0 if r['version'] else 2)


def render(r, a):
    """The whole report as one string, so a failure can't leave half of it."""
    if a.json:
        return json.dumps(r, indent=1)
    if not r['unreal']:
        return 'Unreal: no (no .uproject, .uplugin or *.Build.cs above %s)' % ', '.join(a.paths)
    lines = ['Unreal: yes, %s %s' % (r['kind'], r['project'] or r['root']),
             'Version: %s' % (r['version'] and '%s (from %s)' % (r['version'], r['from']) or 'unknown'),
             'Engine headers: %s' % (r['engine_headers'] or 'none found for that version'),
             'Evidence:']
    lines += ['  %-12s %s' % (i['probe'], i['note']) for i in r['evidence']]
    lines += ['Conflicts: %s' % ('; '.join(r['conflicts']) or 'none'),
              'Standards line: %s' % r['standards_line']]
    return '\n'.join(lines)

if __name__ == '__main__':
    sys.exit(main())
