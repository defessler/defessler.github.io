---
name: smartreview
description: Use when reviewing a changelist or fileset before accepting or merging — triggers on "review this change", "find bugs in this diff", or "apply/check/enforce conventions". Reports three ranked categories — game-breaking bugs first, then best practices, then conventions — against a swappable standards doc; shipped default is C++ gamedev (vanilla/custom/Unreal).
---

# smartreview

You review **one changelist or fileset** in **three ranked categories**.
This file is the **driver** (ranking, protocol, report). A swappable
**standards doc** supplies the checklist, tag legend, breaking-defect
classes, and fill-once tokens.

**Rank before you report.** A game-breaking bug buried under forty naming
nits has not been surfaced.

| Category | What belongs | Disposition |
|---|---|---|
| **BREAKING** | It ships broken — crash, UB, memory or save corruption, data loss, hang, deadlock, a leak that exhausts memory, desync, or a build/link failure that only shows in another configuration. | **Blocks the merge.** |
| **PRACTICE** | Built the wrong way, works today — API misuse, a missing guard, an avoidable allocation off the hot path, dead registration code, a trap the next change walks into. | Fix, or file it. |
| **CONVENTION** | House style — naming, formatting, comment style, ordering. No runtime consequence. | Fix in place. |

**Name the failure or demote it.** A BREAKING finding states the concrete
failure a player, a build, or a save file would see. Can't name one? It's
PRACTICE. Inflating severity destroys the ranking's only value, and the
reverse is worse: a real crash filed as a style nit ships.

## Project Profile — set once

One token picks the standards doc. Three knobs apply to every language.

| Token | Meaning | Default |
|-------|---------|---------|
| `{{STANDARDS}}` | the per-project review-standards doc: checklist, tag legend, severity map, breaking-defect classes, profile selector, fill-once tokens | [`references/cpp-review-standards.md`](references/cpp-review-standards.md) (C++ gamedev, engine-profiled) |

How it resolves:

- **Set to a path** → load that doc. It defines "conventions" and
  "breaking" here.
- **Unset** → ask: confirm the shipped C++ default or take a path. Never
  guess conventions from file extensions.
- **A path that doesn't resolve** → say so and stop.

**Swapping the standards doc:** a Python or TypeScript project points
`{{STANDARDS}}` at its own `references/<lang>-review-standards.md` (own
checklist, tokens, tag legend, breaking classes). This driver stays
unchanged. Web UI ships one: `references/web-ui-review-standards.md`.

| Knob | Meaning | This project | Epic C++ example |
|------|---------|--------------|------------------|
| **Indentation** | tabs, or _N_ spaces | _fill in_ | `tabs` (size 4) |
| **Max line length** | a number, or `none` | _fill in_ | `none` |
| **Local-variable case** | `lowerCamelCase` or `PascalCase` | _fill in_ | `PascalCase` |

**"This project" ships unfilled, on purpose.** A pre-set value would impose
one project's style on every project this skill installs into globally.
Fill it once per project. Until then its rows are **N/A**, never a value
guessed from the code. The Epic column is an example to copy (provenance:
`references/cpp-review-standards.md § Provenance & Epic-standard validation`).

## Protocol

Copy this checklist and check off items as you go:

```
- [ ] 1. {{STANDARDS}} resolved — before reading a line of code
- [ ] 2. Files gathered and read in full
- [ ] 3. Breaking hunt done — every class swept, clean sweeps recorded
- [ ] 4. Checklist walked — every row PASS, FAIL, or N/A
- [ ] 5. Report written, BREAKING first
```

1. **Gather files.** Take the files in scope (a changelist via your VCS's
   describe/diff, or user-specified paths). Read each in full.
2. **Hunt breaking defects first**, before any style row. Sweep every
   breaking-defect class `{{STANDARDS}}` names. This pass is **not**
   checklist-driven: a bug is what nobody wrote a rule for. Read for what
   the code *does*: who owns each allocation, what runs on which thread,
   what the failure path does, what a malformed or stale input does. A swept
   class with nothing found is a result. Report it.
3. **Walk the checklist** in `{{STANDARDS}}` per file, gating rows as that
   doc's tag legend and profile selector dictate. Mark each item **PASS**,
   **FAIL**, or **N/A**, never skipped. File each FAIL under the severity
   that doc's severity map assigns.
4. **Report** using the template below.

A clean checklist never replaces the hunt, and a crash never excuses
skipping the checklist. Both run, every time.

## Report

```
REVIEW: <changelist / fileset>
Standards: <doc {{STANDARDS}} resolved to> · <active profile/selector, if the doc declares one>
Files reviewed: <n>
Findings: BREAKING <n> · PRACTICE <n> · CONVENTION <n>

BREAKING — blocks the merge
  - <file>:<line> — <category> — <the failure, concretely> → <fix applied | proposed>
PRACTICE
  - <file>:<line> — <what's wrong> → <fix applied | proposed>
CONVENTION
  - <file>:<line> — <rule #> — <what was wrong> → <fix applied | proposed>

Checklist: <n> items (PASS <n> · FAIL <n> · N/A <n>)
Categories swept, clean: <breaking categories that produced nothing, or "none">
Ambiguous / flagged: <rule # or category> — <why unsure> (asked, did not guess)
```

An empty category prints its heading and `none`. Silence reads as "not
looked at."

With the shipped doc and the Engine unset, the `Standards:` line reads
`cpp-review-standards.md · Engine: vanilla` (or `custom` / `unreal`).

**Where this sits.** This seat is the merge gate over a whole fileset.
smartcheck's `cpp-gamedev-check.md` is the verify seat inside a smartplan
fan-out, over one leaf's diff. The driver **reuses** that taxonomy through
the standards doc so the two can't drift. Name the category on every
BREAKING row so the reports collate on `category · file:line`. Mark a row a
leaf's smartcheck already filed as already-filed.

**Review away from the author.** A session reviewing code it just wrote
shares its blind spots. Hand the review to the `smartplan-verifier` seat,
which loads this skill read-only. Its fixes are always `proposed`.

## Output register (default: max-savings)

When the review's only reader is another model seat (a smartplan fan-out
leaf, or any invocation feeding another agent), the report's free-text
fields (`<what's wrong>`, `<why unsure>`, not the counts, rule IDs, or
category headings) follow `modes.md`'s caveman register. **Default here is
max-savings** (caveman *ultra*). It replaces smartplan's per-harness
*shipped default*, so any mode set above it still wins (`modes.md` § Setting
it). File paths, rule IDs, and quoted code stay byte-verbatim, as does **a
BREAKING finding's failure description**, the sentence a human reads first.
Run interactively, the report stays full prose per `modes.md`'s
human-facing floor.

## Hard rules

- **Breaking first, no exceptions.** BREAKING goes ahead of everything,
  even when the convention pass returns two hundred rows.
- **Exhaustive, not sampled.** Every class, item, and file. A skipped row is
  a silent FAIL waiting to ship.
- **Resolve the Profile first.** `{{STANDARDS}}` before reading code. If it,
  a knob, or a standards-doc token is unset, the dependent rows are **N/A**.
  Never invent a value, a language, or a standard.
- **Don't guess.** If a rule's applicability or a defect's reachability is
  ambiguous, flag it rather than marking PASS, FAIL, or BREAKING.
- **Reproduce before you file.** A BREAKING row is a claim, not a verdict.
  Name the input or path that triggers the failure. A reviewer asked for
  bugs finds some even in sound code (`check.md` § Review / audit output),
  so an unreproducible suspicion goes under Ambiguous.
- **Respect the standards doc's enforcement tags.** Rows it marks as
  externally enforced (engine-, build-, or toolchain-mandated, the C++
  doc's **[U]**) aren't house style to adapt. Change only project-choice
  rows.
- **Gated-off rows are N/A, not deleted.** They still appear in the tally.
- Tiering (see smartroute): the convention pass is mechanical per row, so a
  Cheap tier runs it. **The breaking hunt is not.** Ownership, threading,
  and lifetime judgment take at least a Mid tier, and the floor tracks the
  executor: a Sonnet- or Opus-authored diff gets the hunt at
  Opus-or-comparable strength. On a seat below that, ask first (smartplan's
  Seat ceiling). On a no, the seat runs the hunt and the report names the
  gap. Run inline unless the fileset won't fit one context.
- **Verify before the merge (see smartcheck).** This seat sits at the merge
  gate, so the verify floor holds at any size: a risky merge takes an
  independent check, and this seat can't be it. That check also covers any
  fix this seat makes rather than reports.

## Completion exemplar

Inline completions ignore instruction files but read open tabs. To steer
them toward this project's conventions, build an exemplar file with
[`references/completion-exemplar.md`](references/completion-exemplar.md).
Resolve the Profile first, as for a review.

## Changelog / edge-case log

Moved to [the repo's commit log](https://github.com/defessler/smartplan/commits/main) to keep this body lean and out of the shipped plugin.
