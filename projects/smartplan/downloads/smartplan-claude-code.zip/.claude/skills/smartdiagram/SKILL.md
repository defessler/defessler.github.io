---
name: smartdiagram
description: Generate an interactive system-wiring diagram (ownership columns, selectable flows, click-to-inspect invariants) for any codebase. Use when asked for an architecture/wiring/system diagram, "how is everything hooked up", or to update a repo's existing diagram. Curation-first - never emit an auto-generated symbol hairball.
---

# smartdiagram — curated interactive architecture graphs

The output is a self-contained, artifact-ready interactive HTML diagram: ownership
columns, selectable **flows** that dim everything else, click-to-inspect **contracts** per
node, and honest **health annotations**. The renderer is generic. All judgment lives in a
per-repo spec file. Rendering is mechanical and **curation is the value** — a diagram nobody
has to squint at beats a complete one.

## Procedure

Copy this checklist and check off items as you go:

```
- [ ] 1. Scouted — columns, nodes, flows, health, each from a real symbol
- [ ] 2. Spec authored and checked into the repo
- [ ] 3. Rendered — the script validated every reference
- [ ] 4. Published (Artifact, or the rendered HTML)
- [ ] 5. On an update: drift-checked every node symbol FIRST
```

1. **Scout the system** (read, don't guess): the repo's CLAUDE.md / README / design docs,
   module or package boundaries, the load-bearing types/functions, and the part auto-tools miss,
   *verification evidence* (test results, known limitations, TODO debt). Find four things:
   - **Columns** (2–5): ownership domains, not folders. e.g. consumer code · core module ·
     tooling module · platform/engine.
   - **Nodes** (≤ 20 total): load-bearing pieces only. Each must name a REAL symbol/file.
     If you can't point at it, it doesn't go in.
   - **Flows** (3–6): named end-to-end stories of how the system is *used or lives*
     (creation, the main query, the special case, the deploy/build boundary). They are
     semantic, taken from docs and headers, never from a call graph.
   - **Health**: what is verified and what is broken/limited, with evidence. An honest red
     edge is the most valuable ink in the diagram.

2. **Author the spec** at `<repo>/Docs/wiring.json` (or `docs/`), schema and authoring rules
   in [references/schema.md](references/schema.md). Node `desc` states the
   *contract/invariant* (ideally paraphrasing the code's header comments), never the
   title. Check the spec in. It is versioned, diffable documentation.

3. **Render**: `python <this-skill-dir>/scripts/render_wiring.py <spec.json> -o <out.html>`
   The script validates all references (edges, flows, groups) and fails loudly on dangling
   ones.

4. **Publish** with the Artifact tool where the harness has one (suggested favicon 🧭), else
   the rendered HTML file. To update, re-render to the same path. Where Artifacts exist,
   republish that path to keep the URL.

5. **On updates, drift check first**: before re-publishing, grep the repo for each node's
   named symbol. A node whose symbol is gone is a spec bug to fix. This keeps the diagram
   from rotting like other architecture docs.

## Rules

- Never exceed ~20 nodes or ~30 edges. If the system is bigger, raise the altitude (merge
  nodes) or split into one diagram per subsystem.
- Every flow's `html` is 2–4 sentences telling the story in the system's own vocabulary.
  `caption` is the optional heading above it, not the prose. A paragraph put there renders
  as an `<h2>`.
- Health/limitation markings need evidence (a test run, a recorded finding).
- The `over` flow id is reserved: it shows everything and its `html` states the system's
  one-sentence load-bearing shape.

## Family fit and tiering

`smartdiagram` is an **optional** companion seat (like `smartreview`/`smartwiki`/`smartvoice`).
The family works without it and it sits outside the tiering loop: a reusable procedure, not
a model-role. It pairs with `smartwiki`, which renders a change for a non-engineer
audience. A diagram does the same for system shape.

Tiering (see `smartroute`): when the scout fits one context, author inline. The tiers below
apply once you fan out. Nothing dispatches above your seat unasked (`smartplan` § Seat
ceiling). Choosing which 20 nodes carry a system is the call a weak model gets wrong, so
authoring a spec fits **Strong**, or **Mid** when the repo has a good design doc. The render
step is a script and costs nothing. A drift check (step 5) is mechanical grep work and
routes **Cheap** behind the usual verify.

## Changelog

the repo's commit log (source repo only, so a path and not a link), kept out of
the shipped plugin to keep this body lean.
