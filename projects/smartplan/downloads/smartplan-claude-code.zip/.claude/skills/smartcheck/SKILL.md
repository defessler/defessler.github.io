---
name: smartcheck
description: smartplan part. The independent verify protocol that gives a leaf or diff one PASS, FAIL or UNKNOWN verdict. Load for any verify smartplan or a verifier seat runs.
user-invocable: false
---

# smartcheck — part of smartplan

The verify protocol. Read [`references/check.md`](references/check.md)
whole and follow it exactly: the authorization gate, the ranked oracle
floor, re-running acceptance, the scope audit, the verdict templates
and the reflective sweep. A C++ gamedev diff also layers
`smartcheck-cpp` when that part is on.

When this skill is off, smartplan verifies with executable oracles
only, sends no Cheap leaves, and names the missing model verify at the
gate.
