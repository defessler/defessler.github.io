---
name: smartcache
description: smartplan part. Prompt-cache mechanics and cache-aware fan-out ordering on Claude Code. Load when ordering a fan-out wave.
user-invocable: false
---

# smartcache — part of smartplan

Read [`references/caching.md`](references/caching.md) whole before
ordering a wave. It covers prompt-cache mechanics and how to order
dispatch so siblings share a warm prefix.

When this skill is off, smartplan dispatches without regard to the
cache.
