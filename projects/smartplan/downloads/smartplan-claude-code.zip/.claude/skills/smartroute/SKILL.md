---
name: smartroute
description: smartplan part. Maps each task class to a model tier and holds the cross-vendor model registry with dated prices. Load when smartplan picks a seat or tier.
user-invocable: false
---

# smartroute — part of smartplan

Model tiering for smartplan. Read
[`references/routing.md`](references/routing.md) whole for the
class-to-tier mapping, seat eligibility, the cost ceiling, the Cheap
hard floors and session-limit pressure.
[`references/model-classes.md`](references/model-classes.md) is the
model registry: classes, dated prices, and default or candidate status.
Reclassify a model there.

When this skill is off, every subagent smartplan sends runs the session
model and nothing climbs a tier.
