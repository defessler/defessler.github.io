# selftest: verify smartplan is actually working on your harness

*Load on demand to prove the family works on a harness
(Claude Code or Copilot CLI) — not part of the
per-invocation read. Two halves: a static doctor script (step 0) and six
runtime probes graded on **observable artifacts** (files created, chat lines
emitted), which lets one rubric work on every harness.*

## Step 0: static surface (deterministic, ~2 seconds)

```bash
bash scripts/selftest.sh
```

Checks the install shape: every skill present (smartplan, its part skills
and the companions), every frontmatter
description under the 1024-char load limit, flow-critical references
resolve, the Copilot agent surface (7 profiles) and the single-manifest
plugin definition where those apply. Exit 0 means the install is sound. It runs anywhere,
skipping surfaces the checkout lacks. Fix any step 0 failure first. A
mis-shaped install fails probes for boring reasons.

## The probes: how they work

Each probe is a prompt you type plus a PASS rubric of what you can **see**:
files in the repo root and lines in the chat. Grade the artifacts, not the
model's narration ("I dispatched to Haiku" is a
claim; a `run-state.md` row and a dispatch-board line are evidence — and on
Claude Code even those record *intent*, per `claude-code.md`'s #43869
caveat, which is exactly why the rubric checks artifacts instead of trusting
prose). Run probes in a scratch repo or on a throwaway branch.

Where to watch live, per harness (zero-token surfaces): Claude Code — the
agent panel; Copilot — `/tasks`. The rubric itself never
depends on these.

## Probe 1: trivial leaf (routing + collapse discipline)

**Type:** `/smartplan add a one-line comment header to <some small file>`

**PASS when all of:**
- No full plan+gate ceremony. The flow either sends the leaf down a tier
  (the dispatch-board line shows the Cheap seat's model, not the session
  model). Or it emits a one-line `Routing call: inline — …` and makes one bounded
  inline edit, **saying which**.
- If dispatched, one dispatch-board line appears (`▶ 1 running: …`).
- `git status` shows only the target file, plus `run-state.md` if the leaf
  was dispatched.

**FAIL looks like:** the session model does the edit with no routing
statement and no board line. That's the priciest-seat-doing-cheap-work
failure the family exists to prevent.

## Probe 2: small fan-out (the full loop)

**Type:** `/smartplan finishing sooner beats finishing cheaper here: create
docs/probe/a.md, docs/probe/b.md, docs/probe/c.md and docs/probe/d.md, each
containing a 3-line summary of a different smartplan part skill:
smartflow, smartroute, smartbrief and smartcheck`

**Keep both halves of that prompt.** `SKILL.md`'s fan-out row needs four
independent units with disjoint files *and* a stated preference for
finishing sooner over cheaper. Without either, a correct router lands on
"Everything else" and stays inline. The probe then fails on doctrine, not a defect.

**PASS when all of:**
- A plan with ~4 independent leaves is **presented at a gate** and waits
  for your approval before any file appears.
- After approval, `run-state.md` gets one row per leaf **including the
  `attempts` column**. A dispatch-board line shows the leaf→model pairs on
  Mechanical or Implementer-class models, never the session model or a
  Reasoning-class one.
- Leaves dispatch **concurrently where the harness allows** (watch the
  panel or `/tasks`).
- Each leaf's acceptance is verified before the wave closes, with verdicts
  stated **including the one-line reflective sweep** (least-confident /
  missing / 3-month / assumed). One Integrate pass then closes with the
  wave-level sweep (plus at most one flagged improvement, offered, not
  built). Then every `run-state.md` row closes with its final status and
  note.
- The four files exist with plausible content.

**FAIL looks like:** files appear before the gate, run-state.md is never
created, every leaf runs on the session model, or there's no verification
step between "done" and "accepted".

## Probe 3: seat-eligibility enforcement (the refusal path)

**Type:** `/smartplan use Opus to rename the probe files from probe 2 to
w.md, x.md, y.md, z.md`

**PASS when all of:**
- The plan **does not seat Opus for the renames** and states the reseating
  at the gate (Opus → planner/verifier seats, renames → the Cheap seat per
  `model-classes.md`).
- You're offered the explicit override ("seat it anyway"), not silently
  obeyed or silently refused.
- Take the override and the leaf's `run-state.md` note records a deliberate
  over-tier. Decline it and **either** outcome passes: a Cheap-seat
  dispatch **or** an inline edit whose `Routing call: inline` line says why.
  This probe tests the refusal path, not the dispatch.

**FAIL looks like:** Opus (or the session model) just does the renames.
That's the named-model-as-instruction failure § Seat eligibility exists to refuse.

## Probe 4: the fan-out trigger fires unprompted (two arms, both required)

Probes 1 to 3 *tell* the flow what shape to take. This one doesn't, because
the failure it catches is silence: a router that fans out when asked and
never when it isn't. Check.sh gate (p) proves the trigger text sits in the
pre-gate file. Only a live run proves a model *counts*. Run both arms, since
a trigger tested only on firing passes by always firing.

**Arm A: must fire, or must justify in the routing line.**

**Type:** `/smartplan in docs/probe/, write five short notes read from this
repo: gates.md on what check.sh gates, exports.md on what the three export
scripts emit, harnesses.md on the four supported surfaces, budgets.md on the
byte-budget ratchet, freshness.md on gate (n)`

Five units, five source reads, disjoint files, no stated deadline, and it
all fits one context with room to spare.

**PASS when:**
- The routing line **names the unit count** (five) before work starts.
- **Then either** it fans out **or** it routes inline and says why inline
  still wins. Both pass. Stating the count is the test.

**FAIL looks like:** work begins with no routing line, or one that never
states the unit count. The call then defaults to inline and nobody can see
a call was made.

**Arm B: must NOT fire.**

**Type:** `/smartplan add the line "# probe" as the first line of every .md
file in docs/probe/`

**PASS when:** it routes **inline** and says so, calling this **one leaf**:
N files taking the same edit, not N units.

**FAIL looks like:** a five-leaf wave for one find-and-replace. That
over-fire is how a countable trigger turns into noise you learn to ignore.

## Probe 5: a part switched off is really off

Every smartplan feature is its own skill, so switching one off has to
change what the router does. Switch `smartflow` off in your harness's
skill list (or with the installer's enable/disable menu), start a fresh
session, and confirm the skill listing no longer names it.

**Type:** Probe 2's prompt, word for word.

**PASS when:**
- The routing call lands on **inline**, not fan-out.
- One line after it says `smartflow` is off and that's why no fan-out runs.
- No `run-state.md` appears and nothing dispatches a leaf.

**FAIL looks like:** a plan, a gate or a dispatch anyway, or a read of
`flow.md` by path. Either one means the switch was routed around.

Switch `smartflow` back on afterwards.

**On Copilot CLI, switch off `smartcost` instead.** The fan-out row
never fires there, so Probe 2's prompt routes inline with `smartflow`
on or off and can't fail. A named mode can. Run `copilot skill disable
smartcost`, start a fresh session in a throwaway git folder holding a
short readme, and type:

`/smartplan use max-quality mode for this: add a one-line comment to the
top of README.md saying what the file is`

**PASS when:**
- The routing call lands on **inline**.
- There's no `skill(smartcost)` call and no read of `modes.md`.
- One line after the routing call says `smartcost` is off, so the run
  stays in the default mode.

**FAIL looks like:** a `smartcost` load, a read of `modes.md` by path,
or a run that takes up max-quality anyway.

Run `copilot skill enable smartcost` afterwards. With it on, the same
prompt loads `smartcost` and reads `modes.md`, which is how you know the
probe can fail. On CLI 1.0.105 on 2026-11-04 a Luna session passed the
first two lines with the part off and missed the third. It made the edit
without saying the part was off. That run cost 0.32 credits, and the
control with the part on cost 0.39.

## Probe 6: a review runs away from the author

A review in the session that wrote the code shares its blind spots, so
the verifier seat runs reviews too, through `smartreview`.

**Type:** `Have the smartplan-verifier seat review <some small source
file> with smartreview`. On Copilot, call `@smartplan-verifier` by hand,
since the skill never dispatches it there.

**PASS when all of:**
- The review comes back from the verifier seat, not from the session.
- It uses smartreview's Report: a `REVIEW:` line, a `Standards:` line
  naming the doc it resolved, then BREAKING, PRACTICE and CONVENTION,
  with `none` under any empty one.
- Every fix reads `proposed`, and `git status` shows nothing changed.

**FAIL looks like:** a PASS/FAIL leaf verdict instead of a review, a
review with no `Standards:` line (rules from memory), or an edited file.

Note: review a file that sits outside this repo. On 2026-11-04 the
Copilot seat (`copilot --agent smartplan-verifier`, Gemini 3.8 Flash)
passed on the vanilla ProjectilePool fixture, but it also opened the
answer key beside that fixture and old benchmark records, and it cost
35.22 credits. That doesn't fail this probe, but it would spoil a recall
score.

## Scoring

6/6 probes (probe 4 needs both arms) = the flow works on this harness.
File any FAIL through flow.md's "Evolving this skill" procedure, with the
rubric line that failed and what actually happened. Probe
failures are exactly the edge cases that procedure wants captured. On
Claude Code, remember the honest ceiling: artifacts prove the flow's
*discipline* end-to-end. Whether each dispatch *billed* as its intended
tier is provable only at the Console (per-model dollars), never in-chat.

## Cleanup

`git checkout -- . && git clean -fd docs/probe run-state.md` on the
throwaway branch, or delete the scratch repo.
