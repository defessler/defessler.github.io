<#
.SYNOPSIS
  Put `doki-claude`, `doki-copilot`, `zai-claude` and `doki-manager` on the User PATH, so every way
  of running a CLI agent from this stack has a front door from any terminal. doki-claude and
  doki-copilot drive DokiDex's local weights. zai-claude drives Claude Code against z.ai's GLM
  endpoint, cloud and billed. The cloud `claude` and `copilot` keep working, untouched.

.DESCRIPTION
  Five files are generated into scripts\shims (doki-claude.cmd, doki-copilot.cmd, zai-claude.cmd,
  doki-manager.cmd and the shared doki-shim.ps1 they all call), and that one directory is merged
  into the User PATH (HKCU\Environment, no elevation needed). Each shim forwards every argument to
  the matching script under scripts\ and returns its exit code.

  THE SPLIT THIS TABLE MAKES, because it is the reason the manager row exists. doki-claude,
  doki-copilot and zai-claude are thin on purpose: neutralise the environment, point the client at a
  backend, hand over. Nothing else. As of 2026-08-19 they no longer probe the backend or preload the
  model, which took the cold-seat launch from 18.45 s to 0.65 s (measured with a stub client on PATH,
  so the number is the launcher's own; see the header of scripts\claude-local.ps1 for the full set).
  Everything heavy and occasional moved behind doki-manager instead: installing, downloading models,
  starting them, and the preload itself as its `warm` verb. Slow work you asked for beats slow work
  that happens to you.

  Everything under scripts\shims is generated. -Uninstall can delete the lot without losing anything
  you cannot regenerate. That is NOT the same as leaving the checkout untouched, though: the files
  there are tracked in this repo (`git ls-files scripts/shims` lists them). Removing them leaves
  those deletions in `git status`. The uninstall path counts them and names the restore command
  rather than letting that look like damage.

  Why a .cmd wrapper rather than the .ps1 itself: PATHEXT carries no .PS1, so cmd.exe cannot run a
  bare script by name.

  Why the SHARED generated file, doki-shim.ps1, sits between each .cmd and its target: neither of the
  two obvious ways to start a .ps1 from a batch file survives the launchers' `--` divider contract.
  Measured on PS 7.6.5, 2026-08-19:
    pwsh -File <launcher>.ps1 -NoWarm -- -r abc
        -> "Parameter cannot be processed because the parameter name '' is ambiguous"
           (-File hands `--` to the parameter binder instead of ending parameter parsing)
    pwsh -Command "& '<launcher>.ps1' %*"  with  -Model "fix the bug $100"
        -> Model=[fix], Rest=[the|bug|]   (cmd.exe's quotes close the -Command string early, and
           what is left gets re-parsed by PowerShell, which also runs a `;` or a backtick in a
           prompt as source code)
  A script with NO param block is the one form that works: under -File it receives every token
  verbatim in $args, quoting intact. doki-shim.ps1 is that script. It re-quotes each token and
  calls the launcher through Invoke-Expression, which is what makes `--` mean end-of-parameters
  again. The whole chain stays in ONE pwsh process, so the exit code comes back unchanged
  (measured: a launcher exiting 7 gives 7 in both cmd.exe and pwsh).

  Why the names are doki-claude / doki-copilot and never claude / copilot: a same-stem .exe always
  beats a .cmd in the same directory, and both real CLIs are .exe files already on PATH here. A
  shim named `claude` would be shadowed at best and would hijack the cloud client at worst. Owner
  chose these names on 2026-08-19, and doki-manager follows the same prefix for the same reason.
  The cloud shim is the one deliberate break: born doki-zai, renamed zai-claude by the owner on
  2026-08-30. It drops the shared `doki-` tab-completion stem on purpose, so the name says both
  halves of what it drives: z.ai, and Claude. The never-the-bare-client-name half of the rule
  still holds for it, for the same shadowing reason.

  Why doki-manager can still be absent, even though it ships now. scripts\package-bootstrappers.ps1
  has staged scripts\doki-manager.ps1 in the standalone bootstrapper zip since 2026-08-19, alongside
  claude-local.ps1, copilot-local.ps1 and this file. So a zip built on or after that day carries all
  four. The one launcher the packager still leaves out on purpose is scripts\claude-zai.ps1, the
  cloud sibling: a bootstrapper zip is the local-weights bundle, and the billed launcher is reached by
  name from a full checkout instead. This row still degrades to a warning and skips its shim when the
  launcher is missing, rather than the whole install refusing over a file the two client shims never
  needed. That warning firing now points at an older zip built before 2026-08-19, or a full checkout
  where the file is genuinely gone.

  What this script does NOT do. It never touches doki.ps1: the shims call the launchers under
  scripts\ directly. It never sets CLAUDE_CONFIG_DIR or
  COPILOT_HOME either. The launchers already point those at %LOCALAPPDATA%\DokiDex\claude-home and
  ...\copilot-home and seed them per item on first use. Pre-creating those directories here would
  flip claude-local.ps1's $firstRun test to false and swallow its "seeded" note, for no gain, so we
  only print where they will appear.

  Writing the files is not the same as installing them. A successful run therefore ends by RUNNING
  what it just wrote. Each shim is invoked through a real cmd.exe and has to reach its launcher with
  its arguments intact. The backend gets probed and reported on too. See Test-ShimEndToEnd and
  Show-BackendPreflight below for how each is measured and what proves it can still fail.

  What a new terminal is and is not needed for. Measured 2026-08-19 on this box with a throwaway
  User variable, written to HKCU\Environment exactly the way the PATH merge writes, then read back
  from four places:
    registry, immediately after the write                    -> new value
    this script's own already-running process                -> stale
    a fresh cmd.exe spawned as a CHILD of a running shell    -> stale
    a cmd.exe launched through the already-running explorer  -> NEW VALUE
  So the WM_SETTINGCHANGE broadcast that rides along with the registry write (Add-UserPathEntry
  sends it on the add, Remove-UserPathEntry on the remove) does
  reach Explorer. A terminal opened from the Start menu or the taskbar has the new PATH with no
  sign-out. What no broadcast can fix is a shell that is already open, or anything that shell
  launches, because a process inherits its parent's environment block instead of re-reading the
  registry. That is the whole of the "open a new terminal" caveat. It is also why the closing note
  names those two cases separately rather than saying "restart your terminal" and leaving you to
  guess which terminals it meant.

  Usage:
    .\scripts\install-clients.ps1              # generate the shims, merge the PATH entry, verify
    .\scripts\install-clients.ps1 -Uninstall   # remove both, leaving PATH as it was

  Both directions are idempotent. A second run reports what was already right and writes nothing.
  The verification at the end still runs, because "already installed" is a claim worth re-proving.

  KNOWN RISK, honestly untested as of 2026-08-19. cmd.exe classically queues
  "Terminate batch job (Y/N)?" when a batch file receives a CTRL_C_EVENT, and Ctrl+C is Claude
  Code's interrupt key. The session that wrote this had no interactive terminal to press Ctrl+C in,
  so this is documented rather than claimed to work. If the prompt shows up, run the launcher
  directly instead:  pwsh -NoProfile -File scripts\claude-local.ps1
#>
[CmdletBinding()]
param(
    [switch]$Uninstall,                          # remove the shims and the PATH entry, leaving nothing behind
    # Which backend the closing preflight probes. The default matches the -BaseUrl default in both
    # scripts\claude-local.ps1 and scripts\copilot-local.ps1. That way the check reports on the
    # server the shims will actually reach. Point it elsewhere to preflight a non-default port.
    [string]$BaseUrl = "http://127.0.0.1:8080"
)

$ErrorActionPreference = "Stop"
$repo    = Split-Path $PSScriptRoot -Parent
$shimDir = Join-Path $PSScriptRoot "shims"

function Info($m) { Write-Host "  $m"   -ForegroundColor DarkGray }
function Ok($m)   { Write-Host "  + $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  ! $m" -ForegroundColor Yellow }
function Fail($what, $fix) {
    Write-Host ""
    Write-Host $what -ForegroundColor Red
    Write-Host "  $fix"
    exit 1
}

# The four commands this installs, side by side.
#
#   Cli / Install  the real executable a launcher drives, and what to type when it is missing.
#                  doki-manager drives no external client, so it has neither.
#   Required       what happens when the LAUNCHER is absent. The two client launchers are the whole
#                  point of this script and their absence stays fatal. scripts\doki-manager.ps1 is
#                  different: the standalone bootstrapper zip does not ship it (scripts\package-
#                  bootstrappers.ps1 stages claude-local.ps1, copilot-local.ps1 and this file, and
#                  that is the entire list), so someone installing out of an extracted zip has no
#                  manager to point at. Warn and skip there rather than refusing to install the two
#                  shims that would have worked. A shim pointing at nothing is still never written.
#   Smoke*         the run check, per row. It cannot be shared, because the four targets have
#                  different parameter sets and the whole value of the check is that the token we
#                  send comes back out of the TARGET's own mouth. See Test-ShimEndToEnd.
#
# Adding a fourth command means one more row here, its own SmokeArgs/SmokeExpect, and nothing else.
$smokeUrl  = "http://127.0.0.1:1"
$smokeVerb = "doki-shim-smoke"
# The cloud endpoint claude-zai.ps1 defaults to. Used by its smoke row only.
$zaiUrl    = "https://api.z.ai/api/anthropic"
$shims = @(
    @{ Name = "doki-claude";  Launcher = "claude-local.ps1";  Required = $true
       Cli = "claude";  Install = "npm install -g @anthropic-ai/claude-code"
       # -Print dumps the resolved environment and exits before launching anything. ANTHROPIC_BASE_URL
       # is set from -BaseUrl, so seeing our dead URL there is a flag AND its value making the whole
       # trip. -NoWarm rides along as a belt: it is the default now, and it was not always.
       SmokeArgs   = "-BaseUrl $smokeUrl -NoWarm -Print"
       SmokeExpect = 'ANTHROPIC_BASE_URL\s+' + [regex]::Escape($smokeUrl) + '(\s|$)'
       SmokeProves = "-BaseUrl and its value reached the launcher's parameter binder intact" }
    @{ Name = "doki-copilot"; Launcher = "copilot-local.ps1"; Required = $true
       Cli = "copilot"; Install = "winget install GitHub.Copilot"
       # Same idea. This launcher appends /v1 for the openai wire, so the expectation says so.
       SmokeArgs   = "-BaseUrl $smokeUrl -NoWarm -Print"
       SmokeExpect = 'COPILOT_PROVIDER_BASE_URL\s+' + [regex]::Escape("$smokeUrl/v1") + '(\s|$)'
       SmokeProves = "-BaseUrl and its value reached the launcher's parameter binder intact" }
    @{ Name = "zai-claude"; Launcher = "claude-zai.ps1"; Required = $false
       Cli = "claude"; Install = "npm install -g @anthropic-ai/claude-code"
       # Not required because the standalone bootstrapper zip never stages claude-zai.ps1 (the
       # cloud sibling launcher stays out on purpose), so a zip install must warn and skip rather
       # than fail. Unlike this row, the doki-manager row below IS staged in the zip since
       # 2026-08-19 and only warns when that assumption doesn't hold.
       # -Print makes no network call and works keyless by design, so the smoke also passes on a
       # box whose settings.json has no z.ai key yet. Seeing the z.ai URL in ANTHROPIC_BASE_URL
       # proves the whole cmd -> bridge -> launcher hop resolved the endpoint.
       SmokeArgs   = "-Print"
       SmokeExpect = 'ANTHROPIC_BASE_URL\s+' + [regex]::Escape($zaiUrl) + '(\s|$)'
       SmokeProves = "the launcher resolved its z.ai endpoint through the whole shim chain" }
    @{ Name = "doki-manager"; Launcher = "doki-manager.ps1";  Required = $false
       Cli = $null; Install = $null
       # A deliberately invalid VERB. scripts\doki-manager.ps1's param block puts a ValidateSet on
       # -Verb, so PowerShell's binder rejects an unknown one and quotes the offending token straight
       # back at us. That makes the echo the binder's doing rather than the manager's, and it runs
       # none of the script: no download, no install, no model touched. The token carries a dash on
       # purpose, so this also proves a dash-word survives the bridge's quoting. The expectation
       # matches the token echo plus the attribute name within a bounded gap rather than the error's
       # PROSE, and that is deliberate: PowerShell's error rendering wraps long messages at the
       # console width and prefixes every wrapped line with a `| ` gutter, so any multi-word phrase
       # can arrive split by " | " (seen live 2026-08-30 on the same 7.6.5 the phrase was first
       # measured on, which broke the original single-space pattern with nothing real changed).
       SmokeArgs   = $smokeVerb
       SmokeExpect = [regex]::Escape('"' + $smokeVerb + '"') + '[\s\S]{0,400}ValidateSet'
       SmokeProves = "a positional dash-word reached the manager's parameter binder verbatim" }
)

$bridgeName = "doki-shim.ps1"

# The seat both shims land on by default. Same value as scripts\claude-local.ps1's -Model default,
# and a model key in serving\llama-swap.yaml. Since the 2026-08-25 rename it is the model's real
# name, so it carries spaces and brackets and stays quoted.
$seat = "Qwen3.8-27B [256k] (Thinking, Standard)"

# cmd.exe wants CRLF, and a batch file's last line wants a terminator. Normalise both here so the
# "already current" comparison below can be a byte-for-byte -ceq instead of a fuzzy one.
function ToCrLf($text) { $text.Replace("`r`n", "`n").Replace("`n", "`r`n") + "`r`n" }

# The shim body. `%~dp0` keeps it self-locating, so moving or renaming the checkout does not strand
# it on a stale absolute path. -NoProfile matters for more than startup time: a user profile that
# writes to the host or sets ANTHROPIC_* variables would land in the launcher's environment.
function New-ShimText($name, $launcher) {
    ToCrLf @"
@echo off
rem $name - forwards every argument to scripts\$launcher and returns its exit code.
rem GENERATED by scripts\install-clients.ps1. Edit that script, not this file.
rem
rem One generator writes all of these, so the argument handling is identical across them by
rem construction rather than by anyone remembering to keep four files in step.
rem
rem Never named the bare client name: a same-stem .exe beats a .cmd in the same directory, and
rem the cloud clients on PATH have to keep working untouched.
rem
rem The hop through $bridgeName is not decoration. See install-clients.ps1's header for the two
rem measurements that rule out calling the launcher with -File or -Command directly.
rem
rem Ctrl+C may raise cmd.exe's "Terminate batch job (Y/N)?" prompt. Untested as of 2026-08-19.
rem If it bites, run the launcher directly: pwsh -NoProfile -File scripts\$launcher
pwsh -NoProfile -ExecutionPolicy Bypass -File "%~dp0$bridgeName" "%~dp0..\$launcher" %*
exit /b %ERRORLEVEL%
"@
}

# The argument bridge, shared by both shims. NO param block, deliberately: that is the only shape
# that receives `--` and quoted values verbatim from `pwsh -File` (measured 2026-08-19, PS 7.6.5).
function New-BridgeText {
    ToCrLf @'
# doki-shim.ps1 - the argument bridge behind doki-claude.cmd and doki-copilot.cmd.
# GENERATED by scripts\install-clients.ps1. Edit that script, not this file.
#
# There is no param block on purpose. Under `pwsh -File` a script declaring parameters hands `--`
# to the parameter binder and dies with "the parameter name '' is ambiguous", while a param-less
# one gets every token in $args exactly as typed, quoting and all. Measured 2026-08-19 on PS 7.6.5.
$ErrorActionPreference = 'Stop'
$launcher = $args[0]
$forward  = @($args | Select-Object -Skip 1)

# A token is forwarded UNQUOTED only when it reads as a flag or as the divider itself. Everything
# else gets single-quoted, which is what keeps a prompt holding a space, a $ or a ; intact. That is
# also the injection guard, because the string below goes through Invoke-Expression: a token like
# `-;whoami` must not qualify as a flag. Requiring a letter right after the dashes is what stops it.
$tokens = foreach ($a in $forward) {
    if ($a -eq '--' -or $a -match '^--?[A-Za-z][A-Za-z0-9._-]*$') { $a }
    else { "'" + ($a -replace "'", "''") + "'" }
}

# Invoke-Expression rather than splatting: a splatted '--' hits the same binder ambiguity that
# -File does (measured). Parsing the call as source text is what gives `--` its meaning back.
# $code is seeded to failure for the reason the launchers seed theirs: $ErrorActionPreference is
# Stop, so a terminating error must not leave an unassigned code that exits 0.
$code = 1
Invoke-Expression ("& '" + ($launcher -replace "'", "''") + "' " + ($tokens -join ' '))
$code = $LASTEXITCODE
exit $code
'@
}

# --- the User PATH ------------------------------------------------------------------------------
# The ADD half used to be borrowed, not written here: electron\main.js owned an idempotent merge and
# exported it as a pure function, and this script shelled out to node to emit the same PowerShell
# rather than keeping a second copy. That shell was removed on 2026-09-02 (see archive.md), so the
# merge is inlined below, natively, in the same shape as Remove-UserPathEntry. Two things came back
# with it and both are load-bearing:
#
#   1. The REG_EXPAND_SZ downgrade trap. Reading Path through [Environment]::GetEnvironmentVariable
#      EXPANDS it, and writing it back through SetEnvironmentVariable downgrades the value kind to
#      REG_SZ, which on this box turns the real %USERPROFILE%\.dotnet\tools entry into a frozen
#      literal. So: raw read with DoNotExpandEnvironmentNames, write back with the ORIGINAL kind.
#   2. The WM_SETTINGCHANGE broadcast. A direct registry write skips the broadcast
#      [Environment]::SetEnvironmentVariable would have done, and without it shells launched later
#      keep the stale block until the next login.
#
# Dropping node also drops a prerequisite: putting three shims on PATH no longer needs a JavaScript
# runtime installed, which was always an odd thing for this script to require.
function Add-UserPathEntry($dirToAdd) {
    $root = $dirToAdd.TrimEnd('\', '/')
    $envKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Environment')
    $current = [string]$envKey.GetValue('Path', '', [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    $kind = [Microsoft.Win32.RegistryValueKind]::ExpandString
    if (($envKey.GetValueNames() -contains 'Path') -and ($envKey.GetValueKind('Path') -eq [Microsoft.Win32.RegistryValueKind]::String)) {
        $kind = [Microsoft.Win32.RegistryValueKind]::String
    }
    if (-not $current) { $current = "" }
    # Trailing-separator insensitive, so 'C:\x\shims' and 'C:\x\shims\' are the same entry and a
    # re-run cannot append a near-duplicate. Same comparison Remove-UserPathEntry uses.
    $parts = @($current -split ';' | Where-Object { $_ })
    foreach ($p in $parts) {
        if ($p.Trim().TrimEnd('\', '/') -ieq $root) { return "ALREADY_PRESENT" }
    }
    $trimmed = $current.TrimEnd(';')
    $updated = if ($trimmed.Length -eq 0) { $root } else { "$trimmed;$root" }
    $envKey.SetValue('Path', $updated, $kind)
    try {
        Add-Type -Namespace DokiDexClients -Name Win32 -MemberDefinition '[DllImport("user32.dll", CharSet=CharSet.Auto)] public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam, uint fuFlags, uint uTimeout, out UIntPtr lpdwResult);' -ErrorAction Stop
        $sent = [UIntPtr]::Zero
        [void][DokiDexClients.Win32]::SendMessageTimeout([IntPtr]0xffff, 0x1A, [UIntPtr]::Zero, 'Environment', 2, 5000, [ref]$sent)
    } catch { }   # best-effort: the PATH is already correct, a failed broadcast costs a re-login
    return "ADDED"
}

# The REMOVE half has no counterpart to borrow. buildPathMergeScript's dirToRemove mode always
# guarantees dirToAdd ends up present, so asking it to drop the shim dir would re-append it in the
# same breath. This mirrors main.js's psReadUserVarRaw/psWriteUserVarRaw deliberately: raw read with
# DoNotExpandEnvironmentNames, write back with the ORIGINAL value kind, then broadcast
# WM_SETTINGCHANGE by hand because a direct registry write skips the broadcast that
# [Environment]::SetEnvironmentVariable would have done for us. Without it, shells launched later
# keep the stale block until the next login.
function Remove-UserPathEntry($dirToRemove) {
    $target = $dirToRemove.TrimEnd('\', '/')
    $envKey = [Microsoft.Win32.Registry]::CurrentUser.CreateSubKey('Environment')
    $current = [string]$envKey.GetValue('Path', '', [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
    $kind = [Microsoft.Win32.RegistryValueKind]::ExpandString
    if (($envKey.GetValueNames() -contains 'Path') -and ($envKey.GetValueKind('Path') -eq [Microsoft.Win32.RegistryValueKind]::String)) {
        $kind = [Microsoft.Win32.RegistryValueKind]::String
    }
    # @(...) on both sides: a single surviving entry would otherwise collapse to a bare [string]
    # and break .Count, which is the comparison the whole no-op decision rests on.
    $parts = @($current -split ';' | Where-Object { $_ })
    $kept  = @($parts | Where-Object { $_.Trim().TrimEnd('\', '/') -ine $target })
    if ($kept.Count -eq $parts.Count) { return "NOT_PRESENT" }
    $envKey.SetValue('Path', ($kept -join ';'), $kind)
    try {
        Add-Type -Namespace DokiDexClients -Name Win32 -MemberDefinition '[DllImport("user32.dll", CharSet=CharSet.Auto)] public static extern IntPtr SendMessageTimeout(IntPtr hWnd, uint Msg, UIntPtr wParam, string lParam, uint fuFlags, uint uTimeout, out UIntPtr lpdwResult);' -ErrorAction Stop
        $sent = [UIntPtr]::Zero
        [void][DokiDexClients.Win32]::SendMessageTimeout([IntPtr]0xffff, 0x1A, [UIntPtr]::Zero, 'Environment', 2, 5000, [ref]$sent)
    } catch { }   # best-effort: the PATH is already correct, a failed broadcast costs a re-login
    return "REMOVED"
}

# --- does the thing we just wrote actually run? --------------------------------------------------
# A generated file that was never executed is not an installation. So each shim gets invoked the way
# a user's terminal will invoke it: through a REAL cmd.exe, by the path we just wrote. A pass means
# cmd.exe resolved the .cmd, pwsh started, doki-shim.ps1 forwarded the tokens, and the TARGET's own
# parameter binder saw them intact. Every row's expectation is an ECHO of a token this script chose,
# which is what keeps the check honest: nothing we can match is something the target prints anyway.
#
# WHAT CHANGED ON 2026-08-19, AND WHY. The old check pointed both launchers at a dead port and
# matched their `No inference server on <url>.` line. That line no longer appears on this path: the
# launchers stopped probing the backend before launch, precisely so a working run does not wait on a
# health check. Matching a message that can no longer be printed is a check that can only fail, which
# is this repo's signature defect wearing the other face. The replacement matches -Print's resolved
# ANTHROPIC_BASE_URL / COPILOT_PROVIDER_BASE_URL instead. That is strictly better besides: it proves
# the VALUE arrived, not merely that a flag did, and it is no longer coupled to prose either launcher
# is free to reword.
#
# ONE PROBE THAT LOOKS UNIVERSAL AND IS NOT, so nobody re-derives it. `pwsh -File <script>.ps1 -?`
# makes PowerShell print that script's own help and exit without running the body, for ANY script
# with a param block, catch-all or not. Measured 2026-08-19 against claude-local.ps1: 7906 characters
# of help, exit 0, body never ran. Through the shim it does the opposite. doki-shim.ps1 forwards a
# token unquoted only when it matches ^--?[A-Za-z][A-Za-z0-9._-]*$, and `-?` has no letter after the
# dash, so it gets single-quoted, lands in $Rest and is handed to the real client as a PROMPT.
# Measured the same day: `doki-claude.cmd -?` launched claude 2.1.236 for real. Do not use it here.
#
# Watched going RED on 2026-08-19 against three known-bad inputs, one per failure this is meant to
# catch: a shim pointing at a launcher path that does not exist, a shim that drops its arguments on
# the floor (the exact defect doki-shim.ps1 exists to prevent), and a .cmd that prints nothing at
# all. None matched. All three real shims did.
function Test-ShimEndToEnd($cmdPath, $smokeArgs, $expectPattern) {
    $out = (& cmd.exe /c "`"$cmdPath`" $smokeArgs 2>&1") -join "`n"
    if ($out -match $expectPattern) { return @{ Ok = $true } }
    $tail = @($out -split "`n" | Where-Object { $_ -and "$_".Trim() } | Select-Object -Last 3)
    return @{ Ok = $false; Tail = $tail }
}

# --- is there anything for the shims to reach? ---------------------------------------------------
# Report only, never start. The GPU holds ONE group at a time on this box. A silent `doki up agent`
# here could evict whatever is already resident. Naming the command is the whole job.
function Show-BackendPreflight($base) {
    $models = $null
    try { $models = Invoke-RestMethod "$base/v1/models" -TimeoutSec 5 } catch { }
    if (-not $models) {
        Warn "nothing answers on $base. The shims will exit 1 until it is up."
        Info "  start it when you want it:  .\doki.ps1 up agent"
        return
    }
    $known = @($models.data | ForEach-Object { $_.id })
    Ok "backend answers on $base ($($known.Count) tiers)"
    if ($known -contains $seat) { Ok "the '$seat' seat resolves" }
    else {
        # This used to hedge that the name "may still resolve as an alias", because llama-swap lists
        # model KEYS and it had varied by version whether an alias showed up too. The 2026-08-25
        # rename deleted every alias, so /v1/models is now the complete set of names a client can
        # ask for and an absent one really does not resolve. Still a Warn rather than a failure: the
        # server on $base may simply be a different tree than the one this script is installing from.
        Warn "'$seat' is not among the $($known.Count) names $base/v1/models returned, so it will not resolve there."
        Info "  most likely that server predates the 2026-08-25 rename and still serves short ids."
        Info "  see what it does serve:  curl $base/v1/models"
        Info "  or re-seat it in:  serving\llama-swap.yaml"
    }
}

Write-Host ""
Write-Host "DokiDex local-model CLI shims" -ForegroundColor Cyan
Write-Host "------------------------------"

# --- uninstall ----------------------------------------------------------------------------------
if ($Uninstall) {
    $touched = $false
    $leaves = @($bridgeName) + @($shims | ForEach-Object { "$($_.Name).cmd" })
    foreach ($leaf in $leaves) {
        $path = Join-Path $shimDir $leaf
        if (Test-Path -LiteralPath $path -PathType Leaf) { Remove-Item -LiteralPath $path -Force; Ok "removed $path"; $touched = $true }
        else { Info "$leaf was not there" }
    }
    # Only when EMPTY. Someone may have parked a shim of their own next to ours, and deleting that
    # would be a surprise the switch never advertised.
    if (Test-Path -LiteralPath $shimDir -PathType Container) {
        if (-not (Get-ChildItem -LiteralPath $shimDir -Force)) { Remove-Item -LiteralPath $shimDir -Force; Ok "removed $shimDir"; $touched = $true }
        else { Warn "$shimDir still holds files we did not put there, so it stays." }
    }
    if ((Remove-UserPathEntry $shimDir) -eq "REMOVED") { Ok "dropped $shimDir from your User PATH"; $touched = $true }
    else { Info "$shimDir was not on your User PATH" }
    Write-Host ""
    if ($touched) {
        Info "PATH: terminals opened from the Start menu or taskbar are already updated."
        Info "      Terminals still open keep the old PATH, this one included. Reopen those."
        # These files are tracked in this repo. Removing them is a working-tree change rather
        # than a return to a pristine checkout. Better to say it than to let `git status` look like
        # something went wrong.
        if (Get-Command git -ErrorAction SilentlyContinue) {
            $tracked = @(& git -C $repo ls-files -- scripts/shims 2>$null)
            if ($LASTEXITCODE -eq 0 -and $tracked.Count -gt 0) {
                Info "Note: scripts\shims is tracked in git. 'git status' now shows $($tracked.Count) deletions."
                Info "      Put the files back without re-installing:  git -C `"$repo`" restore scripts/shims"
            }
        }
    }
    else { Info "Nothing to undo. Already uninstalled." }
    Write-Host ""
    exit 0
}

# --- prerequisites ------------------------------------------------------------------------------
if (-not (Get-Command pwsh -ErrorAction SilentlyContinue)) {
    Fail "pwsh (PowerShell 7) was not found on PATH." "Every shim runs 'pwsh -File <launcher>.ps1'. Install it with:  winget install Microsoft.PowerShell"
}
Info "pwsh      $((Get-Command pwsh).Source)"

# Which rows we can honestly install. A shim pointing at nothing is worse than no shim, so a row
# whose launcher is absent is never written either way. What differs is how loudly we stop: the two
# client launchers are this script's reason to exist, while the manager is genuinely optional in an
# extracted bootstrapper zip. See the Required note on the $shims table.
$active = @()
foreach ($s in $shims) {
    $launcher = Join-Path $PSScriptRoot $s.Launcher
    if (Test-Path -LiteralPath $launcher -PathType Leaf) { $active += $s; continue }
    if ($s.Required) {
        Fail "scripts\$($s.Launcher) is missing." "A shim pointing at nothing is worse than no shim. Restore it from the repo, then re-run this."
    }
    Warn "scripts\$($s.Launcher) is not here, so $($s.Name) is skipped."
    Info "  The bootstrapper zip ships both launchers, doki-manager and this installer. Only"
    Info "  claude-zai.ps1 is absent by design. Anything else missing here means the file's really gone."
}

# One missing client is a warning, because installing only Claude Code or only Copilot is a normal
# thing to do and the other shim costs nothing sitting there. NEITHER installed is a failure: the
# whole point of this script is to reach a client, and there would be none to reach. Rows with no
# Cli (doki-manager drives no external client) sit this check out entirely.
$clients = @($active | Where-Object { $_.Cli })
$found = 0
foreach ($s in $clients) {
    $cli = Get-Command $s.Cli -ErrorAction SilentlyContinue
    if ($cli) { Info "$($s.Cli.PadRight(9)) $($cli.Source)"; $found++ }
    else { Warn "$($s.Cli) is not on PATH. $($s.Name) will be installed anyway. To get the client:  $($s.Install)" }
}
if ($clients.Count -gt 0 -and $found -eq 0) {
    Fail "neither claude nor copilot is installed, so there is nothing for the shims to launch." "Install at least one:  $($clients[0].Install)   or   $($clients[-1].Install)"
}

# --- the shims ----------------------------------------------------------------------------------
New-Item -ItemType Directory -Path $shimDir -Force | Out-Null
$wrote = $false
$files = @{ $bridgeName = (New-BridgeText) }
foreach ($s in $active) { $files["$($s.Name).cmd"] = (New-ShimText $s.Name $s.Launcher) }
foreach ($leaf in ($files.Keys | Sort-Object)) {
    $path = Join-Path $shimDir $leaf
    $want = $files[$leaf]
    $have = if (Test-Path -LiteralPath $path -PathType Leaf) { Get-Content -LiteralPath $path -Raw } else { $null }
    if ($have -ceq $want) { Info "$leaf already current" }
    else { Set-Content -LiteralPath $path -Value $want -NoNewline -Encoding ascii; Ok "wrote $path"; $wrote = $true }
}

# --- the PATH entry -----------------------------------------------------------------------------
# This used to Invoke-Expression a script generated by node out of electron\main.js. The merge is a
# plain function in this file now, so there is no generated text and no subprocess left to trust.
$outcome = Add-UserPathEntry $shimDir
if ($outcome -eq "ADDED") { Ok "added $shimDir to your User PATH"; $wrote = $true }
elseif ($outcome -eq "ALREADY_PRESENT") { Info "$shimDir already on your User PATH" }
else { Warn "unexpected merge result '$outcome'. Check your User PATH by hand." }

# --- prove it runs ------------------------------------------------------------------------------
Write-Host ""
Write-Host "Verifying" -ForegroundColor Cyan
$smokeFailed = 0
foreach ($s in $active) {
    $r = Test-ShimEndToEnd (Join-Path $shimDir "$($s.Name).cmd") $s.SmokeArgs $s.SmokeExpect
    if ($r.Ok) {
        Ok "$($s.Name) reaches scripts\$($s.Launcher) through cmd.exe"
        Info "  proved: $($s.SmokeProves)"
    }
    else {
        $smokeFailed++
        Warn "$($s.Name) did NOT reach scripts\$($s.Launcher) with its arguments intact."
        Info "  sent:     $($s.SmokeArgs)"
        Info "  expected: $($s.SmokeExpect)"
        foreach ($line in $r.Tail) { Info "  | $line" }
        # Full path on purpose. The bare name may not resolve in THIS shell yet, and a diagnostic
        # that tells you to run something that cannot run is worse than no diagnostic.
        Info "  see it for yourself:  pwsh -NoProfile -File scripts\$($s.Launcher) -Print"
    }
}
Show-BackendPreflight $BaseUrl

# --- what to do next ----------------------------------------------------------------------------
Write-Host ""
if ($smokeFailed -gt 0) { Write-Host "Installed. $smokeFailed of $($active.Count) shims failed the run check above." -ForegroundColor Yellow }
elseif ($wrote) { Write-Host "Installed." -ForegroundColor Green }
else { Write-Host "Already installed. Nothing changed." -ForegroundColor Green }

# Both halves of this are measured. The header records how. The broadcast really does reach
# Explorer, which is why the Start menu is live now. Nothing reaches a shell that is already open.
Info "PATH: terminals opened from the Start menu or taskbar have it now, no sign-out needed."
Info "      Terminals already open keep the old PATH, this one included. Reopen those."
Write-Host ""
Info "  doki-claude                 interactive Claude Code, seat $seat"
Info "  doki-claude -Task `"...`"      one-shot"
Info "  doki-claude -- -r <id>      short CLI flags go after the divider"
Info "  doki-copilot                the same for GitHub Copilot CLI"
Info "  zai-claude                  Claude Code on z.ai GLM (cloud, billed, nothing local)"
if ($active | Where-Object { $_.Name -eq "doki-manager" }) {
    Write-Host ""
    # The two client shims are deliberately thin: they set the environment and hand over. Everything
    # slow and occasional lives behind this one, which is why it is worth naming here rather than
    # leaving someone to find it. Verbs are read off scripts\doki-manager.ps1's own ValidateSet.
    Info "  doki-manager status         what is up, what is resident, what is on PATH"
    Info "  doki-manager warm           preload the seat, so the first turn is not a cold load"
    Info "  doki-manager start agent    bring the models up"
    Info "  doki-manager start -Warm    bring them up AND preload the seat, in one command"
}
Write-Host ""
Info "Per-client config stays isolated in %LOCALAPPDATA%\DokiDex\claude-home and ...\copilot-home."
Info "The launchers create and seed those on first use, so your global clients are never written to."
Info "zai-claude is the exception that points the other way: a cloud run keeps the real global"
Info "config, since that is the home configuration. See scripts\claude-zai.ps1's header."
Info "To remove the shims and the PATH entry:  .\scripts\install-clients.ps1 -Uninstall"
Write-Host ""
