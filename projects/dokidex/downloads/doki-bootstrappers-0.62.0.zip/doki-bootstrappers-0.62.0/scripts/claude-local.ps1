﻿<#
.SYNOPSIS
  Launch the real Anthropic Claude Code CLI against DokiDex's local models. No cloud, no proxy.

.DESCRIPTION
  llama.cpp's llama-server implements the Anthropic Messages API natively (/v1/messages +
  /v1/messages/count_tokens, ggml-org/llama.cpp PR #17570), and llama-swap v235 routes both to
  whichever tier the request names. Claude Code speaks exactly that API and does not check that a
  real Claude is on the other end, so the whole integration is environment variables — there is no
  translation proxy in this picture and nothing new to install.

  Every variable below is set for a reason that was measured or read out of the current docs at
  code.claude.com on 2026-08-18. The ones that look paranoid are the ones that bit during testing.

  Usage:
    .\scripts\claude-local.ps1                      # interactive REPL in the current directory
    .\scripts\claude-local.ps1 -Task "fix the bug"  # one-shot, prints the result, exits
    .\scripts\claude-local.ps1 -Model "gpt-oss-120b [128k] (Reasoning, Heavy)"
                                                    # drive a different llama-swap model. Quote it,
                                                    # the names contain spaces.
    .\scripts\claude-local.ps1 -Warm                # preload the seat first, then launch
    .\scripts\claude-local.ps1 -Print               # show the resolved config and exit
    .\scripts\claude-local.ps1 -SonnetModel "gpt-oss-120b [128k] (Reasoning, Heavy)"
                                                    # put a slot on a model that is NOT co-resident
                                                    # with the seat. This is the one way to do that
                                                    # now, and it costs a full weight swap every
                                                    # time you switch to it. The defaults never do.
    .\scripts\claude-local.ps1 -OneSeat            # every tier back on -Model, so no swap ever

  WHAT THE /model PICKER SHOWS, AND WHY IT IS SHORTER THAN IT USED TO BE. The four tiers are seated
  from what the server reports RESIDENT, not from a table in this file. In practice that is the seat
  plus its co-resident utility model, because the card holds one model at a time outside the agent-seat
  group. Nothing you can pick from the picker evicts your session any more. Warm more first
  (doki-manager warm) and more appears. See section 4 for the rule and for the money guard.

  THIS LAUNCHER NO LONGER PRELOADS THE MODEL, AND THAT IS WHAT -Warm IS FOR.
  Until 2026-08-19 every run probed /v1/models and then sent a real /v1/messages request to page the
  weights in before handing over. On a cold seat that is a long silent wait for something you did not
  ask for. Measured on this box with a STUB cli on PATH, so each number is the launcher's own cost
  and never the client's, median of the runs stated:
    cold seat, preload on   (the old default)   18.45 s   1 run
    hot  seat, preload on   (the old default)    0.87 s   3 runs
    hot  seat, preload off  (the new default)    0.58 s   3 runs
  Caveat on the cold number, because it flatters us: those weights had been resident minutes before,
  so Windows still held much of the file. A genuine first-boot load off cold disk is longer again.
  The preload is a real capability rather than dead weight. Skip it and the same wait happens inside
  the client's first turn, where it reads as a hang. It just belongs somewhere you ask for it, which
  is doki-manager (its `warm` verb) or -Warm here for a one-off.

  The backend reachability probe moved with it, and for a measured reason. A fresh pwsh pays 78-149 ms
  for its first Invoke-RestMethod against a LIVE server (2026-08-19, three runs: 141.4, 80.4, 78.3 ms),
  and even a raw TCP connect costs 13.6-20.5 ms there. Neither is the single-digit price that would
  earn a place on the happy path. So the probe now runs in exactly two places: before a -Warm preload,
  and after the client exits non-zero, where it turns an opaque failure into a named one. A run that
  works never pays for it.

  SHORT (single-dash) FLAGS ARE A DOCUMENTED LIMITATION, NOT A BUG WE CAN CATCH.
  PowerShell binds parameters by PREFIX, and it does that before a single line of this script
  runs, so a short claude flag typed plainly gets bound by the launcher and never reaches claude.
  Nothing in here can detect it afterwards. Measured 2026-08-19 on PS 7.6.5 against this exact
  param block, in-session:
    claude-local.ps1 -r abc123   ->  Rest=[abc123]
    claude-local.ps1 abc123      ->  Rest=[abc123]
  Byte-identical. The eaten flag leaves no trace in $PSBoundParameters, in the parameter metadata,
  or anywhere else in binding state, and $MyInvocation.Line is empty under `pwsh -File`. A guard
  used to sit at the top of this file trying to spot the mangle from the raw command line. It
  could not fire on the `pwsh -File` route at all, and through doki.ps1 it scanned doki.ps1's own
  source rather than anything you typed, so it was a check that could not fail on the two routes
  that needed it. It's gone. What follows is the honest limitation in its place.

  WHAT EACH SINGLE-DASH LETTER DOES TO THIS PARAM SET. Measured 2026-08-19, `-x VAL` in-session:
    bound by a launcher parameter, so claude never sees the flag
      -b -> BaseUrl    -c -> ContextTokens    -m -> Model      -t -> Task
      -p -> Print      -d -> Debug            -v -> Verbose    (the last two are PowerShell's own)
    TWO LETTERS THIS TABLE USED TO CLAIM NO LONGER BIND, and both rotted the same way: a parameter
    added after 2026-08-19 collided with a prefix nobody re-measured.
      -n  was NoWarm,          now ambiguous with -NoTelemetry
      -s  was SkipPermissions, now ambiguous with -SonnetModel
    PowerShell refuses the whole invocation rather than picking one, which is the good failure: it
    errors loudly instead of silently binding the wrong switch. Spell those two out. Nothing is lost
    on -n either way, since -NoWarm is the default behaviour now anyway.
    tests\launcher-flag-table.test.ps1 re-measures this table against the real parameter set, so the
    next parameter that collides fails a test instead of a user's muscle memory.
      -d -> Debug      -v -> Verbose          (PowerShell's own common parameters)
      -r -> Rest, and this is the quiet one. The FLAG itself vanishes while its value survives
           as a bare token, so `-r abc123` reaches claude as `abc123`: a prompt where a resume
           was meant. So do -d and -v: measured, `-d VAL` and `-v VAL` also forward a bare
           VAL, byte-identical to `-r VAL` in the argv claude receives. -d at least turns on
           PowerShell's debug stream, so it leaves a trace. -v and -r leave none. The rest of
           the collisions above change something you can see.
    hard error, ambiguous against the common parameters
      -e  -i  -o  -w
    forwarded to claude untouched
      -a  -f  -g  -h  -j  -k  -l  -q  -u  -x  -y  -z
    Of claude's own short flags that leaves -h safe. -c, -d, -p, -r and -v are not.

  HOW TO PASS A SHORT FLAG ANYWAY, PER ROUTE. All four measured 2026-08-19:
    & .\scripts\claude-local.ps1 -- -r abc123
        Works. Everything after the literal `--` lands in $Rest untouched and is forwarded
        verbatim and in order.
    doki-claude -- -r abc123
        Works. The PATH shim hops through scripts\shims\doki-shim.ps1, which re-parses the call
        as source text and so gives `--` its meaning back.
    pwsh -NoProfile -File .\scripts\claude-local.ps1 ...
        NO short flag can be passed on this route, and the divider does not rescue it either:
        `-File` hands `--` to the parameter binder, which rejects it before the script starts
        with "Parameter cannot be processed because the parameter name '' is ambiguous". Use
        claude's LONG flag (--resume abc123, --continue), or call through doki-claude, or wrap
        it:  pwsh -NoProfile -Command "& '.\scripts\claude-local.ps1' -- -r abc123"
    .\doki.ps1 claude ...
        Short flags collide with doki.ps1's own much larger parameter set first and mostly
        hard-error there, e.g. `-r` is ambiguous against -Refine -Raw -Realism -Reference
        -RefWeight -Rest. Worse, any flag that TAKES A VALUE mis-binds on that route: both
        `doki claude --resume abc123` and `doki claude -- -r abc123` send abc123 to claude as
        the PROMPT, because doki.ps1's own positional -Arg claims it. Value-less long flags are
        clean (`doki claude --continue` forwards as --continue). That binding lives in doki.ps1,
        not in this file.

  LONG flags are unambiguous in-session and need no divider:
    .\scripts\claude-local.ps1 --continue --resume abc123
  One measured exception. Under `pwsh -File`, `--verbose` binds to PowerShell's common -Verbose
  parameter and never reaches claude. In-session the same token forwards fine. Use `--debug`, or
  one of the working routes above, when you want claude's own verbose output from a shim.

  Your global %USERPROFILE%\.claude\settings.json is never written: the whole per-user surface is
  redirected to %LOCALAPPDATA%\DokiDex\claude-home for the run. See section 4b for what that shares
  with the global one (CLAUDE.md, skills, agents) and what it deliberately does not (sessions,
  history, credentials).

  Isolation runs in both directions. Section 4b covers what a local run WRITES. Section 0 covers
  what it INHERITS: an ambient ANTHROPIC_API_KEY and a parent Claude Code session's identity are
  cleared before the first child process starts, so a local run never carries a cloud credential or
  another session's id. Both edits are per-process. Nothing here touches your User or Machine
  environment. tests\local-cli-isolation.test.ps1 is the oracle for all of it.
#>
# PositionalBinding=$false is what makes flag pass-through work AT ALL, and it is not decoration.
# With PowerShell's default positional binding, an unrecognised `--flag` binds to the first free
# POSITIONAL parameter instead of landing in $Rest. Measured 2026-08-18 on PS 7.6.5, same script,
# only this attribute differing:
#   default        -Model m1 --continue --dangerously-skip-permissions
#                     -> Model=[m1]  Task=[--continue]  Rest=[--dangerously-skip-permissions]
#   PositionalBinding=$false, identical call
#                     -> Model=[m1]  Task=[]            Rest=[--continue|--dangerously-skip-permissions]
# The default form silently swallowed a flag into a STRING parameter and carried on, which is the
# quiet-wrong shape this repo keeps getting bitten by. Every parameter below must now be named.
[CmdletBinding(PositionalBinding = $false)]
param(
    # The llama-swap model that answers. The default is the measured Claude Code seat, named exactly
    # as llama-swap names it: real model, its per-request context window, then what it is and what it
    # costs you. Quote it, because it contains spaces.
    [string]$Model = "Qwen3.8-27B [256k] (Thinking, Standard)",
    [string]$Task,                       # one-shot prompt (maps to `claude -p`)
    # 0 means DERIVE it from -Model's own [Nk] bracket, which is the default and the right answer.
    # This used to be a hardcoded 106496 with a comment saying it must match the tier's -c. That is
    # the same shape as the bug that made the Copilot launcher ask for 35,504 tokens more than the
    # server served and truncate silently: one fact, written in two places, one of which rots. The
    # model name already states the window, so read it from there. Pass a number to override, and
    # it gets checked against the window rather than trusted.
    [int]$ContextTokens = 0,
    [string]$BaseUrl = "http://127.0.0.1:8080",
    [switch]$Print,                      # print the resolved config and exit without launching
    # Which tier answers background calls (session titles, the one-shot helpers). "auto" asks the
    # server which cheaper model is already resident beside the seat and uses that, so nothing in
    # this file has to know the utility model's name. Pass "same" to put every tier back on -Model, or
    # name a model to pin it.
    [string]$HaikuModel = "auto",
    # -Warm preloads the tier before handing over. OFF by default since 2026-08-19: see the header
    # for the three timings that moved it. -NoWarm is what the default now does on its own, and it
    # stays as an accepted parameter rather than being deleted, because callers already pass it:
    # tests\local-cli-isolation.test.ps1 line 342 and scripts\install-clients.ps1's shim smoke both
    # do, and every -NoWarm in docs\local-cli-setup.md would break. It also still means something
    # real, since it overrides -Warm.
    [switch]$Warm,                       # preload the tier before launching (the old default)
    # Point sonnet and fable at OTHER llama-swap keys so the picker becomes a real menu. Each is a
    # separate model on one card, so selecting a different tier costs a weight swap. -OneSeat
    # collapses all four back onto -Model, which is the no-swap configuration.
    [string]$SonnetModel,
    [string]$FableModel,
    [switch]$OneSeat,
    [switch]$NoWarm,                     # never preload. Now the default; kept because it overrides -Warm
    [switch]$NoTelemetry,                # do not record this run. DOKI_TELEMETRY=0 turns it off for good
    [switch]$SkipPermissions,            # convenience alias for --dangerously-skip-permissions
    # Voice and behaviour rules handed to `claude --append-system-prompt`, read from the output-style
    # file so the rules live in exactly one place. Pass a different path to use another file, or
    # -NoSystemPrompt to launch without one. A missing file is skipped silently.
    [string]$SystemPromptFile = (Join-Path $env:USERPROFILE ".claude\output-styles\plain-language.md"),
    [switch]$NoSystemPrompt,             # launch without the appended system prompt
    # EVERYTHING ELSE IS FORWARDED TO `claude` VERBATIM, in order. All of these now work:
    #   .\claude-local.ps1 --continue
    #   .\claude-local.ps1 --resume 0cb916db
    #   .\claude-local.ps1 --dangerously-skip-permissions --verbose
    #   .\claude-local.ps1 -Task "fix the parser" --output-format stream-json --verbose
    [Parameter(ValueFromRemainingArguments = $true)][string[]]$Rest
)

$ErrorActionPreference = "Stop"

# --- system-prompt append -----------------------------------------------------------------------
# WHY THIS READS THE OUTPUT STYLE RATHER THAN CARRYING ITS OWN COPY. The voice rules already live in
# ~\.claude\output-styles\plain-language.md. Pasting them here too would be one fact written in two
# places, one of which rots, which is the defect class this repo keeps finding. So read that file and
# strip its YAML frontmatter, leaving the body to go in as --append-system-prompt.
#
# Best-effort by design. A missing file is the normal state on a fresh box or another user's
# checkout, and it must never stop the CLI from launching, so it is skipped in silence rather than
# warned about. A caller who passes their own --append-system-prompt wins outright: we add nothing,
# because two appends is a prompt neither of them wrote.
function Get-SystemPromptAppend($Path) {
    if (-not $Path -or -not (Test-Path $Path)) { return $null }
    try {
        $text = Get-Content $Path -Raw -ErrorAction Stop
    } catch { return $null }
    # Frontmatter only counts when the file OPENS with it. A --- further down is a horizontal rule
    # in the body, and eating from there would silently swallow the rules above it.
    if ($text -match '^\s*---\r?\n') {
        $parts = [regex]::Split($text, '(?m)^---\s*$', 3)
        if ($parts.Count -ge 3) { $text = $parts[2] }
    }
    $text = $text.Trim()
    if (-not $text) { return $null }
    return $text
}

$repo = Split-Path $PSScriptRoot -Parent

# The lease this script drops has to land where doki.ps1 LOOKS for it, and doki.ps1 looks under the
# resolved DATA root, not under the checkout. Those are the same directory on a dev box and different
# ones on an install, so writing the lease repo-relative would give `doki down` a warning that
# can never fire — worse than no warning, because it reads as coverage. Mirror doki.ps1's
# Resolve-DokiRoot order exactly: -DokiRoot is doki.ps1's own parameter and never reaches here, so
# this covers the two signals that do: DOKI_DATA_ROOT, then settings.json dataRoot, then the checkout.
function Resolve-DataRoot($fallback) {
    if ($env:DOKI_DATA_ROOT -and (Test-Path -LiteralPath $env:DOKI_DATA_ROOT -PathType Container)) {
        return $env:DOKI_DATA_ROOT
    }
    $settingsPath = Join-Path $env:LOCALAPPDATA "dokidex\settings.json"
    if (Test-Path -LiteralPath $settingsPath -PathType Leaf) {
        try {
            $candidate = (Get-Content -LiteralPath $settingsPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop).dataRoot
            if ($candidate -is [string] -and $candidate.Trim() -and (Test-Path -LiteralPath $candidate -PathType Container)) {
                return $candidate
            }
        } catch { }   # missing/corrupt settings.json: fall through, never throw
    }
    return $fallback
}
$root = Resolve-DataRoot $repo

# Warn() used to live beside this. Its only caller was the "'$Model' is not a llama-swap model key"
# note in the old section 2, which needed the tier list the removed probe fetched. Deleted rather
# than left dangling, and no loss: that warning fired only under -NoWarm and its own comment
# admitted /v1/models listed keys but not the aliases the seat resolved through, so an absent name
# was never evidence of anything. Aliases are gone entirely now, which retires that whole class of
# doubt: a model id either is a key on the server or it is nothing.
function Info($m) { Write-Host "  $m" -ForegroundColor DarkGray }
# Warn was missing until 2026-08-25 and its absence was invisible, because nothing on the happy path
# called it. The context-derivation code below does, on exactly two paths: a model whose name carries
# no window, and an explicit budget above what the server serves. Both are edge cases, and with
# ErrorActionPreference Stop a missing function does not degrade, it kills the launcher. So the
# fallback that exists to keep a launch working was itself the thing that broke it.
function Warn($m) { Write-Host "  !    $m" -ForegroundColor Yellow }

Write-Host ""
Write-Host "Claude Code -> DokiDex local models" -ForegroundColor Cyan
Write-Host "------------------------------------"

# --- 0. a known starting environment -----------------------------------------------------------
# Section 4b fixed the OUTBOUND direction: nothing this run does reaches the global client state.
# It does nothing for the INBOUND one. Every variable in the shell that launched this script is
# inherited by `claude` and by every child this script spawns. An ambient cloud credential or a
# parent session's identity therefore rides straight into a local run. Measured on this box
# 2026-08-19: a shell started from inside Claude Code carries CLAUDECODE, CLAUDE_PID,
# CLAUDE_CODE_SESSION_ID, CLAUDE_CODE_ENTRYPOINT, CLAUDE_CODE_BRIDGE_SESSION_ID and
# CLAUDE_CODE_CHILD_SESSION.
#
# WHY THIS SITS AHEAD OF SECTION 1 RATHER THAN NEXT TO THE VARIABLES IT REPLACES. ANTHROPIC_API_KEY
# was already cleared, down in section 4 where AUTH_TOKEN gets set. That is too late by one child.
# Section 1 runs `claude --version`, which is a child process. The pre-fix version of this script
# handed it the ambient key. Measured 2026-08-19 by dumping that child's own environment
# (tests\local-cli-isolation.test.ps1). Neutralise first, spawn second.
#
# PER-PROCESS ONLY. That is the whole safety argument. `Remove-Item Env:\NAME` edits this process's
# environment block and nothing else. No other terminal, no other client, and no future session
# sees any of it. The call that WOULD write through is the User overload of
# [Environment]::SetEnvironmentVariable. It appears nowhere in this file on purpose. The test
# asserts that by scanning the source, and again by diffing the User and Machine environment blocks
# around a real run.
$neutralised = @()
function Clear-InheritedVar([string]$Name) {
    if (Test-Path -LiteralPath "Env:\$Name") {
        Remove-Item -LiteralPath "Env:\$Name" -ErrorAction SilentlyContinue
        $script:neutralised += $Name
    }
}

# Credentials. Enumerated from the live process rather than typed out, because a hardcoded list only
# ever covers the names somebody thought of. The floor list underneath it is the belt to that
# braces. The name that actually matters dies even if the pattern is ever edited wrong.
# Conservative on purpose. Only names that are credential-SHAPED get cleared. ANTHROPIC_BASE_URL,
# ANTHROPIC_MODEL, the ANTHROPIC_DEFAULT_* tiers and ANTHROPIC_SMALL_FAST_MODEL are configuration
# rather than secrets. Section 4 sets every one of them a few lines down anyway. ANTHROPIC_PROFILE
# and the workload-identity variables are identifiers rather than secrets. They are left alone too.
# That is a stated limitation rather than a measurement. This leaf did not test what Claude Code
# does with them.
$credentialShape = "(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL)"
$liveCreds = @(Get-ChildItem Env: |
    Where-Object { $_.Name -match "^ANTHROPIC_" -and $_.Name -match $credentialShape } |
    ForEach-Object { $_.Name })
foreach ($n in @($liveCreds + @("ANTHROPIC_API_KEY", "ANTHROPIC_AUTH_TOKEN") | Select-Object -Unique)) {
    Clear-InheritedVar $n
}

# Session identity, as an EXPLICIT list rather than a CLAUDE_CODE_* wildcard. The difference
# matters. That namespace also holds configuration this script sets on purpose in section 4
# (CLAUDE_CODE_MAX_CONTEXT_TOKENS, CLAUDE_CODE_SUBAGENT_MODEL, CLAUDE_CODE_ATTRIBUTION_HEADER and
# friends). A wildcard here happens to be harmless today only because every one of those is set
# afterwards. It would quietly swallow the next deliberate one somebody adds.
foreach ($n in @(
        "CLAUDECODE", "CLAUDE_PID",
        "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_EXECPATH",
        "CLAUDE_CODE_BRIDGE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION")) {
    Clear-InheritedVar $n
}

# GITHUB_* and GH_* are deliberately NOT touched here. That is an asymmetry with copilot-local.ps1
# rather than an oversight. Copilot has a documented GitHub credential path of its own
# (`copilot help environment`: COPILOT_GITHUB_TOKEN, GH_TOKEN, GITHUB_TOKEN, in that precedence
# order, outrank stored credentials). Claude Code has no such path. What it has is a Bash tool that
# runs `gh`. Clearing the token here would change what the user's own commands do rather than what
# the client does. That is a different decision with a different blast radius.

# Names only, never values. This line goes to the terminal. Half of what it lists is a credential.
if ($neutralised.Count) { Info "cleared   inherited: $($neutralised -join ', ')" }

# --- 1. the CLI itself -------------------------------------------------------------------------
# NOTE the section 0 above is the environment-neutralising block and is unrelated to what this note
# is about. A short-flag guard used to live here and read
# $MyInvocation.Line to spot a flag the binder had eaten. It is deleted rather than repaired: the
# raw line is EMPTY under `pwsh -File`, which is the shape the PATH shims and every scripted caller
# use, and under `doki claude` the line it scanned was doki.ps1's own source rather than anything
# the user typed. Binding state cannot stand in for it either, because `-r abc123` and a bare
# `abc123` both arrive as Rest=[abc123] with nothing to tell them apart (measured 2026-08-19, PS
# 7.6.5). A warning that fires on two routes and is structurally unable to fire on the two that
# need it reads as coverage without being any. The limitation is written out in .SYNOPSIS instead,
# route by route, with the full collision list.
$claude = Get-Command claude -ErrorAction SilentlyContinue
if (-not $claude) {
    Write-Host "claude CLI not found on PATH." -ForegroundColor Red
    Write-Host "  Install it, then re-run:  npm install -g @anthropic-ai/claude-code"
    exit 1
}
Info "claude    $(& claude --version 2>$null)"

# --- 2. the backend, and why nothing here touches it -------------------------------------------
# A dead :8080 is still the single most likely reason a session fails, and Claude Code's own error
# for it is an opaque connection message several screens in. That has not changed. What changed is
# WHEN we go looking. The probe costs 78-149 ms in a fresh pwsh against a live server (measured
# three times, 2026-08-19: 141.4, 80.4, 78.3 ms), which is a toll every good run was paying to
# improve the wording of a bad one. Now the two functions below get called only where they earn it:
# ahead of a -Warm preload, and after the client exits non-zero. Both are already-slow paths.
#
# WATCH THIS GO RED before trusting it: point -BaseUrl at a port with nothing on it. The reachability
# test returns $false there, which is what Show-BackendDown keys on.
function Test-BackendReachable([string]$Base) {
    # 3 seconds, not the old 5. This runs where the user is already waiting, so it has to be a
    # bounded wait rather than a generous one. A live loopback server answers in single-digit ms.
    try { $null = Invoke-RestMethod "$Base/v1/models" -TimeoutSec 3; return $true } catch { return $false }
}
function Show-BackendDown([string]$Base) {
    Write-Host "No inference server on $Base." -ForegroundColor Red
    Write-Host "  Bring the models up with doki-manager, then run this again."
    Write-Host "  In a full checkout that is also:  .\doki.ps1 up agent"
}
Info "backend   $BaseUrl  (not probed: a working run should not wait on a health check)"

# --- 3. the preload, opt-in ---------------------------------------------------------------------
# Sending one real /v1/messages request does two jobs at once: it pages the weights in, and it proves
# the Anthropic surface is actually there. An engine built without it answers /v1/models perfectly
# well and then 404s every inference request. Both jobs are worth having. Neither is worth doing on
# every launch, which is why doki-manager owns the routine case and this stays here for a one-off.
#
# -NoWarm wins over -Warm. It has always meant "do not preload" and it keeps meaning exactly that,
# so a caller that passes both gets the safer of the two rather than a surprise.
if ($Warm -and -not $NoWarm) {
    # Fail fast rather than sitting on the 900-second request timeout below. An unreachable backend
    # is the common case here and it must not look like a load in progress.
    if (-not (Test-BackendReachable $BaseUrl)) { Show-BackendDown $BaseUrl; exit 1 }
    Info "warming $Model (first load pages the weights off disk; this can take a minute) ..."
    $body = @{ model = $Model; max_tokens = 4; messages = @(@{ role = "user"; content = "hi" }) } | ConvertTo-Json -Depth 5
    try {
        Invoke-RestMethod "$BaseUrl/v1/messages" -Method Post -ContentType "application/json" `
            -Headers @{ "anthropic-version" = "2023-06-01"; "x-api-key" = "dummy" } `
            -Body $body -TimeoutSec 900 | Out-Null
        Info "ready     /v1/messages answered"
    } catch {
        Write-Host "$BaseUrl/v1/messages did not answer: $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "  If this is a 404, the llama.cpp build predates its Anthropic Messages support (PR #17570)."
        Write-Host "  Check with:  .\doki.ps1 verify"
        exit 1
    }
}

# --- 4. the environment ------------------------------------------------------------------------
# A saved claude.ai login outranks nothing and is outranked by a credential variable, so setting
# ANTHROPIC_AUTH_TOKEN is what actually routes traffic here. The value is never checked by
# llama-server; it only has to be non-empty.
$env:ANTHROPIC_BASE_URL   = $BaseUrl
$env:ANTHROPIC_AUTH_TOKEN = "doki-local"
# Section 0 already cleared this one, ahead of the first child process. Kept here as well because it
# costs nothing and it is the line that stops an API key fighting AUTH_TOKEN over the header, which
# is a second reason independent of the isolation one.
Remove-Item Env:\ANTHROPIC_API_KEY -ErrorAction SilentlyContinue

# Claude Code resolves the opus / sonnet / haiku / fable aliases through these. Which model each
# one lands on is no longer a table in this file. It gets asked of the server, and the reason is a
# bug this file kept having. A hardcoded list of "names that mean the seat" broke silently the
# moment somebody added a name and did not update the list. That happened on 2026-08-20: a fourth
# alias for the seat went into the yaml, the list here did not follow, and naming that alias quietly
# lost the utility model and sent every background call back to the 27GB seat. The list was the bug, so
# the list is gone rather than corrected.
#
# WHAT WE ASK, AND WHY IT IS ONE ROUND TRIP. llama-swap's GET /running reports the models it holds
# resident right now, each with its state, its name and its description. That is everything needed
# to seat a picker: what is up, what it is called, and whether it costs money. The naming contract
# makes a row's key and its display name the same string, so there is no second lookup to do.
# Measured against a live server: 78-141 ms. The launcher pays it once, here, and nowhere else.
#
# THE RULE. Only a model that is ALREADY LOADED, or that the card can hold ALONGSIDE the seat, may
# be seated. This GPU holds one model at a time apart from the `agent-seat` group in
# serving\llama-swap.yaml, whose members carry swap:false and stay resident together. So a model
# reported resident beside the seat is by definition one that co-resides with it, and seating a
# picker slot on it costs no weight swap. The old default ladder pointed sonnet and fable at models
# outside that group, which meant picking either one evicted the session mid-conversation.
function Get-ResidentModels([string]$Base) {
    # A plain llama-server has no /running at all, so a 404 here means "this backend cannot tell us"
    # rather than "nothing is loaded". Both answers lead to the same safe fallback below, so they do
    # not need telling apart.
    try {
        $r = Invoke-RestMethod "$Base/running" -TimeoutSec 3
        return @(@($r.running) | Where-Object { $_.state -eq "ready" })
    } catch { return @() }
}

# THE MONEY GUARD, and it is not optional. The cloud row in serving\llama-swap.yaml is a member of
# the agent-seat group on purpose: it uses zero VRAM, and while it sat outside the group one cloud
# call evicted the 27GB seat. The consequence for this file is sharp. That row is resident beside
# the seat ALL THE TIME, so a rule that seats "whatever is resident" would put GitHub Copilot Cloud
# on a picker slot, and Claude Code's background traffic would then spend a real premium request per
# conversation title. It never gets seated automatically. Reaching it stays an explicit -Model or
# -SonnetModel that somebody typed on purpose.
#
# Two independent signals, because being wrong in the permissive direction here costs real money.
# WATCH THIS GO RED: hand it a row whose id ends "(Cloud, Billed)" and it must return $true.
function Test-BilledModel($Row) {
    if ([string]$Row.model -match '\([^)]*\b(?:Cloud|Billed)\b[^)]*\)') { return $true }
    # The yaml opens that row's description with "CLOUD, not local:", so this half keeps working
    # even if the naming contract is ever loosened.
    if ([string]$Row.description -match '^\s*CLOUD\b') { return $true }
    return $false
}

# The cost word every row name carries, ranked. Free means co-resident and evicting nothing, Heavy
# means experts paged out to system RAM. An unrecognised shape sorts as Standard deliberately: never
# the cheapest, never the heaviest, so a row this parser does not understand cannot be seated by
# accident in either direction.
#
# BILLED IS IN HERE ON PURPOSE, and leaving it out was a real bug for about ten minutes. Without a
# rank it landed in the unknown-shape fallback and got skipped for being neither cheapest nor
# heaviest, which LOOKED like the money guard working. It was not. Defeating the guard changed
# nothing, because the guard was never what excluded it. A protection nobody can watch fail is not a
# protection. Ranking it alongside Heavy puts the cloud row squarely in the fable slot's sights, so
# Test-BilledModel below is the only thing keeping it out, which is exactly where the safety should
# sit. tests\claude-local-seating.test.ps1 defeats the guard and proves the row gets seated without it.
$costRank = @{ 'Free' = 0; 'Light' = 1; 'Standard' = 2; 'Heavy' = 3; 'Billed' = 3 }
function Get-CostRank([string]$Id) {
    if ($Id -match '\(\s*[^,)]+,\s*([A-Za-z]+)\s*\)\s*$') {
        $word = $Matches[1]
        if ($costRank.ContainsKey($word)) { return $costRank[$word] }
    }
    return 2
}

$resident   = Get-ResidentModels $BaseUrl
$residentId = @($resident | ForEach-Object { [string]$_.model })
$seatIsUp   = $residentId -contains $Model

# Candidates are the models resident ALONGSIDE the seat. Not the seat itself, never a billed row,
# and nothing at all when the seat is cold: if the model you asked for is not up, seating the other
# slots off some unrelated resident model answers a question nobody asked.
$candidates = @()
if ($seatIsUp) {
    $candidates = @($resident |
        Where-Object { [string]$_.model -ne $Model -and -not (Test-BilledModel $_) } |
        ForEach-Object { [string]$_.model })
}
$modelRank = Get-CostRank $Model
$cheaper   = @($candidates | Where-Object { (Get-CostRank $_) -lt $modelRank } | Sort-Object { Get-CostRank $_ })
$dearer    = @($candidates | Where-Object { (Get-CostRank $_) -gt $modelRank } | Sort-Object { Get-CostRank $_ } -Descending)

# -SonnetModel and -FableModel still override, because paying for a weight swap on purpose is a real
# thing to want. What changed is the DEFAULT: an unnamed slot falls back to the seat instead of to a
# model that would evict it.
if ($OneSeat) {
    $opusTier = $Model; $sonnetTier = $Model; $fableTier = $Model; $haikuTier = $Model
} else {
    $opusTier   = $Model
    $sonnetTier = if ($SonnetModel) { $SonnetModel } else { $Model }
    $fableTier  = if ($FableModel)  { $FableModel  } elseif ($dearer.Count) { $dearer[0] } else { $Model }
    $haikuTier  = switch ($HaikuModel) {
        "same"  { $Model }
        "auto"  { if ($cheaper.Count) { $cheaper[0] } else { $Model } }
        default { if ($HaikuModel) { $HaikuModel } else { $Model } }
    }
}

# The picker labels. Without these it lists "opus" and "sonnet", which say nothing about what is
# actually answering. The row's name comes back on the same /running call we already paid for, and
# because the key and the name are now the same string, the bare id is a correct fallback rather
# than a degraded one.
$script:modelNames = @{}
foreach ($r in $resident) {
    if ($r.model -and $r.name) { $script:modelNames[[string]$r.model] = [string]$r.name }
}
function Get-TierName([string]$Key) {
    if ($Key -and $script:modelNames.ContainsKey($Key)) { return $script:modelNames[$Key] }
    return $Key
}
# The sub-line under each picker entry. It answers the one question the name does not: is this
# waiting for me, or does choosing it cost a load off disk.
function Get-TierNote([string]$Key) {
    if ($residentId -contains $Key) { return "local, resident now" }
    return "local, loads on first use"
}

$env:ANTHROPIC_MODEL                = $Model
$env:ANTHROPIC_DEFAULT_OPUS_MODEL   = $opusTier
$env:ANTHROPIC_DEFAULT_SONNET_MODEL = $sonnetTier
$env:ANTHROPIC_DEFAULT_HAIKU_MODEL  = $haikuTier
# 2.1.235 carries a fable tier too. Left unset, resolving it emits the baked-in id "claude-fable-5",
# which llama-swap has no key for, so the call 404s instead of landing on the seat.
$env:ANTHROPIC_DEFAULT_FABLE_MODEL  = $fableTier
# ANTHROPIC_SMALL_FAST_MODEL is the older name for the haiku slot and it still wins. The measured
# lookup order is ["ANTHROPIC_SMALL_FAST_MODEL", "ANTHROPIC_DEFAULT_HAIKU_MODEL"], first hit taking
# it, so a stale value already sitting in the shell short-circuits the line above and routes every
# background call somewhere else without saying a word. Pin it to the same tier. Then the two cannot
# disagree no matter what the environment arrived carrying.
$env:ANTHROPIC_SMALL_FAST_MODEL     = $haikuTier
$env:CLAUDE_CODE_SUBAGENT_MODEL     = $Model

$env:ANTHROPIC_DEFAULT_OPUS_MODEL_NAME          = (Get-TierName $opusTier)
$env:ANTHROPIC_DEFAULT_SONNET_MODEL_NAME        = (Get-TierName $sonnetTier)
$env:ANTHROPIC_DEFAULT_HAIKU_MODEL_NAME         = (Get-TierName $haikuTier)
$env:ANTHROPIC_DEFAULT_FABLE_MODEL_NAME         = (Get-TierName $fableTier)
$env:ANTHROPIC_DEFAULT_OPUS_MODEL_DESCRIPTION   = (Get-TierNote $opusTier)
$env:ANTHROPIC_DEFAULT_SONNET_MODEL_DESCRIPTION = (Get-TierNote $sonnetTier)
$env:ANTHROPIC_DEFAULT_HAIKU_MODEL_DESCRIPTION  = (Get-TierNote $haikuTier)
$env:ANTHROPIC_DEFAULT_FABLE_MODEL_DESCRIPTION  = (Get-TierNote $fableTier)

# The extra pinned entry, kept so -Model always has a slot of its own even when a tier override has
# taken the others. It carries the real model name now. It used to wrap an invented alias in an
# invented product label, which put two made-up names in front of the one thing the picker exists
# to tell you.
$env:ANTHROPIC_CUSTOM_MODEL_OPTION             = $Model
$env:ANTHROPIC_CUSTOM_MODEL_OPTION_NAME        = (Get-TierName $Model)
$env:ANTHROPIC_CUSTOM_MODEL_OPTION_DESCRIPTION = "Local llama.cpp on $BaseUrl"

# CLAUDE_CODE_MAX_CONTEXT_TOKENS below goes silently inert for any model id starting "clau", so a
# name that ever drifted into that shape would bring the context guessing back with no error. No
# row is named that way today and none should be. Say so if it ever happens, because the symptom
# otherwise is early compaction that looks like a client bug.
if ($Model -match '^(?i)clau') {
    Write-Host "  WARNING: model id '$Model' starts with 'clau', so CLAUDE_CODE_MAX_CONTEXT_TOKENS is ignored." -ForegroundColor Yellow
}

# Claude Code sizes its context window from the model ID. It cannot recognise ours, so without
# this it guesses, and a wrong guess means it either compacts far too early or overruns the tier's
# -c and gets truncated silently. Measured in 2.1.235: the override applies whenever it is > 0 AND
# the normalised model id does NOT start with "clau". DISABLE_COMPACT is a separate unconditional
# path, not a precondition for this one, whatever the older comment here claimed. The behaviour was
# right, the stated reason was inverted. Consequence worth keeping in mind: no display id we ever
# hand Claude Code may start with "clau", or this variable goes silently inert and the guessing
# comes back.
# DERIVE the context budget from the model name, unless the caller named one.
# The bracket is an exact encoding of the server's real per-request window: verified 2026-08-25
# against all 22 weighted rows, comment-stripped and -np divided, 22 exact and 0 mismatched. So
# "[104k]" means exactly 104 * 1024 = 106496 and there is nothing to keep in sync by hand.
#
# WHAT HAPPENS WHEN IT CANNOT BE READ. A model with no bracket (the cloud row, or a name somebody
# typed by hand) falls back to a conservative 32768 rather than to a large guess. Guessing high is
# the failure that truncates silently. Guessing low only costs an early compaction, and it says so.
function Get-ModelWindow([string]$Name) {
    if ($Name -match '\[(\d+)k\]') { return [int]$Matches[1] * 1024 }
    return $null
}
$derivedWindow = Get-ModelWindow $Model
if (-not $PSBoundParameters.ContainsKey('ContextTokens') -or $ContextTokens -le 0) {
    if ($derivedWindow) {
        $ContextTokens = $derivedWindow
    } else {
        $ContextTokens = 32768
        Warn "'$Model' carries no [Nk] window in its name, so the context budget falls back to 32768."
        Warn "  Guessing high here truncates prompts silently, so this guesses low on purpose."
    }
}
elseif ($derivedWindow -and $ContextTokens -gt $derivedWindow) {
    # An explicit value is honoured, but never silently: telling the client it has more window than
    # the server serves is the exact shape of the Copilot bug.
    Warn "-ContextTokens $ContextTokens is ABOVE what '$Model' serves ($derivedWindow)."
    Warn "  The server will truncate anything past $derivedWindow with no error. Clamping."
    $ContextTokens = $derivedWindow
}

$env:CLAUDE_CODE_MAX_CONTEXT_TOKENS = "$ContextTokens"

# WHAT YOU ACTUALLY GET TO USE, and why it used to be 62.8% of the window rather than 75%.
#
# This was `Max(100000, ctx * 0.75)`. The 0.75 is a round number, not a derived one, and it left a
# third of the headroom on the floor. Two terms decide how much conversation you can hold:
#
#   usable conversation = auto-compact trigger - the reply Claude Code reserves room for
#
# Claude Code picks max_tokens from the model id, and for this seat it picks 32,000 (measured on the
# wire, and corroborated in telemetry\requests.jsonl by exactly one reply landing on 32,000 with the
# next largest at 16,100). So the old arithmetic was:
#
#   trigger 196,608 - reserve 32,000 = 164,608 usable = 62.8% of a 262,144 window
#   and trigger + reserve = 228,608, which is 33,536 tokens SHORT of the window
#
# Nothing was protecting that 33,536. The real safety constraint is only that a full-length reply
# must still fit after the trigger, so trigger + reserve <= ctx. Sizing to that, minus a margin for
# the turn that crosses the line (a tool result can add a lot between checks), gives:
#
#   trigger 226,144 - reserve 32,000 = 194,144 usable = 74.1% of the window, ~29,500 tokens more
#
# WHY THIS MATTERS NOW rather than in theory: the deepest prompt in telemetry is 161,560 tokens,
# which is 98.1% of the old 164,608 ceiling. Sessions on this box really do reach it.
#
# THE TRADE, stated because it is real: deeper context is slower. Conversation decode measures
# 54.0 tok/s at 63k depth against 41.7 at 157k. Using more window costs throughput, so this raises a
# ceiling rather than making anything faster.
# THE RESERVE IS NOW SET RATHER THAN GUESSED, WHICH IS WHERE THE REMAINING CONTEXT CAME FROM.
#
# Claude Code reserves room for the reply and picks that number off the model id. Left alone it
# chooses 32,000 for this seat, and usable conversation is trigger minus reserve, so the reserve is
# paid TWICE against the window: once in the trigger's own headroom and once again underneath it.
# Best case at 32,000 is ctx - 2 x 32,000 - margin = 194,144 tokens, and the launcher was already
# there. There was nothing left to win without moving the reserve itself.
#
# MEASURED, not assumed. CLAUDE_CODE_MAX_OUTPUT_TOKENS is honoured. Captured off the wire against a
# logging stub on 2026-08-27, same config both times, reading max_tokens out of the request body:
#     unset          -> max_tokens = 32000
#     set to 20000   -> max_tokens = 20000
#
# WHY 20,000. Reply length across 1,663 recorded seat requests: p50 301, p90 1,591, p99 8,853,
# p99.5 12,397. Exactly two replies ever exceeded 16,000 and the single largest reading, 32,000, is
# the old cap being hit rather than a reply that wanted that much. 20,000 covers every real reply in
# the corpus with room over the p99.5 by a factor of 1.6.
#
# THE TRADE, stated because it is real: a reply that genuinely wants more than 20,000 tokens now
# stops at 20,000 instead of 32,000. That has happened once, to a request that was already being
# capped. Against it, every conversation gets 24,000 more tokens before compaction. Raise this back
# to 32000 if long single replies matter more than conversation depth for your work.
#
# Setting it here also removes a drift class: the launcher used to HARDCODE 32000 as the reserve it
# subtracted while not setting it, so a client-side default change would have silently desynced the
# two. One value now feeds both.
$CompactReserve = 20000     # what Claude Code reserves for the reply, and now what we tell it to
$CompactMargin  = 4000      # slack for the turn that crosses the trigger
$env:CLAUDE_CODE_MAX_OUTPUT_TOKENS = "$CompactReserve"
# The floor means ONE thing: a window too small to compact into should never compact at all. Writing
# it as Max(100000, derived) conflated that with a second, unintended case. On a 106,496-token row the
# derived trigger is 82,496, the floor overrode it to 100,000, and 100,000 + a reply no longer fit the
# window. That row would compact and then overflow. Spelling the intent out fixes it, and the same
# reshape closes the identical overflow the 131,072 row had at the old 32,000 reserve.
$compactWindow = if ($ContextTokens -le 100000) { 100000 }
                 else { $ContextTokens - $CompactReserve - $CompactMargin }
#
# DO NOT CLAMP THIS TO $ContextTokens. An early draft did, and a sweep across every window this repo
# serves caught it: on a 32,768-token row a trigger ABOVE the window is exactly right, because it
# means auto-compact never fires and a small window has nothing useful to compact into. Clamping to
# ctx turned that into "compact at the window", which on a 16k row left ZERO usable conversation and
# on a 32k row left 768 tokens.
#
# Usable conversation is trigger - reserve. Against the original ctx * 0.75 trigger at a 32,000
# reserve:
#   ctx  16,384 /  32,768 /  65,536   trigger 100,000, auto-compact never fires, unchanged
#   ctx 106,496                       usable  47,872 ->  62,496,  45.0% -> 58.7%   (overflow closed)
#   ctx 131,072                       usable  66,304 ->  87,072,  50.6% -> 66.4%   (overflow closed)
#   ctx 196,608                       usable 115,456 -> 152,608,  58.7% -> 77.6%
#   ctx 262,144  (the seat)           usable 164,608 -> 218,144,  62.8% -> 83.2%
$env:CLAUDE_CODE_AUTO_COMPACT_WINDOW = "$compactWindow"

# Local prefill of a large context is slow, and Claude Code aborts a stream that goes quiet.
# llama-server sends no SSE keep-alive pings during prefill, so the byte watchdog is the one that
# fires: its default is 300s, and a cold 100k-token prompt can sit silent for longer than that.
# 30 minutes is the documented ceiling for both watchdogs.
$env:CLAUDE_BYTE_STREAM_IDLE_TIMEOUT_MS = "1800000"
$env:CLAUDE_STREAM_IDLE_TIMEOUT_MS      = "1800000"
$env:API_TIMEOUT_MS                     = "1800000"

# Pre-release capabilities pair a beta header with a request body field. llama-server accepts the
# body field it does not know, but there is no upside to sending them to a local backend.
$env:CLAUDE_CODE_DISABLE_EXPERIMENTAL_BETAS = "1"

# Feature-flag fetches and other nonessential calls go to Anthropic, not to your GPU. Off.
$env:CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC = "1"
$env:DISABLE_TELEMETRY       = "1"
$env:DISABLE_ERROR_REPORTING = "1"

# Claude Code prepends a small attribution block to the system prompt. api.anthropic.com strips it;
# any other backend sees it. Dropping it keeps the prompt prefix byte-stable across turns, which is
# what lets llama-server reuse the KV cache (--cache-reuse) instead of re-prefilling every turn.
$env:CLAUDE_CODE_ATTRIBUTION_HEADER = "0"

# --- 4b. config isolation ----------------------------------------------------------------------
# Choosing a local tier from Claude Code's /model picker WRITES that id into the global
# %USERPROFILE%\.claude\settings.json 'model' key. On 2026-08-18 that left every other terminal's
# cloud-backed `claude` exiting 1 at startup with "There's an issue with the selected model".
# Measured: --settings and --managed-settings only change what gets READ, so neither prevents it.
# Moving the WRITE target is the one mechanism that does.
$claudeHome = Join-Path $env:LOCALAPPDATA "DokiDex\claude-home"
$firstRun = -not (Test-Path -LiteralPath $claudeHome -PathType Container)
New-Item -ItemType Directory -Path $claudeHome -Force -ErrorAction SilentlyContinue | Out-Null
$env:CLAUDE_CONFIG_DIR = $claudeHome

# CLAUDE_CONFIG_DIR relocates the WHOLE per-user surface, not just settings.json. CLAUDE.md,
# skills, agents, projects, sessions, history.jsonl and .credentials.json all hang off it, so an
# isolated run starts blank unless we seed it, and "where did my global CLAUDE.md go" is a nasty
# first impression. What the isolated home shares with the global one, and what it doesn't:
#   shared  - skills\ and agents\ (junctions). Read-mostly, and letting them drift from the real
#             ones would be worse than sharing. Junctions work unelevated on this box, measured,
#             no Developer Mode needed.
#   copied  - settings.json, once, on first run. A link here would defeat the entire point: the
#             /model write would travel straight back to the global file.
#   neither - sessions, projects, history.jsonl, .credentials.json. Local runs keep their own
#             history and never see the cloud login. That's the intent, not an oversight.
# Each item is seeded only when missing, so this stays idempotent and never clobbers isolated state.
$globalHome = Join-Path $env:USERPROFILE ".claude"
if (Test-Path -LiteralPath $globalHome -PathType Container) {
    foreach ($dir in @("skills", "agents")) {
        $src = Join-Path $globalHome $dir
        $dst = Join-Path $claudeHome $dir
        if ((Test-Path -LiteralPath $src) -and -not (Test-Path -LiteralPath $dst)) {
            New-Item -ItemType Junction -Path $dst -Target $src -ErrorAction SilentlyContinue | Out-Null
        }
    }
    $srcSettings = Join-Path $globalHome "settings.json"
    $dstSettings = Join-Path $claudeHome "settings.json"
    if ((Test-Path -LiteralPath $srcSettings -PathType Leaf) -and -not (Test-Path -LiteralPath $dstSettings)) {
        Copy-Item -LiteralPath $srcSettings -Destination $dstSettings -ErrorAction SilentlyContinue
    }
    # CLAUDE.md IS DELIBERATELY NOT SEEDED, AND AN OLD SEED IS REMOVED. Measured 2026-09-03 against
    # CLI 2.1.259.910 with a request tap: the client reads %USERPROFILE%\.claude\CLAUDE.md
    # UNCONDITIONALLY, whatever CLAUDE_CONFIG_DIR points at, and then reads the config dir's copy on
    # top of it. With the old hardlink in place both copies land in the first user message, so the
    # same 11,256-byte file went into every session TWICE: first-request message bytes 18,639
    # without the seed against 28,815 with it, +10,176 bytes (~2,500 tokens) of pure duplication,
    # and every standing instruction stated twice.
    #
    # Only a copy that still MATCHES the global file is removed, because that one is provably the
    # old seed and nothing is lost. A copy that has DIVERGED gets a warning instead of a delete: it
    # might be something someone wrote for the isolated home on purpose, and it might equally be a
    # seed whose hardlink an editor broke by rewriting the global file in place. This box was in the
    # second state on 2026-09-03 (seed 11,256 B dated Aug 17 against a live 11,482 B), which is the
    # worse shape of the same bug: TWO DIFFERENT VERSIONS of one standing-instruction file in one
    # prompt, disagreeing with each other.
    $staleMemory = Join-Path $claudeHome "CLAUDE.md"
    $globalMemory = Join-Path $globalHome "CLAUDE.md"
    if ((Test-Path -LiteralPath $staleMemory -PathType Leaf) -and (Test-Path -LiteralPath $globalMemory -PathType Leaf)) {
        $a = (Get-FileHash -LiteralPath $staleMemory  -Algorithm SHA256).Hash
        $b = (Get-FileHash -LiteralPath $globalMemory -Algorithm SHA256).Hash
        if ($a -eq $b) {
            Remove-Item -LiteralPath $staleMemory -Force -ErrorAction SilentlyContinue
        } else {
            Write-Host ("  WARNING: $staleMemory differs from the global CLAUDE.md. The client reads " +
                "BOTH, so every session carries two disagreeing copies of the same standing " +
                "instructions. Delete it unless you wrote it on purpose.") -ForegroundColor Yellow
        }
    }
}
if ($firstRun) { Info "seeded    $claudeHome (skills + agents shared, sessions are not)" }

if ($Print) {
    Write-Host ""
    Write-Host "resolved environment" -ForegroundColor Cyan
    Get-ChildItem Env: |
        Where-Object { $_.Name -like "ANTHROPIC_*" -or $_.Name -like "CLAUDE_*" -or $_.Name -in @("API_TIMEOUT_MS", "DISABLE_TELEMETRY", "DISABLE_ERROR_REPORTING") } |
        Sort-Object Name | ForEach-Object { "  {0,-46} {1}" -f $_.Name, $_.Value } | Write-Host
    Write-Host ""
    exit 0
}

Info "model     $Model"
# Say what each slot actually resolved to, and say WHY, because the why is the whole change. A slot
# that fell back to the seat did so for one of two reasons and they are worth telling apart: either
# nothing else is loaded, or the server could not be asked.
$seatedElsewhere = @($sonnetTier, $fableTier, $haikuTier | Where-Object { $_ -ne $Model } | Select-Object -Unique)
if ($seatedElsewhere.Count) {
    if ($haikuTier -ne $Model) { Info "haiku     $haikuTier  (resident beside the seat, so background calls evict nothing)" }
    if ($sonnetTier -ne $Model) { Info "sonnet    $sonnetTier" }
    if ($fableTier  -ne $Model) { Info "fable     $fableTier" }
} elseif (-not $residentId.Count) {
    Info "tiers     every slot on the seat: nothing is loaded yet. Warm first and the picker fills in:  doki-manager warm"
} elseif (-not $seatIsUp) {
    Info "tiers     every slot on the seat: '$Model' is not loaded, so nothing else was seated"
} else {
    Info "tiers     every slot on the seat: nothing else is resident beside it"
}
Info "context   $ContextTokens tokens, auto-compact at $env:CLAUDE_CODE_AUTO_COMPACT_WINDOW"
Write-Host ""

# --- 5. go -------------------------------------------------------------------------------------
$argv = @()
if ($SkipPermissions -and $Rest -notcontains "--dangerously-skip-permissions") {
    $argv += "--dangerously-skip-permissions"
}
# Forwarded verbatim and in order, which is exactly what the `--` divider promises at the top of
# this file. Nothing is filtered out any more: PowerShell already consumes the divider itself, so a
# `--` that survives into $Rest is a second one the caller typed on purpose for claude.
# Goes in BEFORE $Rest so the forwarded-verbatim contract below still holds for everything the
# caller typed, and well before the -Task divider, which has to stay last.
if (-not $NoSystemPrompt -and $Rest -notcontains "--append-system-prompt") {
    $sysPrompt = Get-SystemPromptAppend $SystemPromptFile
    if ($sysPrompt) { $argv += @("--append-system-prompt", $sysPrompt) }
}
if ($Rest) { $argv += $Rest }
# The -Task guard goes LAST, and that ordering is load-bearing. claude reads everything after its
# own `--` as prompt text, so a forwarded flag placed after it would be sent as part of the prompt
# rather than parsed. Flags first, prompt last.
if ($Task) { $argv += @("--print", "--", $Task) }

# --- telemetry, best-effort and opt-out ---------------------------------------------------------
# WHY THIS IS HERE AT ALL. The launcher hands over to a client that talks to :8080 directly, so it
# never sees a single response and cannot measure throughput itself. scripts\doki-telemetry.ps1 taps
# llama-swap instead, which sits in front of every client at once. What only THIS file knows is the
# session: which launcher ran, against which model, for how long, and how it ended. So that is all
# it writes.
#
# THREE RULES, and they are the reason this block is as boring as it is.
#  1. It must never block. This launcher measured 0.19s to hand over and that is a feature, so the
#     collector is spawned detached with NO pipe on its output. A reader on that pipe would block
#     until the collector exits, because the child inherits this process's stdout. Measured and
#     documented in doki-telemetry.ps1's own header.
#  2. It must never fail the launch. Every call is wrapped, and a telemetry problem is a note at
#     most. Nobody's session dies because a JSON line could not be appended.
#  3. It must be refusable. -NoTelemetry turns it off for one run, DOKI_TELEMETRY=0 turns it off for
#     good. And when it IS on, the launcher says so out loud rather than collecting silently.
function Start-DokiTelemetry([string]$Base, [string]$Root) {
    if ($env:DOKI_TELEMETRY -eq "0") { return $false }
    $tool = Join-Path $PSScriptRoot "doki-telemetry.ps1"
    if (-not (Test-Path -LiteralPath $tool)) { return $false }
    # ALREADY-RUNNING FAST PATH, and it is not a micro-optimisation. Measured 2026-08-25: the
    # Start-Process below costs 109 ms, against a launcher whose whole measured handover budget is
    # about 190 ms. Paying that on every run to spawn a process that immediately refuses (the
    # collector is a singleton and declines when one is live) would give back more than half of what
    # making this launcher thin bought in the first place. So read the lock first. A live lock means
    # a collector is already tapping this backend and there is nothing to do.
    #
    # Deliberately a LOOSER check than doki-telemetry.ps1's own Get-LockState, which also proves the
    # pid was not recycled. Being wrong here is cheap in exactly one direction: a false "live" skips
    # a spawn and loses telemetry, and a false "dead" spawns a process that refuses and exits. Both
    # are harmless, and neither is worth another 100 ms on the happy path. The tool stays the
    # authority on its own lock.
    try {
        $lock = Join-Path $Root ".run\doki-telemetry.lock"
        if (Test-Path -LiteralPath $lock -PathType Leaf) {
            $held = Get-Content -LiteralPath $lock -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            $heldPid = [int]($held.pid -as [int])
            if ($heldPid -gt 0 -and (Get-Process -Id $heldPid -ErrorAction SilentlyContinue)) { return $true }
        }
    } catch { }   # unreadable lock: fall through and let the tool decide
    try {
        # -WindowStyle Hidden plus no redirection: detached, silent, and nothing to block on. The
        # tool is a singleton, so a second launcher in another terminal is a no-op rather than a
        # second collector.
        Start-Process -FilePath "pwsh" -WindowStyle Hidden `
            -ArgumentList @("-NoProfile", "-File", $tool, "collect", "-BaseUrl", $Base) | Out-Null
        return $true
    } catch { return $false }
}

function Write-DokiSession($Root, $Fields) {
    if ($env:DOKI_TELEMETRY -eq "0") { return }
    try {
        $dir = Join-Path $Root "telemetry"
        New-Item -ItemType Directory $dir -Force -ErrorAction SilentlyContinue | Out-Null
        $line = ($Fields | ConvertTo-Json -Depth 5 -Compress)
        # Append, never rewrite, and UTF8 without BOM to match every other file the collector writes.
        [System.IO.File]::AppendAllText((Join-Path $dir "sessions.jsonl"), $line + "`n",
            [System.Text.UTF8Encoding]::new($false))
    } catch { }   # a telemetry write is never worth a failed session
}

# Claude Code holds the GPU for as long as the session lives, and it doesn't run in the shell where
# `doki down` or `doki restart` gets typed. Leave a lease so doki.ps1 can warn before it unloads the models under
# a live turn. Best-effort by design: a missing .run dir or a crashed session must never stop the
# CLI from launching, and doki.ps1 discards a lease whose process is gone.
$lease = Join-Path $root ".run\claude-code.lease"
try {
    New-Item -ItemType Directory (Split-Path $lease) -Force -ErrorAction SilentlyContinue | Out-Null
    Set-Content $lease "$PID`n$Model`n$(Get-Date -Format o)" -ErrorAction SilentlyContinue
} catch { }

# Seed the exit code to a FAILURE. $ErrorActionPreference is Stop at the top of this script, so a
# terminating error out of `& claude` skips the assignment below and runs straight into finally —
# and an unassigned $code makes `exit $code` exit 0. That is the shape of a check that reports
# success for a run that never happened, which is the defect class this repo keeps finding. Start
# from 1 and let a completed run lower it.
$telemetryOn = $false
if (-not $NoTelemetry) {
    $telemetryOn = Start-DokiTelemetry $BaseUrl $root
    if ($telemetryOn) { Info "telemetry recording to $root\telemetry (doki-telemetry report to view, -NoTelemetry to skip)" }
}
$sessionStart = Get-Date

$code = 1
try {
    & claude @argv
    $code = $LASTEXITCODE
} finally {
    # Delete the lease only when it is still OURS. Two concurrent launchers write the SAME filename
    # (contracts.md: LeaseFile), so a bare delete here would remove a second session's lease the
    # moment this one exits, and doki.ps1 would then warn about nothing while that other session is
    # still holding the GPU. Best-effort by design, same as the write above: a missing or unreadable
    # lease, or one that already belongs to someone else, is not this launcher's problem to fix.
    try {
        $ownedLine = Get-Content -LiteralPath $lease -TotalCount 1 -ErrorAction Stop
        if ($ownedLine -eq "$PID") { Remove-Item -LiteralPath $lease -Force -ErrorAction SilentlyContinue }
    } catch { }
    if ($telemetryOn) {
        $now = Get-Date
        Write-DokiSession $root ([ordered]@{
            ts_start          = $sessionStart.ToString("o")
            ts_end            = $now.ToString("o")
            launcher          = "claude"
            model             = $Model
            exit_code         = $code
            duration_s        = [math]::Round(($now - $sessionStart).TotalSeconds, 1)
            resident_at_start = @($residentId)
            context_tokens    = $ContextTokens
        })
    }
}

# The reachability probe the happy path no longer pays for, spent here instead. Two conditions, and
# the order matters: only a FAILED run asks the question at all, and only an actually-dead backend
# gets the message. claude exits non-zero for plenty of ordinary reasons (a bad flag, a refused
# permission, Ctrl+C), and answering every one of them with "your GPU is down" would be a diagnosis
# that cannot be wrong, which is the same thing as a diagnosis that says nothing.
if ($code -ne 0 -and -not (Test-BackendReachable $BaseUrl)) {
    Write-Host ""
    Show-BackendDown $BaseUrl
}
exit $code
