﻿<#
.SYNOPSIS
  doki-manager: install the DokiDex client bootstrappers, fetch their weights, and bring the local
  LLM stack up. The slow, occasional half of the pair whose fast half is doki-claude/doki-copilot.

.DESCRIPTION
  THE SPLIT THIS FILE EXISTS TO CREATE.

  scripts\claude-local.ps1 and scripts\copilot-local.ps1 are launchers. You type doki-claude and you
  want a session, not an install. Until 2026-08-19 both of them probed the backend and then POSTed a
  warm request to /v1/messages before handing over. Neither does that on the happy path any more:
  each preloads only under its own -Warm, and the routine warm-up lives here.

  On a cold card that first request pages the seat's weights off disk. The seat loads three files,
  and all three are named on its cmd line in serving\llama-swap.yaml:

    -m        models\Qwen3.8-27B-Uncensored-noMTP-Q4_K_M.gguf   15.41 GB
    -md       models\Qwen3.8-27B-Uncensored-draft-Q4_0.gguf      1.56 GB   the MTP draft head
    --mmproj  models\mmproj-Qwen3.8-27B-Q8_0.gguf                0.59 GB   the vision projector

  "noMTP" in the main file's name is not a claim that MTP is off. It says the draft tensors are not
  fused into that file, because the vendor ships them beside it for --model-draft. MTP is ON, and
  scripts\doki-preset.ps1 is what turns it off. The stock models\Qwen3.8-27B-Q4_K_M.gguf this
  replaced on 2026-08-29 is the fused, censored build, and it measured 17.67 GB.

  The warm-up is not a mistake. Without it the first real request looks like a hang, several screens
  into a session, with the client's own opaque connection error on top. So it moves here instead of
  disappearing, into a verb you ask for on purpose:  doki-manager warm.

  WHAT NEEDS A CHECKOUT AND WHAT DOES NOT. The standalone bootstrapper zip ships three files
  (scripts\package-bootstrappers.ps1:115-119): the two launchers and install-clients.ps1. It ships
  no doki.ps1, no setup.ps1 and no serving\. So the verbs split cleanly:

    works anywhere          install, uninstall, warm, status, doctor, help
    needs a full checkout   models, download, start, stop

  Every verb in the second group checks for the file it needs and says which one is missing, where
  it looked, and how the root was resolved. None of them throws a path error at you.

  THE GPU HOLDS ONE MODEL AT A TIME. This box has 32 GB, and the seat plus its small co-resident
  utility row is the whole budget. There used to be a second, mutually-exclusive media group on the
  other side of the card; it was removed on 2026-09-02 (see archive.md). `start` still says what it
  is taking before it takes it, and it never runs as a side effect of another verb.

  VERBS
    help                       every verb, its options, and what a bare install can and cannot do
    status                     one screen: root, backend, resident model, seat, shims, lease
    doctor                     the preflight, with the exact command that fixes each red row
    install                    put doki-claude and doki-copilot on your User PATH
    uninstall                  take them off again
    models                     what the manifest declares, what llama-swap wants, what is on disk
    download <switches>        fetch weights by delegating to setup.ps1
    start [agent|coexist]      bring the LLM group up AND preload the seat's group (this takes the GPU)
    start -Warm                the same; warming is the default now, so this only states the intent
    start -NoWarm              up without the preload, leaving ~13s of page-in for the first request
    stop                       stop every managed service
    warm [tier]                preload a tier so the next real request is not a cold page-in
    skills                     install the tier skills (/doki-max, -think, -work, -cheap) into ~\.claude\skills
    config [name]              serving presets: what runs beside the seat, and how fast it decodes

  ONE COMMAND FOR THE WHOLE COLD START. `start` and `warm` stayed separate so the page-in is a cost
  you ask for. Asking for it twice in a row is still asking, so `start` now does both: it brings
  the profile up, waits for llama-swap to answer /v1/models (a server that just launched is not
  serving yet, so a straight `warm` after it would refuse), then warms the seat's group. The exit code
  is the warm's, because a stack that is up with cold weights is not what you asked for.

  EXIT CODES.  0 only on success.  2 is a usage refusal (a verb told what it needs and did not run).
  1 is everything else. The code is seeded to 1 at the top for the reason the launchers seed theirs
  (claude-local.ps1:455): $ErrorActionPreference is Stop. A terminating error skips every
  assignment below it. An unassigned code then makes `exit $code` exit 0. That is a success report
  for a run that never happened.

  USAGE
    .\scripts\doki-manager.ps1                       # help
    .\scripts\doki-manager.ps1 status
    .\scripts\doki-manager.ps1 install
    .\scripts\doki-manager.ps1 models
    .\scripts\doki-manager.ps1 download -Qwen38      # the seat's weights and its second engine
    .\scripts\doki-manager.ps1 start coexist
    .\scripts\doki-manager.ps1 start agent -Warm      # up AND loaded, one command
    .\scripts\doki-manager.ps1 warm
    .\scripts\doki-manager.ps1 warm "Qwen2.5-3B-Instruct [32k] (Utility, Free)"   # quote it, the name has spaces

  A NOTE ON FLAG COLLISIONS, the same class the launchers document. PowerShell binds parameters by
  prefix and it does that before this script runs. The names declared below are Verb, Arg, BaseUrl,
  Warm, NoWarm, TimeoutSec, ReadySec and Rest, and that list is the whole of it. Any token that is a
  prefix of one of those binds here instead of being forwarded. Everything else forwards through
  -Rest verbatim, sorted against what the target script declares, and refused if it declares no such
  name.

  This note used to name Media and Full as declared parameters too. They were removed and the note
  was not, so `download -Media -Full` was printed as a working command in three places (here, the
  help screen's Options block, and doctor's fix for a missing utility model) while every one of them
  refused: the tokens fell through to -Rest, setup.ps1 declares neither, and the run exited 2 without
  fetching anything. Corrected 2026-09-10. setup.ps1 declares CoderModels, DeepSeek, DeepSeekV4,
  GlmAir, LlmCandidates, ModelSelection, Qwen38, Reasoning, Vision and VisionHQ, and `doki-manager
  models` prints the switch for each manifest row rather than making you remember them.
#>
[CmdletBinding(PositionalBinding = $false)]
param(
    # Unknown verb? PowerShell's own ValidateSet error lists the valid names, same as doki.ps1:24.
    [Parameter(Position = 0)]
    [ValidateSet("help", "status", "doctor", "install", "uninstall", "models", "download", "start", "stop", "warm", "skills", "config")]
    [string]$Verb = "help",

    # `start agent` / `start coexist` / `warm <tier>`. Ignored by every other verb.
    [Parameter(Position = 1)][string]$Arg,

    # Same default as scripts\claude-local.ps1 and scripts\copilot-local.ps1, so what this script
    # probes is the server the shims will actually reach.
    [string]$BaseUrl = "http://127.0.0.1:8080",

    # start: chain the preload on, so one command leaves the stack up AND loaded. Ignored elsewhere,
    # and it never turns on by itself -- `warm` is still the verb, this is just both in one go.
    # WARMING IS NOW THE DEFAULT, changed 2026-09-03 on a measurement rather than a preference.
    # Timed on this box, stack down to first answer: `doki up` 7.1s, llama-swap answering 0.3s later,
    # and then 12.7s of cold seat page-in landing on whoever sends the FIRST request, against 0.2s
    # once resident. That 12.7s is an underestimate of a real cold start, because the weights were
    # still in the OS page cache; from disk it is a 16.5 GB read.
    #
    # The cost does not disappear either way. It is paid at a moment you chose or in the middle of a
    # request, and the header above already says what the second one looks like: the first real
    # request looks like a hang for several screens. So the default moved and the escape hatch is
    # -NoWarm, which is the old behaviour exactly.
    #
    # -Warm still works and is still documented, both because it reads as intent at a call site and
    # because the bootstrapper bundle and tests use it.
    [switch]$Warm,
    [switch]$NoWarm,
    [int]$TimeoutSec = 900,  # warm: matches the 900s in both launchers and healthCheckTimeout in llama-swap.yaml:10
    # start -Warm: how long to wait for llama-swap to answer /v1/models before giving up on the
    # chained preload. 120s covers a normal launch on this box; it is a parameter so a slower tree
    # (or a test that wants the give-up path in a second) can say so.
    [int]$ReadySec = 120,

    # Forwarded to install-clients.ps1 (install/uninstall) or setup.ps1 (download). Sorted by name
    # against what that script actually declares, so a typo is refused rather than silently dropped.
    [Parameter(ValueFromRemainingArguments = $true)][string[]]$Rest
)

$ErrorActionPreference = "Stop"
$script:code = 1   # seeded to failure on purpose. See EXIT CODES above.

# --- where the stack lives ----------------------------------------------------------------------
# Copied from scripts\claude-local.ps1:130, rung for rung, because a second resolution order is how
# two halves of one product end up managing two different trees. doki.ps1:85 has the same order plus
# its own -DokiRoot parameter, which never reaches a sibling script. The only thing added here is
# $script:RootSource, so a degraded run can tell you WHICH signal picked the directory it looked in.
function Resolve-DataRoot($fallback) {
    if ($env:DOKI_DATA_ROOT -and (Test-Path -LiteralPath $env:DOKI_DATA_ROOT -PathType Container)) {
        $script:RootSource = "DOKI_DATA_ROOT env"
        return $env:DOKI_DATA_ROOT
    }
    $settingsPath = Join-Path $env:LOCALAPPDATA "dokidex\settings.json"
    if (Test-Path -LiteralPath $settingsPath -PathType Leaf) {
        try {
            $candidate = (Get-Content -LiteralPath $settingsPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop).dataRoot
            if ($candidate -is [string] -and $candidate.Trim() -and (Test-Path -LiteralPath $candidate -PathType Container)) {
                $script:RootSource = "settings.json dataRoot"
                return $candidate
            }
        } catch { }   # missing/corrupt settings.json: fall through, never throw
    }
    $script:RootSource = "the directory above this script"
    return $fallback
}

$repo = Split-Path $PSScriptRoot -Parent
$script:RootSource = "unresolved"
$root = Resolve-DataRoot $repo

$DokiPs1     = Join-Path $root "doki.ps1"
$SetupPs1    = Join-Path $root "setup.ps1"
$ManifestCfg = Join-Path $root "serving\model-manifest.json"
$SwapCfg     = Join-Path $root "serving\llama-swap.yaml"
$ModelsDir   = Join-Path $root "models"
# The installer is a SIBLING, never a data-root file. It ships in the standalone zip next to this
# script. $PSScriptRoot finds it even when nothing else here is.
$Installer   = Join-Path $PSScriptRoot "install-clients.ps1"

# Two names copied verbatim from serving\llama-swap.yaml's `models:` block, kept as constants so
# `status` and `doctor` can name them without re-parsing. Since the 2026-08-25 rename these are the
# models' real names rather than short ids, so they carry spaces, brackets and parentheses and have
# to stay quoted everywhere they are used. There are no aliases in that file any more: the key a
# client asks for IS the model name.
#
# THEY ARE NOT A PAIR, and nothing may assume they are. The utility model left the `agent-seat`
# group on 2026-08-26, when the seat took its MTP draft head and 256k plus MTP plus a sidecar
# stopped fitting 32 GB. A constant cannot notice that. Anything that needs to know what actually
# sits beside the seat reads the group through Read-SwapGroups instead of trusting these two lines,
# because the last thing to trust them evicted the seat for a week.
$SeatModel    = "Qwen3.8-27B [256k] (Thinking, Standard)"
$UtilityModel = "Qwen2.5-3B-Instruct [32k] (Utility, Free)"
# It used to share this file with the media stack's prompt-rewriter, which is why setup.ps1 once
# fetched it inside the -Media block rather than beside the coder weights. The media stack went on
# 2026-09-02 and setup.ps1 fetches it in the core path now. See the download verb's note.
$UtilityModelFile  = "Qwen2.5-3B-Instruct-Q5_K_M.gguf"

# --- output register ----------------------------------------------------------------------------
# Same shapes as scripts\package-bootstrappers.ps1:74-76 and the Info/Warn pair in both launchers,
# so a session that runs install then doki-claude reads as one product rather than three scripts.
function Info($m) { Write-Host "  $m"   -ForegroundColor DarkGray }
function Ok($m)   { Write-Host "  + $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  ! $m" -ForegroundColor Yellow }

# The diagnostic row, lifted from doki.ps1:461 so `doki-manager doctor` and `doki doctor` line up
# column for column.
function Row($label, $state, $detail) {
    $color = switch ($state) { "ok" { "Green" } "warn" { "Yellow" } "miss" { "Red" } default { "Gray" } }
    $mark  = switch ($state) { "ok" { "  ok " } "warn" { "  !! " } "miss" { " MISS" } default { "  -- " } }
    Write-Host ("{0}  {1,-22} {2}" -f $mark, $label, $detail) -ForegroundColor $color
}

function Title($t) {
    Write-Host ""
    Write-Host $t -ForegroundColor Cyan
    Write-Host ("-" * $t.Length)
}

# A refusal, not a crash. Prints what is missing and the exact command that fixes it, then leaves
# $script:code at 2 so a caller can tell "you asked for the impossible" from "it broke".
function Refuse($what, $fix) {
    Write-Host ""
    Write-Host "  $what" -ForegroundColor Red
    foreach ($line in @($fix)) { Write-Host "    $line" }
    Write-Host ""
    $script:code = 2
}

function Format-GB($bytes) { "{0:N2} GB" -f ($bytes / 1GB) }

# --- shared helpers -----------------------------------------------------------------------------

# Does the tree we resolved actually hold the control plane? Every checkout-only verb calls this
# first. The message names the resolved root AND the signal that chose it, because "doki.ps1 not
# found" without that is unactionable on a box where settings.json points somewhere unexpected.
function Test-ControlPlane($file, $why) {
    if (Test-Path -LiteralPath $file -PathType Leaf) { return $true }
    $leaf = Split-Path $file -Leaf
    Refuse "$leaf is not in this tree. That makes $why unavailable here." @(
        "looked in:  $root"
        "root came from:  $($script:RootSource)"
        "The standalone bootstrapper zip ships only the two launchers and install-clients.ps1, so"
        "this is the expected state there. install / uninstall / warm / status / doctor still work."
        "For the rest, run this from a DokiDex checkout. Or point DOKI_DATA_ROOT at one:"
        "  `$env:DOKI_DATA_ROOT = 'D:\path\to\DokiDex'"
    )
    return $false
}

# Sort loose tokens into what the target script declares by NAME and refuse anything it does not.
# The by-name half matters: PowerShell splats an ARRAY positionally. A splatted -Vision would
# reach setup.ps1 as a positional string rather than binding its switch. doki.ps1:650 measured that
# and fixed it the same way. The refusal half matters because setup.ps1 declares no
# ValueFromRemainingArguments. An unknown token there is a binder error several screens later.
function Split-ForwardArgs($ScriptPath, [string[]]$Tokens) {
    $decl = (Get-Command $ScriptPath -ErrorAction Stop).Parameters
    $named = @{}
    $unknown = @()
    for ($i = 0; $i -lt $Tokens.Count; $i++) {
        $t = $Tokens[$i]
        if ($t -notmatch '^--?([A-Za-z][A-Za-z0-9]*)$') { $unknown += $t; continue }
        $hit = $matches[1]
        $name = @($decl.Keys) | Where-Object { $_ -eq $hit } | Select-Object -First 1
        if (-not $name) { $unknown += $t; continue }
        if ($decl[$name].ParameterType -eq [switch]) { $named[$name] = $true; continue }
        if ($i + 1 -lt $Tokens.Count) { $named[$name] = $Tokens[++$i]; continue }
        # A valued parameter whose flag is the last token has no argument. Defaulting it to $true
        # coerces silently, which is the quiet-wrong shape doki.ps1:684 refuses too.
        $unknown += "$t (expects a value of type $($decl[$name].ParameterType.Name))"
    }
    return @{ Named = $named; Unknown = $unknown; Declared = @($decl.Keys | Sort-Object) }
}

# Turn the sorted result back into a flat argv for `pwsh -File`. A child process is used rather than
# an in-session call so the exit code is real: measured 2026-08-19 on PS 7.6.5, `pwsh -NoProfile
# -File` returns 0 for a script that falls off the end and 1 for a terminating error. setup.ps1
# carries exactly one `exit` statement in 2400+ lines (setup.ps1:232) and install-clients.ps1 falls
# off its own end on success. Neither can be judged by $LASTEXITCODE from an in-session call.
#
# The exit code comes back through $script:DelegateExit rather than the pipeline. That is not
# style. Measured 2026-08-19: with `return $LASTEXITCODE` here and `$rc = Invoke-Delegate ...` at
# the call site, PowerShell collects the CHILD's stdout into the same return value. $rc was
# @("STUB setup.ps1 bound:", "  Media = True", ..., 0) and `if ($rc -eq 0)` took the failure branch
# on a run that had exited 0. It printed "setup.ps1 exited STUB setup.ps1 bound: Media = True ... 0".
# A success reported as a failure is the mirror of the defect class this repo keeps finding. It
# only showed up because the verb was run for real against a stub. Not capturing also keeps the
# child's own colours, since nothing sits between it and the console.
function Invoke-Delegate($ScriptPath, [string[]]$Argv) {
    Info "running:  pwsh -NoProfile -File `"$ScriptPath`" $($Argv -join ' ')"
    Write-Host ""
    $global:LASTEXITCODE = 0
    & pwsh -NoProfile -File $ScriptPath @Argv
    $script:DelegateExit = $LASTEXITCODE
}

function ArgvFromNamed($named) {
    $argv = @()
    foreach ($k in @($named.Keys | Sort-Object)) {
        $argv += "-$k"
        if ($named[$k] -isnot [bool]) { $argv += [string]$named[$k] }
    }
    return $argv
}

# The machine-readable seam doki.ps1:313 already publishes. Re-probing eight services here would be
# a second source of truth for the same question that would drift from it. Returns $null when the
# control plane is absent or the call fails. Every caller degrades on $null rather than throwing.
function Get-DokiStatusJson {
    if (-not (Test-Path -LiteralPath $DokiPs1 -PathType Leaf)) { return $null }
    try {
        $raw = & $DokiPs1 status json
        $text = ($raw -join "`n")
        # Resolve-DokiRoot writes its banner to stderr on purpose (doki.ps1:92) so stdout stays
        # parseable. Slicing from the first brace anyway costs nothing and survives a future line
        # that forgets.
        $i = $text.IndexOf('{')
        if ($i -lt 0) { return $null }
        return ($text.Substring($i) | ConvertFrom-Json)
    } catch { return $null }
}

# Per-card free VRAM, read from the shape `doki.ps1 status json` publishes rather than a second
# probe of our own. doki.ps1's own GpuJson reads every card since bc2960c and carries them in
# `gpu.gpus` as {index, usedMB, totalMB, ...}. Isolated from Verb-Doctor's co-residency check so
# EVERY CARD is read: a direct nvidia-smi call with no --id and no loop returns one CSV line per
# card, and reading only the first is invisible on the one-card box this was written for and wrong
# on any other. A card missing either reading (nvidia-smi can report [N/A]) is skipped rather than
# turned into a free-VRAM number that looks real. $st is $null when there is no control plane to
# ask, which this degrades on the same way every other caller of Get-DokiStatusJson does.
function Get-GpuFreeRows($st) {
    if (-not $st -or -not $st.gpu -or -not $st.gpu.gpus) { return @() }
    $rows = @()
    foreach ($c in @($st.gpu.gpus)) {
        if ($null -eq $c.usedMB -or $null -eq $c.totalMB) { continue }
        $rows += [pscustomobject]@{ index = $c.index; usedMB = $c.usedMB; totalMB = $c.totalMB; freeMb = ($c.totalMB - $c.usedMB) }
    }
    return $rows
}

# A line-scan rather than a YAML parser, because "no new dependency" rules out a real one and the
# shape here is fixed: model keys sit at exactly two spaces under `models:`, and every flag naming a
# weights file is one of -m, -md and --mmproj. Comment lines are skipped, which is what keeps the
# large commented-out smaller-card section from registering.
#
# -md WAS MISSING UNTIL 2026-09-10, and it is the seat's own draft head. The original note here said
# "the only two flags naming a weights file are -m and --mmproj (verified by grepping every
# non-comment flag line in that file on 2026-08-19)". That was true when it was written. MTP landed
# on the seat on 2026-08-26 and added a third flag, and nothing came back to re-check the claim.
# Three things read wrong for the two weeks after:
#   models    Qwen3.8-27B-Uncensored-draft-Q4_0.gguf, 1.56 GB, listed under "not named by
#             llama-swap.yaml" beside genuinely unreferenced files. It is named on the seat's own
#             cmd line, and the seat cannot start without it.
#   status    the seat reported 16.00 GB on disk against a real 17.56, because the draft was not
#             summed with the main weights and the projector.
#   doctor    "seat weights: on disk" could not go red on a missing draft. start-serving.ps1's own
#             pruner has the same -m/--mmproj blind spot, so the row is NOT pruned either: the block
#             survives, llama-server exits on the missing -md path, and doctor prints no red rows.
# Verified by tests\doki-manager-verbs.test.ps1 section (d), which goes red on the old pattern.
# --model-draft is accepted as well because llama.cpp declares it as the long form of -md. Nothing
# in this repo's config uses it, so treat it as tolerance rather than as a claim about the file.
# The alternation puts the longer names first so a reader does not have to know that .NET backtracks
# from -m into -md on its own.
#
# THE KEY PATTERN HAS TO ACCEPT A QUOTED NAME WITH SPACES. Before 2026-08-25 every key was a short
# hyphenated id and this matched `[A-Za-z0-9._-]+`. The rename made every key the model's real name,
# so that pattern matched NOTHING and this function returned an empty map while every caller carried
# on reporting cleanly. Both forms are accepted below, quoted-anything first.
function Read-SwapModels($path) {
    $map = [ordered]@{}
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $map }
    $inModels = $false
    $cur = $null
    foreach ($line in (Get-Content -LiteralPath $path)) {
        if ($line -match '^\s*#' -or $line -match '^\s*$') { continue }
        if ($line -match '^models:\s*$') { $inModels = $true; $cur = $null; continue }
        if (-not $inModels) { continue }
        if ($line -match '^[^\s]') { $inModels = $false; continue }   # a new top-level key ends the section
        if ($line -match '^  (?:"([^"]+)"|([A-Za-z0-9][A-Za-z0-9._-]*)):\s*(#.*)?$') {
            # A group that did not take part is simply absent from $matches, so this reads $null
            # rather than throwing when the key came in bare.
            $cur = if ($matches[1]) { $matches[1] } else { $matches[2] }
            $map[$cur] = @{ files = @() }
            continue
        }
        if (-not $cur) { continue }
        if ($line -match '^\s+(?:--model-draft|--mmproj|-md|-m)\s+(\S+)\s*$') {
            $map[$cur].files += ($matches[1] -replace '__DOKI_ROOT__', $root)
        }
    }
    return $map
}

# The llama-swap key matching a name, or $null. This is a CONFIG resolution and nothing more, and
# callers label the answer as config-derived rather than letting it read as a live check.
# It used to walk each row's `aliases:` list as well. The 2026-08-25 rename deleted every alias from
# that file, so a name either IS a key or is nothing, and this is now a straight lookup. It stays a
# function because callers want the matched key back to index the map with, and because -eq is
# case-insensitive here, which keeps a difference of case out of the "seat is missing" bucket.
function Resolve-SeatKey($swap, $name) {
    foreach ($k in $swap.Keys) {
        if ($k -eq $name) { return $k }
    }
    return $null
}

# The seat's group membership, read from the same file llama-swap loads. This exists because a
# hardcoded list of what sits beside the seat DRIFTED, and on an `exclusive: true` group that is not
# a cosmetic error. The utility model left the `agent-seat` group on 2026-08-26, when the seat took
# its MTP draft head and 256k plus MTP plus a sidecar stopped fitting 32 GB. `warm` kept naming it
# for another week, and because naming a model OUTSIDE an exclusive group UNLOADS the seat, every
# such warm paged the seat in and then evicted it, then reported success.
# MEASURED in this repo's own telemetry over 2026-08-26..09-02: 6 of the 56 seat evictions were the
# utility model (telemetry/residency.jsonl), which answered 14 requests for 100 output tokens
# in total over the same period (telemetry/requests.jsonl), against a median 5.5s cold-start
# penalty on the first request after each reload, plus the loss of the seat's KV cache.
# Deriving the list means the next membership change carries here on its own.
function Read-SwapGroups($path) {
    $groups = [ordered]@{}
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) { return $groups }
    $inGroups = $false; $groupsIndent = -1; $cur = $null; $inMembers = $false
    foreach ($line in (Get-Content -LiteralPath $path)) {
        if ($line -match '^\s*#' -or $line -match '^\s*$') { continue }
        $indent = $line.Length - $line.TrimStart().Length
        if ($line -match '^\s*groups:\s*$') {
            $inGroups = $true; $groupsIndent = $indent; $cur = $null; $inMembers = $false; continue
        }
        if (-not $inGroups) { continue }
        if ($indent -le $groupsIndent) { $inGroups = $false; continue }   # a shallower key ends the block
        # `members:` is checked BEFORE the group-key pattern, because it matches that pattern too.
        if ($line -match '^\s*members:\s*$') { $inMembers = $true; continue }
        if ($line -match '^\s*([A-Za-z0-9][A-Za-z0-9._-]*):\s*$') {
            $cur = $matches[1]; $groups[$cur] = @(); $inMembers = $false; continue
        }
        if ($inMembers -and $cur -and $line -match '^\s*-\s*"([^"]+)"\s*$') { $groups[$cur] += $matches[1] }
    }
    return $groups
}

# A row that spends real money when you talk to it. THE SAME RULE as claude-local.ps1's
# Test-BilledModel, applied to a name rather than to a /running row, because it now runs the same
# regex rather than a lookalike of it: either word, Cloud or Billed, inside any parenthetical marks
# the row billed. This used to require "(Cloud, Billed)" in that exact order and claimed to be the
# same rule while it was not, which let "(Billed, Cloud)" or a lone "(Cloud)" row read as free.
# WATCH THIS GO RED: hand it a name carrying "Cloud" or "Billed" in ANY parenthetical, in either
# order, and it must return $true. The Copilot shim is a member of the seat's group despite using
# zero VRAM, so anything walking that membership has to skip it or it will spend a premium request
# on a request nobody made.
function Test-BilledRow([string]$name) { return [bool]($name -match '\([^)]*\b(?:Cloud|Billed)\b[^)]*\)') }

# Two separate questions. install-clients.ps1's own header measured why they differ: the
# registry write broadcasts WM_SETTINGCHANGE. A terminal opened from the Start menu is live,
# while a shell that is already open keeps its inherited block. Reporting one number for both is how
# "I installed it and it does not work" happens.
function Get-ShimState {
    $shimDir = (Join-Path $PSScriptRoot "shims").TrimEnd('\', '/')
    $onUserPath = $false
    try {
        $envKey = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Environment')
        if ($envKey) {
            # Raw read with DoNotExpandEnvironmentNames, mirroring install-clients.ps1:210, then
            # expanded by hand. Reading it expanded and writing it back is the REG_EXPAND_SZ
            # downgrade trap that file documents. This only reads, which makes expanding a copy safe.
            $rawPath = [string]$envKey.GetValue('Path', '', [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            $entries = @([Environment]::ExpandEnvironmentVariables($rawPath) -split ';' |
                ForEach-Object { $_.Trim().TrimEnd('\', '/') } | Where-Object { $_ })
            $onUserPath = $entries -contains $shimDir
            $envKey.Dispose()
        }
    } catch { }
    $found = @{}
    foreach ($n in @("doki-claude", "doki-copilot")) {
        $found[$n] = (Get-Command $n -ErrorAction SilentlyContinue).Source
    }
    return @{
        Dir        = $shimDir
        FilesExist = @("doki-claude.cmd", "doki-copilot.cmd", "doki-shim.ps1" |
            Where-Object { Test-Path -LiteralPath (Join-Path $shimDir $_) -PathType Leaf })
        OnUserPath = $onUserPath
        Resolved   = $found
    }
}

# One POST to the Anthropic surface, byte-identical in shape to the block this verb takes over from
# (claude-local.ps1:264). Returns $true on a real answer. Nothing is guessed: the elapsed time is
# measured with a stopwatch around the call.
function Invoke-Warm($tier) {
    $body = @{ model = $tier; max_tokens = 4; messages = @(@{ role = "user"; content = "hi" }) } | ConvertTo-Json -Depth 5
    $sw = [Diagnostics.Stopwatch]::StartNew()
    try {
        $r = Invoke-RestMethod "$BaseUrl/v1/messages" -Method Post -ContentType "application/json" `
            -Headers @{ "anthropic-version" = "2023-06-01"; "x-api-key" = "dummy" } `
            -Body $body -TimeoutSec $TimeoutSec
        $sw.Stop()
        $served = if ($r.model) { " (server says: $($r.model))" } else { "" }
        Ok ("{0} ready in {1:N1}s{2}" -f $tier, $sw.Elapsed.TotalSeconds, $served)
        return $true
    } catch {
        $sw.Stop()
        Write-Host ("  x {0} did not answer after {1:N1}s: {2}" -f $tier, $sw.Elapsed.TotalSeconds, $_.Exception.Message) -ForegroundColor Red
        return $false
    }
}

function Test-Backend {
    try { return [bool](Invoke-RestMethod "$BaseUrl/v1/models" -TimeoutSec 5) } catch { return $false }
}

# `doki.ps1 up` returns when the processes are LAUNCHED, not when llama-swap is serving. A warm
# fired straight after it would hit a closed port and refuse, which reads as a failure of the very
# thing that just succeeded. So the chained path polls instead of assuming.
function Wait-Backend($seconds) {
    if (Test-Backend) { return $true }
    Info "waiting for $BaseUrl to answer /v1/models (up to ${seconds}s) ..."
    $sw = [Diagnostics.Stopwatch]::StartNew()
    while ($sw.Elapsed.TotalSeconds -lt $seconds) {
        Start-Sleep -Seconds 2
        if (Test-Backend) { $sw.Stop(); Ok ("backend answered after {0:N0}s" -f $sw.Elapsed.TotalSeconds); return $true }
    }
    $sw.Stop()
    return $false
}

# ================================================================================================
# VERBS
# ================================================================================================

function Verb-Help {
    Title "DokiDex manager"
    Info "the install-and-load half of the client bootstrappers. doki-claude and doki-copilot stay thin."
    Write-Host ""
    $rows = [ordered]@{
        'help'                    = 'this screen (also what a bare run prints)'
        'status'                  = 'root, backend, resident model, the seat and its group, shims, lease'
        'doctor'                  = 'preflight rows, each red one carrying its own fix command'
        'install [switches]'      = 'put doki-claude and doki-copilot on your User PATH'
        'uninstall'               = 'take them off again, leaving PATH as it was'
        'models'                  = 'manifest rows, what llama-swap wants, what is on disk'
        'config [name]'           = 'serving presets: what runs beside the seat, and how fast it decodes'
        'download <switches>'     = 'fetch weights through setup.ps1 (-Qwen38, -CoderModels, or any switch it declares)'
        'start [agent|coexist]'   = 'bring the LLM group up AND preload the seat''s group. THIS TAKES THE GPU'
        'start ... -Warm'         = 'states the intent; preloading is the default, so this changes nothing'
        'start ... -NoWarm'       = 'skip the preload. The first request then pays ~13s of page-in'
        'stop'                    = 'stop every managed service and free the card'
        'warm [tier]'             = 'preload a tier so the next real request is not a cold page-in'
        'skills'                  = 'copy the tier skills (/doki-max, -think, -work, -cheap) into ~\.claude\skills'
    }
    foreach ($k in $rows.Keys) { "  {0,-24} {1}" -f $k, $rows[$k] | Write-Host }

    Write-Host ""
    Write-Host "Options" -ForegroundColor Cyan
    Info "-BaseUrl <url>     which server to probe and warm (default $BaseUrl)"
    Info "-Warm              start: warm the seat once the profile is up (cold to ready in one)"
    Info "-NoWarm            start: bring the profile up and preload nothing"
    Info "-TimeoutSec <n>    warm: how long to wait for the first token (default $TimeoutSec)"
    Info "-ReadySec <n>      start -Warm: how long to wait for the server before warming (default $ReadySec)"
    Info "anything else      forwarded to install-clients.ps1 or setup.ps1, checked against what it declares"

    Write-Host ""
    Write-Host "What the warm-up move means for you" -ForegroundColor Cyan
    Info "doki-claude and doki-copilot do NOT warm anything. They set the environment up and hand"
    Info "over. Measured 2026-08-19 against a stub CLI: 0.19s and 0.17s. Warming moved HERE, because"
    Info "a cold 17.6GB page-in is a cost you should ask for rather than trip over."
    Info "So: 'doki-manager start', then 'doki-manager warm', and every doki-claude after is quick."
    Info "Or ask for both at once:  doki-manager start agent -Warm"
    Info "Pass -Warm to a launcher to get the old behaviour for one run."

    Write-Host ""
    Write-Host "Without a full checkout" -ForegroundColor Cyan
    Info "The standalone zip ships the launchers and install-clients.ps1 and nothing else."
    Info "install / uninstall / warm / status / doctor work there. models / download / start / stop"
    Info "need doki.ps1 and setup.ps1. Each says so instead of throwing a path error."
    Info "install itself writes all three shims there, then does the PATH merge against"
    Info "the User PATH registry key. It prints the folder to add by hand if that fails."
    Write-Host ""
    $script:code = 0
}

function Verb-Status {
    Title "DokiDex manager status"

    Row "data root" "ok" "$root  (from $($script:RootSource))"

    $hasCtl = Test-Path -LiteralPath $DokiPs1 -PathType Leaf
    Row "control plane" $(if ($hasCtl) { "ok" } else { "warn" }) `
        $(if ($hasCtl) { "doki.ps1 present" } else { "no doki.ps1 in this tree (launcher-only install)" })

    # Prefer the published seam over eight probes of our own. Fall back to one direct probe when
    # there is no control plane to ask, then say which of the two answered.
    $st = Get-DokiStatusJson
    $backendUp = $false
    if ($st) {
        $ls = @($st.services | Where-Object name -eq 'llama-swap')[0]
        $backendUp = [bool]$ls.healthy
        $detail = if ($ls.healthy) { "UP on :$($ls.port), pid $($ls.pid)" } elseif ($ls.running) { "starting on :$($ls.port)" } else { "down" }
        Row "backend" $(if ($ls.healthy) { "ok" } elseif ($ls.running) { "warn" } else { "miss" }) "$detail   (doki.ps1 status json)"
        if ($ls.model) { Row "resident model" "ok" "$($ls.model)  [$($ls.modelState)]" }
        else { Row "resident model" "warn" "none loaded yet. 'doki-manager warm' loads the seat" }
        if ($st.gpu -and $null -ne $st.gpu.usedMB) {
            $cards = if ($st.gpu.count -gt 1) { " across $($st.gpu.count) cards" } else { "" }
            Row "gpu" "ok" "$($st.gpu.usedMB) / $($st.gpu.totalMB) MB used$cards, group '$($st.gpu.activeGroup)'"
            # Per-card, because the total is the number that misleads: a model has to fit the cards
            # it is split across, and one full card beside one empty one sums to "plenty free".
            if ($st.gpu.count -gt 1) {
                foreach ($c in $st.gpu.gpus) { Row "  gpu $($c.index)" "ok" "$($c.usedMB) / $($c.totalMB) MB used" }
            }
        }
        $running = @($st.services | Where-Object { $_.healthy } | ForEach-Object { $_.name })
        Row "services up" $(if ($running.Count) { "ok" } else { "warn" }) $(if ($running.Count) { $running -join ', ' } else { "none. 'doki-manager start' brings the LLM group up" })
    } else {
        $backendUp = Test-Backend
        Row "backend" $(if ($backendUp) { "ok" } else { "miss" }) "$BaseUrl $(if ($backendUp) { 'answered /v1/models' } else { 'did not answer' })   (direct probe, no control plane)"
        Row "resident model" "--" "unknown without doki.ps1 status json"
    }

    # Config resolution, labelled as such. See Resolve-SeatKey for why there is no live version.
    $swap = Read-SwapModels $SwapCfg
    if ($swap.Count) {
        # WHICH GROUP EACH ROW SITS IN, derived rather than assumed. These two used to print as a
        # bare "seat" and "utility model" one under the other, which reads as a pair. They stopped
        # being one on 2026-08-26: the utility model left the agent-seat group when the seat took a
        # 256k window and an MTP draft head. $SeatModel and $UtilityModel are constants and a
        # constant cannot notice that, so the membership is read from the same file llama-swap loads.
        # Without this line the screen implies two resident tiers on a card that holds one.
        $groups    = Read-SwapGroups $SwapCfg
        $seatGroup = @($groups.Keys | Where-Object { $groups[$_] -contains $SeatModel }) | Select-Object -First 1
        foreach ($pair in @(@($SeatModel, "seat"), @($UtilityModel, "utility model"))) {
            $name = $pair[0]; $label = $pair[1]
            $key = Resolve-SeatKey $swap $name
            if (-not $key) { Row $label "miss" "'$name' is not a model key in serving\llama-swap.yaml"; continue }
            $files = @($swap[$key].files)
            $missing = @($files | Where-Object { -not (Test-Path -LiteralPath $_) })
            if ($missing.Count) {
                Row $label "miss" "$key, weights MISSING: $(($missing | ForEach-Object { Split-Path $_ -Leaf }) -join ', ')"
            } else {
                $sz = ($files | ForEach-Object { (Get-Item -LiteralPath $_).Length } | Measure-Object -Sum).Sum
                $seated = if ($seatGroup -and $groups[$seatGroup] -contains $name) {
                    "in group '$seatGroup'"
                } elseif ($seatGroup) {
                    "NOT in group '$seatGroup', so loading it evicts the seat"
                } else { "no group resolved" }
                Row $label "ok" "$key, $(Format-GB $sz) on disk, $seated (config, not a live load)"
            }
        }
        if ($seatGroup) {
            $vramMembers = @($groups[$seatGroup] | Where-Object { -not (Test-BilledRow $_) })
            Info "  group '$seatGroup' is exclusive: $($vramMembers.Count) VRAM-using member(s), $(@($groups[$seatGroup]).Count) total"
        }
    } else {
        Row "seat" "warn" "serving\llama-swap.yaml not in this tree, so the seat cannot be resolved"
    }

    $shim = Get-ShimState
    $resolved = @($shim.Resolved.Keys | Where-Object { $shim.Resolved[$_] } | Sort-Object)
    Row "shims on PATH" $(if ($resolved.Count -eq 2) { "ok" } elseif ($resolved.Count) { "warn" } else { "miss" }) `
        $(if ($resolved.Count) { "$($resolved -join ', ') resolve in this shell" } else { "neither doki-claude nor doki-copilot resolves here" })
    Row "shims in User PATH" $(if ($shim.OnUserPath) { "ok" } else { "miss" }) `
        $(if ($shim.OnUserPath) { $shim.Dir } else { "$($shim.Dir) is not in HKCU\Environment Path. Fix: doki-manager install" })

    # doki.ps1 drops this file so `down` and `restart` can warn before they unload the models under a live
    # turn. Worth surfacing here too, because `stop` has the same blast radius.
    $lease = Join-Path $root ".run\claude-code.lease"
    if (Test-Path -LiteralPath $lease) {
        $leasePid = (Get-Content -LiteralPath $lease -TotalCount 1 -ErrorAction SilentlyContinue) -as [int]
        if ($leasePid -and (Get-Process -Id $leasePid -ErrorAction SilentlyContinue)) {
            Row "claude lease" "warn" "pid $leasePid is holding the local models. 'stop' will break its turn"
        } else { Row "claude lease" "ok" "no live session (stale lease file, doki.ps1 clears it)" }
    } else { Row "claude lease" "ok" "no session holding the models" }

    Write-Host ""
    if (-not $backendUp) { Info "backend is down. Bring it up with:  doki-manager start" }
    Write-Host ""
    $script:code = 0
}

function Verb-Doctor {
    Title "DokiDex manager doctor"
    Info "each red row carries the command that fixes it."
    Write-Host ""

    function Check($label, $ok, $good, $fix) {
        if ($ok) { Row $label "ok" $good } else { Row $label "miss" $fix; $script:bad++ }
    }
    $script:bad = 0

    Check "pwsh 7+" ($PSVersionTable.PSVersion.Major -ge 7) `
        "PowerShell $($PSVersionTable.PSVersion)" `
        "every shim runs 'pwsh -File'. Fix: winget install Microsoft.PowerShell"

    Check "claude CLI" ([bool](Get-Command claude -ErrorAction SilentlyContinue)) `
        "$((Get-Command claude -ErrorAction SilentlyContinue).Source)" `
        "not on PATH. Fix: npm install -g @anthropic-ai/claude-code"

    Check "copilot CLI" ([bool](Get-Command copilot -ErrorAction SilentlyContinue)) `
        "$((Get-Command copilot -ErrorAction SilentlyContinue).Source)" `
        "not on PATH. Fix: winget install GitHub.Copilot"

    Check "installer" (Test-Path -LiteralPath $Installer -PathType Leaf) `
        "$Installer" `
        "install-clients.ps1 is missing from $PSScriptRoot. Fix: re-extract the bundle or use a checkout"

    $shim = Get-ShimState
    Check "shim files" ($shim.FilesExist.Count -eq 3) `
        "all three present in $($shim.Dir)" `
        "$($shim.FilesExist.Count) of 3 present. Fix: doki-manager install"
    Check "shims in User PATH" $shim.OnUserPath `
        "$($shim.Dir)" `
        "$($shim.Dir) is not in HKCU\Environment Path. Fix: doki-manager install"
    $resolvedNow = @($shim.Resolved.Keys | Where-Object { $shim.Resolved[$_] })
    if ($shim.OnUserPath -and $resolvedNow.Count -lt 2) {
        Row "this shell's PATH" "warn" "installed, but this terminal inherited the old block. Open a new one from the Start menu"
    }

    Check "control plane" (Test-Path -LiteralPath $DokiPs1 -PathType Leaf) `
        "doki.ps1 in $root" `
        "no doki.ps1 in $root (root from $($script:RootSource)). start/stop/models/download are unavailable. Fix: run from a checkout or set DOKI_DATA_ROOT"

    Check "installer for weights" (Test-Path -LiteralPath $SetupPs1 -PathType Leaf) `
        "setup.ps1 in $root" `
        "no setup.ps1 in $root. 'download' is unavailable. Fix: run from a checkout"

    Check "llama-swap config" (Test-Path -LiteralPath $SwapCfg -PathType Leaf) `
        "serving\llama-swap.yaml" `
        "missing, so the seat cannot be resolved. Fix: run from a checkout"

    $swap = Read-SwapModels $SwapCfg
    $seatKey = if ($swap.Count) { Resolve-SeatKey $swap $SeatModel } else { $null }
    Check "seat resolves" ([bool]$seatKey) `
        "$seatKey (from serving\llama-swap.yaml)" `
        "'$SeatModel' is not a model key in serving\llama-swap.yaml. If that name looks like an old short id, this tree predates the 2026-08-25 rename, which replaced every id with the model's real name. Fix: copy the key you want out of that file's models: block, verbatim and quoted"

    if ($seatKey) {
        $seatMissing = @($swap[$seatKey].files | Where-Object { -not (Test-Path -LiteralPath $_) })
        Check "seat weights" ($seatMissing.Count -eq 0) `
            "on disk in $ModelsDir" `
            "missing: $(($seatMissing | ForEach-Object { Split-Path $_ -Leaf }) -join ', '). Fix: 'doki-manager models' names the setup switch, then doki-manager download <switch>"
    }

    $utilityModelPath = Join-Path $ModelsDir $UtilityModelFile
    Check "utility model weights" (Test-Path -LiteralPath $utilityModelPath) `
        "$UtilityModelFile on disk" `
        "$UtilityModelFile missing. No switch fetches it: setup.ps1 pulls it in the core path, unconditionally, since 2026-09-02. Fix: run .\setup.ps1 from this checkout"

    Check "backend" (Test-Backend) `
        "$BaseUrl answered /v1/models" `
        "$BaseUrl has no inference server. Fix: doki-manager start"

    $script:CoresidencyMargin = 2048   # chosen margin, not a measured floor. See the note below.

    # --- co-residency headroom -------------------------------------------------------------------
    # This row REFUSES to go green without evidence, and that is the whole point of it.
    #
    # serving\llama-swap.yaml declares an `agent-seat` group with swap:false, which keeps the seat
    # and the utility model loaded together. Whether they FIT is arithmetic that has already been
    # got wrong once. The worked example that got it wrong assumed the seat at -c 131072 and the
    # utility model at -c 65536: 18,094 MiB of seat weights plus ~8,192 MiB of fp16 KV, against a utility model
    # measured at ~6,285 MiB. That is about 32.7 GB on a 32,607 MiB card, before the desktop takes
    # its share, so it never fit. Both rows have since been tuned down and today serve -c 106496 and
    # -c 32768, which is why the numbers above no longer match the yaml. Read them as the arithmetic
    # that has to be redone whenever a window moves, not as the current figures.
    #
    # And it cannot be settled by watching it start. WDDM oversubscribes SILENTLY on this box
    # (docs\scorecards\2026-08-19-sidecar-vram.md), so a model that "loaded and answered" may be
    # paging over PCIe the whole time. The only honest signal is measured free VRAM with both
    # members actually resident, which is why this row reports UNMEASURED rather than ok when they
    # are not both loaded. An unmeasured row is not a passing row.
    # Only the members that actually HOLD VRAM count as co-residents. Read through Read-SwapGroups
    # rather than regexing the whole file: the old pattern matched any quoted list item anywhere in
    # it, and it counted the Copilot shim, which is a group member using ZERO VRAM (it is a
    # PowerShell HTTP listener). Counting it demanded two loaded models where only one can ever be
    # loaded, so this row sat permanently at UNMEASURED and its advice was "doki-manager warm",
    # which was the very thing evicting the seat. A check that cannot go green is this repo's
    # signature defect wearing its other face.
    $groupNames = @()
    try {
        $groups = Read-SwapGroups (Join-Path $script:Root "serving\llama-swap.yaml")
        $seatGroup = @($groups.Keys | Where-Object { $groups[$_] -contains $SeatModel }) | Select-Object -First 1
        if ($seatGroup) { $groupNames = @($groups[$seatGroup] | Where-Object { -not (Test-BilledRow $_) }) }
    } catch { }

    if ($groupNames.Count -lt 2) {
        Row "co-residency" "ok" ("the seat's group holds $($groupNames.Count) VRAM-using member, so nothing " +
            "shares the card and there is no co-residency arithmetic to get wrong")
    } else {
        $resident = @()
        try {
            $running = Invoke-RestMethod "$BaseUrl/running" -TimeoutSec 4
            $resident = @($running.running | ForEach-Object { $_.model })
        } catch { }
        # EVERY CARD, not the first. This used to shell out to nvidia-smi on its own and read only
        # @($lines)[0], which reported half a two-card box's VRAM as the whole picture and no hint a
        # second card existed. doki.ps1 status json already reads every card (bc2960c), so read that
        # shape instead of running a second, narrower probe here.
        $cardRows = Get-GpuFreeRows (Get-DokiStatusJson)
        foreach ($c in $cardRows) { Row "  gpu $($c.index)" "ok" ("{0} MiB free of {1} MiB" -f $c.freeMb, $c.totalMB) }
        # A split model has to fit every card it touches, so the TIGHTEST card, not the sum and not
        # just the first one, is what decides whether this passes.
        $freeMb = if ($cardRows.Count) { ($cardRows | ForEach-Object { $_.freeMb } | Measure-Object -Minimum).Minimum } else { $null }

        $both = @($groupNames | Where-Object { $resident -contains $_ })
        if ($both.Count -lt 2 -or $null -eq $freeMb) {
            Row "co-residency" "warn" ("UNMEASURED. " + $both.Count + " of " + $groupNames.Count +
                " group members resident. Load both and re-run: doki-manager warm, then doki-manager doctor")
        } elseif ($freeMb -lt 1024) {
            Row "co-residency" "miss" ("only $freeMb MiB free on the tightest card with both resident. WDDM " +
                "oversubscribes silently, so this may already be paging. Fix: lower -c on the utility model or " +
                "the seat in serving\llama-swap.yaml, or drop the group and let haiku share the seat")
            $script:bad++
        } elseif ($freeMb -lt $script:CoresidencyMargin) {
            # HONEST ABOUT WHERE THIS NUMBER COMES FROM: 2 GB is a CHOSEN MARGIN, not a measured
            # floor. Nobody has established what this pair actually needs at full batch, and on this
            # box nobody easily can: nvidia-smi reports per-process VRAM as [N/A] under WDDM, so a
            # paging model and a comfortable one look identical from outside. Checked 2026-08-20 with
            # both resident and no allocation complaints in any log, which is consistent with fine and
            # equally consistent with silently paging.
            #
            # So this warns rather than fails, and says which it is. The margin exists because
            # llama.cpp sizes compute buffers from the batch, so headroom that looks ample idle is
            # what a long prompt eats. Treat it as a prompt to measure, not as a verdict.
            Row "co-residency" "warn" ("$freeMb MiB free on the tightest card with both resident, under the " +
                "$($script:CoresidencyMargin) MiB margin this check uses. That margin is a CHOSEN " +
                "number, not a measured floor, and WDDM reports per-process VRAM as [N/A] so paging " +
                "cannot be ruled out from here. If turns feel slow, drop the utility model to -c 32768 or " +
                "the seat to -c 65536 in serving\llama-swap.yaml and compare tokens/sec")
        } else {
            Row "co-residency" "ok" "$freeMb MiB free on the tightest of $($cardRows.Count) card(s) with both members resident"
        }
    }


    Write-Host ""
    if ($script:bad -eq 0) {
        Ok "no red rows."
        $script:code = 0
    } else {
        Warn "$($script:bad) red row(s) above. Each names its fix."
        # A red row is a real finding. doctor reports it in the exit code rather than exiting 0
        # with the bad news only in the text. A caller that scripts this needs the signal.
        $script:code = 1
    }
    if (Test-Path -LiteralPath $DokiPs1 -PathType Leaf) {
        Info "deeper environment check (GPU, toolchain, model files):  .\doki.ps1 doctor"
    }
    Write-Host ""
}

function Verb-Install([bool]$Undo) {
    Title $(if ($Undo) { "Uninstall the DokiDex client shims" } else { "Install the DokiDex client shims" })
    if (-not (Test-Path -LiteralPath $Installer -PathType Leaf)) {
        Refuse "install-clients.ps1 is not beside this script." @(
            "looked for:  $Installer"
            "It ships in the same folder in every bundle. Re-extract the bundle or run from a checkout."
        )
        return
    }
    $sorted = Split-ForwardArgs $Installer $Rest
    if ($sorted.Unknown.Count) {
        Refuse "install-clients.ps1 does not take: $($sorted.Unknown -join ', ')" @(
            "It declares: $($sorted.Declared -join ', ')"
        )
        return
    }
    $named = $sorted.Named
    $named['BaseUrl'] = $BaseUrl   # ours wins here. The preflight then probes the server we were told about
    if ($Undo) { $named['Uninstall'] = $true } else { $named.Remove('Uninstall') | Out-Null }

    Invoke-Delegate $Installer (ArgvFromNamed $named)
    $rc = $script:DelegateExit
    Write-Host ""
    if ($rc -eq 0) {
        # "exited 0" and "worked" are not the same claim. Saying the second one from the first
        # would be this repo's signature defect wearing a friendly face. install-clients.ps1 runs a
        # per-shim end-to-end check, prints the result in its Verifying block, and then falls off
        # its own end with no exit statement. A failed run check still leaves the process at 0.
        # Measured 2026-08-19 on this box: it reported "2 of 2 shims failed the run check above" and
        # exited 0. So report the code and send the reader to the block that carries the verdict.
        Ok "install-clients.ps1 exited 0."
        Info "that is the process exit code on its own. Its Verifying block above is what says whether"
        Info "each shim actually reached its launcher. That block exits 0 either way. Read it."
        if (-not $Undo) { Info "next:  doki-manager status   then   doki-claude" }
        $script:code = 0
    } else {
        Warn "install-clients.ps1 exited $rc. Its own output above says why."
        Info "On a launcher-only extract this is usually the PATH merge against the registry."
        Info "The three shims are already written. Add that folder to your User PATH by hand."
        $script:code = 1
    }
    Write-Host ""
}

function Verb-Config($Which) {
    # SERVING CONFIGURATIONS, delegated. scripts\doki-preset.ps1 owns the presets, their measured
    # costs and the rewrite; this is the front door people already know to type. Duplicating any of
    # it here would be a second copy that drifts from the first, which is how the model names got out
    # of step in the first place.
    #
    # The choice it exposes is real and cannot be had both ways: MTP speculative decoding and the
    # co-resident utility model each cost about 3.3 GB, and the seat plus both misses this card. So
    # it is faster decoding, or a local haiku tier. Not both.
    #
    # HOW MUCH FASTER, measured on the weights that actually ship. The pair is
    # seat-ship-131k-mtp and seat-ship-131k-nospec in telemetry\bench\runs.jsonl, both 2026-09-03,
    # same corpus, same 131k depth, MTP the only variable:
    #     raw decode           87.3 with, 65.7 without    1.33x
    #     conversation decode  54.7 with, 44.1 without    1.24x
    #     model VRAM        25,396 with, 22,018 without   3,378 MiB
    # Conversation decode is the number a session feels. Read 1.24x as the conservative end: a repeat
    # of the MTP arm at identical flags came back at 63.9, so same-config spread on this row is wide
    # and the no-MTP arm has only the one draw.
    #
    # The "+43%" this comment used to carry is void, and doki-preset.ps1 still prints it in its own
    # Gains line. It came from a 2026-08-26 run against models\Qwen3.8-27B-Q4_K_M.gguf, the stock
    # censored build the seat stopped using on 2026-08-29, at a 7,840-token prefill against a 131k
    # working depth. Same trap as -ub 1024 in the seat's own row: a measurement taken outside a
    # change's regime is no evidence at all.
    $preset = Join-Path $PSScriptRoot "doki-preset.ps1"
    if (-not (Test-Path -LiteralPath $preset)) {
        Refuse "scripts\doki-preset.ps1 is missing." "It owns the serving presets. Reinstall or pull the repo."
        return
    }
    $argv = if ($Which) { @('set', $Which) } else { @('show') }
    Invoke-Delegate $preset $argv
    # Same four-line shape Verb-Download uses below: this verb was skipping it, which is why
    # `doki-manager config` exited 1 on a clean run every time. $script:code is seeded to 1 at the
    # top of the file, and nothing here ever moved it off that seed.
    $rc = $script:DelegateExit
    if ($rc -eq 0) { $script:code = 0 } else { $script:code = 1 }
}

function Verb-Models {
    Title "Models"
    if (-not (Test-ControlPlane $ManifestCfg "the model inventory")) { return }

    $manifest = @()
    try { $manifest = @(Get-Content -LiteralPath $ManifestCfg -Raw | ConvertFrom-Json) }
    catch {
        Refuse "serving\model-manifest.json did not parse: $($_.Exception.Message)" "Fix the file or restore it from git."
        return
    }

    Write-Host ""
    Write-Host "  What the manifest declares (serving\model-manifest.json)" -ForegroundColor Cyan
    Info "sizes here are the manifest's own declared GB, not a measurement of your disk."
    Write-Host ""
    Write-Host ("  {0,-26} {1,-9} {2,-22} {3}" -f "id", "declared", "setup switch", "group") -ForegroundColor DarkGray
    foreach ($m in $manifest) {
        $mark = if ($m.defaultOn) { "*" } else { " " }
        Write-Host ("  {0,-26} {1,9} {2,-22} {3}" -f "$mark$($m.id)", ("{0:N1} GB" -f $m.sizeGB), $m.setupSwitch, $m.group)
    }
    Info "* = defaultOn in the manifest"

    # The manifest carries no file names. It cannot answer "is it on disk". llama-swap.yaml can,
    # because every model block names its weights with -m. That is the bridge between the two, and
    # saying so here is the difference between a report and a guess.
    Write-Host ""
    Write-Host "  What llama-swap wants, and what is on disk (serving\llama-swap.yaml)" -ForegroundColor Cyan
    $swap = Read-SwapModels $SwapCfg
    if (-not $swap.Count) {
        Warn "serving\llama-swap.yaml is not in this tree. There is nothing to resolve against."
    } else {
        # One file often serves several tiers (the 30B coder weights back four keys). Collect
        # every key that names it rather than letting the last one win.
        $wanted = [ordered]@{}
        foreach ($k in $swap.Keys) {
            foreach ($f in $swap[$k].files) {
                if (-not $wanted.Contains($f)) { $wanted[$f] = @() }
                $wanted[$f] += $k
            }
        }
        $present = 0; $missing = 0; $presentBytes = 0
        Write-Host ""
        Write-Host ("       {0,-62} {1,10}  {2}" -f "file", "size", "wanted by") -ForegroundColor DarkGray
        foreach ($f in $wanted.Keys) {
            $leaf = Split-Path $f -Leaf
            $by = ($wanted[$f] -join ', ')
            if (Test-Path -LiteralPath $f) {
                $len = (Get-Item -LiteralPath $f).Length
                $presentBytes += $len; $present++
                Write-Host ("  ok   {0,-62} {1,10}  {2}" -f $leaf, (Format-GB $len), $by) -ForegroundColor Green
            } else {
                $missing++
                Write-Host (" MISS  {0,-62} {1,10}  {2}" -f $leaf, "absent", $by) -ForegroundColor Red
            }
        }
        Write-Host ""
        Info "$present referenced file(s) present, $(Format-GB $presentBytes).  $missing missing."
    }

    Write-Host ""
    Write-Host "  Everything in models\" -ForegroundColor Cyan
    if (-not (Test-Path -LiteralPath $ModelsDir -PathType Container)) {
        Warn "$ModelsDir does not exist yet. Nothing has been downloaded."
    } else {
        $onDisk = @(Get-ChildItem -LiteralPath $ModelsDir -File -ErrorAction SilentlyContinue)
        $total = ($onDisk | Measure-Object Length -Sum).Sum
        Info "$($onDisk.Count) file(s), $(Format-GB $total) total in $ModelsDir"
        $refLeaves = @()
        foreach ($k in $swap.Keys) { $refLeaves += @($swap[$k].files | ForEach-Object { Split-Path $_ -Leaf }) }
        # A shard set is named once. llama-swap points at part 1 of a split GGUF and never at parts
        # 2..N. A literal name match reports every sibling as an orphan. They share the stem
        # before the -NNNNN-of-NNNNN suffix, which is what this groups on. That is a filename rule,
        # not a claim about what the engine does with them.
        $shardRx = '^(?<stem>.+)-\d{5}-of-\d{5}\.gguf$'
        $refStems = @($refLeaves | ForEach-Object { if ($_ -match $shardRx) { $matches['stem'] } })
        $orphans = @($onDisk | Where-Object {
            $n = $_.Name
            if ($refLeaves -contains $n) { return $false }
            if ($n -match $shardRx -and $refStems -contains $matches['stem']) { return $false }
            return $true
        })
        if ($orphans.Count) {
            $orphanBytes = ($orphans | Measure-Object Length -Sum).Sum
            Warn "$($orphans.Count) file(s) here are not named by llama-swap.yaml, holding $(Format-GB $orphanBytes):"
            foreach ($o in $orphans) { Info "  $($o.Name)  $(Format-GB $o.Length)" }
            # NAMED, NOT CITED BY LINE. These three lines used to print doki.ps1:127 and doki.ps1:498.
            # Both had drifted by 2026-09-10 and landed on unrelated code, which is worse than no
            # pointer at all: the reader goes and looks. A file plus a filename cannot go stale that
            # way, and both are greppable in one step.
            Info "Not named is not the same as unused. Other services own some of these. doki.ps1 gates"
            Info "the embed server on nomic-embed-text-v1.5.f16.gguf, and serving\start-fim.ps1 names"
            Info "qwen2.5-coder-3b-q8_0.gguf as the FIM model. Neither goes through llama-swap."
        }
    }

    Write-Host ""
    Info "to fetch something:  doki-manager download <the setup switch from the table above>"
    Info "the utility model ($UtilityModelFile) is the exception, see: doki-manager download"
    Write-Host ""
    $script:code = 0
}

function Verb-Download {
    Title "Download weights"
    if (-not (Test-ControlPlane $SetupPs1 "downloading weights")) { return }

    $sorted = Split-ForwardArgs $SetupPs1 $Rest
    if ($sorted.Unknown.Count) {
        Refuse "setup.ps1 does not take: $($sorted.Unknown -join ', ')" @(
            "It declares: $($sorted.Declared -join ', ')"
            "'doki-manager models' lists the switch that fetches each manifest row."
        )
        return
    }
    $named = $sorted.Named

    if (-not $named.Count) {
        Refuse "download needs to be told WHAT to fetch. It will not guess." @(
            "Weights are tens of GB each. There is no sensible default here."
            "See the switch for each row:   doki-manager models"
            "Common ones:"
            "  doki-manager download -CoderModels     the chat/code weights (manifest: coder-core)"
            "  doki-manager download -Qwen38          the Claude Code seat (manifest id: qwen3-8-27b)"
        )
        # This verb used to carry a long warning here, and the warning is worth keeping as history
        # because it was the sharpest edge in the whole install path. Until 2026-09-02 the utility
        # model was behind TWO gates: setup.ps1 fetched it inside an `if ($Models -eq "full")` block
        # that itself sat past the `if (-not $Media) { ...; return }` early return, so getting a 2 GB
        # file meant asking for a 95 GB media kit you did not want. It was filed that way only because
        # the same GGUF also served the media prompt-rewriter.
        Info "$UtilityModelFile is fetched unconditionally by setup.ps1 now, in the core path,"
        Info "beside the embed model. No switch, no gate. It backs the co-resident utility row that"
        Info "Claude Code's haiku slot and the /doki-cheap skill both land on, so a stack without it"
        Info "is a stack with a tier that fails on an unknown model."
        Write-Host ""
        return
    }

    Warn "download delegates to setup.ps1, which is the INSTALLER, not a fetch-only tool."
    Info "It also checks toolchains and can install packages. Read its output rather than walking away."
    Write-Host ""

    Invoke-Delegate $SetupPs1 (ArgvFromNamed $named)
    $rc = $script:DelegateExit
    Write-Host ""
    if ($rc -eq 0) {
        Ok "setup.ps1 finished cleanly."
        Info "check what landed:  doki-manager models"
        $script:code = 0
    } else {
        Warn "setup.ps1 exited $rc. Its own output above says why."
        $script:code = 1
    }
    Write-Host ""
}

function Verb-Start {
    Title "Start the LLM group"
    if (-not (Test-ControlPlane $DokiPs1 "starting services")) { return }

    $profileName = if ($Arg) { $Arg } else { "agent" }
    if ($profileName -notin @("agent", "coexist")) {
        Refuse "'$profileName' is not an LLM profile." @(
            "agent    llama-swap + embed. The default, and what doki-claude wants."
            "coexist  the same plus the FIM autocomplete server."
        )
        return
    }

    # Say what it is taking BEFORE taking it. Read from the published seam so the numbers come from
    # $Services rather than a copy of them that can drift.
    $st = Get-DokiStatusJson
    if ($st) {
        $wanted = @($st.profiles.$profileName)
        $rows = @($st.services | Where-Object { $wanted -contains $_.name })
        $vram = ($rows | Measure-Object -Property vramGB -Sum).Sum
        Write-Host ""
        Write-Host "  This takes the GPU." -ForegroundColor Yellow
        Info "profile '$profileName' starts: $($wanted -join ', ')"
        Info "declared VRAM for those services: ${vram} GB (doki.ps1's `$Services vramGB)"
        if ($st.gpu -and $null -ne $st.gpu.totalMB) {
            $where = if ($st.gpu.count -gt 1) { "cards right now" } else { "card right now" }
            Info "${where}: $($st.gpu.usedMB) / $($st.gpu.totalMB) MB used, active group '$($st.gpu.activeGroup)'"
            if ($st.gpu.count -gt 1) {
                foreach ($c in $st.gpu.gpus) { Info "  gpu $($c.index): $($c.usedMB) / $($c.totalMB) MB used" }
            }
        }
        # There is only the llm group now, but the sweep in doki.ps1 still stops anything outside the
        # target profile, so report it rather than assume nothing will be taken down.
        $otherUp = @($st.services | Where-Object { $_.group -ne 'llm' -and ($_.healthy -or $_.running) } | ForEach-Object { $_.name })
        if ($otherUp.Count) {
            Warn "these are up and will be STOPPED: $($otherUp -join ', ')"
        }
        $notInstalled = @($rows | Where-Object { -not $_.installed } | ForEach-Object { $_.name })
        if ($notInstalled.Count) { Info "will be skipped, not installed: $($notInstalled -join ', ')" }
    } else {
        Warn "could not read 'doki.ps1 status json'. This starts without a preview of the cost."
    }
    Write-Host ""

    Invoke-Delegate $DokiPs1 @("up", $profileName)
    $rc = $script:DelegateExit
    Write-Host ""
    if ($rc -eq 0) {
        Ok "profile '$profileName' is up."
        if (-not $NoWarm) {
            # The one-command cold start. Deliberately AFTER the success check: warming a profile
            # that failed to start would just be a slow way to print the same error twice.
            Write-Host ""
            if (Wait-Backend $ReadySec) {
                Verb-Warm $null   # $Arg is the profile here, never a tier name
            } else {
                Warn "profile '$profileName' started but $BaseUrl never answered /v1/models in ${ReadySec}s."
                Info "nothing was warmed. Look at the server:  doki-manager doctor"
                Info "then retry the preload on its own:  doki-manager warm"
                $script:code = 1
            }
            return   # Verb-Warm owns $script:code from here. Up with cold weights is not what -Warm asked for.
        }
        # Only reachable via -NoWarm now. Deliberately not claiming the weights are cold: `up` on an
        # already-running stack is a no-op and the tiers may well still be resident. This says what
        # to do rather than asserting a state nothing here measured.
        Info "-NoWarm: the stack is up and nothing was preloaded."
        Info "a server being up is not the same as a tier being loaded, and the first request pays"
        Info "about 13s of page-in on this box. Pay it on purpose instead:  doki-manager warm"
        $script:code = 0
    } else {
        Warn "doki.ps1 up $profileName exited $rc."
        $script:code = 1
    }
    Write-Host ""
}

function Verb-Stop {
    Title "Stop every managed service"
    if (-not (Test-ControlPlane $DokiPs1 "stopping services")) { return }

    Write-Host ""
    Write-Host "  What stopping costs." -ForegroundColor Yellow
    Info "the weights leave VRAM. The next request pages them off disk again, which is the ~13s"
    Info "'doki-manager warm' exists to spend on purpose rather than mid-session."
    $lease = Join-Path $root ".run\claude-code.lease"
    if (Test-Path -LiteralPath $lease) {
        $leasePid = (Get-Content -LiteralPath $lease -TotalCount 1 -ErrorAction SilentlyContinue) -as [int]
        if ($leasePid -and (Get-Process -Id $leasePid -ErrorAction SilentlyContinue)) {
            Warn "a Claude Code session (pid $leasePid) is holding the models. Its current turn will fail mid-tool-call."
        }
    }
    Write-Host ""

    Invoke-Delegate $DokiPs1 @("down")
    $rc = $script:DelegateExit
    Write-Host ""
    if ($rc -eq 0) { Ok "all managed services stopped. The card is free."; $script:code = 0 }
    else { Warn "doki.ps1 down exited $rc."; $script:code = 1 }
    Write-Host ""
}

function Verb-Skills {
    Title "Install the tier skills"
    Info "/doki-max, /doki-think, /doki-work and /doki-cheap pick a TIER for one task."
    Info "The tier is a slot. What answers it is whatever the launcher wired, so re-seating a"
    Info "tier moves every skill with it."
    Write-Host ""

    # Source of truth is the repo, because .claude\ is gitignored here and skills living only in
    # an ignored directory are one clean checkout away from gone.
    $src = Join-Path $script:Root "harness\claude-skills"
    if (-not (Test-Path -LiteralPath $src)) {
        Refuse "no skills to install: $src is missing." @(
            "The standalone bundle does not ship them. Use a full checkout:"
            "  git clone <repo> && .\scripts\doki-manager.ps1 skills"
        )
        return
    }

    $dest = Join-Path $env:USERPROFILE ".claude\skills"
    New-Item -ItemType Directory $dest -Force -ErrorAction SilentlyContinue | Out-Null

    $n = 0; $skipped = 0
    foreach ($d in @(Get-ChildItem -LiteralPath $src -Directory)) {
        $from = Join-Path $d.FullName "SKILL.md"
        if (-not (Test-Path -LiteralPath $from)) { continue }
        $to = Join-Path $dest $d.Name
        New-Item -ItemType Directory $to -Force -ErrorAction SilentlyContinue | Out-Null
        $target = Join-Path $to "SKILL.md"
        # Copies, never links. A link would send an edit in the installed copy straight back into
        # the repo, which is the same failure the per-client config isolation exists to prevent.
        if ((Test-Path -LiteralPath $target) -and
            ((Get-FileHash $target).Hash -eq (Get-FileHash $from).Hash)) {
            $skipped++
        } else {
            Copy-Item -LiteralPath $from -Destination $target -Force
            $n++
        }
        Ok "$($d.Name)  ->  $target"
    }

    Write-Host ""
    if ($n) { Ok "$n skill(s) written, $skipped already current." } else { Ok "all $skipped skill(s) already current. Nothing changed." }
    Info "They are PERSONAL scope (~\.claude\skills), so they work in every project. Under a"
    Info "normal cloud session the same tier names resolve to real Anthropic models, which is"
    Info "the intended behaviour rather than an accident."
    Write-Host ""
    Info "Try:  /doki-work fix the failing test"
    Write-Host ""
    # The tools that grew up around this one. They are separate scripts on purpose, since each is a
    # different job, but this is where somebody managing the stack looks first and they were
    # invisible from here.
    Info "Related tools, each its own script:"
    Info "  scripts\doki-context.ps1          windows and GGUF ceilings, and change one safely"
    Info "  scripts\doki-preset.ps1           what runs beside the seat, and what each choice costs"
    Info "  scripts\doki-bench.ps1            measure a flag change instead of guessing at it"
    Info "  scripts\doki-ctx-experiment.ps1   the 256k ladder, waits for a free card"
    Info "  scripts\doki-telemetry.ps1        record what the stack actually does"
    Info "  scripts\doki-telemetry-report.ps1 render that recording as an HTML dashboard"
    # doki-release.ps1 used to be listed here. It went with the Electron installer on 2026-09-02
    # (archive.md), and doki-telemetry.ps1 has never had a -report flag: its verbs are collect,
    # start, stop and status, and the dashboard is the separate script above. Both corrected
    # 2026-09-10. What ships now is the bootstrapper bundle, so that is what this points at instead.
    Info "  scripts\package-bootstrappers.ps1 build the standalone launcher zip for a box with no checkout"
    $script:code = 0
}


function Verb-Warm($tier) {
    Title "Warm the local tiers"
    Info "this is the work that used to sit in front of every doki-claude and doki-copilot launch."

    if (-not (Test-Backend)) {
        Refuse "no inference server on $BaseUrl." @(
            "Nothing to warm until it is up. Start it with:"
            "  doki-manager start"
            "Or point somewhere else:  doki-manager warm -BaseUrl http://host:port"
        )
        return
    }
    Ok "backend answered /v1/models"

    # An explicitly named tier is warmed and its failure is a failure. $tier is the positional Arg on
    # a bare `warm`, and $null when Verb-Start chains this on (where Arg holds the profile name, not a
    # tier).
    #
    # THE DEFAULT SET IS DERIVED, NEVER HARDCODED, and that is a correctness rule rather than a
    # style one. It is the seat plus every other member of the seat's own group, minus billed rows
    # and minus anything whose weights are not on disk. That group is `exclusive: true`, so naming a
    # model outside it unloads the seat: a stale list here does not warm the wrong thing, it evicts
    # the thing it just warmed and still prints success. That is precisely what this verb did from
    # 2026-08-26 to 2026-09-02. See Read-SwapGroups for the telemetry.
    # If the config cannot be read at all, the seat alone is the honest fallback.
    $tiers = @()
    if ($tier) {
        $tiers += $tier
    } else {
        $tiers += $SeatModel
        $groups     = Read-SwapGroups $SwapCfg
        $swapModels = Read-SwapModels $SwapCfg
        $seatGroup  = @($groups.Keys | Where-Object { $groups[$_] -contains $SeatModel }) | Select-Object -First 1
        if ($seatGroup) {
            foreach ($m in $groups[$seatGroup]) {
                if ($m -eq $SeatModel) { continue }
                # Warming a billed row would spend a premium request to page in nothing at all.
                if (Test-BilledRow $m) { continue }
                $key = Resolve-SeatKey $swapModels $m
                $missing = if ($key) { @($swapModels[$key].files | Where-Object { -not (Test-Path -LiteralPath $_) }) } else { @() }
                if ($missing.Count) {
                    Warn "skipping $m, its weights are not on disk ($(($missing | ForEach-Object { Split-Path $_ -Leaf }) -join ', '))."
                    Info "fetch it with:  doki-manager models"
                    continue
                }
                $tiers += $m
            }
        }
    }

    Write-Host ""
    Info "warming: $($tiers -join ', ')   (first load pages the weights off disk, up to ${TimeoutSec}s each)"
    Write-Host ""
    $failed = 0
    foreach ($t in $tiers) { if (-not (Invoke-Warm $t)) { $failed++ } }

    Write-Host ""
    if ($failed -eq 0) {
        Ok "$($tiers.Count) tier(s) warm. doki-claude and doki-copilot will hand over quick now."
        $script:code = 0
    } else {
        Warn "$failed of $($tiers.Count) tier(s) did not answer."
        Info "a 404 here usually means the name is not a llama-swap model key. They carry spaces and"
        Info "brackets since the 2026-08-25 rename, so quote them. Check:  doki-manager status"
        Info "a connection error means the server went away. Check:  doki-manager doctor"
        $script:code = 1
    }
    Write-Host ""
}

# ================================================================================================
# DISPATCH
# ================================================================================================
# Every verb sets $script:code. A verb that forgets leaves the seeded 1, which fails safe. The catch
# below turns a terminating error into the same 1 with the message visible rather than a raw stack.
try {
    switch ($Verb) {
        "help"      { Verb-Help }
        "status"    { Verb-Status }
        "doctor"    { Verb-Doctor }
        "install"   { Verb-Install $false }
        "uninstall" { Verb-Install $true }
        "models"    { Verb-Models }
        "download"  { Verb-Download }
        "start"     { Verb-Start }
        "stop"      { Verb-Stop }
        "warm"      { Verb-Warm $Arg }
        "skills"    { Verb-Skills }
        "config"    { Verb-Config $Arg }
    }
} catch {
    Write-Host ""
    Write-Host "  doki-manager $Verb failed: $($_.Exception.Message)" -ForegroundColor Red
    Write-Host ""
    $script:code = 1
}
exit $script:code
