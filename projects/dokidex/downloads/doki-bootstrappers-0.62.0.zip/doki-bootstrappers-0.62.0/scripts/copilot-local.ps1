﻿<#
.SYNOPSIS
  Launch GitHub Copilot CLI against DokiDex's local models. No cloud, no GitHub account needed.

.DESCRIPTION
  Copilot CLI has had BYOK ("bring your own key") since 1.0.x: set COPILOT_PROVIDER_BASE_URL and it
  routes every request to your provider instead of GitHub's model routing. Its own help says it
  plainly — "GitHub authentication is not required when using a custom provider" — so this works on
  a machine that has never signed in.

  llama-swap serves BOTH API shapes Copilot understands, which is why this needs no translation:
    -ProviderType openai    -> http://127.0.0.1:8080/v1   (OpenAI chat-completions, the default)
    -ProviderType anthropic -> http://127.0.0.1:8080      (the same /v1/messages Claude Code uses)

  Usage:
    .\scripts\copilot-local.ps1                          # interactive, on the default seat
    .\scripts\copilot-local.ps1 -Task "fix the parser"   # one-shot (adds --allow-all-tools)
    .\scripts\copilot-local.ps1 -Model "Qwen3-Coder-30B-A3B [128k] (Coding, Light)"
                                                         # a different model. Quote it: model names
                                                         # carry spaces and brackets.
    .\scripts\copilot-local.ps1 -Offline                 # zero network: no auth, telemetry, or MCP
    .\scripts\copilot-local.ps1 -Warm                    # preload the seat first, then launch
    .\scripts\copilot-local.ps1 --continue               # any LONG copilot flag, forwarded verbatim
    .\scripts\copilot-local.ps1 -Print                   # show the resolved config and exit

  THIS LAUNCHER NO LONGER PRELOADS THE MODEL, AND THAT IS WHAT -Warm IS FOR.
  Same change as claude-local.ps1, same day, same reasoning. Until 2026-08-19 every run probed
  /v1/models and then sent a real chat request to page the weights in before handing over. Measured
  on this box with a STUB cli on PATH, so each number is the launcher's own cost and never the
  client's, median of the runs stated:
    cold seat, preload on   (the old default)   18.43 s   1 run
    hot  seat, preload on   (the old default)    0.90 s   3 runs
    hot  seat, preload off  (the new default)    0.56 s   3 runs
  Caveat on the cold number: those weights had been resident minutes earlier, so Windows still held
  much of the file. A genuine first-boot load off cold disk is longer again.
  The preload is a real capability. Without it the same wait lands inside Copilot's first turn, where
  it reads as a hang. It belongs where you ask for it: doki-manager (its `warm` verb), or -Warm here.

  The backend reachability probe moved with it, measured rather than assumed. A fresh pwsh pays
  78-149 ms for its first Invoke-RestMethod against a LIVE server (2026-08-19, three runs: 141.4,
  80.4, 78.3 ms), and a raw TCP connect is 13.6-20.5 ms there. Neither is single-digit, so neither
  belongs on a path that works. It runs before a -Warm preload and after a non-zero exit. Nowhere else.

  SHORT (single-dash) FLAGS ARE A DOCUMENTED LIMITATION, NOT A BUG WE CAN CATCH.
  PowerShell binds parameters by PREFIX, and it does that before a single line of this script
  runs, so a short copilot flag typed plainly gets bound by the launcher and never reaches
  copilot. Nothing in here can detect it afterwards. Measured 2026-08-19 on PS 7.6.5 against this
  exact param block, in-session:
    copilot-local.ps1 -r abc123   ->  Rest=[abc123]
    copilot-local.ps1 abc123      ->  Rest=[abc123]
  Byte-identical. The eaten flag leaves no trace in $PSBoundParameters or in the parameter
  metadata, and $MyInvocation.Line is empty under `pwsh -File`. A guard used to sit at the top of
  this file trying to spot the mangle from the raw command line. It could not fire on the
  `pwsh -File` route at all, and through doki.ps1 it scanned doki.ps1's own source rather than
  anything you typed, so it was a check that could not fail on the two routes that needed it.
  It's gone. What follows is the honest limitation in its place. Same call as claude-local.ps1,
  same reasoning.

  WHAT EACH SINGLE-DASH LETTER DOES TO THIS PARAM SET. Measured 2026-08-19, `-x VAL` in-session:
    bound by a launcher parameter, so copilot never sees the flag
      -a -> AllowAll   -b -> BaseUrl   -n -> NoWarm   -o -> Offline   -t -> Task
      -d -> Debug      -v -> Verbose   (PowerShell's own common parameters)
      -r -> Rest, and this is the quiet one. The FLAG itself vanishes while its value survives
           as a bare token, so `-r abc123` reaches copilot as `abc123`. Every other collision
           above changes something you can see, except -d and -v, which
#          forward a bare value exactly as -r does. Measured 2026-08-19.
    hard error, ambiguous
      -m  (-Model / -MaxPromptTokens / -MaxOutputTokens)
      -p  (-ProviderType / -Print / -ProgressAction / -PipelineVariable)
      -e  -i  -w  (common parameters)
    forwarded to copilot untouched
      -c  -f  -g  -h  -j  -k  -l  -q  -s  -u  -x  -y  -z
    Of copilot's own short flags that leaves -h safe. -p errors out loudly, which is at least not
    silent, and -v is eaten by -Verbose.

  HOW TO PASS A SHORT FLAG ANYWAY, PER ROUTE. All four measured 2026-08-19:
    & .\scripts\copilot-local.ps1 -- -p "fix the parser"
        Works. Everything after the literal `--` lands in $Rest untouched and is forwarded
        verbatim and in order.
    doki-copilot -- -p "fix the parser"
        Works. The PATH shim hops through scripts\shims\doki-shim.ps1, which re-parses the call
        as source text and so gives `--` its meaning back.
    pwsh -NoProfile -File .\scripts\copilot-local.ps1 ...
        NO short flag can be passed on this route, and the divider does not rescue it either:
        `-File` hands `--` to the parameter binder, which rejects it before the script starts
        with "Parameter cannot be processed because the parameter name '' is ambiguous". Use
        copilot's LONG flag (--prompt, --continue, --resume <id>), or call through doki-copilot,
        or wrap it:  pwsh -NoProfile -Command "& '.\scripts\copilot-local.ps1' -- -p 'fix it'"
    .\doki.ps1 copilot ...
        Short flags collide with doki.ps1's own much larger parameter set first and mostly
        hard-error there, e.g. `-r` is ambiguous against -Refine -Raw -Realism -Reference
        -RefWeight -Rest. Worse, any flag that TAKES A VALUE mis-binds on that route: the token
        after it lands in doki.ps1's own positional -Arg and is sent on as the PROMPT. Value-less
        long flags are clean (`doki copilot --continue` forwards as --continue). That binding
        lives in doki.ps1, not in this file.

  LONG flags are unambiguous in-session and need no divider:
    .\scripts\copilot-local.ps1 --continue --log-level debug
  One measured exception. Under `pwsh -File`, `--verbose` binds to PowerShell's common -Verbose
  parameter and never reaches the client. In-session the same token forwards fine.

  Your global %USERPROFILE%\.copilot config is never written: the per-user surface is redirected to
  %LOCALAPPDATA%\DokiDex\copilot-home for the run. See section 4b for what that shares and what it
  deliberately does not.

  Isolation runs in both directions. Section 4b covers what a local run WRITES. Section 0 covers
  what it INHERITS: GitHub credentials in the environment are cleared before the first child process
  starts, so a BYOK session against your own GPU never carries a PAT. Auto-update is off for the
  session too, so a local run cannot change the shared copilot binary your normal cloud sessions
  use. Both edits are per-process. Nothing here touches your User or Machine environment.
  tests\local-cli-isolation.test.ps1 is the oracle for all of it.
#>
# PositionalBinding=$false is load-bearing, same as in claude-local.ps1: with PowerShell's default
# binding an unrecognised `--flag` binds to the first free POSITIONAL parameter instead of reaching
# $Rest, so `--continue` would silently land in -Task and be sent as a prompt. Measured on PS 7.6.5.
[CmdletBinding(PositionalBinding = $false)]
param(
    # The llama-swap model that answers, named exactly as llama-swap names it. Quote it, because it
    # contains spaces. There are no aliases any more: every id a client can ask for is a model key.
    [string]$Model = "Qwen3.8-27B [256k] (Thinking, Standard)",
    [string]$Task,                       # one-shot prompt (maps to `copilot -p`)
    [string]$BaseUrl = "http://127.0.0.1:8080",
    [ValidateSet("openai", "anthropic")][string]$ProviderType = "openai",
    # STARTING POINTS, not the numbers that reach Copilot. Section 0a below DERIVES both from the
    # [Nk] window in -Model's name, and only falls back to these when the name carries no window.
    # Pass either one and it is honoured, then checked: llama-server's -c covers prompt AND
    # generation out of one budget, so a pair that does not fit is clamped, loudly.
    [int]$MaxPromptTokens = 110000,
    [int]$MaxOutputTokens = 32000,
    # Claim a well-known catalog model id so the agent uses its real tool-support and prompting
    # config instead of safe defaults. The wire model stays -Model. Unmeasured here, see the
    # comment at the COPILOT_MODEL assignment before trusting it.
    [string]$ProviderModelId,
    [switch]$Offline,                    # COPILOT_OFFLINE=true — no GitHub, no telemetry, no MCP
    [switch]$NoTelemetry,                # do not record this run. DOKI_TELEMETRY=0 turns it off for good
    [switch]$AllowAll,                   # --allow-all (tools + paths + urls)
    [switch]$Print,                      # print the resolved config and exit
    # -Warm preloads the tier before handing over. OFF by default since 2026-08-19: see the header
    # for the three timings that moved it. -NoWarm is what the default now does by itself, and it
    # stays an accepted parameter rather than being deleted, because callers already pass it:
    # tests\local-cli-isolation.test.ps1 line 342 and scripts\install-clients.ps1's shim smoke both
    # do, and every -NoWarm in docs\local-cli-setup.md would break. It still means something real
    # too, since it overrides -Warm.
    [switch]$Warm,                       # preload the tier before launching (the old default)
    [switch]$NoWarm,                     # never preload. Now the default; kept because it overrides -Warm
    # Everything else is forwarded to `copilot` verbatim and in order:
    #   --continue · --resume <id> · --allow-all-tools · --yolo · --model <m> · --log-level debug
    [Parameter(ValueFromRemainingArguments = $true)][string[]]$Rest
)

$ErrorActionPreference = "Stop"
$repo = Split-Path $PSScriptRoot -Parent

# Same data-root resolution as claude-local.ps1, and for the same reason: doki.ps1 reads the lease
# from the resolved DATA root, so writing it repo-relative gives a warning that can never fire.
function Resolve-DataRoot($fallback) {
    if ($env:DOKI_DATA_ROOT -and (Test-Path -LiteralPath $env:DOKI_DATA_ROOT -PathType Container)) {
        return $env:DOKI_DATA_ROOT
    }
    $settingsPath = Join-Path $env:LOCALAPPDATA "dokidex\settings.json"
    if (Test-Path -LiteralPath $settingsPath -PathType Leaf) {
        try {
            $candidate = (Get-Content -LiteralPath $settingsPath -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop).dataRoot
            if ($candidate -is [string] -and $candidate.Trim() -and (Test-Path -LiteralPath $candidate -PathType Container)) {
                return $candidate
            }
        } catch { }
    }
    return $fallback
}
$root = Resolve-DataRoot $repo

function Info($m) { Write-Host "  $m" -ForegroundColor DarkGray }

Write-Host ""
Write-Host "Copilot CLI -> DokiDex local models" -ForegroundColor Cyan
Write-Host "------------------------------------"

# --- 0a. the context budget, derived from the model NAME ----------------------------------------
# llama-server's -c is the TOTAL KV budget. Prompt and generation come out of the SAME window, so
# the two caps below are a pair against one number rather than two independent limits. The shipped
# defaults used to be flat (110000 prompt + 32000 output), chosen when the seat ran -c 131072. The
# seat dropped to -c 106496 on 2026-08-20 to make room for the co-resident utility model, and nothing
# followed it here: 142000 against 106496 is 35504 tokens over. Copilot answers an over-budget
# request by silently truncating the prompt, so the symptom is a model that quietly stops seeing the
# top of its own context. Found 2026-08-25 while renaming harness\copilot.md, which had been
# claiming 131072 and was what made 110000 look safe.
#
# DERIVED, NOT PINNED, and that part is the actual fix. A constant here that has to track a flag in
# another file is exactly what rotted. The source of truth is the model's own name: the [Nk] in a
# llama-swap key is an exact encoding of that row's per-request -c. Checked against the landed
# serving\llama-swap.yaml on 2026-08-25, comment-stripped and with -np division applied: 22 of 22
# weighted rows exact, 0 mismatched. tests\llama-swap-descriptions.test.ps1 is the standing oracle
# for that encoding, so it cannot drift without a test going red.
#
# THE ONE ROW WITH A BRACKET AND NO -c is "GitHub Copilot Cloud [32k] (Cloud, Billed)". It is a
# PowerShell HTTP listener rather than a llama-server, so its 32k describes what
# serving\copilot-shim.ps1 will accept, not a KV allocation. Its bracket is therefore ADVISORY: a
# cap derived from it is a courtesy to the shim, and nothing on this box will fail if it is wrong.
function Get-ModelContextWindow([string]$name) {
    # The pattern escapes its brackets, so the ones in the SUBJECT are ordinary characters. Nothing
    # here may hand a model name to -like, or to -match as a PATTERN: both read [ ] as a class.
    if ($name -match '\[(\d+)k\]') { return [int]$Matches[1] * 1024 }
    return $null
}

# CHOSEN NUMBERS, not measured ones, and worth saying which. The 1024-token reserve absorbs the
# template and role scaffolding Copilot adds on top of what it counted for us. The quarter-window
# ceiling on generation stops a small row spending its whole budget on one answer. Neither is a
# floor anybody established, and both live here rather than in three places.
#
# PULLED OUT AS A FUNCTION so this arithmetic can be extracted by AST and tested against real
# numbers without launching Copilot. $BoundNames stands in for $PSBoundParameters.Keys: a function
# gets its OWN bound-parameters set rather than the caller's, so the caller has to hand down which
# of its parameters were explicitly typed.
#
# Found 2026-09-07: an explicit -MaxOutputTokens close to a small row's budget used to drive the
# derived MaxPromptTokens negative while the PAIR'S SUM still read as under the window (the negative
# prompt term and the oversized output term partly cancel), so the overrun re-check below never
# fired and a negative number reached COPILOT_PROVIDER_MAX_PROMPT_TOKENS with no warning at all.
# The re-check now also fires whenever MaxPromptTokens alone is non-positive, whatever the sum says.
function Resolve-CopilotTokenBudget([string]$Model, [int]$MaxPromptTokens, [int]$MaxOutputTokens, [string[]]$BoundNames) {
    $ctxReserve = 1024
    $ctxWindow  = Get-ModelContextWindow $Model
    $clamped = $false

    if ($ctxWindow) {
        $budget = $ctxWindow - $ctxReserve
        # $BoundNames is the only honest way to tell "the caller asked for this" apart from "this is
        # the parameter default". Overriding a number somebody typed would be its own bug.
        if ($BoundNames -notcontains 'MaxOutputTokens') {
            $MaxOutputTokens = [math]::Min($MaxOutputTokens, [int][math]::Floor($ctxWindow / 4))
        }
        if ($BoundNames -notcontains 'MaxPromptTokens') {
            $MaxPromptTokens = $budget - $MaxOutputTokens
        }

        # ALWAYS re-check the final pair, INCLUDING one the caller typed in full. Silent truncation is
        # the entire defect class here, so clamping quietly would be the same mistake in a new hat.
        if ((($MaxPromptTokens + $MaxOutputTokens) -gt $ctxWindow) -or ($MaxPromptTokens -le 0)) {
            $wantPrompt = $MaxPromptTokens
            $wantOutput = $MaxOutputTokens
            if ($MaxOutputTokens -ge $budget) { $MaxOutputTokens = [int][math]::Floor($ctxWindow / 4) }
            $MaxPromptTokens = $budget - $MaxOutputTokens
            $clamped = $true
            if ($wantPrompt -le 0) {
                Write-Host ("  ! negative prompt budget: $wantOutput output alone left $wantPrompt " +
                            "prompt tokens for '$Model', which serves $ctxWindow per request.") `
                           -ForegroundColor Yellow
            } else {
                Write-Host ("  ! context overrun: $wantPrompt prompt + $wantOutput output = " +
                            "$($wantPrompt + $wantOutput) tokens, but '$Model' serves $ctxWindow per request.") `
                           -ForegroundColor Yellow
            }
            Write-Host ("    llama-server's -c covers BOTH, so Copilot would have truncated the prompt with " +
                        "no error anywhere. Clamped to $MaxPromptTokens prompt + $MaxOutputTokens output.") `
                       -ForegroundColor Yellow
        }
    } else {
        Info "context   '$Model' carries no [Nk] window in its name, so the token caps stand as passed"
    }

    [PSCustomObject]@{
        MaxPromptTokens = $MaxPromptTokens
        MaxOutputTokens = $MaxOutputTokens
        Clamped         = $clamped
    }
}

$resolvedBudget  = Resolve-CopilotTokenBudget -Model $Model -MaxPromptTokens $MaxPromptTokens `
    -MaxOutputTokens $MaxOutputTokens -BoundNames @($PSBoundParameters.Keys)
$MaxPromptTokens = $resolvedBudget.MaxPromptTokens
$MaxOutputTokens = $resolvedBudget.MaxOutputTokens

# --- 0. a known starting environment ------------------------------------------------------------
# Section 4b fixed the OUTBOUND direction: nothing this run does reaches the global copilot config.
# It does nothing for the INBOUND one. Every variable in the launching shell is inherited by
# `copilot` and by every child this script spawns. This box carries an ambient
# GITHUB_PERSONAL_ACCESS_TOKEN. Before this section, a local BYOK session inherited it whole.
#
# WHY IT SITS AHEAD OF SECTION 1. Section 1 runs `copilot --version`, which is already a child
# process. A clear placed lower down leaves that first child holding everything. Measured
# 2026-08-19 by dumping that child's own environment (tests\local-cli-isolation.test.ps1).
#
# PER-PROCESS ONLY. That is the whole safety argument. `Remove-Item Env:\NAME` edits this process's
# environment block and nothing else. The call that WOULD write through is the User overload of
# [Environment]::SetEnvironmentVariable. It appears nowhere in this file on purpose. The test
# asserts that by scanning the source, and again by diffing the User and Machine environment blocks
# around a real run.
$neutralised = @()
function Clear-InheritedVar([string]$Name) {
    if (Test-Path -LiteralPath "Env:\$Name") {
        Remove-Item -LiteralPath "Env:\$Name" -ErrorAction SilentlyContinue
        $script:neutralised += $Name
    }
}

# The namespace sweep is enumerated from the live process rather than typed out, because a hardcoded
# list only ever covers the names somebody thought of. It is deliberately narrow: only names that
# are credential-SHAPED get cleared. GH_HOST, GITHUB_ACTIONS, GITHUB_WORKSPACE and whatever else CI
# tooling leaves in that namespace are configuration a user's own commands may still want inside the
# session. None of them is a secret.
$credentialShape = "(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL)"
$liveCreds = @(Get-ChildItem Env: |
    Where-Object { $_.Name -match "^(GITHUB_|GH_)" -and $_.Name -match $credentialShape } |
    ForEach-Object { $_.Name })

# The floor list has two jobs. It guarantees the named three die even if the pattern above is ever
# edited wrong. It also covers the one a GITHUB_*/GH_* sweep structurally CANNOT see.
# COPILOT_GITHUB_TOKEN is a GitHub credential living in the COPILOT_ namespace. Per
# `copilot help environment` it is the HIGHEST-precedence of the three ("COPILOT_GITHUB_TOKEN,
# GH_TOKEN, GITHUB_TOKEN, in order of precedence: an authentication token that takes precedence over
# previously stored credentials"). A namespace sweep alone would have shipped feeling complete.
# COPILOT_PROVIDER_BEARER_TOKEN is here for a second reason on top of being a credential. The same
# help says it outranks COPILOT_PROVIDER_API_KEY. An ambient one would override the value section 4
# sets and break the local session quietly.
# NOT cleared: COPILOT_PROVIDER_HEADERS, which can carry a gateway key. It is sent only to the BYOK
# endpoint. That endpoint is 127.0.0.1 here. It goes nowhere.
$floor = @("GITHUB_PERSONAL_ACCESS_TOKEN", "GITHUB_TOKEN", "GH_TOKEN",
           "COPILOT_GITHUB_TOKEN", "COPILOT_PROVIDER_BEARER_TOKEN")
foreach ($n in @($liveCreds + $floor | Select-Object -Unique)) { Clear-InheritedVar $n }

# Telemetry. This is the tail of the bug commit 17eefde fixed. That commit redirected
# COPILOT_OTEL_FILE_EXPORTER_PATH under the isolated home. It did so in section 4b, which is AFTER
# the `copilot --version` child in section 1. Measured 2026-08-19: that child still inherited the
# ambient path pointing at %USERPROFILE%\.copilot\otel. Clearing it here closes the gap. Section 4b
# then sets the isolated path exactly as before. Note the global file was not observed to actually
# move, which makes this a latent hole rather than a caught leak. OTEL_EXPORTER_OTLP_ENDPOINT goes
# too: per `copilot help environment`, setting it "automatically enables OTel", which would put a
# local session's telemetry on the network.
foreach ($n in @("COPILOT_OTEL_FILE_EXPORTER_PATH", "OTEL_EXPORTER_OTLP_ENDPOINT")) { Clear-InheritedVar $n }

# The parent Claude Code session identity, for the same reason claude-local.ps1 clears it. Found
# 2026-08-19 by a verifier, live and with NOTHING injected: a copilot child launched from inside a
# Claude Code session was carrying CLAUDECODE, CLAUDE_PID, CLAUDE_CODE_SESSION_ID and friends. The
# sibling launcher had been hardened and this one had not, and the isolation test only checked the
# claude side of the matrix, so nothing caught it. Explicit list, not a wildcard, matching the
# reasoning in claude-local.ps1: that namespace also holds config a launcher may set on purpose.
foreach ($n in @(
        "CLAUDECODE", "CLAUDE_PID",
        "CLAUDE_CODE_SESSION_ID", "CLAUDE_CODE_ENTRYPOINT", "CLAUDE_CODE_EXECPATH",
        "CLAUDE_CODE_BRIDGE_SESSION_ID", "CLAUDE_CODE_CHILD_SESSION")) {
    Clear-InheritedVar $n
}


# Names only, never values. This line goes to the terminal. Most of what it lists is a credential.
if ($neutralised.Count) { Info "cleared   inherited: $($neutralised -join ', ')" }

# --- 1. the CLI ---------------------------------------------------------------------------------
# NOTE the section 0 above is the environment-neutralising block and is unrelated to what this note
# is about. A short-flag guard used to live here and read
# $MyInvocation.Line to spot a flag the binder had eaten. It is deleted rather than repaired, for
# the reason written out at length in claude-local.ps1's matching note: the raw line is EMPTY under
# `pwsh -File`, and binding state cannot stand in for it because `-r abc123` and a bare `abc123`
# both arrive as Rest=[abc123] with nothing to tell them apart. The limitation is documented in
# .SYNOPSIS instead, route by route, with the full collision list.
$exe = Get-Command copilot -ErrorAction SilentlyContinue
if (-not $exe) {
    Write-Host "copilot CLI not found on PATH." -ForegroundColor Red
    Write-Host "  Install it, then re-run:  winget install GitHub.Copilot"
    exit 1
}
Info "copilot   $((& copilot --version 2>$null | Select-Object -First 1))"

# --- 2. the backend, and why nothing here touches it ----------------------------------------------
# Same call as claude-local.ps1 makes, for the same measured reason. The probe costs 78-149 ms in a
# fresh pwsh against a live server, which is a toll every good run was paying to improve the wording
# of a bad one. These two functions now run only where they earn it: ahead of a -Warm preload, and
# after the client exits non-zero. Both are paths where the waiting has already happened.
#
# WATCH THIS GO RED before trusting it: point -BaseUrl at a port with nothing on it. The reachability
# test returns $false there, which is what Show-BackendDown keys on.
function Test-BackendReachable([string]$Base) {
    # 3 seconds, not the old 5. This runs where the user is already waiting, so it has to be bounded.
    try { $null = Invoke-RestMethod "$Base/v1/models" -TimeoutSec 3; return $true } catch { return $false }
}
function Show-BackendDown([string]$Base) {
    Write-Host "No inference server on $Base." -ForegroundColor Red
    Write-Host "  Bring the models up with doki-manager, then run this again."
    Write-Host "  In a full checkout that is also:  .\doki.ps1 up agent"
}
Info "backend   $BaseUrl  ($ProviderType wire, not probed: a working run should not wait on a health check)"

# --- 3. the preload, opt-in -----------------------------------------------------------------------
# One model at a time on this GPU, so the first request pays a full weight load. Doing it here says
# so out loud instead of letting it look like a hang inside Copilot's first turn. That is worth
# having and it is not worth doing on every launch, which is the whole split: doki-manager owns the
# routine case, -Warm covers the one-off.
#
# -NoWarm wins over -Warm. It has always meant "do not preload" and it keeps meaning that, so a
# caller passing both gets the safer of the two rather than a surprise.
if ($Warm -and -not $NoWarm) {
    if (-not (Test-BackendReachable $BaseUrl)) { Show-BackendDown $BaseUrl; exit 1 }
    Info "warming $Model (first load pages the weights off disk; this can take a minute) ..."
    try {
        if ($ProviderType -eq "anthropic") {
            $b = @{ model = $Model; max_tokens = 8; messages = @(@{ role = "user"; content = "ok" }) } | ConvertTo-Json -Depth 5
            Invoke-RestMethod "$BaseUrl/v1/messages" -Method Post -ContentType "application/json" `
                -Headers @{ "anthropic-version" = "2023-06-01"; "x-api-key" = "doki-local" } -Body $b -TimeoutSec 900 | Out-Null
        } else {
            $b = @{ model = $Model; max_tokens = 8; messages = @(@{ role = "user"; content = "ok" }) } | ConvertTo-Json -Depth 5
            Invoke-RestMethod "$BaseUrl/v1/chat/completions" -Method Post -ContentType "application/json" -Body $b -TimeoutSec 900 | Out-Null
        }
        Info "ready     $Model answered"
    } catch {
        Write-Host "$Model did not answer on $BaseUrl : $($_.Exception.Message)" -ForegroundColor Red
        Write-Host "  Check the tier exists:  .\doki.ps1 status  /  curl $BaseUrl/v1/models"
        exit 1
    }
}

# --- 4. the environment -------------------------------------------------------------------------
# Setting COPILOT_PROVIDER_BASE_URL is what activates BYOK. Everything else refines it.
$env:COPILOT_PROVIDER_BASE_URL = if ($ProviderType -eq "anthropic") { $BaseUrl } else { "$BaseUrl/v1" }
$env:COPILOT_PROVIDER_TYPE     = $ProviderType
# COPILOT_MODEL sets the model id AND the wire model together, which is the simple case and what
# this launcher has always done. It has a cost that is easy to miss: a local name such as
# "Qwen3.8-27B [256k] (Thinking, Standard)" is not in Copilot's built-in catalog, and
# `copilot help providers` is explicit about what that means.
# "Matching a well-known model ID lets the agent use model-specific configuration such as tool
# support, token limits, and prompting strategies. Without a recognized model ID, the agent falls
# back to safe defaults." So every local run today gets the safe-default agent, not the good one.
#
# -ProviderModelId splits the two: the wire keeps carrying our llama-swap key, while the ID claims
# a catalog model. MEASURED 2026-08-20 by capturing the full request body both ways against a mock,
# so this is no longer guesswork:
#
#   SAME either way: the model on the wire (still the local model name), the tool array (24 tools,
#   identical), max_tokens, temperature, tool_choice, parallel_tool_calls. So of GitHub's three
#   claims, "tool support" and "token limits" do not fire in this configuration.
#
#   DIFFERENT: the system prompt, 918 characters longer, 17 lines added. Claiming claude-sonnet-4
#   adds a <tool_preferences> block (use the built-in grep/glob/view rather than Select-String,
#   Get-ChildItem and Get-Content) and an <exploration_and_reading_files> block (files truncate at
#   20KB, use view_range, issue independent reads in one response). That guidance is real and the
#   safe-default prompt has none of it.
#
#   AND THE COST, which is why this stays off. The added <model_information> block tells the model
#   it IS claude-sonnet-4 and instructs it to say so when asked. A local Qwen would then misreport
#   its own identity, which runs against this project's rule that the real model id stays viewable.
#
# So: a real prompting gain, bought with the model lying about what it is. Off by default, and the
# one thing still unmeasured is whether that guidance actually improves OUR models' output, which
# is what evals/run-suite.ps1 is for.
if ($ProviderModelId) {
    $env:COPILOT_PROVIDER_MODEL_ID   = $ProviderModelId
    $env:COPILOT_PROVIDER_WIRE_MODEL = $Model
    $env:COPILOT_MODEL               = $Model
} else {
    $env:COPILOT_MODEL             = $Model
}

# llama-swap needs no credential, but some Copilot paths expect *a* value rather than none.
$env:COPILOT_PROVIDER_API_KEY  = "doki-local"

# Copilot sizes its context from a built-in catalog keyed on well-known model IDs. Ours is not in
# that catalog, so without these it falls back to conservative defaults and can either waste the
# row's window or overrun it. Both numbers were settled in section 0a: derived from the [Nk] in
# -Model's name, or clamped there with a warning when what the caller passed did not fit. They are a
# PAIR against ONE budget, because llama-server's -c covers prompt and generation together. So don't
# reintroduce a constant here, and don't compare either number to a -c on its own.
$env:COPILOT_PROVIDER_MAX_PROMPT_TOKENS = "$MaxPromptTokens"
$env:COPILOT_PROVIDER_MAX_OUTPUT_TOKENS = "$MaxOutputTokens"

# Auto-update is the one piece of Copilot's network behaviour that reaches OUTSIDE this session's
# isolated home. That is the reason this line exists. `copilot help environment` documents
# COPILOT_AUTO_UPDATE as "set to 'false' to disable downloading updated CLI versions automatically",
# on by default outside CI. The CLI itself is a single shared install (measured 2026-08-19 on this
# box: `copilot` resolves to
# %LOCALAPPDATA%\Microsoft\WinGet\Packages\GitHub.Copilot_Microsoft.Winget.Source_8wekyb3d8bbwe\copilot.exe),
# which is the same binary the user's normal cloud-backed sessions run. COPILOT_HOME does not cover
# it, exactly as it did not cover the telemetry path. A local run should not be able to change the
# other app's client underneath it. This is per-process only. Other terminals keep updating
# normally. Where an update actually writes was not measured here. Treat this as closing a
# plausible path rather than as a caught incident.
$env:COPILOT_AUTO_UPDATE = "false"

# WHY COPILOT_OFFLINE STAYS OPT-IN.
# Offline is a bundle of five things. `copilot help environment`: "When active, the CLI skips all
# network access: GitHub authentication, telemetry, web tools, GitHub MCP server, and auto-update
# are disabled." Taken one at a time against what a local BYOK session actually needs:
#   GitHub auth     - not needed. The same help says authentication "is not required" once
#                     COPILOT_PROVIDER_BASE_URL is set. Section 4b never seeds auth into the
#                     isolated home either. There is nothing to authenticate with.
#   telemetry       - already local. Section 4b pins the exporter to a file under the isolated home.
#                     Section 0 drops any inherited OTLP endpoint.
#   GitHub MCP      - section 0 clears every GitHub credential this process inherited. The server
#                     can only do unauthenticated work now. Little is left to protect.
#   auto-update     - the only one that touches the SHARED install. It has its own dedicated switch,
#                     set unconditionally above. A targeted switch beats a bundle.
#   web tools       - the one real capability in the bundle, and the one with no local substitute on
#                     the Copilot side.
# Defaulting to offline would therefore buy nothing the four lines above do not already buy, while
# silently costing web tools on every `doki copilot` run. That is the opposite of seamless. It stays
# a flag for the case the flag is actually for: a session where zero outbound traffic is the point.
# Reversing this is defensible. It just has to be deliberate. tests\local-cli-isolation.test.ps1
# pins the default so a flip goes red. doki.ps1 and docs\site\local-cli.md both describe -Offline as
# opt-in and would need updating in the same change.
if ($Offline) {
    $env:COPILOT_OFFLINE = "true"
}

# --- 4b. config isolation ------------------------------------------------------------------------
# Same safety fix as claude-local.ps1, for the same reason. Picking a local tier from inside the
# client writes it into the GLOBAL per-user config, and on 2026-08-18 the Claude Code equivalent of
# that left every other terminal's cloud-backed CLI exiting 1 at startup. Redirecting the per-user
# home moves the WRITE target, which is the only thing that actually protects the cloud client.
$copilotHome = Join-Path $env:LOCALAPPDATA "DokiDex\copilot-home"
$firstRun = -not (Test-Path -LiteralPath $copilotHome -PathType Container)
New-Item -ItemType Directory -Path $copilotHome -Force -ErrorAction SilentlyContinue | Out-Null
$env:COPILOT_HOME = $copilotHome

# COPILOT_HOME does NOT capture the telemetry path. Measured 2026-08-19: this box carries an
# ambient COPILOT_OTEL_FILE_EXPORTER_PATH pointing at %USERPROFILE%\.copilot\otel, and it is
# inherited straight through, so an isolated run would still append to the GLOBAL telemetry file.
# That is a hole in the isolation this section exists to provide, so redirect it under the
# isolated home. Only when the caller has not deliberately set one for this process.
# Unconditional on purpose. There is no way to tell an ambient value apart from a deliberate one,
# and defaulting to the global file is the wrong way to be wrong here. Override it after launch if
# you actually want local runs in the global telemetry stream.
$env:COPILOT_OTEL_FILE_EXPORTER_PATH = Join-Path $copilotHome "otel\copilot-otel.jsonl"
New-Item -ItemType Directory (Join-Path $copilotHome "otel") -Force -ErrorAction SilentlyContinue | Out-Null
# Pin the exporter BACKEND as well, not just the path. `copilot help environment` documents two
# things that only bite together. COPILOT_OTEL_EXPORTER_TYPE defaults to "otlp-http". Setting
# COPILOT_OTEL_FILE_EXPORTER_PATH "automatically enables OTel". A path on its own therefore turns
# telemetry ON while leaving the backend at a network default. Setting both is what makes the line
# above the whole story.
$env:COPILOT_OTEL_EXPORTER_TYPE = "file"

# COPILOT_HOME relocates the whole surface, not just the config file: skills, agents, logs, the
# session store and the auth state all hang off it, so an isolated run starts blank unless seeded.
#   shared  - skills\ and agents\ (junctions). Read-mostly, and drift between the two copies would
#             be worse than sharing. Junctions work unelevated on this box, measured.
#   copied  - config.json, settings.json and permissions-config.json, once, on first run. Copies,
#             never links: a link would send the write straight back to the global file, which is
#             the exact failure this section exists to prevent.
#   neither - session-store.db, logs, GitHub auth. Local runs keep their own history and never
#             touch the signed-in account.
# Each item is seeded only when missing, so this is idempotent and never clobbers isolated state.
$globalHome = Join-Path $env:USERPROFILE ".copilot"
if (Test-Path -LiteralPath $globalHome -PathType Container) {
    foreach ($dir in @("skills", "agents")) {
        $src = Join-Path $globalHome $dir
        $dst = Join-Path $copilotHome $dir
        if ((Test-Path -LiteralPath $src) -and -not (Test-Path -LiteralPath $dst)) {
            New-Item -ItemType Junction -Path $dst -Target $src -ErrorAction SilentlyContinue | Out-Null
        }
    }
    foreach ($file in @("config.json", "settings.json", "permissions-config.json")) {
        $src = Join-Path $globalHome $file
        $dst = Join-Path $copilotHome $file
        if ((Test-Path -LiteralPath $src -PathType Leaf) -and -not (Test-Path -LiteralPath $dst)) {
            Copy-Item -LiteralPath $src -Destination $dst -ErrorAction SilentlyContinue
        }
    }
}
if ($firstRun) { Info "seeded    $copilotHome (skills + agents shared, sessions and auth are not)" }

if ($Print) {
    Write-Host ""
    # -Print is the diagnostic path, so the round trip the normal path refuses is welcome here.
    try {
        $cat = Invoke-RestMethod "$BaseUrl/v1/models" -TimeoutSec 4
        $rows = @($cat.data | ForEach-Object { if ($_.name) { "{0,-30} {1}" -f $_.id, $_.name } else { $_.id } })
        if ($rows.Count) {
            Write-Host ""
            Write-Host "models you can pass to /model or --model" -ForegroundColor Cyan
            $rows | Sort-Object | ForEach-Object { Write-Host "  $_" }
        }
    } catch { Write-Host "  (could not read $BaseUrl/v1/models for the model list)" -ForegroundColor DarkGray }
    Write-Host ""
    Write-Host "resolved environment" -ForegroundColor Cyan
    Get-ChildItem Env: | Where-Object { $_.Name -like "COPILOT_*" } | Sort-Object Name |
        ForEach-Object { "  {0,-42} {1}" -f $_.Name, $_.Value } | Write-Host
    Write-Host ""
    exit 0
}

Info ("model     $Model  ($MaxPromptTokens prompt / $MaxOutputTokens output tokens" +
      $(if ($ctxWindow) { " of a $ctxWindow-token window)" } else { ", window unknown)" }))

# WHY THE /model PICKER LOOKS EMPTY, and what to do about it. `copilot help environment` is
# explicit: COPILOT_PROVIDER_BASE_URL makes the CLI use "this provider INSTEAD of GitHub Copilot's
# model routing". BYOK replaces the catalog rather than adding to it, so the picker has exactly one
# entry, whatever COPILOT_MODEL is. There is no way to show ours alongside GitHub's in one session.
#
# But you are not stuck with one model. --model and /model both override COPILOT_MODEL, and the
# value goes straight through as the wire model, so ANY llama-swap model key works. MEASURED
# 2026-08-20 against a request-logging mock: asking for "Qwen3-Coder-30B-A3B [128k] (Coding, Light)"
# put that on the wire and asking for the seat put the seat. The picker cannot browse them, so print
# the list here instead. That turns "I cannot pick a model" into "here is what to type".
# QUOTE THE VALUE. Model names carry spaces and square brackets since the 2026-08-25 rename, so a
# bare --model Qwen3-Coder-30B-A3B [128k] (Coding, Light) will not survive the parse.
# The list itself needs a /v1/models round trip, and this launcher is deliberately thin: it does
# not even probe the backend, because a working run should not wait on a health check. So the
# hint is free on every launch, and the actual list only prints under -Print, which is the
# diagnostic path where a round trip is what you asked for.
Info "models    /model `"<name>`" or --model `"<name>`" takes ANY llama-swap model. The picker cannot list"
Info "          them because BYOK replaces GitHub's catalog. See them: .\doki.ps1 status"
Info "updates   auto-update off for this session, so the shared copilot install is never changed from here"
if ($Offline) { Info "offline   COPILOT_OFFLINE=true — no GitHub, no telemetry, no MCP, no auto-update" }
Write-Host ""

# --- 5. go --------------------------------------------------------------------------------------
$argv = @()
# -p is non-interactive and cannot answer a permission prompt, so it needs tools pre-approved.
# Only add it when the caller has not already passed an equivalent flag of their own.
if ($Task) {
    $argv += @("-p", $Task)
    $hasPerm = @($Rest | Where-Object { $_ -in @("--allow-all-tools", "--allow-all", "--yolo") }).Count -gt 0
    if (-not $hasPerm -and -not $AllowAll) { $argv += "--allow-all-tools" }
}
if ($AllowAll -and $Rest -notcontains "--allow-all") { $argv += "--allow-all" }
# Forwarded verbatim and in order, which is what the `--` divider promises at the top of this file.
# Nothing is filtered out: PowerShell consumes the divider itself, so a `--` that survives into
# $Rest is a second one the caller typed on purpose for copilot.
if ($Rest) { $argv += $Rest }

# --- telemetry, best-effort and opt-out ---------------------------------------------------------
# Same three rules as scripts\claude-local.ps1, and the same reason: this launcher hands over to a
# client that talks to :8080 directly, so it never sees a response and cannot measure throughput.
# scripts\doki-telemetry.ps1 taps llama-swap, which sits in front of every client. What only THIS
# file knows is the session, so that is all it writes.
#   1. Never block. The collector is spawned detached with NO pipe on its output, because a reader
#      on that pipe blocks until the collector exits (the child inherits this process's stdout).
#   2. Never fail the launch. Everything is wrapped, and a telemetry problem is a note at most.
#   3. Always refusable. -NoTelemetry for one run, DOKI_TELEMETRY=0 for good, and it says so out
#      loud when it is on rather than collecting silently.
# One honest difference from the Claude launcher: that one already asks the server what is resident,
# so it can record it. This one deliberately does not probe at all, so resident_at_start is empty
# here rather than guessed.
function Start-DokiTelemetry([string]$Base, [string]$Root) {
    if ($env:DOKI_TELEMETRY -eq "0") { return $false }
    $tool = Join-Path $PSScriptRoot "doki-telemetry.ps1"
    if (-not (Test-Path -LiteralPath $tool)) { return $false }
    # ALREADY-RUNNING FAST PATH, and it is not a micro-optimisation. Measured 2026-08-25: the
    # Start-Process below costs 109 ms, against a launcher whose whole measured handover budget is
    # about 190 ms. Paying that on every run to spawn a process that immediately refuses (the
    # collector is a singleton and declines when one is live) would give back more than half of what
    # making this launcher thin bought in the first place. So read the lock first. A live lock means
    # a collector is already tapping this backend and there is nothing to do.
    #
    # Deliberately a LOOSER check than doki-telemetry.ps1's own Get-LockState, which also proves the
    # pid was not recycled. Being wrong here is cheap in exactly one direction: a false "live" skips
    # a spawn and loses telemetry, and a false "dead" spawns a process that refuses and exits. Both
    # are harmless, and neither is worth another 100 ms on the happy path. The tool stays the
    # authority on its own lock.
    try {
        $lock = Join-Path $Root ".run\doki-telemetry.lock"
        if (Test-Path -LiteralPath $lock -PathType Leaf) {
            $held = Get-Content -LiteralPath $lock -Raw -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
            $heldPid = [int]($held.pid -as [int])
            if ($heldPid -gt 0 -and (Get-Process -Id $heldPid -ErrorAction SilentlyContinue)) { return $true }
        }
    } catch { }   # unreadable lock: fall through and let the tool decide
    try {
        Start-Process -FilePath "pwsh" -WindowStyle Hidden `
            -ArgumentList @("-NoProfile", "-File", $tool, "collect", "-BaseUrl", $Base) | Out-Null
        return $true
    } catch { return $false }
}

function Write-DokiSession($Root, $Fields) {
    if ($env:DOKI_TELEMETRY -eq "0") { return }
    try {
        $dir = Join-Path $Root "telemetry"
        New-Item -ItemType Directory $dir -Force -ErrorAction SilentlyContinue | Out-Null
        [System.IO.File]::AppendAllText((Join-Path $dir "sessions.jsonl"),
            ($Fields | ConvertTo-Json -Depth 5 -Compress) + "`n",
            [System.Text.UTF8Encoding]::new($false))
    } catch { }
}

# The lease doki.ps1 reads before unloading the models on a down or a restart. Same contract as
# claude-local.ps1: best-effort, reaped by doki.ps1 when the pid is gone.
$lease = Join-Path $root ".run\claude-code.lease"
try {
    New-Item -ItemType Directory (Split-Path $lease) -Force -ErrorAction SilentlyContinue | Out-Null
    Set-Content $lease "$PID`ncopilot:$Model`n$(Get-Date -Format o)" -ErrorAction SilentlyContinue
} catch { }

# Seeded to failure: $ErrorActionPreference is Stop, so a terminating error skips the assignment
# below and an unassigned $code would exit 0 — success for a run that never happened.
$telemetryOn = $false
if (-not $NoTelemetry) {
    $telemetryOn = Start-DokiTelemetry $BaseUrl $root
    if ($telemetryOn) { Info "telemetry  recording to $root\telemetry (doki-telemetry report to view, -NoTelemetry to skip)" }
}
$sessionStart = Get-Date

$code = 1
try {
    & copilot @argv
    $code = $LASTEXITCODE
} finally {
    # Delete the lease only when it is still OURS. Same contract as claude-local.ps1
    # (contracts.md: LeaseFile): two concurrent launchers share this one filename, so a bare delete
    # here would remove a second session's lease the moment this one exits, and doki.ps1 would then
    # warn about nothing while that other session is still holding the GPU.
    try {
        $ownedLine = Get-Content -LiteralPath $lease -TotalCount 1 -ErrorAction Stop
        if ($ownedLine -eq "$PID") { Remove-Item -LiteralPath $lease -Force -ErrorAction SilentlyContinue }
    } catch { }
    if ($telemetryOn) {
        $now = Get-Date
        Write-DokiSession $root ([ordered]@{
            ts_start          = $sessionStart.ToString("o")
            ts_end            = $now.ToString("o")
            launcher          = "copilot"
            model             = $Model
            exit_code         = $code
            duration_s        = [math]::Round(($now - $sessionStart).TotalSeconds, 1)
            resident_at_start = @()
            context_tokens    = $MaxPromptTokens
        })
    }
}

# The probe the happy path no longer pays for, spent here instead. Two conditions, and the order
# matters: only a FAILED run asks the question, and only an actually-dead backend gets the message.
# copilot exits non-zero for plenty of ordinary reasons, and answering all of them with "your GPU is
# down" would be a diagnosis that cannot be wrong, which is the same as one that says nothing.
if ($code -ne 0 -and -not (Test-BackendReachable $BaseUrl)) {
    Write-Host ""
    Show-BackendDown $BaseUrl
}
exit $code
