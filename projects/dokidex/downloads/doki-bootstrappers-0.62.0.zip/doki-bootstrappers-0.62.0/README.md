# DokiDex bootstrappers 0.62.0

Run Anthropic's real Claude Code CLI and GitHub's real Copilot CLI against your own DokiDex box, on
local weights, with nothing going to a cloud API. This archive is just the launchers and their
installer. No model weights, no DokiDex app, no repo checkout. That is what keeps it small.

You point it at a DokiDex backend you are already running. If you don't have one of those yet, this
archive is not the place to start.

## What you get

Three commands, on your PATH, in any terminal:

- `doki-claude` runs Claude Code against your local seat
- `doki-copilot` runs GitHub Copilot CLI against the same
- `doki-manager` handles the slower, occasional stuff: installing, downloading models, starting
  them, and preloading the seat

Your ordinary cloud `claude` and `copilot` keep working, untouched. That's the reason the names are
prefixed rather than shadowing the real ones.

## What's in this archive

- `scripts\claude-local.ps1` is the Claude Code launcher
- `scripts\copilot-local.ps1` is the Copilot launcher
- `scripts\doki-manager.ps1` is the manager behind `doki-manager`
- `scripts\install-clients.ps1` puts the three commands on your User PATH
- `README.md` is this file

The shims themselves (`doki-claude.cmd`, `doki-copilot.cmd` and the `doki-shim.ps1` bridge) aren't
in the archive on purpose. `install-clients.ps1` writes them into `scripts\shims\` when you run it.
That's also why its `-Uninstall` can clean up completely: it only deletes files it wrote.

## Before you start

Three things have to be true:

- **Windows with PowerShell 7.** Type `pwsh -v`. If that's not found, install it with
  `winget install Microsoft.PowerShell`. Windows PowerShell 5.1 is not enough.
- **A DokiDex backend already running and answering on `http://127.0.0.1:8080`.** In a DokiDex
  checkout that's `.\doki.ps1 up agent`. The launchers check this and tell you if it's down.
- **At least one of the two real CLIs installed.** Claude Code comes from
  `npm install -g @anthropic-ai/claude-code`. Copilot comes from `winget install GitHub.Copilot`.
  The installer warns about a missing one and fails only if both are absent.

Node isn't on that list, and until 2026-09-02 it was. The PATH merge used to be borrowed from the
Electron shell over a `node` subprocess, so this archive couldn't do it and told you to add a
directory by hand. That shell is gone and the merge is native PowerShell now, so the installer
edits your PATH itself. The PATH section below describes what it does and why it is careful.

Copilot works here without signing in to GitHub. The launcher puts it in bring-your-own-key mode
against your local server. A custom provider skips the GitHub sign-in.

## Install

Unzip it wherever you like, then from the unzipped folder:

```
pwsh -NoProfile -File scripts\install-clients.ps1
```

Open a **new** terminal afterwards. The one you ran it in already has its old PATH.

To undo everything, including the PATH entry:

```
pwsh -NoProfile -File scripts\install-clients.ps1 -Uninstall
```

Both directions are safe to run twice. A second run reports what was already right and writes
nothing.

## What the installer does to your PATH

It adds one directory, `scripts\shims`, to your **User** PATH. Not the machine PATH, so it needs
no admin rights.

That edit is more careful than it looks, and the care is the reason it is worth describing.
Reading your PATH the obvious way expands it, and writing it back that way rewrites the value as
a plain string. A PATH holding `%USERPROFILE%\.dotnet\tools` then becomes a frozen literal
pointing wherever that expanded to at write time. Nothing errors. It surfaces months later as a
tool that stopped resolving. The installer reads raw and writes back the original value kind, so
your expandable entries stay expandable.

It then broadcasts the change, which means a terminal opened from the Start menu or the taskbar
picks it up with no sign-out. A shell that was already open keeps the old PATH, because a process
inherits its environment rather than re-reading the registry. So: open a **new** terminal.

Re-running the installer is safe. It reports the entry as already present and writes nothing.

## Using it


```
doki-claude                          interactive, on the default local seat
doki-claude -Task "fix the parser"   one-shot
doki-claude -Print                   show the resolved config and exit
doki-copilot                         the same, for Copilot
```

Long flags pass straight through as you'd type them. `--continue`, `--resume <id>` and
`--dangerously-skip-permissions` all work.

**Short single-dash flags need a `--` divider first.** They collide with the launcher's own
parameter names otherwise. PowerShell binds them before the CLI ever sees them:

```
doki-claude -- -r <session-id>
```

## Where your config goes

The launchers point Claude Code and Copilot at `%LOCALAPPDATA%\DokiDex\claude-home` and
`%LOCALAPPDATA%\DokiDex\copilot-home`. Both get seeded on first use. Your global config is never
written to.

That isolation isn't decoration. Claude Code's `/model` picker writes your choice to the global
`~/.claude\settings.json`. A local-only model name saved there makes plain `claude` fail at
startup in every other terminal you own. Keeping a separate config home is what stops that.

## Honest limits

Things that are true and worth knowing before you're surprised by them.

- **Ctrl+C through the shims is untested.** `cmd.exe` traditionally asks "Terminate batch job
  (Y/N)?" when a batch file catches Ctrl+C. Ctrl+C is also how you interrupt Claude Code. Nobody has
  sat at a terminal and confirmed which way it goes. If it bites you, skip the shim and run the
  launcher directly: `pwsh -NoProfile -File scripts\claude-local.ps1`.
- **One model on the card at a time.** 32 GB holds one seat. Asking the backend for a different
  model evicts the one that is loaded and pays a multi-gigabyte reload, so naming a second model
  mid-session is slower than it looks. `doki-manager status` says what is resident.
- **The backend has to be up first.** These are launchers, not a server. `doki-manager start` can
  bring one up for you, but only on the DokiDex box itself: it needs the checkout, and this archive
  is not one.
- **Sizing is unmeasured except on one card.** All of this was built and measured on a single 32 GB
  card. Nothing in this archive is a claim that any smaller card fits. We haven't tested one.

## Version

This bundle is `0.62.0`. Check it against the SHA-256 published with the download before you
run anything out of it.